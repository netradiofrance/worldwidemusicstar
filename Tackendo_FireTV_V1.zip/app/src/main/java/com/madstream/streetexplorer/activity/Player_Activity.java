package com.madstream.streetexplorer.activity;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ProgressBar;

import com.madstream.streetexplorer.webapp.WholeHealthTV.R;
import com.google.android.exoplayer2.C;
import com.google.android.exoplayer2.ExoPlaybackException;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.PlaybackParameters;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.ProgressiveMediaSource;
import com.google.android.exoplayer2.source.TrackGroupArray;
import com.google.android.exoplayer2.source.dash.DashMediaSource;
import com.google.android.exoplayer2.source.hls.HlsMediaSource;
import com.google.android.exoplayer2.source.smoothstreaming.SsMediaSource;
import com.google.android.exoplayer2.trackselection.TrackSelectionArray;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DefaultHttpDataSource;
import com.google.android.exoplayer2.util.Util;

import ai.vfr.monetizationsdk.vastsdk.VastManager;
import ai.vfr.monetizationsdk.videocontroller.SdkMonView;

public class Player_Activity extends Activity {

    private static final String TAG = "Player_Activity";
    public ProgressBar progressBar;
    private SimpleExoPlayer simpleExoPlayer;
    PlayerView playerView;
    String streamUrl;
    private VastManager vastManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player_);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        playerView = findViewById(R.id.sPalyer);
        progressBar = findViewById(R.id.playerProgress);
        streamUrl = getIntent().getStringExtra("video_url");
    }

    @Override
    protected void onResume() {
        super.onResume();
        playVideo();
        vastManagerInitPlay();
    }

    private void vastManagerInitPlay() {
        SdkMonView sdkMonView = (SdkMonView)
                findViewById(R.id.sdkmonview);
        vastManager = VastManager.getInstance(sdkMonView, this);
        vastManager.initPlayCycle();
    }


    String userAgent;
    Uri uri;

    public void playVideo() {
        userAgent = Util.getUserAgent(this, getString(R.string.app_name));
        uri = Uri.parse(streamUrl);

        // Build the appropriate MediaSource
        MediaSource mediaSource;
        DataSource.Factory dataSourceFactory;

        // Parse the URI to try to determine the type.
        // NOTE: inferContentType returns C.TYPE_OTHER if no matching signatures found
        int mediaSourceType = Util.inferContentType(uri);
        switch (mediaSourceType) {
            case C.TYPE_DASH:
                // Create a data source factory.
                dataSourceFactory = new DefaultHttpDataSource.Factory();

                // Create a DASH media source pointing to a DASH manifest uri.
                mediaSource =
                        new DashMediaSource.Factory(dataSourceFactory)
                                .createMediaSource(MediaItem.fromUri(uri));
                // Create a player instance.
                SimpleExoPlayer player = new SimpleExoPlayer.Builder(this).build();
                // Set the media source to be played.
                player.setMediaSource(mediaSource);
                // Prepare the player.
                player.prepare();
                break;

            case C.TYPE_SS:
                // Create a data source factory.
                dataSourceFactory = new DefaultHttpDataSource.Factory();

                // Create a SmoothStreaming media source pointing to a manifest uri.
                mediaSource =
                        new SsMediaSource.Factory(dataSourceFactory)
                                .createMediaSource(MediaItem.fromUri(uri));
                // Create a player instance.
                simpleExoPlayer = new SimpleExoPlayer.Builder(this).build();
                // Set the media source to be played.
                simpleExoPlayer.setMediaSource(mediaSource);
                // Prepare the player.
                simpleExoPlayer.prepare();
                break;

            case C.TYPE_HLS:
                // Create a data source factory.
                dataSourceFactory = new DefaultHttpDataSource.Factory();

                // Create a HLS media source pointing to a playlist uri.
                HlsMediaSource hlsMediaSource =
                        new HlsMediaSource.Factory(dataSourceFactory)
                                .createMediaSource(MediaItem.fromUri(uri));
                // Create a player instance.
                simpleExoPlayer = new SimpleExoPlayer.Builder(this).build();
                // Set the media source to be played.
                simpleExoPlayer.setMediaSource(hlsMediaSource);
                // Prepare the player.
                simpleExoPlayer.prepare();
                break;

            case C.TYPE_OTHER:
            default:
                // Create a data source factory.
                dataSourceFactory = new DefaultHttpDataSource.Factory();

                // Create a progressive media source pointing to a stream uri.
                mediaSource = new ProgressiveMediaSource.Factory(dataSourceFactory)
                        .createMediaSource(MediaItem.fromUri(uri));
                // Create a player instance.
                simpleExoPlayer = new SimpleExoPlayer.Builder(this).build();
                // Set the media source to be played.
                simpleExoPlayer.setMediaSource(mediaSource);
                // Prepare the player.
                simpleExoPlayer.prepare();
        }

        playerView.setPlayer(simpleExoPlayer);
        playerView.setUseController(true);
        playerView.requestFocus();

        simpleExoPlayer.setPlayWhenReady(true);
        simpleExoPlayer.addListener(new Player.Listener() {
            @Override
            public void onIsPlayingChanged(boolean isPlaying) {
                if (isPlaying) {
                    progressBar.setVisibility(View.GONE);
                } else {
                    progressBar.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onPlaybackStateChanged(int playbackState) {
                // Se precisar de lógica para o estado do player, coloque aqui.
            }

            @Override
            public void onPlayerError(com.google.android.exoplayer2.PlaybackException error) {
                progressBar.setVisibility(View.GONE);
            }

            // Você pode remover ou adaptar os métodos antigos não mais presentes na interface.
        });




    }

    @Override
    protected void onPause() {
        super.onPause();
        simpleExoPlayer.stop();
        vastManager.pause();

    }

    @Override
    protected void onStop() {
        super.onStop();
        simpleExoPlayer.stop();

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if (simpleExoPlayer != null) {
            simpleExoPlayer.release();
            finish();
        }

    }


    private void startContinualFastForward() {
        playerView.showController();
        playerView.setUseController(true);
        simpleExoPlayer.setPlayWhenReady(true);
        playerView.setControllerShowTimeoutMs(5000);
    }

    private void startContinualRewind() {
        playerView.showController();
        playerView.setUseController(true);
        simpleExoPlayer.setPlayWhenReady(true);
        playerView.setControllerShowTimeoutMs(5000);
    }


    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case 20:
                if (keyCode == 20) {
                    playerView.showController();
                    playerView.setUseController(true);
                    simpleExoPlayer.setPlayWhenReady(true);
                    playerView.setControllerShowTimeoutMs(5000);
                }
                break;
            case 23:
                if (keyCode == 23) {
                    playerView.showController();
                    playerView.setUseController(true);
                    simpleExoPlayer.setPlayWhenReady(true);
                    playerView.setControllerShowTimeoutMs(5000);
                }
                break;
            case KeyEvent.KEYCODE_MEDIA_REWIND:
                if (event.getAction() == 1) {
                    startContinualRewind();
                }
                break;
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                playerView.showController();
                playerView.setUseController(true);
                simpleExoPlayer.setPlayWhenReady(true);
                playerView.setControllerShowTimeoutMs(5000);
                break;

            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD:

                if (event.getAction() == 1) {
                    startContinualFastForward();
                }
                break;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        switch (event.getKeyCode()) {
            case KeyEvent.KEYCODE_MEDIA_REWIND:
                if (event.getAction() == 1) {
                    startContinualRewind();
                }
                break;
            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD:
                if (event.getAction() == 1) {
                    startContinualFastForward();
                }
                break;
        }
        return super.dispatchKeyEvent(event);
    }
}