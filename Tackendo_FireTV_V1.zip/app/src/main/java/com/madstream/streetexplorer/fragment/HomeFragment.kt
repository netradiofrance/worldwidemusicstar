package com.madstream.streetexplorer.fragment


import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.fragment.app.FragmentTransaction
import androidx.leanback.app.BrowseSupportFragment
import androidx.leanback.widget.*
import com.madstream.streetexplorer.webapp.WholeHealthTV.R
import com.madstream.streetexplorer.activity.HomeActivity
import com.madstream.streetexplorer.activity.Player_Activity
import com.madstream.streetexplorer.model.trial.AllResponse
import com.madstream.streetexplorer.model.trial.Playlists
import com.madstream.streetexplorer.model.trial.TvSpecials
import com.madstream.streetexplorer.utility.Api
import com.madstream.streetexplorer.utility.CardPresenter
import com.madstream.streetexplorer.utility.CustomHeaderRowPresenter
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.bumptech.glide.Glide
import com.google.gson.GsonBuilder
import io.paperdb.Paper
import org.apache.commons.collections4.CollectionUtils
import java.text.DateFormat
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList
import kotlin.collections.set


class HomeFragment : BrowseSupportFragment() {
    private var mCategoryRowAdapter: ArrayObjectAdapter? = null

    private var cardRowAdapter: ArrayObjectAdapter? = null
    var catArrayHeader: ArrayList<String>? = ArrayList()
    private val cardPresenter = CardPresenter()
    val customHeaderRowPresenter = CustomHeaderRowPresenter()
    lateinit var cardPresenterHeader: HeaderItem
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupUIElements()
        customHeaderRowPresenter.setNullItemVisibilityGone(true)
        val listRowPresenter = ListRowPresenter(FocusHighlight.ZOOM_FACTOR_NONE, false)
        listRowPresenter.headerPresenter = customHeaderRowPresenter
        listRowPresenter.selectEffectEnabled = false
        mCategoryRowAdapter = ArrayObjectAdapter(listRowPresenter)
    }

    private fun setupUIElements() {
        headersState = HEADERS_DISABLED
        isHeadersTransitionOnBackEnabled = true
//        loadData()
        setUpEvents()
        loadDataTrial()
    }

    var index = 0;

    private fun loadDataTrial() {
        val request = StringRequest(Request.Method.GET, Api.api, fun(response: String) {
            val gsonBuilder = GsonBuilder()
            gsonBuilder.setDateFormat("M/d/yy hh:mm a")
            val gson = gsonBuilder.create()
            val allResponse = gson.fromJson(response, AllResponse::class.java)
            var linkedHashMapList: MutableList<LinkedHashMap<String, List<TvSpecials>>> =
                java.util.ArrayList<LinkedHashMap<String, List<TvSpecials>>>()
            for (category in allResponse.categories) {
                val stringListLinkedHashMap: LinkedHashMap<String, List<TvSpecials>> =
                    LinkedHashMap<String, List<TvSpecials>>()
                var playlistSelected: Playlists?
                for (playlist in allResponse.playlists) {
                    if (playlist.name == category.playlistName) {
                        playlistSelected = playlist
                        val tvSpecialList: MutableList<TvSpecials> =
                            java.util.ArrayList<TvSpecials>()
                        for (itemId in playlistSelected.itemIds) {
                            for (tvSpecial in allResponse.tvSpecials) {
                                if (itemId == tvSpecial.id) {
                                    tvSpecialList.add(tvSpecial)
                                }
                            }
                        }
                        stringListLinkedHashMap[category.name] = tvSpecialList
                    }
                }
                linkedHashMapList.add(stringListLinkedHashMap)
            }
            val iterator = linkedHashMapList.listIterator()
            for (stringListLinkedHashMap in iterator) {
                stringListLinkedHashMap.forEach { (name: String, tvSpecialList: List<TvSpecials>) ->
                    catArrayHeader!!.add(name)
                    cardPresenterHeader = HeaderItem(name)
                    cardRowAdapter = ArrayObjectAdapter(cardPresenter)
                    cardRowAdapter!!.addAll(0, tvSpecialList)
                    mCategoryRowAdapter!!.add(index,
                        ListRow(
                            cardPresenterHeader,
                            cardRowAdapter
                        )
                    )
                    index++
                }
            }
            setAdapter(mCategoryRowAdapter)
            HomeActivity.progressBar.visibility = View.GONE
        }, {
            Toast.makeText(
                getActivity(),
                "Something went wrong.",
                Toast.LENGTH_SHORT
            ).show()
            HomeActivity.progressBar.visibility = View.GONE
        });
        val requestQueue = Volley.newRequestQueue(getActivity())
        requestQueue.add(request)
    }

    fun setUpEvents() {

        onItemViewSelectedListener = OnItemViewSelectedListener { viewHolder, o, viewHolder1, row ->
            if (o is TvSpecials) {
                Glide.with(this).load(o.thumbnail).into(HomeActivity.banner)
                HomeActivity.textTitle.text = o.title
                HomeActivity.textDesc.text = o.shortDescription
                val outputDateStr: String
                outputDateStr = try {
                    val inputFormat: DateFormat =
                        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.US)
                    val outputFormat: DateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
                    val inputDateStr = o.releaseDate
                    val date: Date = inputFormat.parse(inputDateStr)
                    outputFormat.format(date)
                } catch (e: ParseException) {
                    e.message?.let { Log.d("Date Exception", it) };
                    o.releaseDate;
                }
                HomeActivity.textRDate.text = outputDateStr
                HomeActivity.textquality.text = o.content.videos[0].quality
                HomeActivity.textSpecial.text = o.genres[0]
                //textDuration.text = "Episodes: " + content.
            }
        }
        onItemViewClickedListener =
            OnItemViewClickedListener { viewHolder, item, viewHolder1, row ->
                if (item is TvSpecials) {
                    val storedPasswords = Paper.book().read<List<String>>(item.id)
                    if (item.password.isNullOrEmpty() || (storedPasswords != null && CollectionUtils.containsAny(storedPasswords, item.password))) {
                        val intent = Intent(activity, Player_Activity::class.java)
                        intent.putExtra("video_url", item.content.videos[0].url)
                        startActivity(intent)
                    } else {
                        showPasswordFragment(item.password, item.content.videos[0].url, item.id)
                    }
                }
            }
    }

    fun showPasswordFragment(password: List<String>, url: String, id: String) {
        val passwordFragment = PasswordFragment()
        HomeActivity.passwords = password
        HomeActivity.currentIDForPassword = id
        HomeActivity.itemAfterPasswordVerification = url
        val fragmentManager = fragmentManager
        val fragmentTransaction: FragmentTransaction
        if (fragmentManager != null) {
            fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.add(R.id.passwordFragment, passwordFragment)
            fragmentTransaction.addToBackStack("PasswordFragment")
            fragmentTransaction.commit();
        }
    }
}
