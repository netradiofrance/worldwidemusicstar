package com.madstream.streetexplorer.utility

class Api {
    companion object{
        val api:String="https://radiotool.fr/tackendo/tackendo.json"
    }
}