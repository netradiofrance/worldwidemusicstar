package com.madstream.streetexplorer.utility;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.leanback.widget.HeaderItem;
import androidx.leanback.widget.Presenter;
import androidx.leanback.widget.Row;
import androidx.leanback.widget.RowHeaderPresenter;
import androidx.leanback.widget.RowHeaderView;

import com.madstream.streetexplorer.webapp.WholeHealthTV.R;

public class CustomHeaderRowPresenter extends RowHeaderPresenter {


    @Override
    public Presenter.ViewHolder onCreateViewHolder(ViewGroup viewGroup) {
        LayoutInflater inflater = (LayoutInflater) viewGroup.getContext()
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.custom_header_item, null);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(Presenter.ViewHolder viewHolder, Object item) {
        HeaderItem headerItem = item == null ? null : ((Row) item).getHeaderItem();
        ViewHolder vh = (ViewHolder) viewHolder;
        if (headerItem == null) {
            /*if (label != null) {
                label.setText(null);
            }
            viewHolder.view.setContentDescription(null);*/
            if (isNullItemVisibilityGone()) {
                viewHolder.view.setVisibility(View.GONE);
            }
        } else {
            RowHeaderView label = (RowHeaderView) viewHolder.view.findViewById(R.id.header_label);
            label.setText(headerItem.getName());
            viewHolder.view.setVisibility(View.VISIBLE);
        }
    }


}
