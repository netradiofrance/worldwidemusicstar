package com.madstream.streetexplorer.activity

import android.os.Bundle
import android.view.KeyEvent
import android.view.WindowManager
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.RelativeLayout
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import com.madstream.streetexplorer.webapp.WholeHealthTV.R
import com.madstream.streetexplorer.fragment.HomeFragment
import kotlinx.android.synthetic.main.fragment_password_layout.*

import ai.vfr.monetizationsdk.vastsdk.MonetizeSdkEvents
import ai.vfr.monetizationsdk.vastsdk.VastManager
import ai.vfr.monetizationsdk.videocontroller.SdkMonView


class HomeActivity : FragmentActivity(), MonetizeSdkEvents {


    companion object {
        lateinit var homeFragment: HomeFragment
        lateinit var progressBar: ProgressBar
        lateinit var textTitle: androidx.appcompat.widget.AppCompatTextView
        lateinit var textRDate: androidx.appcompat.widget.AppCompatTextView
        lateinit var textquality: androidx.appcompat.widget.AppCompatTextView
        lateinit var textDesc: androidx.appcompat.widget.AppCompatTextView
        lateinit var textSpecial: androidx.appcompat.widget.AppCompatTextView
        lateinit var banner: ImageView
        lateinit var tvof: androidx.appcompat.widget.AppCompatTextView
        lateinit var tvtotalItem: androidx.appcompat.widget.AppCompatTextView
        lateinit var tvfocuson: androidx.appcompat.widget.AppCompatTextView
        lateinit var home_layout: RelativeLayout
        lateinit var passwords: List<String>
        lateinit var itemAfterPasswordVerification: String
        lateinit var currentIDForPassword: String

        lateinit var vastManager: VastManager

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
        home_layout = findViewById(R.id.home_layout)
        progressBar = findViewById(
            R.id.progress_home
        )
        textTitle = findViewById(
            R.id.tvTitle
        )
        textRDate = findViewById(
            R.id.tvRelease
        )
        textquality = findViewById(
            R.id.tvQuality
        )
        textDesc = findViewById(
            R.id.tvDescription
        )
        textSpecial = findViewById(
            R.id.tvSpecial
        )
        banner = findViewById(
            R.id.imgBanner
        )
        tvfocuson = findViewById(
            R.id.tvFocuson
        )
        tvof = findViewById(
            R.id.tvof
        )
        tvtotalItem = findViewById(
            R.id.tvtotalItem
        )

        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )

        homeFragment = supportFragmentManager.findFragmentById(R.id.homeFragment) as HomeFragment


        val sdkMonView = findViewById<SdkMonView>(R.id.sdkmonview)
        vastManager = VastManager.getInstance(sdkMonView, applicationContext)
        vastManager.registerListener(this)
        vastManager.init("madstream", "street_explorer")
    }

    override fun onBackPressed() {
        super.onBackPressed()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        return when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> {
                val test = getCurrentFragment()
                if (test != null && test.isVisible) {
                    home_layout.isFocusable = false
                    test.edittext_password.requestFocus()
                } else {
                    home_layout.isFocusable = true
                    super.onKeyDown(keyCode, event)
                }
            }
            else -> super.onKeyDown(keyCode, event)
        }
    }

    private fun getCurrentFragment(): Fragment? {
        return supportFragmentManager.findFragmentById(R.id.passwordFragment)
    }
    private fun vastManagerInitPlay() {
        val sdkMonView = findViewById<SdkMonView>(R.id.sdkmonview)
        vastManager = VastManager.getInstance(sdkMonView, this)
        vastManager.initPlayCycle()
    }

    override fun onSdkInitialized() {
        vastManagerInitPlay()
    }

    override fun onPause() {
        super.onPause()
        vastManager.pause()
    }

    override fun onResume() {
        super.onResume()
        vastManagerInitPlay()
    }

}