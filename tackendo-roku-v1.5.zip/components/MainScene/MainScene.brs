Sub init()
    m.top.backgroundURI=""
    m.top.backgroundColor="#101010"

    m.screens=m.top.findNode("screens")
    m.screensContainerArray=[]

    m.homeScreen=m.screens.createChild("homeScreen")
    m.homeScreen.id="homeScreen"
    m.homeScreen.deeplinkValues=m.global.deeplinkValues
    m.homeScreen.loadData=true
    m.screensContainerArray.Push(m.homeScreen)
    m.focusKey=0
    updateFocus()
End Sub

Sub updateFocus()
    if m.focusKey=0
        m.nextScreen = m.screensContainerArray[m.screens.getChildren(3000,0).Count()-1]
        m.nextScreen.setFocus = true
    end if
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
    result = false

    if press then
        if key="back"
            if m.screensContainerArray.Count()>1 
                m.screens.removeChildIndex(m.screens.getChildren(3000,0).Count()-1)
                m.screensContainerArray.Pop()                
                m.screensContainerArray[m.screens.getChildren(3000,0).Count()-1].visible=true
                m.focusKey=0
                updateFocus()
                result=true
            end if
        else if key="options"
            
        else if key="play"
            
        else if key="down"

        else if key="up"

        end if
    end if
    return result
end function