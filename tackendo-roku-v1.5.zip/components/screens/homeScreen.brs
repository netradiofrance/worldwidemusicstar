Sub init()
    m.screenBG=m.top.findNode("screenBG")
    m.screenBG.color="#000000"

    m.AC_Font_28= CreateObject("roSGNode","Font")
    m.AC_Font_28.uri="pkg://fonts/AvenirNextBold/AvenirNext-Bold.ttf"
    m.AC_Font_28.size=30

    m.AC_Font_36= CreateObject("roSGNode","Font")
    m.AC_Font_36.uri="pkg://fonts/AvenirNextBold/AvenirNext-Bold.ttf"
    m.AC_Font_36.size=36

    m.AC_Font_32= CreateObject("roSGNode","Font")
    m.AC_Font_32.uri="pkg://fonts/AvenirNextBold/AvenirNext-DemiBold.ttf"
    m.AC_Font_32.size=32

    m.appLaunch=false
    m.customOverlay=m.top.findNode("customOverlay")
    m.bannerImage=m.top.findNode("bannerImage")
    m.bannerTitle=m.top.findNode("bannerTitle")
    m.bannerTimeStamp=m.top.findNode("bannerTimeStamp")
    m.bannerDesc=m.top.findNode("bannerDesc")
    m.releaseYear=m.top.findNode("releaseYear")
    m.contentMetadata=m.top.FindNode("contentMetadata")
    m.contentCredit=m.top.findNode("contentCredit")
    m.contentGenres=m.top.findNode("contentGenres")
    m.hdText=m.top.findNode("hdText")
    m.viewsCount=m.top.findNode("viewsCount")
    m.viewsIcon=m.top.findNode("viewsIcon")

    m.contentRow=m.top.findNode("contentRow")
    m.contentRow.focusXOffset=[(0)]
    m.contentRow.itemSize=[(1700),(250)]
    m.contentRow.translation=[(150),(600)]
    m.contentRow.numRows=(10)
    m.contentRow.itemSpacing=[0,30]
    m.contentRow.rowItemSpacing= [[(10),(3)]]
    m.contentRow.rowLabelOffset= [(0),(17)]
    m.contentRow.rowCounterRightOffset=0.10
    m.contentRow.rowLabelFont=m.AC_Font_28
    m.contentRow.rowLabelColor="#ffffff"

    m.contentRow.ObserveField("rowItemSelected","homeContentSelection")
    m.contentRow.ObserveField("rowItemFocused","homeContentFocused")

    m.appLogo=m.top.findNode("appLogo")
    m.appLogo.height=m.global.appLogoHeight
    m.appLogo.width=m.global.appLogoWidth
    m.appLogo.translation=[1920-m.global.appLogoWidth-100,1080-m.global.appLogoHeight-50]

    m.videoPlayer=m.top.findNode("videoPlayer")
    m.videoPlayer.ObserveField("state","onStateChangedForVideo")
    m.videoPlayer.ObserveField("position","onVideoPositionRender")

    m.peviousestate=""
    m.adPlayToBeDone=false
    m.adPlayBackInterval=0

    initRafController()
end sub

Sub loadDataForUI()
    getURLCallGet("https://radiotool.fr/tackendo/tackendo.json","contentDataCall")
End Sub

Sub setFocus()
    m.focusKey=0
    updateFocus()
End Sub

Sub loadContentData(json As Object)
    jsonData=parseJSON(json)

    deeplink=(m.top.deeplinkValues)
    deeplinkData=invalid
    if jsonData<>invalid
        if jsonData.tvSpecials<>invalid and jsonData.tvSpecials.Count()>0
            m.container=[]
            for each item in jsonData.tvSpecials
                dateTime=createObject("roDateTime")
                if item.releaseDate<>invalid
                    releaseDate=item.releaseDate+"T00:00:00+00:00"
                    dateTime.FromISO8601String(releaseDate)
                    item.AddReplace("newReleaseDate",dateTime.AsSeconds())
                end if
                m.container.Push(item)
            end for
            m.finalContainer=[]

            for each item in jsonData.categories
                contentData=[]
                for each item2 in jsonData.playlists
                    if item2.name=item.playlistName
                        for each item3 in item2.itemIds
                            for each content in m.container
                                if item3 = content.id
                                    contentData.Push(content)
                                end if
                            end for
                        end for
                    end if
                end for
                item.AddReplace("contents",contentData)
                m.finalContainer.Push(item)
            end for

            rowItemSize=[]
            rowHeights=[]
            parentNode=createObject("roSGNode","ContentNode")
            for each item in m.finalContainer
                if item.contents.Count()>0
                    rowHeights.Push([250])
                    rowItemSize.Push([(345),(194)])
                    shelfNode=createObject("roSGNode","ContentNode")
                    shelfNode.title=Ucase(item.name)
                    for each item2 in item.contents
                        if deeplink<>invalid and deeplink.id<>invalid and item2.id=deeplink.id
                            deeplinkData=item2
                        end if
                        itemNode=createObject("roSGNode","CustomContentNode")
                        itemNode.placeHolderImage="pkg://images/demo-thumb3.png"
                        itemNode.thumbnailImage=item2.thumbnail
                        itemNode.contentTitle=item2.title
                        itemNode.shortDesc=item2.shortDescription
                        itemNode.detailContent=formatJSON(item2)
                        itemNode.contentReleaseYear=item2.releaseDate
                        itemNode.streamURL=item2.content.videos[0].url
                        if item2.adPlayBackonStartOfVideo<>invalid and item2.adPlayBackURL<>invalid and Lcase(type(item2.adPlayBackURL)).inStr("string")>=0
                            itemNode.addField("adPlayBackonStartOfVideo","bool",true)
                            itemNode.adPlayBackonStartOfVideo=item2.adPlayBackonStartOfVideo
                            itemNode.addField("adPlayBackURL","string",true)
                            itemNode.adPlayBackURL=item2.adPlayBackURL
                            itemNode.adPlayBackInterval=item2.adPlayBackInterval
                        else if item2.adPlayBackonStartOfVideo<>invalid and item2.adPlayBackURL<>invalid and type(item2.adPlayBackURL)="roArray"
                            itemNode.addField("adPlayBackonStartOfVideo","bool",true)
                            itemNode.adPlayBackonStartOfVideo=item2.adPlayBackonStartOfVideo
                            itemNode.addField("adPlayBackURL","array",true)
                            itemNode.adPlayBackURL=item2.adPlayBackURL
                            itemNode.adPlayBackInterval=item2.adPlayBackInterval
                        end if
                        shelfNode.appendChild(itemNode)
                    end for
                    parentNode.appendChild(shelfNode)
                end if
            end for

            m.contentRow.rowItemSize=rowItemSize
            m.contentRow.rowHeights=rowHeights
            m.contentRow.focusBitmapBlendColor=m.global.focusColorHex
            m.contentRow.content=parentNode
            ' On ne lance le deep link que si l'identifiant a bien ete
            ' trouve dans le flux : sinon on retombe sur la grille.
            if deeplink<>invalid and deeplink.type<>invalid and deeplinkData<>invalid
                contentData=createObject("roSGNode","ContentNode")
                contentData.title=deeplinkData.title
                contentData.url=deeplinkData.content.videos[0].url
                contentData.streamFormat="Auto"

                m.videoplayer.content=contentData
                m.videoPlayer.control="Play"
                m.videoPlayer.visible=true
                m.videoPlayer.EnableTrickPlay=true
                m.focusKey=3
                updateFocus()
            else
                m.contentRow.visible=true
                m.focusKey=0
                updateFocus()
            end if
        end if
    end if
    m.top.signalBeacon("AppLaunchComplete")
End Sub

Sub homeContentSelection()
    content=m.contentRow.content.getChild(m.contentRow.rowItemSelected[0]).getChild(m.contentRow.rowItemSelected[1])
    m.contentData=createObject("roSGNode","ContentNode")
    m.contentData.title=content.contentTitle
    m.exactPlayerMediaSeek=0
    m.contentData.url=content.streamURL
    m.contentData.streamFormat="Auto"
    if content.adPlayBackonStartOfVideo<>invalid and content.adPlayBackonStartOfVideo
        if content.adPlayBackURL<>invalid and Lcase(type(content.adPlayBackURL)).inStr("string")>=0
            m.adcontent_main=createObject("roSGNode","ContentNode")
            m.adcontent_main.title=content.contentTitle
            m.adcontent_main.url=content.adPlayBackURL
            m.adcontent_main.streamFormat="Auto"
            m.videoplayer.content=m.adcontent_main
            m.videoPlayer.control="Play"
            m.videoPlayer.visible=true
            m.videoPlayer.EnableTrickPlay=false
            m.adPlayToBeDone=true
        else if content.adPlayBackURL<>invalid and type(content.adPlayBackURL)="roArray"
            m.adcontent_main=createObject("roSGNode","ContentNode")
            for each item in content.adPlayBackURL
                adcontent=createObject("roSGNode","ContentNode")
                adcontent.title=content.contentTitle
                adcontent.url=item
                adcontent.streamFormat="Auto"
                m.adcontent_main.appendChild(adcontent)
            end for
            m.videoplayer.content=m.adcontent_main
            m.videoplayer.contentIsPlaylist=true
            m.videoPlayer.control="Play"
            m.videoPlayer.visible=true
            m.videoPlayer.EnableTrickPlay=false
            m.adPlayToBeDone=true
        end if
    else
        m.adPlayToBeDone=false

        ' --- Injection du RIDA dans l'URL du flux ---
        ' Le lecteur Roku ne substitue aucune macro : on ajoute nous-memes
        ' l'identifiant publicitaire pour que le SSAI le transmette aux SSP.
        u = m.contentData.url
        if u <> invalid and Instr(1, u, "tackendo.tv/") > 0 and Instr(1, u, "ifa=") = 0
            di = CreateObject("roDeviceInfo")
            rida = di.GetRIDA()
            latFlag = "0"
            if di.IsRIDADisabled()
                rida = "00000000-0000-0000-0000-000000000000"
                latFlag = "1"
            end if
            sep = "&"
            if Instr(1, u, "?") = 0 then sep = "?"
            m.contentData.url = u + sep + "ifa=" + rida + "&lat=" + latFlag
            print "TACKENDO: RIDA injecte dans l'URL du flux"
        end if

        ' --- PRE-ROLL : on tente une pub avant de lancer la chaine ---
        m.pendingContent = m.contentData
        if tryPlayPreRoll(content.contentTitle)
            print "TACKENDO: pre-roll demandee avant " + content.contentTitle
        else
            m.pendingContent = invalid
            m.videoplayer.content=m.contentData
            m.videoPlayer.control="Play"
            m.videoPlayer.visible=true
            m.videoPlayer.EnableTrickPlay=true
        end if
    end if
    if content.adPlayBackInterval<>invalid and content.adPlayBackInterval>0
        m.adPlayBackInterval=content.adPlayBackInterval
    end if
    m.focusKey=3
    updateFocus()
End Sub

Sub homeContentFocused()
    contentData=m.contentRow.content.getChild(m.contentRow.rowItemFocused[0]).getChild(m.contentRow.rowItemFocused[1])
    m.bannerImage.uri=contentData.thumbnailImage
    m.bannerTitle.text=Ucase(contentData.contentTitle)
    m.bannerDesc.text=contentData.shortDesc
    m.releaseYear.text=contentData.contentReleaseYear
    m.contentMetadata.visible=true
    contentJson=parseJSON(contentData.detailContent)

    m.contentGenres.text=""
    genreIndex=0
    if contentJson.genres<>invalid and contentJson.genres.Count()>0
        for each genre in contentJson.genres
            genreIndex+=1
            if genreIndex=contentJson.genres.Count()
                m.contentGenres.text+=genre
            else
                m.contentGenres.text+=genre+", "
            end if
        end for
    end if
End Sub

Sub playLiveVideo()
    if m.jsonApiData.liveStreaming<>invalid and m.jsonApiData.liveStreaming.enabled<>invalid and m.jsonApiData.liveStreaming.enabled and m.jsonApiData.liveStreaming.src<>invalid and m.jsonApiData.liveStreaming.src<>""
        m.liveSection.visible=true

        contentData=createObject("roSGNode","ContentNode")
        contentData.title="Live"
        contentData.url=m.jsonApiData.liveStreaming.src
        contentData.streamFormat="Auto"
        m.videoplayer.content=contentData
        m.videoPlayer.control="Play"
        m.videoPlayer.visible=true
        m.videoPlayer.EnableTrickPlay=false
        m.videoPlayer.enableUI=true
        m.focusKey=3
        updateFocus()
    end if
End Sub

Sub updateFocus()
    if m.focusKey=0
        m.videoPlayer.visible=false
        m.contentRow.setFocus(true)
        m.contentRow.visible=true
    else if m.focusKey=3
        m.videoPlayer.setFocus(true)
    end if
End Sub

Sub onVideoPositionRender()
    if m.adPlayBackInterval>0 AND m.adPlayToBeDone=false
        if m.videoPlayer.state="playing"
            if Cint(m.videoPlayer.Position)>0 and (Cint(m.videoPlayer.Position) mod m.adPlayBackInterval=0)
                m.exactPlayerMediaSeek=Cint(m.videoPlayer.Position)+5
                m.videoPlayer.control="Stop"
                m.videoplayer.content=m.adcontent_main
                m.videoplayer.contentIsPlaylist=true
                m.videoPlayer.control="Play"
                m.videoPlayer.visible=true
                m.videoPlayer.EnableTrickPlay=false
                m.adPlayToBeDone=true
            end if
        end if
    end if
end sub

SUB onStateChangedForVideo()
    print"the state of the video==>"m.videoPlayer.state
    if m.videoPlayer.state="finished"
        if m.adPlayToBeDone=true
            m.adPlayToBeDone=false
            m.videoplayer.content=m.contentData
            m.videoPlayer.seek=m.exactPlayerMediaSeek
            m.videoPlayer.control="Play"
            m.videoPlayer.visible=true
            m.videoPlayer.EnableTrickPlay=true
        else
            m.videoPlayer.control="stop"
            m.videoPlayer.visible=false
            m.focusKey=0
            updateFocus()
        end if
    else if m.videoPlayer.state="buffering"
    else if m.videoPlayer.state="stopped"
        m.videoPlayer.control="stop"
        m.focusKey=2
        updateFocus()
    else if m.videoPlayer.state="error"
        m.videoPlayer.control="stop"
        m.videoPlayer.visible=false
        m.focusKey=0
        updateFocus()
    else if m.videoPlayer.state = "paused"
    else if m.videoPlayer.state = "playing" AND m.peviousestate = "paused"
        m.animateOffSet=false
    else if m.videoPlayer.state="playing"
    else
        m.videoPlayer.control="stop"
        m.focusKey=0
        updateFocus()
    end if
End SUB

function onKeyEvent(key as String, press as Boolean) as Boolean
    result = false

    if press then
        if key="back"
            if m.videoPlayer.visible=true
                m.videoPlayer.visible=false
                m.videoPlayer.control="Stop"
                m.focusKey=0
                updateFocus()
                result=true
            end if
        else if key="options"
        else if key="play"
        else if key="right"
            if m.focusKey=1 and m.liveSection.visible
                m.focuskey=2
                updateFocus()
                result=true
            end if
        else if key="left"
            if m.focusKey=2
                m.focuskey=1
                updateFocus()
                result=true
            end if
        else if key="down"
            if m.focusKey=1 or m.focusKey=2
                m.focuskey=0
                updateFocus()
                result=true
            end if
        else if key="up"
            if m.focusKey=0
                m.focuskey=1
                updateFocus()
                result=true
            end if
        end if
    end if
    return result
end function

'---------------------------------------------- Raf Implementation ----------------------------------------------'

sub initRafController()
    m.preRollCalled = 0
    m.pendingContent = invalid

    m.rafController = m.top.findNode("rafController")
    m.showRafAdsTimer = m.top.findNode("showRafAdsTimer")

    m.showRafAdsTimer.observeFieldScoped("fire", "startRafShowAd")

    m.rafController.observeFieldScoped("isReady", "onRafReady")
    m.rafController.observeFieldScoped("adStarted", "onRafAdStarted")
    m.rafController.observeFieldScoped("adFinished", "onRafAdFinished")
    setRafMeasurementData({
        genresArray: ["Educational"],
        contentID: "home_screen"
        contentLength: 0
    })
end sub

sub setRafMeasurementData(contentData)
    if contentData <> invalid
        m.rafController.measurementData = {
            genresArray: contentData.genresArray,
            contentID: contentData.contentID
            contentLength: contentData.contentLength
        }
    end if
end sub

' Programme la prochaine coupure publicitaire pendant la lecture.
sub startMidrollTimer()
    if m.showRafAdsTimer = invalid then return
    iv = 600
    if m.rafController <> invalid and m.rafController.midrollIntervalS > 0
        iv = m.rafController.midrollIntervalS
    end if
    m.showRafAdsTimer.control = "stop"
    m.showRafAdsTimer.duration = iv
    m.showRafAdsTimer.control = "start"
end sub

sub onRafReady(isReadyMsg)
    m.rafIsReady = isReadyMsg.getData()
    ' pre-chargement d'un pod des le lancement, pour que la pre-roll
    ' parte instantanement quand le spectateur choisit une chaine
    m.rafController.startAdsLoad = true
    print "TACKENDO: RAF pret, prechargement du pod publicitaire"
end sub

' Declenche une pre-roll si un pod est disponible.
' Retourne false si aucune pub n'est prete : la chaine demarre alors direct.
function tryPlayPreRoll(title as String) as Boolean
    if m.rafController = invalid then return false
    if m.rafIsReady <> true then return false
    if m.rafController.isAdsReady <> true then return false

    setRafMeasurementData({
        genresArray: ["Music"],
        contentID: title,
        contentLength: 0
    })
    m.preRollCalled = m.preRollCalled + 1
    m.rafController.showAd = true
    return true
end function

sub startRafShowAd()
    ' Coupure publicitaire pendant la lecture, uniquement si un pod est pret.
    if m.rafController = invalid then return
    if m.rafIsReady <> true then return
    if m.rafController.isAdsReady <> true
        startMidrollTimer()   ' pas de pub : on retentera plus tard
        return
    end if
    if m.videoPlayer = invalid or m.videoPlayer.state <> "playing"
        startMidrollTimer()
        return
    end if
    m.videoPosition = m.videoPlayer.position
    m.rafController.showAd = true
end sub

sub onRafAdStarted()
    if m.videoPlayer.control = "play"
        m.videoPosition = m.videoPlayer.position
        m.videoPlayer.control="Stop"
        m.top.removeChild(m.videoPlayer)
    end if
end sub

sub onRafAdFinished()
    ' --- fin de pre-roll : on demarre la chaine demandee ---
    if m.pendingContent <> invalid
        pending = m.pendingContent
        m.pendingContent = invalid
        m.videoplayer.content = pending
        m.videoPlayer.control = "Play"
        m.videoPlayer.visible = true
        m.videoPlayer.EnableTrickPlay = true
        m.videoPlayer.setFocus(true)
        m.focusKey = 3
        ' on recharge un pod pour la prochaine fois
        m.rafController.startAdsLoad = true
        startMidrollTimer()
        return
    end if

    if m.videoPlayer.control = "stop"
        m.top.appendChild(m.videoPlayer)
        m.videoPlayer.seek = m.videoPosition
        m.videoPlayer.control="play"
        m.videoPlayer.setFocus(true)
    else
        m.top.setFocus(true)
    end if
end sub

'---------------------------------------------- Raf Implementation ----------------------------------------------'