function randIntInRange(min, max)
    return int(rnd(0) * ((max - min) + 1)) + min
end function

function MathUtil() as Object
    math = {
        E: 2.71828
        PI: 3.14159

        ceil: function(number as Float) as Integer
            i = int(number)
            if number > i then return i+1
            return i
        end function

        floor: function(number as Float) as Integer
            return int(number)
        end function

        round: function(number as Float, precision=0 as Integer) as Float
            return cint(number * 10^precision) / 10^precision
        end function

        min: function(a, b)
            if not b < a then
                return a
            else
                return b
            end if
        end function

        max: function(a, b)
            if a < b then
                return b
            else
                return a
            end if
        end function

        _isNumber: function(number)
            return getInterface(number, "ifInt") <> invalid or getInterface(number, "ifFloat") <> invalid or getInterface(number, "ifDouble") <> invalid
        end function

        modulo: function (x, n)
            return (x mod n + n) mod n
        end function

        radiansToDegrees: function(radians)
            return radians * 180 / m.PI
        end function

        degreeToRadians: function(degree)
            return degree * m.PI / 180
        end function

        power: function(base, exp as Integer)
            if exp = 0 then return 1
            pow = m.power(base, fix(abs(exp/2)))
            if exp mod 2 = 0 then
                pow = pow * pow
            else
                pow = base * pow * pow
            end if
            if sgn(exp) < 0 then
                return 1 / pow
            else
                return pow
            end if
        end function

        NchooseK: function(n as Integer, k as Integer)
            result = 1
            for i = 1 to k
                result = result *((n-(k-i))/i)
            end for
            return result
        end function

        rotatePoint: function(point, radians)
            x = point.x
            y = -point.y
            return {x: x*cos(radians) - y*sin(radians), y: -(x*sin(radians)+ y*cos(radians))}
        end function
    }

    return math
end function