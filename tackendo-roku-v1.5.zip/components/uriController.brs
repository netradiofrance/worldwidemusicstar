Sub getURLCallGet(url As String,requestType As String)
  queryParam=""

  if queryParam<>""
    url=url+queryParam
  end if
  m.loadingIndicator=m.top.findNode("loadingIndicator")

  m.loadingIndicator.translation=[(870),(415)]

  m.loadingIndicator.control="start"
  m.loadingIndicator.visible=true

  m.contentRetriever = m.global.contentRetriever 
  makeURLCallGet({uri:url, requesttype: requestType })
End Sub

sub makeURLCallGet(parameters as Object)
  context = createObject("RoSGNode","Node")
  if type(parameters) = "roAssociativeArray"
    context.addFields({
      parameters: parameters,
      response: {}
    })
    context.observeField("response","receiveRequestResponse")
    m.contentRetriever.requestGet = { context: context }
  end if
end sub

sub receiveRequestResponse(msg as Object)
  mt = type(msg)
  if mt = "roSGNodeEvent"
    response = msg.getData()
    rt = type(response)
    if rt = "roAssociativeArray"
        requestType = response.parameters.requesttype
        m.loadingIndicator.control="stop"
        m.loadingIndicator.visible=false 
        if response.code = 200
          if  requestType="contentDataCall"
            response=response.content
            loadContentData(response)
          end if
        else
          if GetRegValue("jsonData")<>invalid
            loadContentData(GetRegValue("jsonData"))
          end if
        end if
    else
        print "[ERROR] HomeScreen: Expected response of type roAA, received response of type: '"; rt; "'"
    end if
  else
    print "[ERROR] HomeScreen: Received unknown response message of type: '"; mt; "'"
  end if
end sub