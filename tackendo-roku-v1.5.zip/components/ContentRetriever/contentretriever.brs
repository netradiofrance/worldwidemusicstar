function init()
    m.jobQueue = {}
    m.port = createObject("roMessagePort") 
    m.top.observeField("requestGet", m.port)  

    m.top.functionName = "listen"
    m.top.control = "run"
end function

function listen() as Void
    while (true)
        msg = wait(0, m.port)
        mt = type(msg)
        if mt = "roSGNodeEvent"
            if msg.getField() = "requestGet"
                makeAPIRequestGet(msg.getData())
            else
                print "[ERROR] ContentRetriever: unrecognized field '"; msg.getField(); "'"
            end if
        else if mt = "roUrlEvent"
            processResponse(msg)
        else
            print "[ERROR] ContentRetriever: unrecognized event type '"; mt; "'"
        end if
    end while
end function

function makeAPIRequestGet(request as Object) as Boolean
    if type(request) = "roAssociativeArray"
        context = request.context
        if type(context) = "roSGNode"
            parameters = context.parameters
            if type(parameters) = "roAssociativeArray"
                uri = parameters.uri
                if type(uri) = "roString"
                    urlTransfer = CreateObject("roUrlTransfer")
                    urlTransfer.SetCertificatesFile("common:/certs/ca-bundle.crt")
                    urlTransfer.AddHeader("X-Roku-Reserved-Dev-Id", "")
                    urlTransfer.AddHeader("Content-Type","application/json")
                    urlTransfer.InitClientCertificates()
                    urlTransfer.setUrl(uri)
                    urlTransfer.setPort(m.port)
                    if (urlTransfer.AsyncGetToString())
                        id = stri(urlTransfer.getIdentity()).trim()
                        m.jobQueue[id] = {context:context, transfer:urlTransfer}
                        print "Request to "; uri; " successful."
                    else
                        print "[ERROR] ContentRetriever: invalid uri: "; uri
                    end if
                end if
            end if
        end if
    end if
    return true
end function

function processResponse(msg as Object)
    id = stri(msg.GetSourceIdentity()).trim()
    job = m.jobQueue[id]
    if job <> invalid
        result = {
            uri: job.context.parameters.uri,
            parameters: job.context.parameters,
            code: msg.getResponseCode(),
            content: msg.getString(),
            headers:msg.GetResponseHeaders()
        }
        job.context.response = result
        m.jobQueue.delete(id)
    else
        print "[ERROR] Received response message for unknown job: "; idkey
    end if
end function