sub init()
  contentRetriever = CreateObject("roSGNode", "ContentRetriever")
  deviceInfo=CreateObject("roDeviceInfo")
  deviceId=deviceInfo.GetChannelClientId()
  vastAdData=createObject("roAssociativeArray")
  jsonDataResponse=createObject("roString")
  statestToHandle = CreateObject("roAssociativeArray")
  appearance=CreateObject("roString")

  ' API paths
  this = {}
  this.baseURL = ""

  m.global.addFields({
    api: this,
    contentRetriever: contentRetriever,
    jsonDataResponse:jsonDataResponse,
    deviceId:deviceId,
    focusColorHex:"#ffffff",
    unfocusColorHex:"#868686",
    textFieldBGColor:"#ffffff",
    textFieldTextColor:"#363636",
    rowTitleTextColor:"#ffffff",
    statestToHandle:statestToHandle,
    appearance:"DARK",
    appLogoHeight:200,
    appLogoWidth:200,
  })
end sub