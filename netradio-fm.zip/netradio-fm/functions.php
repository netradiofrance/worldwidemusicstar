<?php
/**
 * Netradio FM — Functions
 *
 * @package NetradioFM
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Endpoint JSON par défaut de la plateforme de playout RadioAirplay.
 * Modifiable dans Réglages → Netradio FM → Source des données.
 */
define( 'NETRADIO_DEFAULT_API_URL', 'https://radioairplay.fr/api/nowplaying/netradio-p5v0' );

/**
 * Flux audio par défaut (HLS).
 *
 * listen.m3u8 REDIRIGE vers une playlist de session unique par auditeur
 * (/hls/netradio/s/<id>.m3u8) : c'est ce qui permet à l'AdServer GAM de
 * compter les impressions et de plafonner la répétition des spots.
 * Conséquence : ne jamais ajouter de paramètre anti-cache à cette URL, et
 * laisser le lecteur poursuivre sur l'URL de session obtenue après
 * redirection — sinon chaque rafraîchissement ouvrirait une session neuve.
 */
define( 'NETRADIO_DEFAULT_STREAM_URL', 'https://radioairplay.fr/hls/netradio/listen.m3u8' );

/**
 * Smart category URL : trouve une catégorie par nom puis par slug
 *
 * Évite les liens cassés en cherchant la catégorie existante.
 * Renvoie l'URL si trouvée, sinon null (l'item du menu sera masqué).
 *
 * @param string   $name  Nom à chercher (insensible casse + accents)
 * @param string[] $slugs Slugs alternatifs à essayer
 * @return string|null
 */
function netradio_smart_category_url( $name, $slugs = array() ) {
    // 1. Cherche par nom (insensible casse/accents)
    $term = get_term_by( 'name', $name, 'category' );
    if ( $term && ! is_wp_error( $term ) ) {
        return get_category_link( $term->term_id );
    }

    // 2. Cherche par slug parmi les variantes fournies
    foreach ( $slugs as $slug ) {
        $term = get_term_by( 'slug', $slug, 'category' );
        if ( $term && ! is_wp_error( $term ) ) {
            return get_category_link( $term->term_id );
        }
    }

    // 3. Dernier recours : remove_accents + lowercase et recherche par slug
    if ( function_exists( 'remove_accents' ) ) {
        $auto_slug = sanitize_title( remove_accents( $name ) );
        $term = get_term_by( 'slug', $auto_slug, 'category' );
        if ( $term && ! is_wp_error( $term ) ) {
            return get_category_link( $term->term_id );
        }
    }

    return null;
}

/**
 * Smart category by name : retourne l'objet term ou null
 * Utile pour front-page.php qui a besoin de l'ID pour WP_Query
 */
function netradio_smart_category( $name, $slugs = array() ) {
    $term = get_term_by( 'name', $name, 'category' );
    if ( $term && ! is_wp_error( $term ) ) return $term;

    foreach ( $slugs as $slug ) {
        $term = get_term_by( 'slug', $slug, 'category' );
        if ( $term && ! is_wp_error( $term ) ) return $term;
    }

    if ( function_exists( 'remove_accents' ) ) {
        $auto_slug = sanitize_title( remove_accents( $name ) );
        $term = get_term_by( 'slug', $auto_slug, 'category' );
        if ( $term && ! is_wp_error( $term ) ) return $term;
    }

    return null;
}

define( 'NETRADIO_VERSION', '2.5.0' );
define( 'NETRADIO_PATH', get_template_directory() );
define( 'NETRADIO_URI', get_template_directory_uri() );

/**
 * Migration de version : nettoyage one-shot des doublons d'historique
 */
function netradio_run_migrations() {
    $installed_version = get_option( 'netradio_version', '0.0.0' );

    if ( version_compare( $installed_version, '1.8.0', '<' ) ) {
        // Migration 1.8 : nettoyer les doublons dans netradio_track_history
        $history = get_option( 'netradio_track_history', array() );
        if ( ! empty( $history ) ) {
            $seen = array();
            $cleaned = array();
            foreach ( $history as $item ) {
                if ( ! is_array( $item ) || empty( $item['artist'] ) && empty( $item['title'] ) ) continue;
                $key = strtolower( trim( $item['artist'] ) . '|' . trim( $item['title'] ) );
                if ( isset( $seen[ $key ] ) ) continue;
                $seen[ $key ] = true;
                $cleaned[] = $item;
            }
            update_option( 'netradio_track_history', array_slice( $cleaned, 0, 20 ), false );
        }

        // Vider les caches d'historique pour forcer le rebuild
        $station_id = netradio_get_option( 'station_id', '847' );
        for ( $i = 1; $i <= 20; $i++ ) {
            delete_transient( 'netradio_history_' . $station_id . '_' . $i );
        }
    }

    if ( version_compare( $installed_version, '1.9.0', '<' ) ) {
        // Migration 1.9 : purger les sweepers NETRADIO et RADIOTARGET déjà stockés
        $history = get_option( 'netradio_track_history', array() );
        if ( ! empty( $history ) ) {
            $excluded_patterns = array( 'netradio', 'radiotarget', 'jingle', 'sweeper', 'pub', 'advertising', 'commercial', 'ad break' );
            $cleaned = array();
            foreach ( $history as $item ) {
                if ( ! is_array( $item ) ) continue;
                $combined = strtolower( trim( ( $item['artist'] ?? '' ) . ' ' . ( $item['title'] ?? '' ) ) );
                $skip = false;
                foreach ( $excluded_patterns as $pattern ) {
                    if ( strpos( $combined, $pattern ) !== false ) {
                        $skip = true;
                        break;
                    }
                }
                if ( ! $skip ) $cleaned[] = $item;
            }
            update_option( 'netradio_track_history', array_slice( $cleaned, 0, 20 ), false );
        }

        // Vider aussi tous les caches d'historique pour forcer le rebuild propre
        $station_id = netradio_get_option( 'station_id', '847' );
        for ( $i = 1; $i <= 20; $i++ ) {
            delete_transient( 'netradio_history_' . $station_id . '_' . $i );
        }
    }

    if ( version_compare( $installed_version, '2.1.0', '<' ) ) {
        // Migration 2.1 : bascule de RadioBoss vers la plateforme RadioAirplay.
        $options = get_option( 'netradio_settings', array() );

        if ( empty( $options['api_provider'] ) ) {
            $options['api_provider'] = 'radioairplay';
        }
        if ( empty( $options['api_url'] ) ) {
            $options['api_url'] = NETRADIO_DEFAULT_API_URL;
        }
        // RadioAirplay recommande 10-15 s (ancien réglage RadioBoss : 15 s).
        if ( empty( $options['poll_interval'] ) || intval( $options['poll_interval'] ) > 15 ) {
            $options['poll_interval'] = 12;
        }
        update_option( 'netradio_settings', $options );

        // L'historique maison ne sert plus : RadioAirplay fournit un
        // historique complet, filtré et avec les pochettes déjà résolues.
        delete_option( 'netradio_track_history' );

        // Purge des caches RadioBoss devenus obsolètes.
        $station_id = isset( $options['station_id'] ) ? $options['station_id'] : '847';
        delete_transient( 'netradio_nowplaying_' . $station_id );
        delete_transient( 'netradio_raw_info_' . $station_id );
        for ( $i = 1; $i <= 20; $i++ ) {
            delete_transient( 'netradio_history_' . $station_id . '_' . $i );
        }

        // Le cron d'historique n'a plus lieu d'être en mode RadioAirplay.
        $ts = wp_next_scheduled( 'netradio_poll_radioboss_event' );
        if ( $ts ) {
            wp_unschedule_event( $ts, 'netradio_poll_radioboss_event' );
        }
    }

    if ( version_compare( $installed_version, '2.2.0', '<' ) ) {
        // Migration 2.2 : prise en charge du flux HLS.
        // On ne change PAS l'URL du flux : le lecteur détecte le format tout
        // seul. On garantit seulement que la clé existe et on conserve
        // l'ancien flux MP3 comme secours si le flux principal passe en HLS.
        $options = get_option( 'netradio_settings', array() );

        if ( ! isset( $options['stream_fallback_url'] ) ) {
            $options['stream_fallback_url'] = '';
        }
        if ( empty( $options['stream_url'] ) ) {
            $options['stream_url'] = NETRADIO_DEFAULT_STREAM_URL;
        }

        update_option( 'netradio_settings', $options );
    }

    if ( version_compare( $installed_version, '2.3.0', '<' ) ) {
        // Migration 2.3 : passage au flux HLS avec publicité insérée côté
        // serveur (GAM). Le flux MP3 RadioBoss n'existe plus.
        $options = get_option( 'netradio_settings', array() );

        $current  = isset( $options['stream_url'] ) ? $options['stream_url'] : '';
        $is_legacy = ( $current === '' ) || ( stripos( $current, 'radioboss' ) !== false );

        // On ne remplace que l'ancien flux RadioBoss : si une URL a été saisie
        // manuellement, on n'y touche pas.
        if ( $is_legacy ) {
            $options['stream_url'] = NETRADIO_DEFAULT_STREAM_URL;
        }

        // Le repli MP3 pointait vers RadioBoss : devenu invalide, on le vide.
        if ( ! empty( $options['stream_fallback_url'] ) && stripos( $options['stream_fallback_url'], 'radioboss' ) !== false ) {
            $options['stream_fallback_url'] = '';
        }

        update_option( 'netradio_settings', $options );
    }

    update_option( 'netradio_version', NETRADIO_VERSION );
}
add_action( 'admin_init', 'netradio_run_migrations' );

/**
 * Setup du thème
 */
function netradio_setup() {
    // Support WordPress
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'automatic-feed-links' );
    add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
    add_theme_support( 'custom-logo', array(
        'height'      => 80,
        'width'       => 240,
        'flex-height' => true,
        'flex-width'  => true,
    ) );
    add_theme_support( 'responsive-embeds' );
    add_theme_support( 'editor-styles' );

    // Tailles d'images personnalisées
    add_image_size( 'netradio-card', 600, 450, true );        // cartes home
    add_image_size( 'netradio-hero', 1200, 800, true );       // hero
    add_image_size( 'netradio-feature', 900, 675, true );     // grande Une
    add_image_size( 'netradio-thumb', 110, 110, true );       // podcasts

    // Menus
    register_nav_menus( array(
        'primary' => __( 'Navigation principale', 'netradio-fm' ),
        'footer'  => __( 'Navigation footer', 'netradio-fm' ),
    ) );

    // Charger les traductions
    load_theme_textdomain( 'netradio-fm', NETRADIO_PATH . '/languages' );
}
add_action( 'after_setup_theme', 'netradio_setup' );

/**
 * Pré-remplir les options à l'activation du thème
 */
function netradio_activate() {
    $existing = get_option( 'netradio_settings', array() );
    $defaults = array(
        'station_id'    => '847',
        'api_key'       => '80R7MS53YOOY',
        'api_base'      => 'https://c22.radioboss.fm',
        'stream_url'    => 'https://c22.radioboss.fm/stream/847',
        'station_name'  => 'Netradio',
        'poll_interval' => 15,
    );
    update_option( 'netradio_settings', wp_parse_args( $existing, $defaults ) );
}
add_action( 'after_switch_theme', 'netradio_activate' );

/**
 * Chargement des assets (CSS + JS)
 */
function netradio_enqueue_assets() {
    // Google Fonts (Fraunces + Manrope + JetBrains Mono)
    wp_enqueue_style(
        'netradio-fonts',
        'https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,700;0,9..144,900;1,9..144,500;1,9..144,700&family=JetBrains+Mono:wght@400;600&family=Manrope:wght@300;400;500;600;700;800&display=swap',
        array(),
        NETRADIO_VERSION
    );

    // CSS principal du thème
    wp_enqueue_style(
        'netradio-main',
        NETRADIO_URI . '/assets/css/main.css',
        array( 'netradio-fonts' ),
        NETRADIO_VERSION
    );

    // CSS magazine (chargé sur tous les single posts au cas où)
    wp_enqueue_style(
        'netradio-magazine',
        NETRADIO_URI . '/assets/css/magazine.css',
        array( 'netradio-main' ),
        NETRADIO_VERSION
    );

    // style.css de WordPress (header du thème)
    wp_enqueue_style(
        'netradio-style',
        get_stylesheet_uri(),
        array(),
        NETRADIO_VERSION
    );

    // JS — Lecteur audio
    wp_enqueue_script(
        'netradio-player',
        NETRADIO_URI . '/assets/js/player.js',
        array(),
        NETRADIO_VERSION,
        true
    );

    // JS — Polling API RadioBoss
    wp_enqueue_script(
        'netradio-radioboss',
        NETRADIO_URI . '/assets/js/radioboss.js',
        array(),
        NETRADIO_VERSION,
        true
    );

    // JS — Interactions générales
    wp_enqueue_script(
        'netradio-main',
        NETRADIO_URI . '/assets/js/main.js',
        array(),
        NETRADIO_VERSION,
        true
    );

    // Localisation JS : passer les URLs et l'AJAX endpoint au JavaScript
    $js_config = array(
        'ajaxUrl'      => admin_url( 'admin-ajax.php' ),
        'nonce'        => wp_create_nonce( 'netradio_radioboss_nonce' ),
        'streamUrl'    => netradio_get_option( 'stream_url', NETRADIO_DEFAULT_STREAM_URL ),
        // Flux de secours (MP3/AAC) utilisé si le HLS échoue
        'streamFallbackUrl' => netradio_get_option( 'stream_fallback_url', '' ),
        // hls.js est chargé en différé, uniquement si le navigateur en a besoin
        'hlsScriptUrl' => NETRADIO_URI . '/assets/js/vendor/hls.min.js?ver=' . NETRADIO_VERSION,
        'stationId'    => netradio_get_option( 'station_id', '847' ),
        'stationName'  => netradio_get_option( 'station_name', 'Netradio' ),
        'provider'     => netradio_api_provider(),
        // ms — refresh des titres. RadioAirplay recommande 10-15 s.
        'pollInterval' => max( 5, intval( netradio_get_option( 'poll_interval', 12 ) ) ) * 1000,
        'historyCount' => 12,    // nombre de pochettes historique à afficher
        'placeholder'  => NETRADIO_URI . '/assets/images/placeholder-cover.svg',
        // Retard du HLS, en secondes : aligne le titre affiché sur le son entendu
        'metadataDelay' => max( 0, intval( netradio_get_option( 'metadata_delay', 0 ) ) ),
    );
    wp_localize_script( 'netradio-radioboss', 'NetradioConfig', $js_config );
    // player.js a besoin de la même config et peut se charger avant radioboss.js
    wp_localize_script( 'netradio-player', 'NetradioConfig', $js_config );
}
add_action( 'wp_enqueue_scripts', 'netradio_enqueue_assets' );

/**
 * Helper : récupère une option du thème
 */
function netradio_get_option( $key, $default = '' ) {
    $options = get_option( 'netradio_settings', array() );
    return isset( $options[ $key ] ) && $options[ $key ] !== '' ? $options[ $key ] : $default;
}

/**
 * Fournisseur de données radio actuellement sélectionné.
 *
 * @return string 'radioairplay' | 'radioboss'
 */
function netradio_api_provider() {
    $provider = netradio_get_option( 'api_provider', 'radioairplay' );
    return $provider === 'radioboss' ? 'radioboss' : 'radioairplay';
}

/**
 * Routeur : retourne l'instance d'API correspondant au fournisseur choisi.
 *
 * Les deux classes exposent la même interface — get_now_playing(),
 * get_history(), flush_cache(), debug_endpoints() — donc le reste du thème
 * n'a pas à savoir d'où viennent les données.
 *
 * @return Netradio_RadioAirplay_API|Netradio_RadioBoss_API
 */
function netradio_api() {
    if ( netradio_api_provider() === 'radioboss' ) {
        return new Netradio_RadioBoss_API();
    }
    return new Netradio_RadioAirplay_API();
}

/**
 * Charger les classes et fonctions internes
 */
require_once NETRADIO_PATH . '/inc/radioboss-api.php';
require_once NETRADIO_PATH . '/inc/radioairplay-api.php';
require_once NETRADIO_PATH . '/inc/customizer.php';
require_once NETRADIO_PATH . '/inc/widgets.php';
require_once NETRADIO_PATH . '/inc/custom-post-types.php';
require_once NETRADIO_PATH . '/inc/ajax-endpoints.php';
require_once NETRADIO_PATH . '/inc/admin-settings.php';
require_once NETRADIO_PATH . '/inc/article-importer.php';
require_once NETRADIO_PATH . '/inc/spotify-api.php';
require_once NETRADIO_PATH . '/inc/seo-enhancements.php';
require_once NETRADIO_PATH . '/inc/diagnostic-page.php';

/**
 * Cron WordPress : poll l'API toutes les minutes pour maintenir l'historique
 * maison, même quand personne ne visite le site.
 *
 * Utile UNIQUEMENT en mode RadioBoss : cette API ne renvoyant pas d'historique,
 * le thème devait le reconstituer lui-même. RadioAirplay fournit un historique
 * complet et déjà filtré → le cron est inutile et n'est plus planifié.
 */
function netradio_cron_poll_radioboss() {
    if ( netradio_api_provider() !== 'radioboss' ) {
        return;
    }
    if ( class_exists( 'Netradio_RadioBoss_API' ) ) {
        $station_id = netradio_get_option( 'station_id', '847' );
        delete_transient( 'netradio_nowplaying_' . $station_id );
        $api = new Netradio_RadioBoss_API();
        $api->get_now_playing();
    }
}
add_action( 'netradio_poll_radioboss_event', 'netradio_cron_poll_radioboss' );

/**
 * Schedule du cron (toutes les minutes) — seulement en mode RadioBoss.
 */
function netradio_schedule_cron() {
    $scheduled = wp_next_scheduled( 'netradio_poll_radioboss_event' );

    if ( netradio_api_provider() !== 'radioboss' ) {
        // Mode RadioAirplay : on déplanifie proprement s'il traînait.
        if ( $scheduled ) {
            wp_unschedule_event( $scheduled, 'netradio_poll_radioboss_event' );
        }
        return;
    }

    if ( ! $scheduled ) {
        wp_schedule_event( time(), 'netradio_minute', 'netradio_poll_radioboss_event' );
    }
}
add_action( 'wp', 'netradio_schedule_cron' );

/**
 * Ajouter l'intervalle "minute" aux schedules WP
 */
function netradio_cron_schedules( $schedules ) {
    $schedules['netradio_minute'] = array(
        'interval' => 60,
        'display'  => __( 'Toutes les minutes (Netradio)', 'netradio-fm' ),
    );
    return $schedules;
}
add_filter( 'cron_schedules', 'netradio_cron_schedules' );

/**
 * Nettoyer le cron à la désactivation du thème
 */
function netradio_clear_cron() {
    $timestamp = wp_next_scheduled( 'netradio_poll_radioboss_event' );
    if ( $timestamp ) {
        wp_unschedule_event( $timestamp, 'netradio_poll_radioboss_event' );
    }
}
add_action( 'switch_theme', 'netradio_clear_cron' );

/**
 * Charger le mini-plugin Magazine intégré au thème
 */
require_once NETRADIO_PATH . '/plugin-mag/magazine.php';

/**
 * Filtrer le contenu des articles avec mode magazine activé
 */
function netradio_wrap_magazine( $content ) {
    if ( ! is_singular() ) return $content;
    global $post;
    if ( ! $post instanceof WP_Post ) return $content;

    $is_magazine = get_post_meta( $post->ID, '_netradio_magazine_mode', true );
    if ( $is_magazine === 'yes' ) {
        return '<div class="ciao-article"><div class="ciao-body">' . $content . '</div></div>';
    }
    return $content;
}
add_filter( 'the_content', 'netradio_wrap_magazine', 20 );

/**
 * Excerpt personnalisé
 */
function netradio_excerpt_length( $length ) {
    return 22;
}
add_filter( 'excerpt_length', 'netradio_excerpt_length', 999 );

function netradio_excerpt_more( $more ) {
    return '…';
}
add_filter( 'excerpt_more', 'netradio_excerpt_more' );

/**
 * Helper : formater la date à la française
 */
function netradio_format_date( $post_id = null ) {
    if ( ! $post_id ) $post_id = get_the_ID();
    return date_i18n( 'j M Y', strtotime( get_the_date( 'Y-m-d', $post_id ) ) );
}

/**
 * Helper : temps de lecture estimé
 */
function netradio_reading_time( $post_id = null ) {
    if ( ! $post_id ) $post_id = get_the_ID();
    $content = get_post_field( 'post_content', $post_id );
    $word_count = str_word_count( strip_tags( $content ) );
    $minutes = max( 1, ceil( $word_count / 200 ) );
    return sprintf( _n( '%d min de lecture', '%d min de lecture', $minutes, 'netradio-fm' ), $minutes );
}

/**
 * Helper : récupérer la 1ère catégorie d'un article
 */
function netradio_primary_category( $post_id = null ) {
    if ( ! $post_id ) $post_id = get_the_ID();
    $cats = get_the_category( $post_id );
    return ! empty( $cats ) ? $cats[0] : null;
}

/**
 * Helper : URL d'une image fallback si pas de featured image
 */
function netradio_thumbnail_url( $size = 'netradio-card', $post_id = null ) {
    if ( ! $post_id ) $post_id = get_the_ID();
    if ( has_post_thumbnail( $post_id ) ) {
        return get_the_post_thumbnail_url( $post_id, $size );
    }
    // Fallback : dégradé SVG
    return NETRADIO_URI . '/assets/images/placeholder.svg';
}

/**
 * Ajouter une class body si mode magazine
 */
function netradio_body_class( $classes ) {
    if ( is_singular() ) {
        global $post;
        if ( $post && get_post_meta( $post->ID, '_netradio_magazine_mode', true ) === 'yes' ) {
            $classes[] = 'netradio-magazine-active';
        }
    }
    return $classes;
}
add_filter( 'body_class', 'netradio_body_class' );

/**
 * Permettre les SVG dans la médiathèque (utile pour les icônes)
 */
function netradio_allow_svg( $mimes ) {
    if ( current_user_can( 'manage_options' ) ) {
        $mimes['svg'] = 'image/svg+xml';
    }
    return $mimes;
}
add_filter( 'upload_mimes', 'netradio_allow_svg' );

/**
 * Désactiver l'éditeur de blocs sur les articles "magazine"
 * (l'éditeur classique est plus stable avec les shortcodes)
 */
function netradio_disable_gutenberg_on_magazine( $use_block_editor, $post ) {
    if ( $post && get_post_meta( $post->ID, '_netradio_magazine_mode', true ) === 'yes' ) {
        // On laisse l'utilisateur choisir, on ne force pas
    }
    return $use_block_editor;
}
add_filter( 'use_block_editor_for_post', 'netradio_disable_gutenberg_on_magazine', 10, 2 );

/**
 * Ajouter target="_blank" automatique sur les liens externes du player
 */
function netradio_add_admin_bar_link() {
    if ( current_user_can( 'manage_options' ) ) {
        global $wp_admin_bar;
        $wp_admin_bar->add_node( array(
            'id'    => 'netradio-settings',
            'title' => '📻 Netradio FM',
            'href'  => admin_url( 'admin.php?page=netradio-settings' ),
        ) );
    }
}
add_action( 'admin_bar_menu', 'netradio_add_admin_bar_link', 100 );
