<?php
/**
 * 404
 *
 * @package NetradioFM
 */
get_header();
?>
<section class="nr-section" style="text-align:center; padding: 120px 24px;">
    <div style="font-family: var(--nr-mono); font-size: 14px; letter-spacing: 0.2em; color: var(--nr-red); margin-bottom: 16px;">ERREUR 404</div>
    <h1 style="font-family: var(--nr-serif); font-size: clamp(48px, 8vw, 120px); font-weight: 900; line-height: 1; letter-spacing: -0.03em; margin: 0 0 24px 0;">
        Page <em style="font-style: italic; font-weight: 500; color: var(--nr-red);">introuvable</em>
    </h1>
    <p style="font-family: var(--nr-serif); font-style: italic; font-size: 20px; max-width: 500px; margin: 0 auto 32px; color: rgba(10,10,10,0.7);">
        Désolé, cette page n'existe pas ou a été déplacée.
    </p>
    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="nr-feature-cta">Retour à l'accueil →</a>
</section>
<?php get_footer(); ?>
