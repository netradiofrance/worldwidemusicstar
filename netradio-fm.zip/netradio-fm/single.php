<?php
/**
 * Single Post — Magazine Layout
 * @package NetradioFM
 */

get_header();

while ( have_posts() ) : the_post();
    $cat = netradio_primary_category();
    $is_magazine = get_post_meta( get_the_ID(), '_netradio_magazine_mode', true ) === 'yes';
?>

<?php if ( $is_magazine ) : ?>
    <div class="nr-mag-layout">
        <div class="nr-mag-main">
            <?php the_content(); ?>

            <div class="nr-share">
                <div class="nr-share-label">Partager cet article</div>
                <div class="nr-share-buttons">
                    <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode( get_permalink() ); ?>" target="_blank" rel="noopener" class="nr-share-btn">Facebook</a>
                    <a href="https://twitter.com/intent/tweet?text=<?php echo urlencode( get_the_title() ); ?>&url=<?php echo urlencode( get_permalink() ); ?>" target="_blank" rel="noopener" class="nr-share-btn">X</a>
                    <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo urlencode( get_permalink() ); ?>" target="_blank" rel="noopener" class="nr-share-btn">LinkedIn</a>
                    <a href="mailto:?subject=<?php echo urlencode( get_the_title() ); ?>&body=<?php echo urlencode( get_permalink() ); ?>" class="nr-share-btn">Email</a>
                </div>
            </div>
        </div>

        <aside class="nr-mag-aside">
            <div class="nr-mag-sticky">
                <?php echo netradio_get_radioboss_widget_html( 8 ); ?>

                <?php
                if ( $cat ) :
                    $related = new WP_Query( array(
                        'category__in'   => array( $cat->term_id ),
                        'post__not_in'   => array( get_the_ID() ),
                        'posts_per_page' => 3,
                    ) );
                    if ( $related->have_posts() ) :
                ?>
                    <div class="nr-related-card">
                        <div class="nr-related-title">À lire aussi</div>
                        <?php while ( $related->have_posts() ) : $related->the_post(); ?>
                            <a href="<?php the_permalink(); ?>" class="nr-related-item">
                                <div class="nr-related-thumb" style="background-image:url('<?php echo esc_url( netradio_thumbnail_url( 'netradio-thumb' ) ); ?>')"></div>
                                <div class="nr-related-info">
                                    <div class="nr-related-cat"><?php $rcat = get_the_category(); echo $rcat ? esc_html( $rcat[0]->name ) : ''; ?></div>
                                    <h4><?php the_title(); ?></h4>
                                </div>
                            </a>
                        <?php endwhile; wp_reset_postdata(); ?>
                    </div>
                <?php endif; endif; ?>
            </div>
        </aside>
    </div>

<?php else : ?>
    <article class="nr-single-wrap">
        <?php if ( has_post_thumbnail() ) : ?>
            <div class="nr-single-hero" style="background-image: linear-gradient(180deg, rgba(0,0,0,0) 40%, rgba(0,0,0,0.9) 100%), url('<?php echo esc_url( get_the_post_thumbnail_url( null, 'netradio-hero' ) ); ?>')">
                <div class="nr-single-hero-inner">
                    <?php if ( $cat ) : ?>
                        <div class="nr-single-kicker"><?php echo esc_html( $cat->name ); ?></div>
                    <?php endif; ?>
                    <h1 class="nr-single-title"><?php the_title(); ?></h1>
                    <?php if ( has_excerpt() ) : ?>
                        <p class="nr-single-dek"><?php echo esc_html( get_the_excerpt() ); ?></p>
                    <?php endif; ?>
                    <div class="nr-single-meta">
                        <span>Par <?php the_author(); ?></span>
                        <span><?php echo esc_html( netradio_format_date() ); ?></span>
                        <span><?php echo esc_html( netradio_reading_time() ); ?></span>
                    </div>
                </div>
            </div>
        <?php else : ?>
            <header class="nr-single-header-classic">
                <?php if ( $cat ) : ?>
                    <div class="nr-single-kicker"><?php echo esc_html( $cat->name ); ?></div>
                <?php endif; ?>
                <h1 class="nr-single-title-classic"><?php the_title(); ?></h1>
                <?php if ( has_excerpt() ) : ?>
                    <p class="nr-single-dek-classic"><?php echo esc_html( get_the_excerpt() ); ?></p>
                <?php endif; ?>
                <div class="nr-single-meta-classic">
                    <span>Par <?php the_author(); ?></span>
                    <span><?php echo esc_html( netradio_format_date() ); ?></span>
                    <span><?php echo esc_html( netradio_reading_time() ); ?></span>
                </div>
            </header>
        <?php endif; ?>

        <div class="nr-single-body-layout">
            <div class="nr-single-body">
                <div class="entry-content">
                    <?php the_content(); ?>
                </div>

                <div class="nr-share">
                    <div class="nr-share-label">Partager cet article</div>
                    <div class="nr-share-buttons">
                        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode( get_permalink() ); ?>" target="_blank" rel="noopener" class="nr-share-btn">Facebook</a>
                        <a href="https://twitter.com/intent/tweet?text=<?php echo urlencode( get_the_title() ); ?>&url=<?php echo urlencode( get_permalink() ); ?>" target="_blank" rel="noopener" class="nr-share-btn">X</a>
                        <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo urlencode( get_permalink() ); ?>" target="_blank" rel="noopener" class="nr-share-btn">LinkedIn</a>
                        <a href="mailto:?subject=<?php echo urlencode( get_the_title() ); ?>&body=<?php echo urlencode( get_permalink() ); ?>" class="nr-share-btn">Email</a>
                    </div>
                </div>
            </div>

            <aside class="nr-single-sidebar">
                <div class="nr-mag-sticky">
                    <?php echo netradio_get_radioboss_widget_html( 8 ); ?>

                    <?php
                    if ( $cat ) :
                        $related = new WP_Query( array(
                            'category__in'   => array( $cat->term_id ),
                            'post__not_in'   => array( get_the_ID() ),
                            'posts_per_page' => 3,
                        ) );
                        if ( $related->have_posts() ) :
                    ?>
                        <div class="nr-related-card">
                            <div class="nr-related-title">À lire aussi</div>
                            <?php while ( $related->have_posts() ) : $related->the_post(); ?>
                                <a href="<?php the_permalink(); ?>" class="nr-related-item">
                                    <div class="nr-related-thumb" style="background-image:url('<?php echo esc_url( netradio_thumbnail_url( 'netradio-thumb' ) ); ?>')"></div>
                                    <div class="nr-related-info">
                                        <div class="nr-related-cat"><?php $rcat = get_the_category(); echo $rcat ? esc_html( $rcat[0]->name ) : ''; ?></div>
                                        <h4><?php the_title(); ?></h4>
                                    </div>
                                </a>
                            <?php endwhile; wp_reset_postdata(); ?>
                        </div>
                    <?php endif; endif; ?>
                </div>
            </aside>
        </div>
    </article>

    <?php
    // Related posts en pleine largeur, en bas de l'article
    $related_posts = netradio_get_related_posts( 4 );
    if ( ! empty( $related_posts ) ) :
    ?>
    <section class="nr-related-section" aria-labelledby="related-heading">
        <div class="nr-related-inner">
            <div class="nr-related-head">
                <h2 id="related-heading" class="nr-related-section-title">À lire aussi</h2>
                <span class="nr-related-line"></span>
            </div>
            <div class="nr-related-grid">
                <?php foreach ( $related_posts as $rp ) :
                    $rp_cats = get_the_category( $rp->ID );
                ?>
                    <article class="nr-related-tile">
                        <a href="<?php echo esc_url( get_permalink( $rp->ID ) ); ?>">
                            <div class="nr-related-tile-image">
                                <img src="<?php echo esc_url( netradio_thumbnail_url( 'netradio-card', $rp->ID ) ); ?>"
                                     alt="<?php echo esc_attr( get_the_title( $rp->ID ) ); ?>"
                                     loading="lazy" decoding="async">
                            </div>
                            <div class="nr-related-tile-content">
                                <?php if ( $rp_cats ) : ?>
                                    <div class="nr-related-tile-kicker"><?php echo esc_html( $rp_cats[0]->name ); ?></div>
                                <?php endif; ?>
                                <h3 class="nr-related-tile-title"><?php echo esc_html( get_the_title( $rp->ID ) ); ?></h3>
                            </div>
                        </a>
                    </article>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>
<?php endif; ?>

<?php endwhile;
get_footer();
