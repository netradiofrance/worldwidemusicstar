<?php
/**
 * Custom Post Types
 *
 * @package NetradioFM
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * CPT : Podcasts
 */
function netradio_register_cpt() {
    register_post_type( 'podcast', array(
        'labels' => array(
            'name'               => 'Podcasts',
            'singular_name'      => 'Podcast',
            'add_new'            => 'Ajouter un podcast',
            'add_new_item'       => 'Ajouter un nouveau podcast',
            'edit_item'          => 'Modifier le podcast',
            'all_items'          => 'Tous les podcasts',
            'menu_name'          => '🎙 Podcasts',
        ),
        'public'              => true,
        'has_archive'         => 'podcasts',
        'rewrite'             => array( 'slug' => 'podcasts' ),
        'menu_icon'           => 'dashicons-microphone',
        'menu_position'       => 25,
        'supports'            => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ),
        'show_in_rest'        => true,
    ) );

    // CPT Émissions
    register_post_type( 'emission', array(
        'labels' => array(
            'name'               => 'Émissions',
            'singular_name'      => 'Émission',
            'add_new'            => 'Ajouter une émission',
            'menu_name'          => '📡 Émissions',
        ),
        'public'              => true,
        'has_archive'         => 'emissions',
        'rewrite'             => array( 'slug' => 'emissions' ),
        'menu_icon'           => 'dashicons-controls-volumeon',
        'menu_position'       => 26,
        'supports'            => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
        'show_in_rest'        => true,
    ) );
}
add_action( 'init', 'netradio_register_cpt' );

/**
 * Meta-box : durée du podcast
 */
function netradio_podcast_meta_box() {
    add_meta_box( 'netradio_podcast_meta', 'Détails du podcast', 'netradio_podcast_meta_html', 'podcast', 'side', 'high' );
}
add_action( 'add_meta_boxes', 'netradio_podcast_meta_box' );

function netradio_podcast_meta_html( $post ) {
    wp_nonce_field( 'netradio_podcast_meta', 'netradio_podcast_meta_nonce' );
    $duration = get_post_meta( $post->ID, '_podcast_duration', true );
    $audio    = get_post_meta( $post->ID, '_podcast_audio', true );
    $frequency = get_post_meta( $post->ID, '_podcast_frequency', true );
    ?>
    <p>
        <label><strong>Durée</strong><br>
            <input type="text" name="podcast_duration" value="<?php echo esc_attr( $duration ); ?>" placeholder="ex: 32 min" style="width:100%;">
        </label>
    </p>
    <p>
        <label><strong>Fréquence</strong><br>
            <select name="podcast_frequency" style="width:100%;">
                <option value="">—</option>
                <option value="Quotidien" <?php selected( $frequency, 'Quotidien' ); ?>>Quotidien</option>
                <option value="Hebdomadaire" <?php selected( $frequency, 'Hebdomadaire' ); ?>>Hebdomadaire</option>
                <option value="Bi-mensuel" <?php selected( $frequency, 'Bi-mensuel' ); ?>>Bi-mensuel</option>
                <option value="Mensuel" <?php selected( $frequency, 'Mensuel' ); ?>>Mensuel</option>
                <option value="Ponctuel" <?php selected( $frequency, 'Ponctuel' ); ?>>Ponctuel</option>
            </select>
        </label>
    </p>
    <p>
        <label><strong>URL audio (MP3)</strong><br>
            <input type="url" name="podcast_audio" value="<?php echo esc_attr( $audio ); ?>" placeholder="https://..." style="width:100%;">
        </label>
    </p>
    <?php
}

function netradio_save_podcast_meta( $post_id ) {
    if ( ! isset( $_POST['netradio_podcast_meta_nonce'] ) ) return;
    if ( ! wp_verify_nonce( $_POST['netradio_podcast_meta_nonce'], 'netradio_podcast_meta' ) ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;

    if ( isset( $_POST['podcast_duration'] ) ) update_post_meta( $post_id, '_podcast_duration', sanitize_text_field( $_POST['podcast_duration'] ) );
    if ( isset( $_POST['podcast_frequency'] ) ) update_post_meta( $post_id, '_podcast_frequency', sanitize_text_field( $_POST['podcast_frequency'] ) );
    if ( isset( $_POST['podcast_audio'] ) ) update_post_meta( $post_id, '_podcast_audio', esc_url_raw( $_POST['podcast_audio'] ) );
}
add_action( 'save_post', 'netradio_save_podcast_meta' );
