<?php
/**
 * Netradio_RadioAirplay_API
 *
 * Connecteur pour la plateforme de playout RadioAirplay (et tout endpoint
 * JSON respectant le même contrat).
 *
 * Contrat attendu :
 *   GET {api_url}
 *   {
 *     "now": { artist, title, album, year, cover, live, listeners,
 *              started_at, duration, type },
 *     "history": [ { artist, title, cover, played_at, type }, ... ]
 *   }
 *
 * Différences majeures avec RadioBoss :
 *   - Les pochettes arrivent DÉJÀ résolues (Spotify CDN ou upload maison)
 *     → l'appel Spotify côté WordPress n'est fait qu'en dernier recours.
 *   - L'historique est DÉJÀ filtré (que de la musique) et complet
 *     → plus besoin de l'historique maison (wp_options) ni du cron.
 *   - Le champ "type" permet de distinguer musique / jingle / pub / voix.
 *   - started_at + duration permettent une barre de progression temps réel.
 *
 * @package NetradioFM
 * @since 2.1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class Netradio_RadioAirplay_API {

	/** URL complète de l'endpoint JSON */
	private $api_url;

	/** Token optionnel (Bearer) — vide = endpoint public */
	private $api_token;

	/** Durée du cache transient, en secondes */
	private $cache_duration;

	/** Clé de cache dérivée de l'URL (permet plusieurs stations) */
	private $cache_key;

	/** Types considérés comme « musique » */
	const TYPES_MUSIC = array( 'music', 'song', 'track' );

	/** Types considérés comme « interruption » (rien à afficher) */
	const TYPES_BREAK = array( 'id', 'jingle', 'sweeper', 'ad', 'ads', 'advert', 'advertising', 'commercial', 'promo', 'spot' );

	public function __construct() {
		$this->api_url        = netradio_get_option( 'api_url', NETRADIO_DEFAULT_API_URL );
		$this->api_token      = netradio_get_option( 'api_token', '' );
		$this->cache_duration = 10;
		$this->cache_key      = 'netradio_ra_' . substr( md5( $this->api_url ), 0, 12 );
	}

	/* ---------------------------------------------------------------------
	 * Requête HTTP + cache
	 * ------------------------------------------------------------------ */

	/**
	 * Récupère et met en cache la réponse brute de l'API.
	 *
	 * @param bool $force Ignorer le cache
	 * @return array|WP_Error
	 */
	private function fetch( $force = false ) {
		if ( ! $force ) {
			$cached = get_transient( $this->cache_key . '_raw' );
			if ( $cached !== false ) {
				return $cached;
			}
		}

		if ( empty( $this->api_url ) ) {
			return new WP_Error( 'no_api_url', __( 'URL de l\'API non configurée.', 'netradio-fm' ) );
		}

		$args = array(
			'timeout' => 5,
			'headers' => array( 'Accept' => 'application/json' ),
		);

		if ( ! empty( $this->api_token ) ) {
			$args['headers']['Authorization'] = 'Bearer ' . $this->api_token;
		}

		$response = wp_remote_get( $this->api_url, $args );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( $code !== 200 ) {
			return new WP_Error(
				'api_error',
				sprintf( __( 'Erreur API RadioAirplay (HTTP %d)', 'netradio-fm' ), $code )
			);
		}

		$data = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( ! is_array( $data ) || ! isset( $data['now'] ) ) {
			return new WP_Error(
				'invalid_response',
				__( 'Réponse invalide : la clé "now" est absente.', 'netradio-fm' )
			);
		}

		set_transient( $this->cache_key . '_raw', $data, $this->cache_duration );

		return $data;
	}

	/* ---------------------------------------------------------------------
	 * Helpers de typage
	 * ------------------------------------------------------------------ */

	private function is_music( $type ) {
		if ( $type === '' ) return true; // pas de type fourni → on suppose musique
		return in_array( strtolower( $type ), self::TYPES_MUSIC, true );
	}

	private function is_break( $type ) {
		return in_array( strtolower( $type ), self::TYPES_BREAK, true );
	}

	/**
	 * Filet de sécurité : exclut les sweepers repérés au texte, si jamais la
	 * plateforme ne renvoyait pas de champ "type".
	 */
	private function is_excluded_track( $artist, $title ) {
		$combined = strtolower( trim( $artist . ' ' . $title ) );
		if ( $combined === '' ) return true;

		$patterns = array( 'netradio', 'radiotarget', 'jingle', 'sweeper', 'advertising', 'ad break' );
		foreach ( $patterns as $p ) {
			if ( strpos( $combined, $p ) !== false ) return true;
		}
		return false;
	}

	private function placeholder() {
		return get_template_directory_uri() . '/assets/images/placeholder-cover.svg';
	}

	/**
	 * Résout la pochette :
	 *   1. celle fournie par la plateforme (déjà HD) — cas le plus fréquent
	 *   2. sinon Spotify via le filtre existant
	 *   3. sinon le placeholder logo Netradio
	 */
	private function resolve_cover( $cover, $artist, $title, $is_music ) {
		$cover = trim( (string) $cover );

		// 1. La plateforme fournit déjà la pochette → on la prend telle quelle.
		if ( $cover !== '' ) {
			return esc_url_raw( $cover );
		}

		if ( ! $is_music ) {
			return $this->placeholder();
		}

		// 2. Repli Spotify (uniquement si la plateforme n'a rien fourni).
		$enriched = apply_filters( 'netradio_nowplaying_data', array(
			'artist' => $artist,
			'title'  => $title,
			'cover'  => $this->placeholder(),
		) );

		return ! empty( $enriched['cover'] ) ? $enriched['cover'] : $this->placeholder();
	}

	/* ---------------------------------------------------------------------
	 * Now playing
	 * ------------------------------------------------------------------ */

	/**
	 * Retourne le morceau en cours, normalisé.
	 *
	 * Les clés artist/title/cover sont prêtes à afficher : pendant un jingle
	 * ou une pub, on renvoie le nom de la station plutôt que le libellé
	 * technique du sweeper.
	 *
	 * @return array|WP_Error
	 */
	public function get_now_playing() {
		$cached = get_transient( $this->cache_key . '_now' );
		if ( $cached !== false ) {
			return $cached;
		}

		$data = $this->fetch();
		if ( is_wp_error( $data ) ) {
			return $data;
		}

		$now = isset( $data['now'] ) && is_array( $data['now'] ) ? $data['now'] : array();

		$raw_artist = isset( $now['artist'] ) ? trim( (string) $now['artist'] ) : '';
		$raw_title  = isset( $now['title'] ) ? trim( (string) $now['title'] ) : '';
		$type       = isset( $now['type'] ) ? strtolower( trim( (string) $now['type'] ) ) : '';

		$is_music   = $this->is_music( $type );
		$is_break   = $this->is_break( $type );
		$station    = netradio_get_option( 'station_name', 'Netradio' );

		if ( $is_break ) {
			// Jingle, ID station, pub : on n'expose pas le libellé technique.
			$artist = '';
			$title  = $station;
			$cover  = $this->placeholder();
		} elseif ( ! $is_music ) {
			// Voix, chronique, talk : contenu éditorial nommé → on garde le titre.
			// Artiste laissé vide si absent : le player affiche déjà
			// « En direct sur Netradio » juste au-dessus.
			$artist = $raw_artist;
			$title  = $raw_title !== '' ? $raw_title : $station;
			$cover  = $this->resolve_cover( isset( $now['cover'] ) ? $now['cover'] : '', $raw_artist, $raw_title, false );
		} else {
			$artist = $raw_artist;
			$title  = $raw_title;
			$cover  = $this->resolve_cover( isset( $now['cover'] ) ? $now['cover'] : '', $raw_artist, $raw_title, true );
			// Filet : réponse incomplète → on affiche le nom de la station
			// plutôt qu'un libellé vide.
			if ( $artist === '' && $title === '' ) {
				$title = $station;
				$cover = $this->placeholder();
			}
		}

		$normalized = array(
			// Champs historiques (compatibilité avec le JS existant)
			'artist'     => $artist,
			'title'      => $title,
			'album'      => isset( $now['album'] ) ? (string) $now['album'] : '',
			'year'       => isset( $now['year'] ) ? (string) $now['year'] : '',
			'cover'      => $cover,
			'listeners'  => isset( $now['listeners'] ) ? intval( $now['listeners'] ) : 0,
			'live'       => ! empty( $now['live'] ),
			'station'    => $station,
			'timestamp'  => time(),

			// Nouveaux champs RadioAirplay
			'type'       => $type,
			'is_music'   => $is_music,
			'is_break'   => $is_break,
			'started_at' => isset( $now['started_at'] ) ? intval( $now['started_at'] ) : 0,
			'duration'   => isset( $now['duration'] ) ? intval( $now['duration'] ) : 0,
			'server_now' => time(), // permet au JS de corriger le décalage d'horloge
			'raw_artist' => $raw_artist,
			'raw_title'  => $raw_title,
		);

		set_transient( $this->cache_key . '_now', $normalized, $this->cache_duration );

		return $normalized;
	}

	/* ---------------------------------------------------------------------
	 * Historique
	 * ------------------------------------------------------------------ */

	/**
	 * Retourne les N derniers titres joués.
	 *
	 * @param int $limit
	 * @return array
	 */
	public function get_history( $limit = 12 ) {
		$limit = max( 1, min( 20, intval( $limit ) ) );

		$cached = get_transient( $this->cache_key . '_hist_' . $limit );
		if ( $cached !== false ) {
			return $cached;
		}

		$data = $this->fetch();
		if ( is_wp_error( $data ) || empty( $data['history'] ) || ! is_array( $data['history'] ) ) {
			return array();
		}

		$history  = array();
		$seen     = array();
		$position = 1;

		foreach ( $data['history'] as $item ) {
			if ( ! is_array( $item ) ) continue;

			$artist = isset( $item['artist'] ) ? trim( (string) $item['artist'] ) : '';
			$title  = isset( $item['title'] ) ? trim( (string) $item['title'] ) : '';
			$type   = isset( $item['type'] ) ? strtolower( trim( (string) $item['type'] ) ) : '';

			if ( $artist === '' && $title === '' ) continue;

			// La plateforme filtre déjà, mais on double la sécurité.
			if ( $type !== '' ) {
				if ( ! $this->is_music( $type ) ) continue;
			} elseif ( $this->is_excluded_track( $artist, $title ) ) {
				continue;
			}

			// Dédoublonnage par couple artiste|titre
			$key = strtolower( $artist . '|' . $title );
			if ( isset( $seen[ $key ] ) ) continue;
			$seen[ $key ] = true;

			$history[] = array(
				'position'  => $position++,
				'artist'    => $artist,
				'title'     => $title,
				'cover'     => $this->resolve_cover( isset( $item['cover'] ) ? $item['cover'] : '', $artist, $title, true ),
				'played_at' => isset( $item['played_at'] ) ? intval( $item['played_at'] ) : 0,
			);

			if ( count( $history ) >= $limit ) break;
		}

		set_transient( $this->cache_key . '_hist_' . $limit, $history, $this->cache_duration );

		return $history;
	}

	/* ---------------------------------------------------------------------
	 * Maintenance / diagnostic
	 * ------------------------------------------------------------------ */

	public function flush_cache() {
		delete_transient( $this->cache_key . '_raw' );
		delete_transient( $this->cache_key . '_now' );
		for ( $i = 1; $i <= 20; $i++ ) {
			delete_transient( $this->cache_key . '_hist_' . $i );
		}
	}

	/**
	 * Test de connexion (bouton « Tester la connexion API » de l'admin).
	 * Même signature que Netradio_RadioBoss_API::test_connection().
	 *
	 * @return array{success:bool,message:string}
	 */
	public function test_connection() {
		if ( empty( $this->api_url ) ) {
			return array(
				'success' => false,
				'message' => __( 'Aucune URL d\'API configurée.', 'netradio-fm' ),
			);
		}

		$this->flush_cache();
		$data = $this->fetch( true );

		if ( is_wp_error( $data ) ) {
			return array( 'success' => false, 'message' => $data->get_error_message() );
		}

		$now      = isset( $data['now'] ) && is_array( $data['now'] ) ? $data['now'] : array();
		$hist     = isset( $data['history'] ) && is_array( $data['history'] ) ? count( $data['history'] ) : 0;
		$type     = isset( $now['type'] ) ? $now['type'] : '';
		$label    = trim( ( isset( $now['artist'] ) ? $now['artist'] : '' ) . ' — ' . ( isset( $now['title'] ) ? $now['title'] : '' ), ' —' );
		$progress = ! empty( $now['started_at'] ) && ! empty( $now['duration'] );

		return array(
			'success' => true,
			'message' => sprintf(
				/* translators: 1: titre en cours, 2: type, 3: nb items historique, 4: état barre de progression */
				__( 'Connexion OK. À l\'antenne : %1$s (type : %2$s). Historique : %3$d titre(s). Barre de progression : %4$s.', 'netradio-fm' ),
				$label !== '' ? $label : '(vide)',
				$type !== '' ? $type : 'non fourni',
				$hist,
				$progress ? 'disponible' : 'indisponible'
			),
		);
	}

	/**
	 * Diagnostic pour la page de réglages : interroge l'API en direct et
	 * renvoie un rapport lisible.
	 *
	 * @return array
	 */
	public function debug_endpoints() {
		$this->flush_cache();
		$data = $this->fetch( true );

		if ( is_wp_error( $data ) ) {
			return array(
				'nowplaying' => array(
					'status' => 'error',
					'error'  => $data->get_error_message(),
					'sample' => '',
				),
			);
		}

		$now       = $this->get_now_playing();
		$history   = $this->get_history( 12 );
		$raw_hist  = isset( $data['history'] ) && is_array( $data['history'] ) ? $data['history'] : array();
		$covered   = 0;
		foreach ( $raw_hist as $h ) {
			if ( ! empty( $h['cover'] ) ) $covered++;
		}

		$report  = "URL : " . $this->api_url . "\n";
		$report .= "Auth : " . ( $this->api_token ? 'Bearer token' : 'aucune (public)' ) . "\n\n";
		$report .= "--- NOW PLAYING ---\n";
		$report .= "Type       : " . ( $now['type'] !== '' ? $now['type'] : '(non fourni)' ) . "\n";
		$report .= "Musique ?  : " . ( $now['is_music'] ? 'oui' : 'non — affichage neutre (logo + nom station)' ) . "\n";
		$report .= "Artiste    : " . ( $now['raw_artist'] !== '' ? $now['raw_artist'] : '(vide)' ) . "\n";
		$report .= "Titre      : " . ( $now['raw_title'] !== '' ? $now['raw_title'] : '(vide)' ) . "\n";
		$report .= "Pochette   : " . ( $now['cover'] ? $now['cover'] : '(aucune)' ) . "\n";
		$report .= "started_at : " . ( $now['started_at'] ? $now['started_at'] . ' (' . date_i18n( 'H:i:s', $now['started_at'] ) . ')' : '(absent)' ) . "\n";
		$report .= "duration   : " . ( $now['duration'] ? $now['duration'] . ' s' : '(absent)' ) . "\n";
		$report .= "Barre de progression : " . ( $now['started_at'] && $now['duration'] ? '✅ disponible' : '❌ indisponible (started_at/duration manquants)' ) . "\n\n";
		$report .= "--- HISTORIQUE ---\n";
		$report .= "Items reçus de l'API : " . count( $raw_hist ) . "\n";
		$report .= "Items retenus (musique, dédoublonnés) : " . count( $history ) . "\n";
		$report .= "Pochettes fournies par la plateforme : " . $covered . " / " . count( $raw_hist ) . "\n";
		$report .= "Repli Spotify nécessaire : " . ( $covered === count( $raw_hist ) && $covered > 0 ? 'non ✅' : 'oui, pour ' . ( count( $raw_hist ) - $covered ) . ' titre(s)' ) . "\n\n";

		foreach ( $history as $h ) {
			$report .= sprintf(
				"%2d. %s — %s\n    %s\n",
				$h['position'],
				$h['artist'] !== '' ? $h['artist'] : '(sans artiste)',
				$h['title'],
				$h['cover']
			);
		}

		$report .= "\n--- JSON BRUT ---\n";
		$report .= wp_json_encode( $data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );

		return array(
			'nowplaying' => array(
				'status'  => 200,
				'is_json' => true,
				'keys'    => array_keys( $data ),
				'sample'  => $report,
			),
		);
	}
}
