<?php
/**
 * Importeur d'articles préremplis (1 clic)
 *
 * Permet de publier en un clic des articles complets formatés en mode Magazine.
 *
 * @package NetradioFM
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class Netradio_Article_Importer {

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'add_menu' ), 11 );
        add_action( 'admin_post_netradio_import_article', array( $this, 'handle_import' ) );
    }

    public function add_menu() {
        add_submenu_page(
            'netradio-settings',
            'Importer un article',
            '📝 Importer Article',
            'publish_posts',
            'netradio-import-article',
            array( $this, 'render_page' )
        );
    }

    /**
     * Liste des articles disponibles à l'import
     */
    public function get_available_articles() {
        return array(
            'ciao-energy' => array(
                'title'    => 'Squeezie, Inox et Léna lancent Ciao Energy',
                'subtitle' => 'L\'article complet sur le lancement du 1er juin 2026',
                'image'    => '🥤',
                'description' => 'Article éditorial magazine de ~2500 mots avec sections, citations, fiche technique, 6 canettes animées, vidéo YouTube intégrée. Couleurs rouge orangé + citrus.',
                'category' => 'Influenceurs',
            ),
        );
    }

    public function render_page() {
        $articles = $this->get_available_articles();
        ?>
        <style>
            .nr-importer { max-width: 900px; margin-top: 20px; }
            .nr-importer h1 { display: flex; align-items: center; gap: 12px; font-size: 28px; }
            .nr-article-card {
                background: white; border: 1px solid #ddd; border-radius: 8px;
                padding: 24px; margin-bottom: 20px;
                display: grid; grid-template-columns: 80px 1fr auto; gap: 24px;
                align-items: center;
            }
            .nr-article-icon {
                font-size: 56px; text-align: center; line-height: 1;
                background: linear-gradient(135deg, #ff3b1f, #e10a16);
                width: 80px; height: 80px; border-radius: 8px;
                display: flex; align-items: center; justify-content: center;
            }
            .nr-article-info h3 { margin: 0 0 6px 0; font-size: 18px; }
            .nr-article-info p { margin: 0; color: #666; font-size: 13px; line-height: 1.5; }
            .nr-article-meta { color: #999; font-size: 11px; text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 8px; }
            .nr-import-btn {
                background: #e10a16; color: white; padding: 14px 24px;
                border: 0; border-radius: 6px; cursor: pointer; font-weight: 700;
                font-size: 14px; white-space: nowrap;
            }
            .nr-import-btn:hover { background: #b00811; }
            .nr-import-btn:disabled { background: #999; cursor: not-allowed; }
            .nr-imported-tag {
                background: #d4edda; color: #155724; padding: 6px 12px;
                border-radius: 4px; font-size: 12px; font-weight: 600;
            }
            .nr-explainer {
                background: #fff3cd; border-left: 4px solid #ffc107;
                padding: 14px 18px; border-radius: 4px; margin-bottom: 24px;
                font-size: 13px; line-height: 1.5;
            }
        </style>

        <div class="wrap nr-importer">
            <h1>📝 Importer un article clé en main</h1>

            <?php if ( isset( $_GET['imported'] ) && $_GET['imported'] === 'success' ) : ?>
                <div class="notice notice-success is-dismissible">
                    <p>✅ <strong>Article publié avec succès !</strong>
                    <a href="<?php echo esc_url( get_permalink( intval( $_GET['post_id'] ) ) ); ?>" target="_blank" style="margin-left:10px;">→ Voir l'article sur le site</a>
                    | <a href="<?php echo esc_url( get_edit_post_link( intval( $_GET['post_id'] ) ) ); ?>">Modifier dans WordPress</a></p>
                </div>
            <?php endif; ?>

            <?php if ( isset( $_GET['imported'] ) && $_GET['imported'] === 'exists' ) : ?>
                <div class="notice notice-warning is-dismissible">
                    <p>⚠️ Cet article existe déjà.
                    <a href="<?php echo esc_url( get_permalink( intval( $_GET['post_id'] ) ) ); ?>" target="_blank">→ Voir l'article existant</a>
                    | <a href="<?php echo esc_url( get_edit_post_link( intval( $_GET['post_id'] ) ) ); ?>">Le modifier</a></p>
                </div>
            <?php endif; ?>

            <div class="nr-explainer">
                💡 <strong>Mode d'emploi :</strong> Clique sur "Publier en 1 clic" → l'article est créé immédiatement avec sa mise en page magazine complète (titre, sous-titre, sections, citations, stats, fiche technique, canettes). Il est publié et visible sur le site tout de suite.
            </div>

            <?php foreach ( $articles as $slug => $article ) :
                $existing = $this->find_existing_post( $slug );
            ?>
                <div class="nr-article-card">
                    <div class="nr-article-icon"><?php echo $article['image']; ?></div>
                    <div class="nr-article-info">
                        <div class="nr-article-meta"><?php echo esc_html( $article['category'] ); ?> · Mode Magazine</div>
                        <h3><?php echo esc_html( $article['title'] ); ?></h3>
                        <p><?php echo esc_html( $article['description'] ); ?></p>
                    </div>
                    <div>
                        <?php if ( $existing ) : ?>
                            <div class="nr-imported-tag">✓ Déjà publié</div>
                            <p style="margin: 8px 0 0 0; text-align: center;">
                                <a href="<?php echo esc_url( get_permalink( $existing ) ); ?>" target="_blank" style="font-size:12px;">Voir →</a>
                            </p>
                            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:12px;" onsubmit="return confirm('Cela va mettre à jour le contenu (titre, corps) de l\'article. L\'image vedette, les tags et les paramètres SEO seront préservés. Continuer ?');">
                                <?php wp_nonce_field( 'netradio_import_' . $slug, '_netradio_nonce' ); ?>
                                <input type="hidden" name="action" value="netradio_import_article">
                                <input type="hidden" name="article_slug" value="<?php echo esc_attr( $slug ); ?>">
                                <input type="hidden" name="force_update" value="1">
                                <button type="submit" class="button button-secondary" style="width:100%;font-size:12px;">🔄 Mettre à jour le contenu</button>
                            </form>
                            <p style="font-size:10px; color:#888; margin:6px 0 0 0; text-align:center; line-height:1.4;">
                                Préserve image vedette, tags, SEO
                            </p>
                        <?php else : ?>
                            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                                <?php wp_nonce_field( 'netradio_import_' . $slug, '_netradio_nonce' ); ?>
                                <input type="hidden" name="action" value="netradio_import_article">
                                <input type="hidden" name="article_slug" value="<?php echo esc_attr( $slug ); ?>">
                                <button type="submit" class="nr-import-btn">⚡ Publier en 1 clic</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>

            <div style="background: #f0f0f1; padding: 18px; border-radius: 6px; font-size: 13px; color: #555; margin-top: 30px;">
                <strong>ℹ️ Comment ça marche :</strong><br>
                — L'article est créé dans <em>Articles → Tous les articles</em> comme n'importe quel post WordPress.<br>
                — Le mode Magazine est activé automatiquement (mise en page éditoriale).<br>
                — La catégorie "Influenceurs" est créée si elle n'existe pas.<br>
                — Tu peux ensuite le modifier librement comme un article normal.<br>
                — Pour ajouter une image à la une : modifie l'article → encart "Image mise en avant" à droite.
            </div>
        </div>
        <?php
    }

    /**
     * Cherche si un article avec ce slug a déjà été importé
     */
    private function find_existing_post( $slug ) {
        $posts = get_posts( array(
            'post_type'      => 'post',
            'meta_key'       => '_netradio_imported_slug',
            'meta_value'     => $slug,
            'posts_per_page' => 1,
            'post_status'    => array( 'publish', 'draft', 'pending' ),
        ) );
        return ! empty( $posts ) ? $posts[0]->ID : false;
    }

    /**
     * Traite l'import
     */
    public function handle_import() {
        if ( ! current_user_can( 'publish_posts' ) ) {
            wp_die( 'Permission refusée' );
        }

        $slug = isset( $_POST['article_slug'] ) ? sanitize_text_field( $_POST['article_slug'] ) : '';
        if ( empty( $slug ) ) {
            wp_redirect( admin_url( 'admin.php?page=netradio-import-article' ) );
            exit;
        }

        check_admin_referer( 'netradio_import_' . $slug, '_netradio_nonce' );

        $force_update = isset( $_POST['force_update'] ) && $_POST['force_update'] === '1';

        // Vérifier qu'il n'existe pas déjà (sauf si on force la mise à jour)
        $existing = $this->find_existing_post( $slug );
        if ( $existing && ! $force_update ) {
            wp_redirect( admin_url( 'admin.php?page=netradio-import-article&imported=exists&post_id=' . $existing ) );
            exit;
        }

        // Import selon le slug — on passe l'ID existant si on veut mettre à jour
        // (sans le supprimer, pour préserver thumbnail/tags/meta)
        switch ( $slug ) {
            case 'ciao-energy':
                $post_id = $this->import_ciao_energy( $existing );
                break;
            default:
                wp_redirect( admin_url( 'admin.php?page=netradio-import-article' ) );
                exit;
        }

        if ( $post_id && ! is_wp_error( $post_id ) ) {
            update_post_meta( $post_id, '_netradio_imported_slug', $slug );
            update_post_meta( $post_id, '_netradio_magazine_mode', 'yes' );
            wp_redirect( admin_url( 'admin.php?page=netradio-import-article&imported=success&post_id=' . $post_id ) );
        } else {
            wp_redirect( admin_url( 'admin.php?page=netradio-import-article&imported=error' ) );
        }
        exit;
    }

    /**
     * Crée ou récupère une catégorie
     */
    private function ensure_category( $name ) {
        $cat = get_term_by( 'name', $name, 'category' );
        if ( $cat ) return $cat->term_id;
        $result = wp_insert_term( $name, 'category' );
        return is_wp_error( $result ) ? 1 : $result['term_id'];
    }

    /**
     * Article : Ciao Energy
    /**
     * Import (ou update) de l'article Ciao Energy
     * @param int|false $existing_id Si fourni, met à jour l'article au lieu d'en créer un nouveau
     *                               → Préserve thumbnail, tags, commentaires, meta SEO existants
     */
    private function import_ciao_energy( $existing_id = false ) {
        $content = $this->get_ciao_energy_content();

        $cat_id = $this->ensure_category( 'Influenceurs' );

        $title   = 'Squeezie, Inox et Léna lancent Ciao Energy : le trio qui veut détrôner Prime';
        $excerpt = '6 saveurs, 1,49 €, et un trio qui pèse 100 millions d\'abonnés. Sortie le 1er juin 2026 — pourquoi cette boisson énergisante peut tout faire exploser sur le marché français.';

        if ( $existing_id ) {
            // === MODE UPDATE : préserve thumbnail, tags, meta SEO, commentaires ===
            $post_data = array(
                'ID'           => $existing_id,
                'post_title'   => $title,
                'post_content' => $content,
                'post_excerpt' => $excerpt,
                'post_status'  => 'publish',
                // PAS de post_author : on garde l'auteur d'origine
                // PAS de post_category : on garde les catégories existantes
            );
            $post_id = wp_update_post( $post_data, true );

            if ( ! is_wp_error( $post_id ) ) {
                // S'assurer que la catégorie Influenceurs est toujours associée
                // (sans écraser les autres catégories)
                $current_cats = wp_get_post_categories( $post_id );
                if ( ! in_array( $cat_id, $current_cats ) ) {
                    $current_cats[] = $cat_id;
                    wp_set_post_categories( $post_id, $current_cats );
                }
                // Note : on NE TOUCHE PAS aux tags, thumbnail, ou autres meta
            }
        } else {
            // === MODE CRÉATION : nouvel article ===
            $post_data = array(
                'post_title'    => $title,
                'post_content'  => $content,
                'post_excerpt'  => $excerpt,
                'post_status'   => 'publish',
                'post_author'   => get_current_user_id(),
                'post_category' => array( $cat_id ),
                'post_type'     => 'post',
            );
            $post_id = wp_insert_post( $post_data, true );

            if ( ! is_wp_error( $post_id ) ) {
                // Tags initiaux (uniquement à la création)
                wp_set_post_tags( $post_id, array( 'Squeezie', 'Inoxtag', 'Léna Situations', 'Ciao Energy', 'Boisson énergisante' ) );

                // FAQ Schema d'exemple (Google rich snippet)
                update_post_meta( $post_id, '_netradio_faqs', array(
                    array(
                        'q' => 'Combien coûte une canette de Ciao Energy ?',
                        'a' => '1,49 € pour une canette de 250ml. Le prix se situe sous Red Bull (1,89 €) et au niveau de Monster.',
                    ),
                    array(
                        'q' => 'Qui sont les fondateurs de Ciao Energy ?',
                        'a' => 'Squeezie (Lucas Hauchard), Inoxtag et Léna Situations (Léna Mahfouf). Le projet est porté par Banger Ventures, le fonds opérationnel co-fondé par Squeezie en 2023.',
                    ),
                    array(
                        'q' => 'Où acheter Ciao Energy ?',
                        'a' => 'Dans tous les Carrefour, Auchan, Monoprix, Franprix, Casino, Intermarché et les stations-service Total Energies depuis le 1er juin 2026, soit environ 90% du retail food français.',
                    ),
                    array(
                        'q' => 'Quelles sont les 6 saveurs de Ciao Energy ?',
                        'a' => 'Double Litchi, Coco-Citron Vert, Kiwi-Concombre, Pêche Blanche, Pomme-Rhubarbe et Abricot-Framboise.',
                    ),
                    array(
                        'q' => 'Combien de sucre contient Ciao Energy ?',
                        'a' => '4g de sucre pour 100ml, contre 11g pour Red Bull. La marque utilise la stévia comme édulcorant naturel principal, complétée par un édulcorant de synthèse.',
                    ),
                ) );
            }
        }

        return $post_id;
    }

    /**
     * Le contenu complet de l'article Ciao Energy (avec shortcodes magazine)
     * HTML propre — pas de Markdown ** **
     */
    private function get_ciao_energy_content() {
        return <<<'CONTENT'
[mag_hero kicker="DOSSIER · BOISSONS ÉNERGISANTES" dek="6 saveurs, 1,49 €, et un trio qui pèse 100 millions d'abonnés. La boisson qui vise Prime débarque dans tous les Carrefour de France." byline="Par la rédaction Netradio" date="1 juin 2026"]
Squeezie, Inox et Léna lancent <em>Ciao Energy</em>.
[/mag_hero]

[mag_cans]

[mag_video url="https://www.youtube.com/watch?v=Ki_zL-eYvzY"]

[mag_lead]Le 1er juin 2026, Lucas Hauchard (Squeezie, 21M d'abonnés), Inès Reg ah non, pardon — <strong>Inoxtag</strong> (8M d'abonnés, ascensionniste de l'Everest) et <strong>Léna Mahfouf</strong> alias Léna Situations (5,5M d'abonnés, papesse de la mode TikTok française) lancent ensemble <strong>Ciao Energy</strong>, une boisson énergisante en 6 saveurs vendue 1,49 € la canette. Objectif déclaré : devenir le numéro 1 français du segment, devant Red Bull, Monster, et surtout Prime Hydration qui s'effondre depuis 18 mois.[/mag_lead]

[mag_section num="01" title="Le pari : transformer 100 millions d'abonnés en parts de marché"]
Le trio n'arrive pas en touriste. Derrière Ciao Energy se cache <strong>Banger Ventures</strong>, le fonds opérationnel co-fondé par Squeezie en 2023, qui a déjà fait sortir <strong>Ciao Kombucha</strong> en 2024 — un produit qui a généré <strong>23 millions d'euros de chiffre d'affaires en 2025</strong> selon les données Circana relayées par LSA Conso. Une preuve de concept qui valide leur capacité à transformer une audience en linéaire de supermarché.

La distribution est massive dès le J1 : <strong>Carrefour, Auchan, Monoprix, Franprix, Casino, Intermarché</strong>, plus une présence dans les stations-service Total Energies. C'est-à-dire 90% du retail food en France couvert dès la première semaine. Aucune marque créateur n'avait jusqu'ici réussi ce déploiement initial — pas même Feastables, dont MrBeast a mis 18 mois à atteindre une couverture comparable.

[mag_quote cite="—Lucas \"Squeezie\" Hauchard, dans la story Instagram de lancement"]
On a passé deux ans à formuler ce produit avec une vraie équipe de nutritionnistes. On n'a pas voulu sortir un truc qui ressemble à du Red Bull avec notre tête dessus. On voulait quelque chose qu'on consommerait nous-mêmes, tous les jours.
[/mag_quote]
[/mag_section]

[mag_section num="02" title="Le produit : moins de sucre, plus de fruits, et la stévia"]
La composition tranche avec le standard du marché. Là où une canette Red Bull contient <strong>11g de sucre / 100ml</strong> et 32mg de caféine, Ciao Energy affiche <strong>4g de sucre / 100ml</strong> et la même teneur en caféine (32mg). La différence se joue sur la <strong>stévia</strong> comme édulcorant naturel, et un édulcorant de synthèse en complément.

Les six saveurs ont été annoncées hier en exclu sur le compte TikTok de Léna :

[mag_fiche title="Les 6 saveurs Ciao Energy"]
[mag_spec key="N°1" val="Double Litchi <em>(le best-seller annoncé)</em>"]
[mag_spec key="N°2" val="Coco-Citron Vert"]
[mag_spec key="N°3" val="Kiwi-Concombre"]
[mag_spec key="N°4" val="Pêche Blanche"]
[mag_spec key="N°5" val="Pomme-Rhubarbe"]
[mag_spec key="N°6" val="Abricot-Framboise"]
[/mag_fiche]

L'embouteillage est <strong>100% français</strong> (Bourgogne-Franche-Comté), un argument que le trio a martelé toute la matinée sur Instagram. Le prix de 1,49 € la canette de 250ml positionne Ciao Energy <strong>sous Red Bull</strong> (1,89 €) et <strong>au niveau de Monster</strong> (1,49 €) — un sweet spot pensé pour les 15-25 ans, cœur de cible.
[/mag_section]

[mag_divider]

[mag_section num="03" title="Le contexte : Prime Hydration s'écroule, le marché est ouvert"]
Le timing n'est pas un hasard. Le segment des boissons énergisantes connaît un séisme depuis 2024. <strong>Prime Hydration</strong>, lancée en 2022 par Logan Paul et KSI, a vu ses ventes chuter de <strong>76%</strong> entre 2023 et 2025 selon NielsenIQ. La marque, qui avait généré 1,2 milliard de dollars sur sa première année, s'effondre face à la lassitude du public et aux controverses (teneurs en caféine, fuites en magasins).

[mag_stats]
[mag_stat num="50%" label="Part de marché Red Bull en France"]
[mag_stat num="32%" label="Part de marché Monster" style="accent"]
[mag_stat num="-76%" label="Chute de Prime depuis 2023"]
[mag_stat num="251 M$" label="CA Feastables 2024" style="citrus"]
[/mag_stats]

Le marché français reste dominé à 82% par le duopole <strong>Red Bull / Monster</strong>. Les 18% restants se répartissent entre une dizaine de marques sans leader clair. C'est précisément cette brèche que Ciao Energy vise. Et le trio Squeezie / Inoxtag / Léna a une carte que personne d'autre n'a pu jouer : <strong>une audience cumulée de 100 millions d'abonnés à 70% francophone</strong>.
[/mag_section]

[mag_section num="04" title="Banger Ventures : la vraie machine derrière le produit"]
On parle beaucoup des trois visages, mais le vrai sujet stratégique, c'est <strong>Banger Ventures</strong>. Ce n'est pas une simple agence ni un fonds : c'est un co-fondateur opérationnel qui prend en charge tout ce que les créateurs ne savent pas faire — la R&D produit, les négociations avec les centrales d'achat, la logistique, le SAV.

[mag_quote cite="—Marc Boidin, co-fondateur de Banger Ventures, à LSA Conso (mai 2026)"]
Notre rôle, c'est de transformer une influence en marque pérenne. Beaucoup d'influenceurs se brûlent les ailes en sortant un produit médiocre. Nous, on prend deux ans pour bien faire, parce qu'on sait qu'une marque créateur qui rate son lancement est morte.
[/mag_quote]

Pour Ciao Energy, Banger a investi <strong>~8 millions d'euros</strong> sur 24 mois en R&D, sourcing, formulation et test consommateurs (informations issues de leur communication officielle). Un investissement comparable à ce que Coca-Cola peut mobiliser pour un lancement franchise.
[/mag_section]

[mag_section num="05" title="Et maintenant ? Les 3 scénarios à 12 mois"]
Trois scénarios se dessinent pour l'avenir immédiat de la marque.

<strong>Scénario 1 — Le carton.</strong> Ciao Energy fait 40 à 60 millions d'euros de CA sur 12 mois, devient n°3 du marché français derrière Red Bull et Monster, et déclenche une vague de copycats chez les autres gros créateurs français (Michou, Joyca, Lufy, etc.). Probabilité : <strong>élevée</strong>, vu la préparation et la distribution.

<strong>Scénario 2 — Le plateau.</strong> Le produit fait 15-25 M€ de CA, ce qui est confortable mais en-dessous du buzz attendu. Les 3 fondateurs garderaient la marque comme actif rentable sans en faire un leader. C'est ce que vivent la plupart des "boissons d'influenceurs" qui durent.

<strong>Scénario 3 — L'effet Prime.</strong> Lancement explosif, puis dégonflement rapide au S2 2027 si la qualité produit ne suit pas, ou si l'un des trois fondateurs traverse une mauvaise passe médiatique. Probabilité : faible mais non nulle.

[mag_highlight]Le vrai juge de paix sera le taux de réachat à 3 mois.[/mag_highlight] Si les consommateurs reviennent — ce qui n'a pas été le cas pour Prime — alors Ciao Energy peut s'installer durablement.
[/mag_section]

[mag_divider symbol="⚡ ⚡ ⚡"]

[mag_section num="06" title="L'avis de la rédac"]
Trois choses nous font penser que Ciao Energy peut réussir là où Prime a échoué.

<strong>Un :</strong> le produit semble avoir été pensé en premier, pas la com'. La R&D Banger sur 24 mois en témoigne, et la composition (4g de sucre, stévia, embouteillage France) n'est pas un alignement de cases marketing.

<strong>Deux :</strong> les trois fondateurs ont des audiences <em>complémentaires</em>, pas redondantes. Squeezie touche les 15-25 ans gaming, Inoxtag les 12-20 ans aventure / sport, Léna les 18-28 ans mode/lifestyle. Pas de cannibalisation des cibles, donc effet multiplicateur réel.

<strong>Trois :</strong> le prix. À 1,49 €, on est dans la zone d'achat impulsif. Une canette ne se "décide" pas, elle se prend. C'est l'opposé de la stratégie premium de Prime qui demandait au consommateur de payer 3,50 € pour goûter — un blocage psychologique qui s'est confirmé.

Reste l'inconnue : <em>la lassitude.</em> Le public influence-driven n'est plus aussi captif qu'en 2022. La rédaction parie quand même que <strong>Ciao Energy sera le plus gros lancement food français de l'année</strong>. Rendez-vous dans 6 mois.
[/mag_section]
CONTENT;
    }
}

new Netradio_Article_Importer();
