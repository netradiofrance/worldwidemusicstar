<?php
/**
 * Widgets
 *
 * @package NetradioFM
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Zones de widgets
 */
function netradio_widgets_init() {
    register_sidebar( array(
        'name'          => 'Sidebar Articles',
        'id'            => 'sidebar-article',
        'description'   => 'Affichée à droite des articles individuels',
        'before_widget' => '<div class="nr-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="nr-widget-title">',
        'after_title'   => '</h4>',
    ) );

    register_sidebar( array(
        'name'          => 'Footer Colonne 2',
        'id'            => 'footer-2',
        'before_widget' => '<div class="nr-footer-col %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h5>',
        'after_title'   => '</h5>',
    ) );

    register_sidebar( array(
        'name'          => 'Footer Colonne 3',
        'id'            => 'footer-3',
        'before_widget' => '<div class="nr-footer-col %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h5>',
        'after_title'   => '</h5>',
    ) );

    register_sidebar( array(
        'name'          => 'Footer Colonne 4',
        'id'            => 'footer-4',
        'before_widget' => '<div class="nr-footer-col %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h5>',
        'after_title'   => '</h5>',
    ) );
}
add_action( 'widgets_init', 'netradio_widgets_init' );

/**
 * Widget : Joués récemment (utilisable n'importe où via shortcode ou widget)
 */
class Netradio_Recent_Tracks_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct(
            'netradio_recent_tracks',
            '📻 Joués récemment',
            array( 'description' => 'Affiche le now-playing + l\'historique des titres' )
        );
    }

    public function widget( $args, $instance ) {
        $count = isset( $instance['count'] ) ? intval( $instance['count'] ) : 8;
        echo $args['before_widget'];
        if ( ! empty( $instance['title'] ) ) {
            echo $args['before_title'] . esc_html( $instance['title'] ) . $args['after_title'];
        }
        echo netradio_get_radioboss_widget_html( $count );
        echo $args['after_widget'];
    }

    public function form( $instance ) {
        $title = ! empty( $instance['title'] ) ? $instance['title'] : 'En direct';
        $count = ! empty( $instance['count'] ) ? $instance['count'] : 8;
        ?>
        <p>
            <label for="<?php echo $this->get_field_id( 'title' ); ?>">Titre :</label>
            <input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'count' ); ?>">Nb de titres historique :</label>
            <input class="widefat" id="<?php echo $this->get_field_id( 'count' ); ?>" name="<?php echo $this->get_field_name( 'count' ); ?>" type="number" min="4" max="20" value="<?php echo esc_attr( $count ); ?>">
        </p>
        <?php
    }

    public function update( $new, $old ) {
        return array(
            'title' => sanitize_text_field( $new['title'] ),
            'count' => max( 4, min( 20, intval( $new['count'] ) ) ),
        );
    }
}

function netradio_register_widgets() {
    register_widget( 'Netradio_Recent_Tracks_Widget' );
}
add_action( 'widgets_init', 'netradio_register_widgets' );

/**
 * Helper : HTML du widget radio (réutilisable)
 */
function netradio_get_radioboss_widget_html( $count = 8 ) {
    ob_start();
    ?>
    <div class="nr-radioboss-widget" data-history-count="<?php echo intval( $count ); ?>">
        <div class="nr-side-header">
            <span>📻</span> Sur l'antenne maintenant
        </div>
        <div class="nr-now-playing">
            <img class="nr-cover" src="<?php echo esc_url( NETRADIO_URI . '/assets/images/placeholder-cover.svg' ); ?>" alt="Cover" data-nr-cover>
            <div class="nr-now-info">
                <div class="nr-now-label">EN DIRECT</div>
                <div class="nr-now-title" data-nr-title>Chargement…</div>
                <div class="nr-now-artist" data-nr-artist>—</div>
            </div>
        </div>
        <div class="nr-history-title">Joués précédemment</div>
        <div class="nr-history" data-nr-history></div>
    </div>
    <?php
    return ob_get_clean();
}

// Shortcode [netradio_widget]
add_shortcode( 'netradio_widget', function( $atts ) {
    $atts = shortcode_atts( array( 'count' => 8 ), $atts );
    return netradio_get_radioboss_widget_html( intval( $atts['count'] ) );
} );
