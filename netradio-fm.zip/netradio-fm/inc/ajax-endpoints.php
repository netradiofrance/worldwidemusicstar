<?php
/**
 * Endpoints AJAX
 *
 * Le front-end appelle ces endpoints. Le PHP fait le proxy vers RadioBoss
 * → la clé API ne quitte jamais le serveur.
 *
 * @package NetradioFM
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * AJAX : récupérer le now-playing + historique
 */
function netradio_ajax_get_radio_data() {
    // Vérifier le nonce
    if ( ! isset( $_GET['nonce'] ) || ! wp_verify_nonce( $_GET['nonce'], 'netradio_radioboss_nonce' ) ) {
        wp_send_json_error( array( 'message' => 'Nonce invalide' ), 403 );
    }

    $api = netradio_api();
    $now = $api->get_now_playing();
    $hist_count = isset( $_GET['history'] ) ? max( 1, min( 20, intval( $_GET['history'] ) ) ) : 12;

    if ( is_wp_error( $now ) ) {
        // On renvoie quand même les artworks (qui ne nécessitent pas l'API)
        wp_send_json_error( array(
            'message' => $now->get_error_message(),
            'code'    => $now->get_error_code(),
        ), 200 ); // 200 car on veut que JS continue à afficher le fallback
    }

    $history = $api->get_history( $hist_count );

    wp_send_json_success( array(
        'now'     => $now,
        'history' => $history,
    ) );
}
add_action( 'wp_ajax_netradio_get_radio_data', 'netradio_ajax_get_radio_data' );
add_action( 'wp_ajax_nopriv_netradio_get_radio_data', 'netradio_ajax_get_radio_data' );

/**
 * AJAX : test de connexion API (admin seulement)
 */
function netradio_ajax_test_api() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( array( 'message' => 'Non autorisé' ), 403 );
    }

    check_ajax_referer( 'netradio_test_api', 'nonce' );

    $api = netradio_api();
    $result = $api->test_connection();

    if ( $result['success'] ) {
        wp_send_json_success( $result );
    } else {
        wp_send_json_error( $result );
    }
}
add_action( 'wp_ajax_netradio_test_api', 'netradio_ajax_test_api' );

/**
 * AJAX : vider le cache (admin)
 */
function netradio_ajax_flush_cache() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( array( 'message' => 'Non autorisé' ), 403 );
    }
    check_ajax_referer( 'netradio_flush_cache', 'nonce' );

    $api = netradio_api();
    $api->flush_cache();

    wp_send_json_success( array( 'message' => __( 'Cache vidé.', 'netradio-fm' ) ) );
}
add_action( 'wp_ajax_netradio_flush_cache', 'netradio_ajax_flush_cache' );

/**
 * AJAX : vider l'historique maison (admin)
 */
function netradio_ajax_flush_history() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( array( 'message' => 'Non autorisé' ), 403 );
    }
    check_ajax_referer( 'netradio_flush_history', 'nonce' );

    delete_option( 'netradio_track_history' );

    // Aussi vider les caches transient d'historique
    $station_id = netradio_get_option( 'station_id', '847' );
    for ( $i = 1; $i <= 20; $i++ ) {
        delete_transient( 'netradio_history_' . $station_id . '_' . $i );
    }

    wp_send_json_success( array( 'message' => __( 'Historique des titres vidé. Il se reconstruira au fil des morceaux joués.', 'netradio-fm' ) ) );
}
add_action( 'wp_ajax_netradio_flush_history', 'netradio_ajax_flush_history' );

/**
 * AJAX : debug des endpoints API RadioBoss
 */
function netradio_ajax_debug_api() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( array( 'message' => 'Non autorisé' ), 403 );
    }
    check_ajax_referer( 'netradio_debug_api', 'nonce' );

    $api = netradio_api();
    $results = $api->debug_endpoints();

    wp_send_json_success( $results );
}
add_action( 'wp_ajax_netradio_debug_api', 'netradio_ajax_debug_api' );

/**
 * AJAX : enregistrer le décalage d'affichage mesuré par le diagnostic.
 */
function netradio_ajax_save_delay() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( array( 'message' => 'Non autorisé' ), 403 );
    }
    check_ajax_referer( 'netradio_save_delay', 'nonce' );

    $delay = isset( $_POST['delay'] ) ? max( 0, min( 300, intval( $_POST['delay'] ) ) ) : 0;

    $options = get_option( 'netradio_settings', array() );
    $options['metadata_delay'] = $delay;
    update_option( 'netradio_settings', $options );

    wp_send_json_success( array(
        'delay'   => $delay,
        'message' => sprintf( __( 'Décalage réglé sur %d s.', 'netradio-fm' ), $delay ),
    ) );
}
add_action( 'wp_ajax_netradio_save_delay', 'netradio_ajax_save_delay' );
