<?php
/**
 * Customizer WordPress
 *
 * @package NetradioFM
 */

if ( ! defined( 'ABSPATH' ) ) exit;

function netradio_customize_register( $wp_customize ) {
    // Section : Identité
    $wp_customize->add_section( 'netradio_identity', array(
        'title'    => '📻 Netradio — Identité',
        'priority' => 30,
    ) );

    // Slogan
    $wp_customize->add_setting( 'netradio_tagline', array(
        'default'           => 'Like Station',
        'sanitize_callback' => 'sanitize_text_field',
    ) );
    $wp_customize->add_control( 'netradio_tagline', array(
        'label'   => 'Slogan affiché',
        'section' => 'netradio_identity',
        'type'    => 'text',
    ) );

    // Couleur primaire
    $wp_customize->add_setting( 'netradio_primary_color', array(
        'default'           => '#e10a16',
        'sanitize_callback' => 'sanitize_hex_color',
    ) );
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'netradio_primary_color', array(
        'label'   => 'Couleur primaire (rouge Netradio)',
        'section' => 'netradio_identity',
    ) ) );

    // Section : Hero homepage
    $wp_customize->add_section( 'netradio_hero', array(
        'title'    => '🎬 Hero Homepage',
        'priority' => 31,
    ) );

    $wp_customize->add_setting( 'netradio_hero_category', array(
        'default'           => 'a-la-une',
        'sanitize_callback' => 'sanitize_text_field',
    ) );
    $wp_customize->add_control( 'netradio_hero_category', array(
        'label'       => 'Slug de catégorie pour le hero',
        'description' => 'L\'article le plus récent de cette catégorie sera mis en hero. Laissez vide pour utiliser le dernier article publié.',
        'section'     => 'netradio_hero',
        'type'        => 'text',
    ) );
}
add_action( 'customize_register', 'netradio_customize_register' );

/**
 * Injecter les couleurs custom dans le head
 */
function netradio_customizer_css() {
    $primary = get_theme_mod( 'netradio_primary_color', '#e10a16' );
    echo '<style>:root { --nr-red: ' . esc_attr( $primary ) . '; }</style>';
}
add_action( 'wp_head', 'netradio_customizer_css' );
