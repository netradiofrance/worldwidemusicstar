<?php
/**
 * Intégration Spotify Web API
 *
 * Quand l'artiste + titre arrivent de RadioBoss, on les passe à Spotify
 * pour récupérer une pochette haute qualité + lien d'écoute.
 *
 * Le token d'accès est obtenu via Client Credentials Flow et caché 1h.
 *
 * @package NetradioFM
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class Netradio_Spotify_API {

    private $client_id;
    private $client_secret;
    private $token_cache_key = 'netradio_spotify_token';
    private $track_cache_duration = 3600; // 1h par morceau

    public function __construct() {
        $this->client_id     = netradio_get_option( 'spotify_client_id', '' );
        $this->client_secret = netradio_get_option( 'spotify_client_secret', '' );
    }

    /**
     * Spotify est-il configuré ?
     */
    public function is_configured() {
        return ! empty( $this->client_id ) && ! empty( $this->client_secret );
    }

    /**
     * Obtenir un token d'accès (Client Credentials Flow)
     */
    private function get_access_token() {
        $cached = get_transient( $this->token_cache_key );
        if ( $cached ) return $cached;

        if ( ! $this->is_configured() ) return false;

        $response = wp_remote_post( 'https://accounts.spotify.com/api/token', array(
            'timeout' => 5,
            'headers' => array(
                'Authorization' => 'Basic ' . base64_encode( $this->client_id . ':' . $this->client_secret ),
                'Content-Type'  => 'application/x-www-form-urlencoded',
            ),
            'body'    => array( 'grant_type' => 'client_credentials' ),
        ) );

        if ( is_wp_error( $response ) ) {
            return false;
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( ! isset( $body['access_token'] ) ) {
            return false;
        }

        // Cache un peu moins longtemps que la validité pour éviter les expirations
        $duration = isset( $body['expires_in'] ) ? max( 60, intval( $body['expires_in'] ) - 60 ) : 3300;
        set_transient( $this->token_cache_key, $body['access_token'], $duration );

        return $body['access_token'];
    }

    /**
     * Chercher un morceau sur Spotify avec stratégie de recherche progressive
     *
     * Essai 1 : recherche stricte "artist:X track:Y" (la plus précise)
     * Essai 2 : recherche libre "X Y" (plus permissive)
     * Essai 3 : recherche du titre seul si l'artiste est obscur
     *
     * @return array|false { cover, cover_large, spotify_url, preview_url, album, year }
     */
    public function search_track( $artist, $title ) {
        if ( ! $this->is_configured() ) return false;
        if ( empty( $artist ) && empty( $title ) ) return false;

        // Cache par morceau (basé sur artiste+titre)
        $cache_key = 'netradio_sp_' . md5( strtolower( $artist . '|' . $title ) );
        $cached = get_transient( $cache_key );
        if ( $cached !== false ) {
            // Note : on cache aussi les "non trouvés" (= null) pour ne pas spammer Spotify
            return $cached === 'NOT_FOUND' ? false : $cached;
        }

        $token = $this->get_access_token();
        if ( ! $token ) return false;

        // Nettoyer les chaînes (enlever (feat. xxx), [Remix], etc. qui perturbent la recherche)
        $clean_artist = $this->clean_search_term( $artist );
        $clean_title  = $this->clean_search_term( $title );

        // Tentatives successives
        $queries = array();
        if ( ! empty( $clean_artist ) && ! empty( $clean_title ) ) {
            // Essai 1 : strict
            $queries[] = 'artist:' . $clean_artist . ' track:' . $clean_title;
            // Essai 2 : libre
            $queries[] = $clean_artist . ' ' . $clean_title;
        } elseif ( ! empty( $clean_title ) ) {
            $queries[] = 'track:' . $clean_title;
            $queries[] = $clean_title;
        } elseif ( ! empty( $clean_artist ) ) {
            $queries[] = 'artist:' . $clean_artist;
        }

        $result = false;
        foreach ( $queries as $query ) {
            $result = $this->do_spotify_search( $query, $token );
            if ( $result ) break;
        }

        if ( $result ) {
            set_transient( $cache_key, $result, $this->track_cache_duration );
        } else {
            // Cacher le "non trouvé" 30 min pour éviter de re-chercher en boucle
            set_transient( $cache_key, 'NOT_FOUND', 1800 );
        }

        return $result;
    }

    /**
     * Nettoie les termes de recherche pour augmenter le taux de match
     */
    private function clean_search_term( $str ) {
        if ( empty( $str ) ) return '';
        // Enlever (feat. xxx), (with xxx), [Remix], etc.
        $str = preg_replace( '/\s*\((feat|ft|featuring|with|avec)\.?\s+[^)]+\)/i', '', $str );
        $str = preg_replace( '/\s*\[(remix|edit|version|mix|extended)[^\]]*\]/i', '', $str );
        $str = preg_replace( '/\s*-\s*(remix|edit|version|radio edit|extended mix).*$/i', '', $str );
        // Normaliser les espaces
        $str = preg_replace( '/\s+/', ' ', $str );
        return trim( $str );
    }

    /**
     * Effectue une recherche Spotify et retourne le 1er résultat normalisé
     */
    private function do_spotify_search( $query, $token ) {
        $url = 'https://api.spotify.com/v1/search?' . http_build_query( array(
            'q'      => $query,
            'type'   => 'track',
            'limit'  => 1,
            'market' => 'FR',
        ) );

        $response = wp_remote_get( $url, array(
            'timeout' => 5,
            'headers' => array( 'Authorization' => 'Bearer ' . $token ),
        ) );

        if ( is_wp_error( $response ) ) return false;
        if ( wp_remote_retrieve_response_code( $response ) !== 200 ) return false;

        $data = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( empty( $data['tracks']['items'][0] ) ) return false;

        $track  = $data['tracks']['items'][0];
        $images = isset( $track['album']['images'] ) ? $track['album']['images'] : array();

        $cover_large = ! empty( $images[0]['url'] ) ? $images[0]['url'] : '';
        $cover       = ! empty( $images[1]['url'] ) ? $images[1]['url'] : $cover_large;

        return array(
            'cover'       => $cover,
            'cover_large' => $cover_large,
            'spotify_url' => isset( $track['external_urls']['spotify'] ) ? $track['external_urls']['spotify'] : '',
            'preview_url' => isset( $track['preview_url'] ) ? $track['preview_url'] : '',
            'album'       => isset( $track['album']['name'] ) ? $track['album']['name'] : '',
            'year'        => isset( $track['album']['release_date'] ) ? substr( $track['album']['release_date'], 0, 4 ) : '',
            'popularity'  => isset( $track['popularity'] ) ? $track['popularity'] : 0,
            'artist_id'   => isset( $track['artists'][0]['id'] ) ? $track['artists'][0]['id'] : '',
        );
    }

    /**
     * Test de connexion (utilisé dans l'admin)
     */
    public function test_connection() {
        if ( ! $this->is_configured() ) {
            return array(
                'success' => false,
                'message' => __( 'Client ID ou Client Secret manquant.', 'netradio-fm' ),
            );
        }

        $token = $this->get_access_token();
        if ( ! $token ) {
            return array(
                'success' => false,
                'message' => __( 'Impossible d\'obtenir un token Spotify. Vérifiez vos identifiants.', 'netradio-fm' ),
            );
        }

        // Test avec une recherche connue
        $test = $this->search_track( 'Daft Punk', 'Get Lucky' );
        if ( ! $test ) {
            return array(
                'success' => false,
                'message' => __( 'Token obtenu mais recherche échouée.', 'netradio-fm' ),
            );
        }

        return array(
            'success'      => true,
            'message'      => __( 'Connexion Spotify réussie !', 'netradio-fm' ),
            'test_cover'   => $test['cover'],
            'test_album'   => $test['album'],
        );
    }
}

/**
 * AJAX : enrichir un morceau via Spotify
 */
function netradio_ajax_spotify_enrich() {
    if ( ! isset( $_GET['nonce'] ) || ! wp_verify_nonce( $_GET['nonce'], 'netradio_radioboss_nonce' ) ) {
        wp_send_json_error( array( 'message' => 'Nonce invalide' ), 403 );
    }

    $artist = isset( $_GET['artist'] ) ? sanitize_text_field( wp_unslash( $_GET['artist'] ) ) : '';
    $title  = isset( $_GET['title'] ) ? sanitize_text_field( wp_unslash( $_GET['title'] ) ) : '';

    if ( empty( $artist ) && empty( $title ) ) {
        wp_send_json_error( array( 'message' => 'Artiste ou titre requis' ) );
    }

    $spotify = new Netradio_Spotify_API();
    if ( ! $spotify->is_configured() ) {
        wp_send_json_error( array( 'message' => 'Spotify non configuré' ) );
    }

    $result = $spotify->search_track( $artist, $title );
    if ( ! $result ) {
        wp_send_json_error( array( 'message' => 'Non trouvé sur Spotify' ) );
    }

    wp_send_json_success( $result );
}
add_action( 'wp_ajax_netradio_spotify_enrich', 'netradio_ajax_spotify_enrich' );
add_action( 'wp_ajax_nopriv_netradio_spotify_enrich', 'netradio_ajax_spotify_enrich' );

/**
 * AJAX : test Spotify (admin)
 */
function netradio_ajax_spotify_test() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( array( 'message' => 'Non autorisé' ), 403 );
    }
    check_ajax_referer( 'netradio_test_spotify', 'nonce' );

    $spotify = new Netradio_Spotify_API();
    $result = $spotify->test_connection();

    if ( $result['success'] ) {
        wp_send_json_success( $result );
    } else {
        wp_send_json_error( $result );
    }
}
add_action( 'wp_ajax_netradio_spotify_test', 'netradio_ajax_spotify_test' );

/**
 * Placeholder SVG dégradé rouge (utilisé quand Spotify ne trouve pas la pochette)
 */
function netradio_get_placeholder_cover() {
    return get_template_directory_uri() . '/assets/images/placeholder-cover.svg';
}

/**
 * Modifier le now-playing de RadioBoss pour y intégrer les données Spotify
 *
 * Politique : si Spotify est configuré, on REMPLACE TOUJOURS la pochette RadioBoss :
 * - Si Spotify trouve le morceau → pochette Spotify HD
 * - Si Spotify ne trouve PAS le morceau → placeholder SVG Netradio
 *   (au lieu de la pochette RadioBoss vide/moche)
 *
 * Si Spotify n'est pas configuré → on garde la pochette RadioBoss
 */
function netradio_enrich_with_spotify( $data ) {
    $spotify = new Netradio_Spotify_API();

    // Si Spotify n'est pas configuré, on ne touche à rien
    if ( ! $spotify->is_configured() ) return $data;

    // Si on n'a ni artiste ni titre, on met le placeholder (impossible de chercher)
    if ( empty( $data['artist'] ) && empty( $data['title'] ) ) {
        $data['cover'] = netradio_get_placeholder_cover();
        $data['spotify_found'] = false;
        return $data;
    }

    $sp = $spotify->search_track( $data['artist'], $data['title'] );

    if ( $sp && ! empty( $sp['cover'] ) ) {
        // Spotify a trouvé → on remplace par la pochette HD
        $data['cover']         = $sp['cover'];
        $data['cover_large']   = ! empty( $sp['cover_large'] ) ? $sp['cover_large'] : $sp['cover'];
        $data['spotify_url']   = ! empty( $sp['spotify_url'] ) ? $sp['spotify_url'] : '';
        $data['spotify_found'] = true;
        if ( ! empty( $sp['album'] ) && empty( $data['album'] ) ) $data['album'] = $sp['album'];
        if ( ! empty( $sp['year'] )  && empty( $data['year'] ) )  $data['year']  = $sp['year'];
    } else {
        // Spotify n'a pas trouvé → placeholder, JAMAIS RadioBoss
        $data['cover']         = netradio_get_placeholder_cover();
        $data['spotify_found'] = false;
    }

    return $data;
}
add_filter( 'netradio_nowplaying_data', 'netradio_enrich_with_spotify', 10, 1 );
