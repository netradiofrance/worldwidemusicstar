<?php
/**
 * Netradio_RadioBoss_API
 *
 * v1.4 — Correction de l'historique :
 * - Utilise l'endpoint /api/info qui retourne aussi l'historique
 * - Support de plusieurs structures de réponse (TRACK, history, prev, recent_tracks)
 * - Parse les champs en majuscules ET en minuscules
 *
 * @package NetradioFM
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class Netradio_RadioBoss_API {

    private $station_id;
    private $api_key;
    private $api_base;
    private $cache_duration;

    public function __construct() {
        $this->station_id     = netradio_get_option( 'station_id', '847' );
        $this->api_key        = netradio_get_option( 'api_key', '' );
        $this->api_base       = netradio_get_option( 'api_base', 'https://c22.radioboss.fm' );
        $this->cache_duration = 10;
    }

    /**
     * Récupère le now-playing + stocke aussi la réponse complète pour l'historique
     */
    public function get_now_playing() {
        $cache_key = 'netradio_nowplaying_' . $this->station_id;
        $cached    = get_transient( $cache_key );

        if ( $cached !== false ) {
            return $cached;
        }

        if ( empty( $this->api_key ) ) {
            return new WP_Error( 'no_api_key', __( 'Clé API RadioBoss manquante.', 'netradio-fm' ) );
        }

        $url = sprintf(
            '%s/api/info/%s?key=%s',
            untrailingslashit( $this->api_base ),
            $this->station_id,
            $this->api_key
        );

        $response = wp_remote_get( $url, array(
            'timeout' => 5,
            'headers' => array( 'Accept' => 'application/json' ),
        ) );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code( $response );
        if ( $code !== 200 ) {
            return new WP_Error( 'api_error', sprintf( __( 'Erreur API RadioBoss (HTTP %d)', 'netradio-fm' ), $code ) );
        }

        $body = wp_remote_retrieve_body( $response );
        $data = json_decode( $body, true );

        if ( ! is_array( $data ) ) {
            return new WP_Error( 'invalid_response', __( 'Réponse API invalide.', 'netradio-fm' ) );
        }

        // Stocker la réponse brute pour l'historique (cache court)
        set_transient( 'netradio_raw_info_' . $this->station_id, $data, $this->cache_duration );

        $normalized = $this->normalize_now_playing( $data );

        // ENREGISTRER dans notre propre historique si nouveau titre
        $this->track_history( $normalized );

        set_transient( $cache_key, $normalized, $this->cache_duration );

        return $normalized;
    }

    /**
     * Détermine si un titre doit être exclu de l'historique
     * (sweepers/jingles internes, pub, etc.)
     */
    private function is_excluded_track( $artist, $title ) {
        // Concaténer pour test simple
        $combined = strtolower( trim( $artist . ' ' . $title ) );

        // Termes à exclure (case-insensitive)
        $excluded_patterns = array(
            'netradio',      // sweepers maison
            'radiotarget',   // écran de pub
            'jingle',        // jingles génériques
            'sweeper',
            'pub',           // pubs flaggées comme telles
            'advertising',
            'commercial',
            'ad break',
        );

        foreach ( $excluded_patterns as $pattern ) {
            if ( strpos( $combined, $pattern ) !== false ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Maintient notre propre historique des titres joués.
     * À chaque appel, si le titre actuel diffère du dernier enregistré, on l'ajoute.
     * Stocke jusqu'à 20 titres avec leurs pochettes Spotify déjà résolues.
     * Exclut automatiquement les sweepers NETRADIO et l'écran pub RADIOTARGET.
     */
    private function track_history( $current ) {
        if ( empty( $current['artist'] ) && empty( $current['title'] ) ) return;

        // FILTRE : exclure les sweepers et écrans pub
        if ( $this->is_excluded_track( $current['artist'], $current['title'] ) ) {
            return;
        }

        $history = get_option( 'netradio_track_history', array() );

        // Vérifier que le titre actuel ne figure pas déjà dans les 5 dernières positions
        // (évite les doublons quand un titre tourne plusieurs fois rapprochés)
        $current_key = strtolower( $current['artist'] . '|' . $current['title'] );
        for ( $i = 0; $i < min( 5, count( $history ) ); $i++ ) {
            if ( empty( $history[ $i ] ) ) continue;
            $existing_key = strtolower( $history[ $i ]['artist'] . '|' . $history[ $i ]['title'] );
            if ( $existing_key === $current_key ) {
                return; // Déjà dans les 5 dernières → on n'ajoute pas
            }
        }

        // Nouveau titre → ajouter en tête de la liste
        array_unshift( $history, array(
            'artist'    => $current['artist'],
            'title'     => $current['title'],
            'cover'     => isset( $current['cover'] ) ? $current['cover'] : '',
            'spotify_found' => ! empty( $current['spotify_found'] ),
            'timestamp' => time(),
        ) );

        // Garder seulement les 20 derniers
        $history = array_slice( $history, 0, 20 );

        update_option( 'netradio_track_history', $history, false );
    }

    /**
     * Dédoublonne une liste d'items d'historique par couple (artist|title).
     * Garde la 1ère occurrence, ignore les suivantes.
     * Exclut aussi les sweepers et écrans pub.
     * Re-numérote les positions pour éviter les trous.
     */
    private function deduplicate_history( $items, $limit ) {
        $seen = array();
        $result = array();
        $position = 1;

        foreach ( $items as $item ) {
            if ( ! is_array( $item ) ) continue;

            $artist = isset( $item['artist'] ) ? trim( $item['artist'] ) : '';
            $title  = isset( $item['title'] ) ? trim( $item['title'] ) : '';

            // Skip vides
            if ( empty( $artist ) && empty( $title ) ) continue;

            // Skip sweepers et pub (NETRADIO, RADIOTARGET, etc.)
            if ( $this->is_excluded_track( $artist, $title ) ) continue;

            // Clé de déduplication insensible à la casse + espaces
            $key = strtolower( $artist . '|' . $title );
            if ( isset( $seen[ $key ] ) ) continue;

            $seen[ $key ] = true;
            $item['position'] = $position++;
            $result[] = $item;

            if ( count( $result ) >= $limit ) break;
        }

        return $result;
    }

    /**
     * Récupère NOTRE historique maison (pas celui de RadioBoss)
     */
    public function get_local_history( $limit = 12 ) {
        $history = get_option( 'netradio_track_history', array() );
        if ( empty( $history ) ) return array();

        // On saute le 1er (= now playing) et on prend le reste
        $previous = array_slice( $history, 1, $limit );

        $result = array();
        $position = 1;
        foreach ( $previous as $item ) {
            $result[] = array(
                'position'  => $position++,
                'artist'    => $item['artist'],
                'title'     => $item['title'],
                'cover'     => $item['cover'],
                'timestamp' => isset( $item['timestamp'] ) ? $item['timestamp'] : 0,
            );
        }

        return $result;
    }

    /**
     * Récupère l'historique des titres récemment joués
     *
     * Stratégie en cascade : on s'arrête dès qu'une méthode renvoie des résultats.
     * Déduplication finale par couple (artist|title) pour éviter les doublons.
     *
     * 1. Notre historique maison (construit au fil des polls now-playing)
     * 2. Endpoint /api/info (parfois inclut l'historique)
     * 3. Endpoint /api/getplaylist (clé "TRACK")
     * 4. Fallback placeholders
     */
    public function get_history( $limit = 12 ) {
        $cache_key = 'netradio_history_' . $this->station_id . '_' . $limit;
        $cached    = get_transient( $cache_key );

        if ( $cached !== false ) {
            return $cached;
        }

        $history = array();

        // === MÉTHODE 1 (priorité) : NOTRE historique maison ===
        $local = $this->get_local_history( $limit );
        if ( ! empty( $local ) ) {
            foreach ( $local as $item ) {
                $data = array(
                    'position' => $item['position'],
                    'artist'   => $item['artist'],
                    'title'    => $item['title'],
                    'cover'    => $item['cover'],
                );
                $history[] = apply_filters( 'netradio_nowplaying_data', $data );
            }
        }

        // === MÉTHODE 2 : utiliser la réponse brute de /api/info ===
        // ⚠️ Seulement si on n'a PAS déjà rempli l'historique avec la méthode 1
        if ( empty( $history ) ) {
            $info_data = get_transient( 'netradio_raw_info_' . $this->station_id );
            if ( ! $info_data ) {
                $this->get_now_playing();
                $info_data = get_transient( 'netradio_raw_info_' . $this->station_id );
            }

            if ( is_array( $info_data ) ) {
                $items = $this->extract_history_items( $info_data );
                if ( ! empty( $items ) ) {
                    $i = 1;
                    foreach ( $items as $item ) {
                        if ( $i > $limit ) break;
                        $normalized = $this->normalize_history_item( $item, $i );
                        if ( ! empty( $normalized['artist'] ) || ! empty( $normalized['title'] ) ) {
                            $history[] = $normalized;
                            $i++;
                        }
                    }
                }
            }
        }

        // === MÉTHODE 3 : endpoint getplaylist (clé "TRACK") ===
        if ( empty( $history ) && ! empty( $this->api_key ) ) {
            $url = sprintf(
                '%s/api/getplaylist/%s?key=%s',
                untrailingslashit( $this->api_base ),
                $this->station_id,
                $this->api_key
            );

            $response = wp_remote_get( $url, array( 'timeout' => 5 ) );

            if ( ! is_wp_error( $response ) && wp_remote_retrieve_response_code( $response ) === 200 ) {
                $body = wp_remote_retrieve_body( $response );
                $data = json_decode( $body, true );

                if ( is_array( $data ) ) {
                    $items = $this->extract_history_items( $data );
                    if ( ! empty( $items ) ) {
                        $i = 1;
                        foreach ( $items as $item ) {
                            if ( $i > $limit ) break;
                            $normalized = $this->normalize_history_item( $item, $i );
                            if ( ! empty( $normalized['artist'] ) || ! empty( $normalized['title'] ) ) {
                                $history[] = $normalized;
                                $i++;
                            }
                        }
                    }
                }
            }
        }

        // === DÉDUPLICATION FINALE ===
        // Filtrer les doublons par couple (artist|title) — garde le 1er, ignore les suivants
        $history = $this->deduplicate_history( $history, $limit );

        // === MÉTHODE 4 : fallback placeholder (si toujours vide) ===
        if ( empty( $history ) ) {
            for ( $i = 1; $i <= $limit; $i++ ) {
                $history[] = array(
                    'position' => $i,
                    'artist'   => '',
                    'title'    => '',
                    'cover'    => sprintf( '%s/w/artwork_played_%d/%s.jpg',
                        untrailingslashit( $this->api_base ),
                        $i,
                        $this->station_id
                    ),
                );
            }
        }

        set_transient( $cache_key, $history, $this->cache_duration );
        return $history;
    }

    /**
     * Extrait la liste d'items d'historique depuis n'importe quelle structure de réponse.
     * Cherche dans : TRACK, track, playlist, history, prev, recent, recent_tracks, songhistory.
     */
    private function extract_history_items( $data ) {
        if ( ! is_array( $data ) ) return array();

        $candidate_keys = array(
            'TRACK', 'track', 'tracks',
            'playlist', 'PLAYLIST',
            'history', 'HISTORY',
            'prev', 'PREV', 'previous',
            'recent', 'RECENT', 'recent_tracks', 'recenttracks',
            'songhistory', 'SONGHISTORY', 'song_history',
            'played', 'PLAYED',
        );

        foreach ( $candidate_keys as $key ) {
            if ( isset( $data[ $key ] ) && is_array( $data[ $key ] ) ) {
                // Si c'est un tableau d'objets, on l'utilise
                if ( isset( $data[ $key ][0] ) ) {
                    return $data[ $key ];
                }
            }
        }

        // Si la racine elle-même est un tableau de tracks
        if ( isset( $data[0] ) && is_array( $data[0] ) ) {
            return $data;
        }

        return array();
    }

    /**
     * Normalise un item d'historique (gère TOUTES les variantes de noms de champs)
     */
    private function normalize_history_item( $item, $position ) {
        $artist = '';
        $title  = '';

        if ( ! is_array( $item ) ) {
            // Si c'est juste une string "Artiste - Titre"
            if ( is_string( $item ) ) {
                $parts = explode( ' - ', $item, 2 );
                if ( count( $parts ) === 2 ) {
                    $artist = trim( $parts[0] );
                    $title  = trim( $parts[1] );
                } else {
                    $title = trim( $item );
                }
            }
        } else {
            // Essayer toutes les variantes de noms de champs
            foreach ( array( 'ARTIST', 'artist', 'Artist' ) as $k ) {
                if ( ! empty( $item[ $k ] ) ) { $artist = $item[ $k ]; break; }
            }
            foreach ( array( 'TITLE', 'title', 'Title' ) as $k ) {
                if ( ! empty( $item[ $k ] ) ) { $title = $item[ $k ]; break; }
            }

            // Si on n'a toujours rien, essayer CASTTITLE (format "Artiste - Titre")
            if ( empty( $artist ) && empty( $title ) ) {
                $cast = '';
                foreach ( array( 'CASTTITLE', 'casttitle', 'track', 'TRACK', 'name', 'NAME' ) as $k ) {
                    if ( ! empty( $item[ $k ] ) ) { $cast = $item[ $k ]; break; }
                }
                if ( ! empty( $cast ) ) {
                    $parts = explode( ' - ', $cast, 2 );
                    if ( count( $parts ) === 2 ) {
                        $artist = trim( $parts[0] );
                        $title  = trim( $parts[1] );
                    } else {
                        $title = trim( $cast );
                    }
                }
            }
        }

        // Si Spotify est configuré, on ne donne PAS l'URL RadioBoss en cover
        // (le filtre Spotify s'occupera de mettre soit la pochette Spotify, soit le placeholder)
        $spotify_configured = ! empty( netradio_get_option( 'spotify_client_id', '' ) ) &&
                              ! empty( netradio_get_option( 'spotify_client_secret', '' ) );

        $cover_fallback = $spotify_configured
            ? get_template_directory_uri() . '/assets/images/placeholder-cover.svg'
            : sprintf( '%s/w/artwork_played_%d/%s.jpg',
                untrailingslashit( $this->api_base ),
                $position,
                $this->station_id
            );

        $data = array(
            'position' => $position,
            'artist'   => $artist,
            'title'    => $title,
            'cover'    => $cover_fallback,
        );

        // Filtre Spotify pour enrichir la pochette (remplace par Spotify HD si trouvé)
        return apply_filters( 'netradio_nowplaying_data', $data );
    }

    /**
     * Normalise la réponse du now-playing
     */
    private function normalize_now_playing( $data ) {
        $artist = '';
        $title  = '';
        $album  = '';
        $year   = '';

        if ( ! empty( $data['nowplaying'] ) ) {
            $parts = explode( ' - ', $data['nowplaying'], 2 );
            if ( count( $parts ) === 2 ) {
                $artist = trim( $parts[0] );
                $title  = trim( $parts[1] );
            } else {
                $title = trim( $data['nowplaying'] );
            }
        }

        if ( ! empty( $data['currenttrack_info']['@attributes'] ) ) {
            $info = $data['currenttrack_info']['@attributes'];
            if ( ! empty( $info['ARTIST'] ) ) $artist = $info['ARTIST'];
            if ( ! empty( $info['TITLE'] ) )  $title  = $info['TITLE'];
            if ( ! empty( $info['ALBUM'] ) )  $album  = $info['ALBUM'];
            if ( ! empty( $info['YEAR'] ) )   $year   = $info['YEAR'];
        }

        // Si Spotify configuré, on n'utilise pas l'URL RadioBoss comme cover (le filter gérera)
        $spotify_configured = ! empty( netradio_get_option( 'spotify_client_id', '' ) ) &&
                              ! empty( netradio_get_option( 'spotify_client_secret', '' ) );

        $cover_url = $spotify_configured
            ? get_template_directory_uri() . '/assets/images/placeholder-cover.svg'
            : sprintf( '%s/w/artwork/%s.jpg?t=%d',
                untrailingslashit( $this->api_base ),
                $this->station_id,
                time()
            );

        return apply_filters( 'netradio_nowplaying_data', array(
            'artist'      => $artist,
            'title'       => $title,
            'album'       => $album,
            'year'        => $year,
            'cover'       => $cover_url,
            'cover_next'  => sprintf( '%s/w/artwork_next/%s.jpg?t=%d',
                untrailingslashit( $this->api_base ),
                $this->station_id,
                time()
            ),
            'listeners'   => isset( $data['listeners'] ) ? intval( $data['listeners'] ) : 0,
            'live'        => ! empty( $data['live'] ),
            'station'     => isset( $data['station_name'] ) ? $data['station_name'] : 'Netradio',
            'station_logo'=> sprintf( '%s/stationlogo/png/%s.png',
                untrailingslashit( $this->api_base ),
                $this->station_id
            ),
            'timestamp'   => time(),
        ) );
    }

    public function flush_cache() {
        delete_transient( 'netradio_nowplaying_' . $this->station_id );
        delete_transient( 'netradio_raw_info_' . $this->station_id );
        for ( $i = 1; $i <= 20; $i++ ) {
            delete_transient( 'netradio_history_' . $this->station_id . '_' . $i );
        }
    }

    /**
     * Debug : retourne les réponses brutes de tous les endpoints connus
     * Permet de voir où se trouve réellement l'historique
     */
    public function debug_endpoints() {
        $endpoints = array(
            'info'              => '/api/info/%s?key=%s',
            'getplaylist'       => '/api/getplaylist/%s?key=%s',
            'info_recenttracks' => '/api/info_recenttracks/%s?key=%s',
            'recenttracks'      => '/api/recenttracks/%s?key=%s',
            'history'           => '/api/history/%s?key=%s',
            'nowplayinginfo'    => '/api/nowplayinginfo/%s?key=%s',
        );

        $results = array();
        foreach ( $endpoints as $name => $path ) {
            $url = untrailingslashit( $this->api_base ) . sprintf( $path, $this->station_id, $this->api_key );
            $response = wp_remote_get( $url, array( 'timeout' => 5 ) );

            if ( is_wp_error( $response ) ) {
                $results[ $name ] = array(
                    'status' => 'error',
                    'error'  => $response->get_error_message(),
                );
                continue;
            }

            $code = wp_remote_retrieve_response_code( $response );
            $body = wp_remote_retrieve_body( $response );
            $data = json_decode( $body, true );

            $results[ $name ] = array(
                'status'       => $code,
                'is_json'      => is_array( $data ),
                'keys'         => is_array( $data ) ? array_keys( $data ) : array(),
                'sample'       => is_array( $data ) ? wp_json_encode( $data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) : substr( $body, 0, 500 ),
            );
        }

        return $results;
    }

    public function test_connection() {
        if ( empty( $this->api_key ) ) {
            return array(
                'success' => false,
                'message' => __( 'Aucune clé API configurée.', 'netradio-fm' ),
            );
        }

        $url = sprintf(
            '%s/api/info/%s?key=%s',
            untrailingslashit( $this->api_base ),
            $this->station_id,
            $this->api_key
        );

        $response = wp_remote_get( $url, array( 'timeout' => 5 ) );

        if ( is_wp_error( $response ) ) {
            return array( 'success' => false, 'message' => $response->get_error_message() );
        }

        $code = wp_remote_retrieve_response_code( $response );
        if ( $code !== 200 ) {
            return array( 'success' => false, 'message' => sprintf( __( 'Code HTTP %d', 'netradio-fm' ), $code ) );
        }

        $body = wp_remote_retrieve_body( $response );
        $data = json_decode( $body, true );

        if ( ! is_array( $data ) ) {
            return array( 'success' => false, 'message' => __( 'Réponse JSON invalide.', 'netradio-fm' ) );
        }

        // Identifier les clés présentes (utile pour debug)
        $keys_found = array_keys( $data );
        $history_items = $this->extract_history_items( $data );

        return array(
            'success'      => true,
            'message'      => __( 'Connexion réussie !', 'netradio-fm' ),
            'station'      => isset( $data['station_name'] ) ? $data['station_name'] : '',
            'nowplaying'   => isset( $data['nowplaying'] ) ? $data['nowplaying'] : '',
            'listeners'    => isset( $data['listeners'] ) ? $data['listeners'] : 0,
            'keys_in_response' => $keys_found,
            'history_found'    => count( $history_items ),
            'history_sample'   => array_slice( $history_items, 0, 3 ),
        );
    }
}
