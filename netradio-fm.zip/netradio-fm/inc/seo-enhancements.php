<?php
/**
 * Améliorations SEO pour Netradio FM
 *
 * - Table of Contents (TOC) auto-générée à partir des h2/h3
 * - Schema FAQ JSON-LD (via meta box)
 * - Related Posts intelligents
 * - Lazy load des images
 * - Alt tags auto pour les images sans alt
 * - Compatible Rank Math SEO
 *
 * @package NetradioFM
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class Netradio_SEO_Enhancements {

    public function __construct() {
        // TOC auto sur les articles avec mode magazine
        add_filter( 'the_content', array( $this, 'inject_toc_and_anchors' ), 12 );

        // FAQ Schema JSON-LD dans le footer si l'article a des FAQ
        add_action( 'wp_head', array( $this, 'maybe_output_faq_schema' ), 100 );

        // Meta box pour FAQ
        add_action( 'add_meta_boxes', array( $this, 'add_faq_meta_box' ) );
        add_action( 'save_post', array( $this, 'save_faq_meta' ) );

        // Lazy load images dans le contenu
        add_filter( 'the_content', array( $this, 'add_lazy_load_to_images' ), 15 );

        // Schema Article JSON-LD pour les single posts
        add_action( 'wp_head', array( $this, 'output_article_schema' ), 99 );
    }

    /**
     * Injecte une Table des Matières auto en début d'article
     * + ajoute des id="" automatiques aux h2/h3 sans id
     */
    public function inject_toc_and_anchors( $content ) {
        if ( ! is_singular( 'post' ) || ! in_the_loop() || ! is_main_query() ) {
            return $content;
        }

        $post_id = get_the_ID();
        $disable_toc = get_post_meta( $post_id, '_netradio_disable_toc', true );
        if ( $disable_toc === 'yes' ) return $content;

        // Extraire tous les h2 et h3
        if ( ! preg_match_all( '#<h([23])([^>]*)>(.*?)</h\1>#is', $content, $matches, PREG_SET_ORDER ) ) {
            return $content;
        }

        // Pas de TOC si moins de 3 sections
        if ( count( $matches ) < 3 ) return $content;

        $headings = array();
        $used_ids = array();

        foreach ( $matches as $match ) {
            $level   = $match[1];
            $attrs   = $match[2];
            $text    = wp_strip_all_tags( $match[3] );

            // Récupérer l'id existant ou en générer un
            if ( preg_match( '/id=["\']([^"\']+)["\']/', $attrs, $id_match ) ) {
                $id = $id_match[1];
            } else {
                $id = 'h-' . sanitize_title( $text );
                // Évite les doublons d'id
                $base = $id; $i = 2;
                while ( in_array( $id, $used_ids, true ) ) {
                    $id = $base . '-' . $i;
                    $i++;
                }
                // Ajouter l'id au heading dans le contenu
                $new_heading = '<h' . $level . $attrs . ' id="' . esc_attr( $id ) . '">' . $match[3] . '</h' . $level . '>';
                $content = str_replace( $match[0], $new_heading, $content );
            }
            $used_ids[] = $id;

            $headings[] = array(
                'level' => $level,
                'text'  => $text,
                'id'    => $id,
            );
        }

        // Construire le TOC
        $toc  = '<nav class="netradio-toc" aria-label="Table des matières">';
        $toc .= '<h2 class="netradio-toc-title">Dans cet article</h2>';
        $toc .= '<ol class="netradio-toc-list">';
        foreach ( $headings as $h ) {
            $indent = $h['level'] === '3' ? ' class="toc-sub"' : '';
            $toc .= '<li' . $indent . '><a href="#' . esc_attr( $h['id'] ) . '">' . esc_html( $h['text'] ) . '</a></li>';
        }
        $toc .= '</ol></nav>';

        // Injection : après le 1er paragraphe (ou en début si pas de paragraphe)
        if ( preg_match( '#</p>#i', $content, $m, PREG_OFFSET_CAPTURE ) ) {
            $pos = $m[0][1] + strlen( $m[0][0] );
            $content = substr( $content, 0, $pos ) . $toc . substr( $content, $pos );
        } else {
            $content = $toc . $content;
        }

        return $content;
    }

    /**
     * Meta box pour FAQ Schema
     */
    public function add_faq_meta_box() {
        add_meta_box(
            'netradio_faq_meta',
            '❓ FAQ Schema (Rank Math compatible)',
            array( $this, 'render_faq_meta_box' ),
            array( 'post', 'page', 'podcast', 'emission' ),
            'normal',
            'default'
        );
    }

    public function render_faq_meta_box( $post ) {
        wp_nonce_field( 'netradio_faq_meta', 'netradio_faq_nonce' );
        $faqs = get_post_meta( $post->ID, '_netradio_faqs', true );
        if ( ! is_array( $faqs ) ) $faqs = array();
        $disable_toc = get_post_meta( $post->ID, '_netradio_disable_toc', true );
        ?>
        <p style="background:#f0f6ff; border-left:4px solid #2271b1; padding:12px; margin-bottom:16px; font-size:13px;">
            <strong>💡 Astuce SEO :</strong> Les FAQ que vous saisissez ici sont automatiquement injectées en <strong>Schema JSON-LD (FAQPage)</strong> dans le &lt;head&gt; de la page. Google peut les afficher en rich snippets dans les résultats de recherche.
        </p>
        <div id="netradio-faqs-container">
            <?php foreach ( $faqs as $i => $faq ) : ?>
                <div class="netradio-faq-row" style="background:#fff; border:1px solid #ddd; border-radius:4px; padding:12px; margin-bottom:8px;">
                    <p style="margin:0 0 8px;"><label><strong>Question</strong></label><br>
                        <input type="text" name="netradio_faqs[<?php echo $i; ?>][q]" value="<?php echo esc_attr( $faq['q'] ?? '' ); ?>" style="width:100%;" placeholder="Ex: Combien coûte une canette de Ciao Energy ?">
                    </p>
                    <p style="margin:0;"><label><strong>Réponse</strong></label><br>
                        <textarea name="netradio_faqs[<?php echo $i; ?>][a]" rows="3" style="width:100%;" placeholder="Ex: 1,49 € la canette de 250ml..."><?php echo esc_textarea( $faq['a'] ?? '' ); ?></textarea>
                    </p>
                </div>
            <?php endforeach; ?>
        </div>
        <button type="button" class="button" id="netradio-add-faq">+ Ajouter une FAQ</button>

        <hr style="margin:20px 0;">

        <p>
            <label>
                <input type="checkbox" name="netradio_disable_toc" value="yes" <?php checked( $disable_toc, 'yes' ); ?>>
                Désactiver la Table des matières automatique sur cet article
            </label>
        </p>
        <script>
        (function(){
            var container = document.getElementById('netradio-faqs-container');
            var btn = document.getElementById('netradio-add-faq');
            btn.addEventListener('click', function() {
                var i = container.querySelectorAll('.netradio-faq-row').length;
                var html = '<div class="netradio-faq-row" style="background:#fff;border:1px solid #ddd;border-radius:4px;padding:12px;margin-bottom:8px;">';
                html += '<p style="margin:0 0 8px;"><label><strong>Question</strong></label><br><input type="text" name="netradio_faqs['+i+'][q]" style="width:100%;" placeholder="Question..."></p>';
                html += '<p style="margin:0;"><label><strong>Réponse</strong></label><br><textarea name="netradio_faqs['+i+'][a]" rows="3" style="width:100%;" placeholder="Réponse..."></textarea></p>';
                html += '</div>';
                container.insertAdjacentHTML('beforeend', html);
            });
        })();
        </script>
        <?php
    }

    public function save_faq_meta( $post_id ) {
        if ( ! isset( $_POST['netradio_faq_nonce'] ) ) return;
        if ( ! wp_verify_nonce( $_POST['netradio_faq_nonce'], 'netradio_faq_meta' ) ) return;
        if ( ! current_user_can( 'edit_post', $post_id ) ) return;

        if ( isset( $_POST['netradio_faqs'] ) && is_array( $_POST['netradio_faqs'] ) ) {
            $clean = array();
            foreach ( $_POST['netradio_faqs'] as $faq ) {
                $q = isset( $faq['q'] ) ? sanitize_text_field( $faq['q'] ) : '';
                $a = isset( $faq['a'] ) ? wp_kses_post( $faq['a'] ) : '';
                if ( $q && $a ) {
                    $clean[] = array( 'q' => $q, 'a' => $a );
                }
            }
            if ( ! empty( $clean ) ) {
                update_post_meta( $post_id, '_netradio_faqs', $clean );
            } else {
                delete_post_meta( $post_id, '_netradio_faqs' );
            }
        } else {
            delete_post_meta( $post_id, '_netradio_faqs' );
        }

        $disable_toc = isset( $_POST['netradio_disable_toc'] ) ? 'yes' : 'no';
        update_post_meta( $post_id, '_netradio_disable_toc', $disable_toc );
    }

    /**
     * Output du schema JSON-LD FAQPage si l'article a des FAQ
     */
    public function maybe_output_faq_schema() {
        if ( ! is_singular() ) return;

        $faqs = get_post_meta( get_the_ID(), '_netradio_faqs', true );
        if ( ! is_array( $faqs ) || empty( $faqs ) ) return;

        $main_entity = array();
        foreach ( $faqs as $faq ) {
            $main_entity[] = array(
                '@type' => 'Question',
                'name'  => $faq['q'],
                'acceptedAnswer' => array(
                    '@type' => 'Answer',
                    'text'  => wp_strip_all_tags( $faq['a'] ),
                ),
            );
        }

        $schema = array(
            '@context' => 'https://schema.org',
            '@type'    => 'FAQPage',
            'mainEntity' => $main_entity,
        );

        echo "\n<!-- Netradio FAQ Schema -->\n";
        echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>' . "\n";
    }

    /**
     * Schema Article JSON-LD pour les single posts
     */
    public function output_article_schema() {
        if ( ! is_singular( 'post' ) ) return;

        $post_id = get_the_ID();
        $author_id = get_post_field( 'post_author', $post_id );
        $thumb_url = get_the_post_thumbnail_url( $post_id, 'full' );

        $schema = array(
            '@context'      => 'https://schema.org',
            '@type'         => 'Article',
            'headline'      => get_the_title( $post_id ),
            'datePublished' => get_the_date( 'c', $post_id ),
            'dateModified'  => get_the_modified_date( 'c', $post_id ),
            'author'        => array(
                '@type' => 'Person',
                'name'  => get_the_author_meta( 'display_name', $author_id ),
            ),
            'publisher'     => array(
                '@type' => 'Organization',
                'name'  => get_bloginfo( 'name' ),
                'logo'  => array(
                    '@type' => 'ImageObject',
                    'url'   => get_theme_mod( 'custom_logo' ) ? wp_get_attachment_image_url( get_theme_mod( 'custom_logo' ), 'full' ) : '',
                ),
            ),
            'mainEntityOfPage' => get_permalink( $post_id ),
        );

        if ( $thumb_url ) {
            $schema['image'] = $thumb_url;
        }

        $excerpt = get_the_excerpt( $post_id );
        if ( $excerpt ) {
            $schema['description'] = wp_strip_all_tags( $excerpt );
        }

        echo "\n<!-- Netradio Article Schema -->\n";
        echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>' . "\n";
    }

    /**
     * Ajoute loading="lazy" et un alt par défaut aux images du contenu
     */
    public function add_lazy_load_to_images( $content ) {
        if ( is_admin() || is_feed() ) return $content;

        // Ajouter loading="lazy" si manquant
        $content = preg_replace_callback( '#<img\b([^>]*)>#i', function( $m ) {
            $tag = $m[0];
            if ( ! preg_match( '/loading=/i', $tag ) ) {
                $tag = str_replace( '<img', '<img loading="lazy"', $tag );
            }
            if ( ! preg_match( '/decoding=/i', $tag ) ) {
                $tag = str_replace( '<img', '<img decoding="async"', $tag );
            }
            return $tag;
        }, $content );

        return $content;
    }
}

new Netradio_SEO_Enhancements();

/**
 * Helper : retourne les related posts par catégorie
 * Utilisable dans les templates : netradio_get_related_posts(5)
 */
function netradio_get_related_posts( $count = 4, $post_id = null ) {
    if ( ! $post_id ) $post_id = get_the_ID();
    if ( ! $post_id ) return array();

    $cats = wp_get_post_categories( $post_id );
    $tags = wp_get_post_tags( $post_id, array( 'fields' => 'ids' ) );

    if ( empty( $cats ) && empty( $tags ) ) return array();

    $args = array(
        'posts_per_page'      => $count,
        'post__not_in'        => array( $post_id ),
        'ignore_sticky_posts' => 1,
        'orderby'             => 'rand',
    );

    if ( ! empty( $cats ) ) {
        $args['category__in'] = $cats;
    }

    $query = new WP_Query( $args );

    // Si pas assez de posts par catégorie, élargir aux tags
    if ( $query->post_count < $count && ! empty( $tags ) ) {
        $args = array(
            'posts_per_page'      => $count,
            'post__not_in'        => array_merge( array( $post_id ), wp_list_pluck( $query->posts, 'ID' ) ),
            'ignore_sticky_posts' => 1,
            'tag__in'             => $tags,
            'orderby'             => 'rand',
        );
        $extra = new WP_Query( $args );
        $combined = array_merge( $query->posts, $extra->posts );
        return array_slice( $combined, 0, $count );
    }

    return $query->posts;
}
