<?php
/**
 * Diagnostic du lecteur — exécuté DANS le navigateur de l'administrateur.
 *
 * Les tests côté serveur ne disent rien du CORS ni des capacités du
 * navigateur : ils doivent donc tourner dans la page, depuis l'origine
 * netradio.fr, pour refléter ce que vit réellement un auditeur.
 *
 * @package NetradioFM
 * @since 2.4.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Ajoute la page de diagnostic au menu Netradio FM.
 */
function netradio_add_diagnostic_page() {
	add_submenu_page(
		'netradio-fm',
		'Diagnostic du lecteur',
		'🩺 Diagnostic',
		'manage_options',
		'netradio-diagnostic',
		'netradio_render_diagnostic_page'
	);
}
add_action( 'admin_menu', 'netradio_add_diagnostic_page', 20 );

function netradio_render_diagnostic_page() {
	$stream_url = netradio_get_option( 'stream_url', NETRADIO_DEFAULT_STREAM_URL );
	$api_url    = netradio_get_option( 'api_url', NETRADIO_DEFAULT_API_URL );
	$hls_js     = NETRADIO_URI . '/assets/js/vendor/hls.min.js?ver=' . NETRADIO_VERSION;
	?>
	<style>
		.nrdiag { max-width: 980px; }
		.nrdiag h1 { display:flex; align-items:center; gap:12px; font-size:26px; }
		.nrdiag .card { background:#fff; border:1px solid #ddd; border-radius:6px; padding:22px; margin-top:18px; }
		.nrdiag .card h2 { margin-top:0; padding-bottom:10px; border-bottom:2px solid #e10a16; font-size:17px; }
		.nrdiag .run { background:#e10a16; color:#fff; border:0; padding:12px 26px; border-radius:4px; cursor:pointer; font-weight:600; font-size:14px; }
		.nrdiag .run:hover { background:#b00811; }
		.nrdiag .run:disabled { opacity:.6; cursor:default; }
		.nrdiag .t { display:grid; grid-template-columns:26px 210px 1fr; gap:10px; padding:9px 0; border-bottom:1px solid #f0f0f0; align-items:start; font-size:13px; }
		.nrdiag .t:last-child { border-bottom:0; }
		.nrdiag .t .lbl { font-weight:600; }
		.nrdiag .t .val { font-family:monospace; font-size:12px; word-break:break-word; }
		.nrdiag .ok { color:#0f7b34; } .nrdiag .ko { color:#b32d2e; } .nrdiag .warn { color:#996800; }
		.nrdiag .hint { background:#fff8e5; border-left:3px solid #e0a800; padding:10px 12px; margin-top:10px; font-size:13px; line-height:1.5; }
		.nrdiag .hint code { background:#fff; padding:1px 4px; }
		.nrdiag .raw { background:#1d1d1d; color:#f4efe6; padding:14px; border-radius:5px; font-family:monospace; font-size:11px; line-height:1.5; max-height:340px; overflow:auto; white-space:pre-wrap; margin-top:12px; }
		.nrdiag .verdict { padding:14px 16px; border-radius:5px; font-size:14px; margin-top:14px; display:none; }
		.nrdiag .verdict.good { background:#d4edda; color:#155724; border:1px solid #c3e6cb; }
		.nrdiag .verdict.bad { background:#f8d7da; color:#721c24; border:1px solid #f5c6cb; }
	</style>

	<div class="wrap nrdiag">
		<h1>🩺 Diagnostic du lecteur <small style="font-size:12px;color:#888;font-weight:400;">v<?php echo esc_html( NETRADIO_VERSION ); ?></small></h1>
		<p style="font-size:13px;color:#555;max-width:700px;">
			Ces tests s'exécutent dans <strong>votre navigateur</strong>, depuis le domaine du site. C'est le seul moyen
			de vérifier réellement le CORS et la compatibilité de lecture&nbsp;: un test côté serveur passerait alors
			qu'un auditeur resterait bloqué. Lancez-les depuis le navigateur où vous constatez le problème.
		</p>

		<p><button type="button" class="run" id="nrd-run">▶ Lancer le diagnostic</button></p>

		<div class="card">
			<h2>1. Navigateur</h2>
			<div id="nrd-env"></div>
		</div>

		<div class="card">
			<h2>2. Flux audio</h2>
			<div id="nrd-stream"></div>
			<div id="nrd-manifest" class="raw" style="display:none;"></div>
		</div>

		<div class="card">
			<h2>3. Métadonnées &amp; synchronisation</h2>
			<div id="nrd-meta"></div>
		</div>

		<div class="verdict" id="nrd-verdict"></div>
	</div>

	<script>
	(function(){
		var STREAM = <?php echo wp_json_encode( $stream_url ); ?>;
		var API    = <?php echo wp_json_encode( $api_url ); ?>;
		var HLSJS  = <?php echo wp_json_encode( $hls_js ); ?>;
		var AJAX   = <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>;
		var NONCE  = <?php echo wp_json_encode( wp_create_nonce( 'netradio_radioboss_nonce' ) ); ?>;
		var SAVENONCE = <?php echo wp_json_encode( wp_create_nonce( 'netradio_save_delay' ) ); ?>;

		var problems = [];

		function row(host, state, label, value){
			var icon = state==='ok' ? '✅' : (state==='ko' ? '❌' : (state==='warn' ? '⚠️' : '·'));
			var d = document.createElement('div');
			d.className = 't';
			d.innerHTML = '<div>'+icon+'</div><div class="lbl">'+label+'</div><div class="val '+state+'">'+value+'</div>';
			document.getElementById(host).appendChild(d);
		}
		function hint(host, html){
			var d = document.createElement('div');
			d.className = 'hint';
			d.innerHTML = html;
			document.getElementById(host).appendChild(d);
		}
		function clear(){
			['nrd-env','nrd-stream','nrd-meta'].forEach(function(id){ document.getElementById(id).innerHTML=''; });
			document.getElementById('nrd-manifest').style.display='none';
			document.getElementById('nrd-verdict').style.display='none';
			problems = [];
		}

		function isAppleMobile(){
			var ua = navigator.userAgent||'';
			return /iPad|iPhone|iPod/.test(ua) || (navigator.platform==='MacIntel' && navigator.maxTouchPoints>1);
		}

		function testEnv(){
			var a = document.createElement('audio');
			var native = a.canPlayType('application/vnd.apple.mpegurl') !== '' || a.canPlayType('application/x-mpegURL') !== '';
			var mse = ('MediaSource' in window);
			var apple = isAppleMobile();
			var engine = (native && (apple || !mse)) ? 'lecture native' : 'hls.js';

			row('nrd-env','ok','Navigateur', navigator.userAgent);
			row('nrd-env', mse?'ok':'warn','MediaSource', mse ? 'disponible' : 'absent (lecture native requise)');
			row('nrd-env','ok','canPlayType HLS', (a.canPlayType('application/vnd.apple.mpegurl')||'(vide)') + ' / ' + (a.canPlayType('application/x-mpegURL')||'(vide)'));
			row('nrd-env','ok','Appareil Apple mobile', apple ? 'oui' : 'non');
			row('nrd-env','ok','Moteur retenu', engine);

			if (native && !apple && mse) {
				hint('nrd-env','Ce navigateur déclare savoir lire le HLS (<code>maybe</code>) alors qu\'il en est incapable dans une balise <code>&lt;audio&gt;</code>. Le lecteur l\'ignore volontairement et utilise hls.js — c\'était la cause de l\'absence de lecture avant la version 2.4.');
			}
			return engine;
		}

		function testHlsLib(){
			return new Promise(function(resolve){
				if (window.Hls) { row('nrd-stream','ok','hls.js','déjà chargé — v'+Hls.version); return resolve(true); }
				var s=document.createElement('script'); s.src=HLSJS;
				s.onload=function(){
					if (window.Hls && Hls.isSupported()) { row('nrd-stream','ok','hls.js','chargé et supporté — v'+Hls.version); resolve(true); }
					else { row('nrd-stream','ko','hls.js','chargé mais non supporté'); problems.push('hls.js non supporté'); resolve(false); }
				};
				s.onerror=function(){ row('nrd-stream','ko','hls.js','introuvable : '+HLSJS); problems.push('hls.js introuvable (404)'); resolve(false); };
				document.head.appendChild(s);
			});
		}

		function testManifest(){
			row('nrd-stream','', 'URL configurée', STREAM);
			var t0 = performance.now();
			return fetch(STREAM, { method:'GET', mode:'cors' })
				.then(function(r){
					var ms = Math.round(performance.now()-t0);
					row('nrd-stream', r.ok?'ok':'ko', 'Requête CORS', 'HTTP '+r.status+' en '+ms+' ms');
					if (r.url && r.url !== STREAM) {
						row('nrd-stream','ok','Redirection de session', r.url);
						hint('nrd-stream','Chaque auditeur reçoit sa propre playlist&nbsp;: c\'est ce qui permet à l\'AdServer de compter les impressions. Comportement normal.');
					}
					if (!r.ok) { problems.push('Le manifeste renvoie HTTP '+r.status); return null; }
					return r.text();
				})
				.then(function(txt){
					if (!txt) return null;
					var box = document.getElementById('nrd-manifest');
					box.style.display='block';
					box.textContent = txt.length>3000 ? txt.slice(0,3000)+'\n[…tronqué]' : txt;

					var segs  = (txt.match(/^(?!#).+\.(ts|aac|mp4|m4s)/gmi)||[]).length;
					var disc  = (txt.match(/#EXT-X-DISCONTINUITY/g)||[]).length;
					var td    = (txt.match(/#EXT-X-TARGETDURATION:(\d+)/)||[])[1];
					var master= /#EXT-X-STREAM-INF/.test(txt);
					var durs  = (txt.match(/#EXTINF:([\d.]+)/g)||[]).map(function(x){ return parseFloat(x.split(':')[1]); });
					var total = durs.reduce(function(a,b){return a+b;},0);

					row('nrd-stream','ok','Type de playlist', master ? 'master (multi-débit)' : 'média (segments)');
					row('nrd-stream', segs?'ok':'ko','Segments listés', segs || '0 — playlist vide');
					if (!segs && !master) problems.push('La playlist ne contient aucun segment');
					if (td) row('nrd-stream','ok','Durée de segment', td+' s');
					if (disc) row('nrd-stream','ok','Raccords publicitaires', disc+' marqueur(s) EXT-X-DISCONTINUITY');
					if (total) {
						row('nrd-stream','ok','Fenêtre disponible', total.toFixed(1)+' s de contenu en playlist');
					}
					window.__nrTargetDuration = td ? parseFloat(td) : 0;
					return testPreflight(STREAM).then(function(){ return txt; });
				})
				.catch(function(err){
					// « Failed to fetch » recouvre deux causes très différentes.
					// La sonde no-cors tranche : si le serveur répond malgré
					// tout, c'est bien le CORS qui bloque, pas le réseau.
					return probeReachable(STREAM).then(function(reachable){
						if (reachable) {
							row('nrd-stream','ko','Requête CORS','BLOQUÉE — le serveur répond, mais sans autorisation pour ce site');
							row('nrd-stream','ok','Joignabilité','serveur accessible (sonde sans CORS réussie)');
							problems.push('CORS absent sur le flux : lecture impossible hors iOS');
							hint('nrd-stream','<strong>Diagnostic : l\'en-tête CORS manque.</strong> Le serveur <code>radioairplay.fr</code> répond correctement, mais n\'autorise pas <code>'+location.origin+'</code> à lire la réponse. hls.js récupérant les segments en XHR, la lecture est impossible sur Chrome, Firefox et Edge. Elle fonctionnerait sur iPhone, dont la lecture native ne passe pas par le contrôle CORS.<br><br><strong>À corriger côté plateforme</strong>, sur la playlist <em>et</em> sur les segments&nbsp;:<br><code>Access-Control-Allow-Origin: '+location.origin+'</code>');
						} else {
							row('nrd-stream','ko','Joignabilité','ÉCHEC — serveur injoignable depuis ce navigateur');
							problems.push('Flux injoignable (réseau, DNS, pare-feu ou blocage d\'extension)');
							hint('nrd-stream','Le serveur ne répond pas du tout, même sans contrôle CORS. Vérifiez qu\'aucun bloqueur de publicité ou extension ne filtre <code>radioairplay.fr</code>, puis testez l\'URL dans un onglet.');
						}
						return null;
					});
				});
		}

		/**
		 * Sonde de joignabilité : une requête « no-cors » aboutit dès lors que
		 * le serveur répond, même sans en-tête d'autorisation. Elle permet de
		 * distinguer un blocage CORS d'une véritable panne réseau.
		 */
		function probeReachable(url){
			return fetch(url, { mode:'no-cors', cache:'no-store' })
				.then(function(){ return true; })
				.catch(function(){ return false; });
		}

		/**
		 * Test du préflight OPTIONS.
		 *
		 * Un échec CORS se présente toujours de la même façon au navigateur
		 * (« Failed to fetch »), alors qu'il recouvre deux causes très
		 * différentes : en-tête d'autorisation absent, ou requête OPTIONS
		 * rejetée par le serveur. Les distinguer suppose de les provoquer
		 * séparément.
		 *
		 * L'en-tête personnalisé ci-dessous ne fait pas partie de la liste
		 * sûre du navigateur : sa présence force un préflight. Si la requête
		 * simple passe et que celle-ci échoue, le serveur ne répond pas
		 * correctement aux OPTIONS — c'est exactement ce qui bloquait
		 * netradio.fr en août 2026, un backend Python renvoyant 501 sur toute
		 * méthode autre que GET.
		 */
		function testPreflight(url){
			return fetch(url, {
					mode: 'cors',
					cache: 'no-store',
					headers: { 'X-Netradio-Preflight': '1' }
				})
				.then(function(r){
					row('nrd-stream', r.ok?'ok':'warn', 'Préflight OPTIONS', r.ok ? 'accepté (HTTP '+r.status+')' : 'réponse HTTP '+r.status);
					return r.ok;
				})
				.catch(function(){
					row('nrd-stream','ko','Préflight OPTIONS','REJETÉ — le serveur ne répond pas correctement aux requêtes OPTIONS');
					problems.push('Préflight OPTIONS rejeté : hls.js ne pourra pas charger les segments');
					hint('nrd-stream','<strong>La requête simple passe, mais pas le préflight.</strong> Les en-têtes d\'autorisation sont donc bien présents&nbsp;: c\'est la méthode <code>OPTIONS</code> qui est refusée. hls.js en déclenche une dès qu\'il demande une plage d\'octets sur un segment.<br><br>À corriger côté plateforme&nbsp;: intercepter <code>OPTIONS</code> au niveau du serveur web (réponse <code>204</code> avec <code>Allow-Methods</code> et <code>Allow-Headers</code>) plutôt que de la transmettre à l\'application.<br><br><em>À vérifier en ligne de commande avec</em> <code>curl -sS -D- -o /dev/null -X OPTIONS</code> — et non <code>curl -I</code>, qui envoie un HEAD et peut renvoyer un faux négatif sur ce type de backend.');
					return false;
				});
		}

		/**
		 * Les métadonnées transitent par WordPress, qui interroge la plateforme
		 * côté serveur. C'est ce chemin qu'il faut tester : une requête directe
		 * depuis le navigateur échouerait sur le CORS sans que cela empêche le
		 * site de fonctionner.
		 */
		/**
		 * Mesure du retard réel, par lecture effective du flux.
		 *
		 * On lit quelques secondes en sourdine et on relève la distance entre
		 * la tête de lecture et le bord du direct. On y ajoute une durée de
		 * segment : un segment doit être entièrement encodé avant d'apparaître
		 * dans la playlist, ce délai s'ajoute donc à ce que mesure le lecteur.
		 *
		 * Le résultat reste une estimation : l'affiner à l'oreille est
		 * toujours plus fiable que n'importe quel calcul.
		 */
		function measureLatency(){
			return new Promise(function(resolve){
				if (!window.Hls || !Hls.isSupported()) { resolve(null); return; }

				var a = document.createElement('audio');
				a.muted = true;
				a.preload = 'auto';

				var h = new Hls({ lowLatencyMode:false, liveSyncDurationCount:4, backBufferLength:30 });
				var done = false, started = 0, iv = null;

				function finish(val){
					if (done) return;
					done = true;
					if (iv) clearInterval(iv);
					try { h.destroy(); } catch(e) {}
					try { a.pause(); a.removeAttribute('src'); } catch(e) {}
					resolve(val);
				}

				h.on(Hls.Events.ERROR, function(e,d){ if (d.fatal) finish(null); });
				h.on(Hls.Events.MANIFEST_PARSED, function(){
					a.play().catch(function(){ finish(null); });
				});

				h.loadSource(STREAM);
				h.attachMedia(a);

				var t0 = Date.now();
				iv = setInterval(function(){
					if (a.currentTime > 0 && !a.paused && !started) started = Date.now();

					// On laisse le tampon se stabiliser avant de relever la mesure.
					if (started && Date.now() - started > 4000) {
						var lat = (typeof h.latency === 'number' && h.latency > 0) ? h.latency : null;
						if (lat === null && h.liveSyncPosition != null) {
							lat = Math.max(0, h.liveSyncPosition - a.currentTime);
						}
						var lvl = h.levels && h.levels[h.currentLevel >= 0 ? h.currentLevel : 0];
						var target = (lvl && lvl.details && lvl.details.targetduration) || window.__nrTargetDuration || 0;
						finish(lat === null ? null : { latency: lat, target: target });
						return;
					}
					if (Date.now() - t0 > 20000) finish(null);
				}, 500);
			});
		}

		function applyDelay(seconds, btn){
			btn.disabled = true;
			btn.textContent = '⏳ Enregistrement…';
			var body = new FormData();
			body.append('action', 'netradio_save_delay');
			body.append('nonce', SAVENONCE);
			body.append('delay', seconds);
			fetch(AJAX, { method:'POST', body: body, credentials:'same-origin' })
				.then(function(r){ return r.json(); })
				.then(function(res){
					btn.textContent = (res && res.success) ? '✅ Enregistré — ' + seconds + ' s' : '❌ Échec';
				})
				.catch(function(){ btn.textContent = '❌ Échec'; });
		}

		function testMetadata(){
			row('nrd-meta','','Source interrogée', API + '  (via le serveur, pas le navigateur)');
			return fetch(AJAX + '?action=netradio_get_radio_data&nonce=' + encodeURIComponent(NONCE) + '&history=12', { credentials:'same-origin' })
				.then(function(r){ return r.json(); })
				.then(function(res){
					if (!res || !res.success || !res.data) {
						row('nrd-meta','ko','Proxy WordPress', (res && res.data && res.data.message) ? res.data.message : 'réponse inattendue');
						problems.push('Le proxy WordPress ne renvoie pas les métadonnées');
						return null;
					}
					row('nrd-meta','ok','Proxy WordPress','opérationnel — les titres transitent par le serveur, sans CORS');

					var now = res.data.now || {}, hist = res.data.history || [];
					row('nrd-meta','ok','Titre annoncé au direct', (now.artist ? now.artist+' — ' : '')+(now.title||'(vide)')+'  [type: '+(now.type||'non fourni')+']');
					row('nrd-meta','ok','Historique', hist.length+' titre(s)');

					if (now.started_at && now.duration) {
						var elapsed = Math.round(Date.now()/1000 - now.started_at);
						row('nrd-meta','ok','Position dans le titre', elapsed+' s écoulées sur '+now.duration+' s');
					} else {
						row('nrd-meta','warn','Barre de progression','indisponible (started_at ou duration manquant)');
					}

					var m = window.__nrMeasure;
					if (!m) {
						row('nrd-meta','warn','Retard du HLS','non mesurable (flux inaccessible ou lecture refusée)');
						hint('nrd-meta','La mesure nécessite de lire réellement le flux quelques secondes. Relancez le diagnostic une fois le flux accessible&nbsp;: la valeur à saisir dans «&nbsp;Décalage d\'affichage&nbsp;» s\'affichera ici.');
						return res.data;
					}

					var lat = Math.round(m.latency + m.target);
					row('nrd-meta','ok','Retard mesuré','≈ '+lat+' s  ('+m.latency.toFixed(1)+' s de tampon + '+m.target+' s d\'encodage de segment)');

					var cur = <?php echo intval( netradio_get_option( 'metadata_delay', 0 ) ); ?>;
					var wrap = document.createElement('div');
					wrap.className = 'hint';
					wrap.innerHTML = cur === lat
						? 'Le réglage «&nbsp;Décalage d\'affichage&nbsp;» est déjà sur <strong>'+cur+'&nbsp;s</strong>, conforme à la mesure.'
						: 'Réglage actuel&nbsp;: <strong>'+cur+'&nbsp;s</strong>. Valeur mesurée&nbsp;: <strong>'+lat+'&nbsp;s</strong>. ';
					if (cur !== lat) {
						var b = document.createElement('button');
						b.className = 'run';
						b.style.cssText = 'padding:7px 16px;font-size:13px;margin-left:8px;';
						b.textContent = 'Appliquer ' + lat + ' s';
						b.addEventListener('click', function(){ applyDelay(lat, b); });
						wrap.appendChild(b);
						var p = document.createElement('div');
						p.style.cssText = 'margin-top:8px;font-size:12px;opacity:.85;';
						p.textContent = 'Il s\'agit d\'une estimation : si le titre affiché reste légèrement décalé, ajustez de quelques secondes à l\'oreille.';
						wrap.appendChild(p);
					}
					document.getElementById('nrd-meta').appendChild(wrap);

					var target = Math.floor(Date.now()/1000) - lat, heard = null;
					if (now.started_at && now.started_at <= target) heard = (now.artist ? now.artist+' — ' : '')+now.title;
					else {
						for (var i=0;i<hist.length;i++){
							if (hist[i].played_at && hist[i].played_at <= target){ heard = hist[i].artist+' — '+hist[i].title; break; }
						}
					}
					if (heard) {
						var live = (now.artist ? now.artist+' — ' : '')+(now.title||'');
						var same = heard === live;
						row('nrd-meta', same?'ok':'warn','Titre réellement entendu', heard);
						if (!same) {
							hint('nrd-meta','<strong>Décalage confirmé.</strong> L\'auditeur entend «&nbsp;'+heard+'&nbsp;» pendant que l\'API annonce «&nbsp;'+live+'&nbsp;». Le bouton ci-dessus aligne l\'affichage sur le son.');
						}
					}
					return res.data;
				})
				.catch(function(err){
					row('nrd-meta','ko','Proxy WordPress','ÉCHEC — '+err.message);
					problems.push('Le proxy WordPress est injoignable');
				});
		}

		document.getElementById('nrd-run').addEventListener('click', function(){
			var btn=this; btn.disabled=true; btn.textContent='⏳ Diagnostic en cours…';
			clear();
			testEnv();
			testHlsLib()
				.then(testManifest)
				.then(function(txt){
					if (!txt) return null;                 // flux inaccessible : rien à mesurer
					row('nrd-meta','','Mesure en cours','lecture du flux en sourdine pendant quelques secondes…');
					return measureLatency().then(function(m){
						window.__nrMeasure = m;
						document.getElementById('nrd-meta').innerHTML = '';   // on efface la ligne d'attente
						return txt;
					});
				})
				.then(testMetadata)
				.then(function(){
					var v=document.getElementById('nrd-verdict');
					v.style.display='block';
					if (problems.length){
						v.className='verdict bad';
						v.innerHTML='<strong>'+problems.length+' problème(s) détecté(s) :</strong><ul style="margin:8px 0 0 18px;"><li>'+problems.join('</li><li>')+'</li></ul>';
					} else {
						v.className='verdict good';
						v.innerHTML='<strong>✅ Tout est opérationnel.</strong> Flux accessible, lecture possible et métadonnées synchronisées dans ce navigateur.';
					}
				})
				.finally(function(){ btn.disabled=false; btn.textContent='▶ Relancer le diagnostic'; });
		});
	})();
	</script>
	<?php
}
