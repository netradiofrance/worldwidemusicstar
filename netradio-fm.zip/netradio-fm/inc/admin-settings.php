<?php
/**
 * Page de réglages admin
 *
 * Réglages → Netradio FM
 *
 * @package NetradioFM
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Ajouter le menu admin
 */
function netradio_admin_menu() {
    add_menu_page(
        'Netradio FM',
        '📻 Netradio FM',
        'manage_options',
        'netradio-settings',
        'netradio_render_settings_page',
        'data:image/svg+xml;base64,' . base64_encode( '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path fill="#fff" d="M10 2C5.6 2 2 5.6 2 10s3.6 8 8 8 8-3.6 8-8-3.6-8-8-8zm-2 11.5L5 10l3-3.5V13.5zm4 0V6.5L15 10l-3 3.5z"/></svg>' ),
        80
    );

    add_submenu_page(
        'netradio-settings',
        'Réglages',
        'Réglages',
        'manage_options',
        'netradio-settings',
        'netradio_render_settings_page'
    );

    add_submenu_page(
        'netradio-settings',
        'Magazine Article',
        'Magazine Article',
        'edit_posts',
        'netradio-magazine-doc',
        'netradio_render_magazine_doc'
    );
}
add_action( 'admin_menu', 'netradio_admin_menu' );

/**
 * Enregistrer les options
 */
function netradio_register_settings() {
    register_setting( 'netradio_settings_group', 'netradio_settings', array(
        'sanitize_callback' => 'netradio_sanitize_settings',
    ) );
}
add_action( 'admin_init', 'netradio_register_settings' );

/**
 * Sanitize des options
 */
function netradio_sanitize_settings( $input ) {
    $clean = array();
    // Source des données : RadioAirplay (par défaut) ou RadioBoss (legacy)
    $provider = isset( $input['api_provider'] ) ? sanitize_key( $input['api_provider'] ) : 'radioairplay';
    $clean['api_provider']  = in_array( $provider, array( 'radioairplay', 'radioboss' ), true ) ? $provider : 'radioairplay';
    $clean['api_url']       = isset( $input['api_url'] ) ? esc_url_raw( trim( $input['api_url'] ) ) : '';
    $clean['api_token']     = isset( $input['api_token'] ) ? sanitize_text_field( $input['api_token'] ) : '';
    $clean['station_id']    = isset( $input['station_id'] ) ? sanitize_text_field( $input['station_id'] ) : '';
    $clean['api_key']       = isset( $input['api_key'] ) ? sanitize_text_field( $input['api_key'] ) : '';
    $clean['api_base']      = isset( $input['api_base'] ) ? esc_url_raw( $input['api_base'] ) : '';
    $clean['stream_url']    = isset( $input['stream_url'] ) ? esc_url_raw( trim( $input['stream_url'] ) ) : '';
    $clean['stream_fallback_url'] = isset( $input['stream_fallback_url'] ) ? esc_url_raw( trim( $input['stream_fallback_url'] ) ) : '';
    $clean['metadata_delay'] = isset( $input['metadata_delay'] ) ? max( 0, min( 300, intval( $input['metadata_delay'] ) ) ) : 0;
    $clean['station_name']  = isset( $input['station_name'] ) ? sanitize_text_field( $input['station_name'] ) : '';
    $clean['poll_interval'] = isset( $input['poll_interval'] ) ? intval( $input['poll_interval'] ) : 15;
    $clean['spotify_client_id']     = isset( $input['spotify_client_id'] ) ? sanitize_text_field( $input['spotify_client_id'] ) : '';
    $clean['spotify_client_secret'] = isset( $input['spotify_client_secret'] ) ? sanitize_text_field( $input['spotify_client_secret'] ) : '';
    return $clean;
}

/**
 * Page de réglages
 */
function netradio_render_settings_page() {
    $options = get_option( 'netradio_settings', array() );
    $defaults = array(
        'api_provider'  => 'radioairplay',
        'api_url'       => NETRADIO_DEFAULT_API_URL,
        'api_token'     => '',
        'station_id'    => '847',
        'api_key'       => '80R7MS53YOOY',
        'api_base'      => 'https://c22.radioboss.fm',
        'stream_url'    => NETRADIO_DEFAULT_STREAM_URL,
        'stream_fallback_url' => '',
        'metadata_delay' => 0,
        'station_name'  => 'Netradio',
        'poll_interval' => 12,
        'spotify_client_id'     => '',
        'spotify_client_secret' => '',
    );
    $options = wp_parse_args( $options, $defaults );
    ?>
    <style>
        .netradio-admin { max-width: 900px; }
        .netradio-admin h1 { display: flex; align-items: center; gap: 12px; font-size: 28px; }
        .netradio-admin .netradio-card { background: #fff; border: 1px solid #ddd; border-radius: 6px; padding: 24px; margin-top: 20px; }
        .netradio-admin .netradio-card h2 { margin-top: 0; padding-bottom: 12px; border-bottom: 2px solid #e10a16; font-size: 18px; }
        .netradio-admin .netradio-row { display: grid; grid-template-columns: 220px 1fr; gap: 20px; align-items: start; padding: 14px 0; border-bottom: 1px solid #f0f0f0; }
        .netradio-admin .netradio-row:last-child { border-bottom: 0; }
        .netradio-admin .netradio-row label { font-weight: 600; padding-top: 8px; }
        .netradio-admin .netradio-row input[type=text], .netradio-admin .netradio-row input[type=url], .netradio-admin .netradio-row input[type=password], .netradio-admin .netradio-row input[type=number] { width: 100%; max-width: 480px; padding: 8px 12px; border: 1px solid #ccc; border-radius: 4px; font-family: monospace; font-size: 13px; }
        .netradio-admin .netradio-help { font-size: 12px; color: #666; margin-top: 6px; line-height: 1.4; }
        .netradio-admin .netradio-test-btn { background: #e10a16; color: #fff; border: 0; padding: 10px 20px; border-radius: 4px; cursor: pointer; font-weight: 600; }
        .netradio-admin .netradio-test-btn:hover { background: #b00811; }
        .netradio-admin #netradio-test-result { margin-top: 12px; padding: 12px; border-radius: 4px; display: none; }
        .netradio-admin #netradio-test-result.success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; display: block; }
        .netradio-admin #netradio-test-result.error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; display: block; }
        .netradio-admin .netradio-toggle-pw { background: #f0f0f0; border: 1px solid #ccc; padding: 8px 12px; cursor: pointer; border-radius: 4px; margin-left: 6px; font-size: 12px; }
        .netradio-admin .netradio-shortcut { background: #1d1d1d; color: #f4efe6; padding: 16px; border-radius: 6px; font-family: monospace; font-size: 13px; line-height: 1.6; margin-top: 12px; }
    </style>

    <div class="wrap netradio-admin">
        <h1>📻 Netradio FM <small style="font-size:13px;color:#888;font-weight:400;">v<?php echo NETRADIO_VERSION; ?></small></h1>

        <?php if ( isset( $_GET['settings-updated'] ) && $_GET['settings-updated'] ) : ?>
            <div class="notice notice-success is-dismissible"><p>✅ Réglages enregistrés.</p></div>
        <?php endif; ?>

        <form method="post" action="options.php">
            <?php settings_fields( 'netradio_settings_group' ); ?>

            <!-- ====== SOURCE DES DONNÉES ====== -->
            <div class="netradio-card">
                <h2>🔀 Source des données (titres &amp; historique)</h2>

                <div class="netradio-row">
                    <label>Plateforme</label>
                    <div>
                        <label style="display:block;padding:10px 12px;border:2px solid <?php echo $options['api_provider'] === 'radioairplay' ? '#e10a16' : '#ddd'; ?>;border-radius:5px;margin-bottom:8px;cursor:pointer;font-weight:400;">
                            <input type="radio" name="netradio_settings[api_provider]" value="radioairplay" <?php checked( $options['api_provider'], 'radioairplay' ); ?>>
                            <strong>RadioAirplay</strong> — plateforme de playout IA <span style="background:#d4edda;color:#155724;padding:1px 7px;border-radius:3px;font-size:11px;font-weight:600;">RECOMMANDÉ</span>
                            <span class="netradio-help" style="margin-left:24px;display:block;">Pochettes déjà en HD, historique complet et filtré, barre de progression temps réel.</span>
                        </label>
                        <label style="display:block;padding:10px 12px;border:2px solid <?php echo $options['api_provider'] === 'radioboss' ? '#e10a16' : '#ddd'; ?>;border-radius:5px;cursor:pointer;font-weight:400;">
                            <input type="radio" name="netradio_settings[api_provider]" value="radioboss" <?php checked( $options['api_provider'], 'radioboss' ); ?>>
                            <strong>RadioBoss Cloud</strong> — ancienne source <span style="background:#f0f0f0;color:#666;padding:1px 7px;border-radius:3px;font-size:11px;font-weight:600;">LEGACY</span>
                            <span class="netradio-help" style="margin-left:24px;display:block;">Conservé comme repli. Utilise les réglages de la carte « API RadioBoss Cloud » ci-dessous.</span>
                        </label>
                    </div>
                </div>

                <div class="netradio-row">
                    <label for="api_url">URL de l'API JSON</label>
                    <div>
                        <input type="url" id="api_url" name="netradio_settings[api_url]" value="<?php echo esc_attr( $options['api_url'] ); ?>" placeholder="<?php echo esc_attr( NETRADIO_DEFAULT_API_URL ); ?>" />
                        <p class="netradio-help">
                            Endpoint « now playing » de RadioAirplay. Une station = une URL.<br>
                            Par défaut : <code><?php echo esc_html( NETRADIO_DEFAULT_API_URL ); ?></code>
                        </p>
                    </div>
                </div>

                <div class="netradio-row">
                    <label for="api_token">Token (facultatif)</label>
                    <div>
                        <input type="password" id="api_token" name="netradio_settings[api_token]" value="<?php echo esc_attr( $options['api_token'] ); ?>" placeholder="Laisser vide — l'endpoint est public" />
                        <button type="button" class="netradio-toggle-pw" onclick="var f=document.getElementById('api_token');f.type=f.type==='password'?'text':'password';">Afficher / Masquer</button>
                        <p class="netradio-help">
                            Envoyé en en-tête <code>Authorization: Bearer …</code>. À remplir uniquement si l'endpoint devient protégé un jour. Le token ne quitte jamais le serveur.
                        </p>
                    </div>
                </div>

                <div class="netradio-row">
                    <label for="poll_interval">Rafraîchissement</label>
                    <div>
                        <input type="number" id="poll_interval" name="netradio_settings[poll_interval]" value="<?php echo esc_attr( $options['poll_interval'] ); ?>" min="5" max="120" style="max-width:100px;" /> secondes
                        <p class="netradio-help">
                            Fréquence d'interrogation de l'API. RadioAirplay recommande 10 à 15 s. La barre de progression, elle, avance seule sans requête.
                        </p>
                    </div>
                </div>
            </div>

            <!-- ====== FLUX AUDIO ====== -->
            <?php $stream_is_hls = (bool) preg_match( '#\.m3u8(\?|\#|$)#i', $options['stream_url'] ); ?>
            <div class="netradio-card">
                <h2>🎧 Flux audio (lecteur)</h2>

                <div class="netradio-row">
                    <label for="stream_url">URL du flux</label>
                    <div>
                        <input type="url" id="stream_url" name="netradio_settings[stream_url]" value="<?php echo esc_attr( $options['stream_url'] ); ?>" />
                        <p class="netradio-help">
                            <?php if ( $stream_is_hls ) : ?>
                                <span style="background:#d4edda;color:#155724;padding:2px 8px;border-radius:3px;font-weight:600;">✅ HLS détecté</span>
                                Lecture via hls.js sur Chrome, Firefox et Edge ; lecture native sur Safari et iOS.
                            <?php else : ?>
                                <span style="background:#e7f0fb;color:#1d4d80;padding:2px 8px;border-radius:3px;font-weight:600;">Flux direct (MP3/AAC)</span>
                                Une URL se terminant par <code>.m3u8</code> bascule automatiquement le lecteur en mode HLS.
                            <?php endif; ?>
                        </p>
                        <p class="netradio-help" style="background:#fff8e5;border-left:3px solid #e0a800;padding:8px 10px;">
                            <strong>Publicité audio (GAM).</strong> <code>listen.m3u8</code> redirige vers une playlist propre à
                            chaque auditeur, ce qui permet de comptabiliser les impressions et de plafonner la répétition des spots.
                            Le lecteur poursuit sur cette URL de session et n'ajoute aucun paramètre anti-cache&nbsp;: modifier ce
                            comportement ouvrirait une session neuve à chaque rafraîchissement et fausserait le décompte.
                        </p>
                    </div>
                </div>

                <div class="netradio-row">
                    <label for="stream_fallback_url">Flux de secours</label>
                    <div>
                        <input type="url" id="stream_fallback_url" name="netradio_settings[stream_fallback_url]" value="<?php echo esc_attr( $options['stream_fallback_url'] ); ?>" placeholder="Aucun — le HLS est la seule diffusion" />
                        <p class="netradio-help">
                            Champ facultatif, à laisser vide tant que le HLS est la seule diffusion.
                            S'il est renseigné, le lecteur bascule dessus quand le flux principal échoue —
                            mais un flux de secours ne passe pas par l'AdServer&nbsp;: les écoutes concernées ne seraient pas monétisées.
                        </p>
                    </div>
                </div>

                <div class="netradio-row">
                    <label for="metadata_delay">Décalage d'affichage</label>
                    <div>
                        <input type="number" id="metadata_delay" name="netradio_settings[metadata_delay]" value="<?php echo esc_attr( $options['metadata_delay'] ); ?>" min="0" max="300" style="max-width:100px;" /> secondes
                        <p class="netradio-help">
                            En HLS, l'auditeur entend le son avec plusieurs dizaines de secondes de retard, alors que l'API annonce
                            le bord du direct&nbsp;: le titre affiché est donc en avance sur celui qu'on entend.
                            Cette valeur décale l'affichage pour le faire correspondre au son.
                            <strong>0 = aucun décalage.</strong>
                            La page <a href="<?php echo esc_url( admin_url( 'admin.php?page=netradio-diagnostic' ) ); ?>">🩺 Diagnostic</a> mesure le retard réel et vous indique la valeur à saisir.
                        </p>
                    </div>
                </div>

                <div class="netradio-row">
                    <label for="station_name">Nom de la station</label>
                    <div>
                        <input type="text" id="station_name" name="netradio_settings[station_name]" value="<?php echo esc_attr( $options['station_name'] ); ?>" />
                        <p class="netradio-help">Affiché dans le lecteur, et à la place du libellé technique pendant les jingles et les pubs.</p>
                    </div>
                </div>
            </div>

            <!-- ====== RADIOBOSS ====== -->
            <div class="netradio-card" style="<?php echo $options['api_provider'] === 'radioairplay' ? 'opacity:.6;' : ''; ?>">
                <h2>📡 API RadioBoss Cloud <?php if ( $options['api_provider'] === 'radioairplay' ) : ?><span style="font-size:11px;font-weight:400;color:#888;background:#f0f0f0;padding:2px 8px;border-radius:3px;">inactif — source RadioAirplay sélectionnée</span><?php endif; ?></h2>

                <div class="netradio-row">
                    <label for="station_id">Station ID</label>
                    <div>
                        <input type="text" id="station_id" name="netradio_settings[station_id]" value="<?php echo esc_attr( $options['station_id'] ); ?>" />
                        <div class="netradio-help">Identifiant numérique de votre station chez RadioBoss (visible dans le dashboard, par exemple <code>847</code>).</div>
                    </div>
                </div>

                <div class="netradio-row">
                    <label for="api_key">Clé API</label>
                    <div>
                        <input type="password" id="api_key" name="netradio_settings[api_key]" value="<?php echo esc_attr( $options['api_key'] ); ?>" />
                        <button type="button" class="netradio-toggle-pw" onclick="var f=document.getElementById('api_key');f.type=f.type==='password'?'text':'password';">Afficher / Masquer</button>
                        <div class="netradio-help">Visible dans RadioBoss Cloud → Settings → Account → API Key. Cette clé reste serveur (jamais exposée au navigateur).</div>
                    </div>
                </div>

                <div class="netradio-row">
                    <label for="api_base">URL de base API</label>
                    <div>
                        <input type="url" id="api_base" name="netradio_settings[api_base]" value="<?php echo esc_attr( $options['api_base'] ); ?>" />
                        <div class="netradio-help">URL du serveur RadioBoss qui héberge votre station. Par défaut : <code>https://c22.radioboss.fm</code></div>
                    </div>
                </div>

                <div class="netradio-row">
                    <label>Test de connexion</label>
                    <div>
                        <button type="button" class="netradio-test-btn" id="netradio-test-btn">🔌 Tester la connexion API</button>
                        <div id="netradio-test-result"></div>
                    </div>
                </div>
            </div>

            <!-- ====== SPOTIFY ====== -->
            <div class="netradio-card">
                <h2>🎵 API Spotify <small style="font-weight:400;color:#888;">— recommandé pour de belles pochettes</small></h2>
                <p style="margin-bottom:16px;color:#444;font-size:13px;line-height:1.6;">
                    <strong>Pourquoi configurer Spotify ?</strong> RadioBoss fournit des pochettes basiques. Spotify retourne <strong>les vraies pochettes officielles haute qualité</strong> + l'album, l'année, et le lien d'écoute. Quand l'API Spotify trouve le morceau, la pochette est automatiquement remplacée partout sur le site.
                </p>
                <details style="background:#f5f5f5;padding:12px 16px;border-radius:4px;margin-bottom:16px;cursor:pointer;">
                    <summary style="font-weight:600;cursor:pointer;">📖 Comment obtenir mes identifiants Spotify ? (gratuit, 3 min)</summary>
                    <ol style="margin:12px 0 0 20px;font-size:13px;line-height:1.7;">
                        <li>Aller sur <a href="https://developer.spotify.com/dashboard" target="_blank"><strong>developer.spotify.com/dashboard</strong></a></li>
                        <li>Se connecter avec un compte Spotify (gratuit, perso ou pro peu importe)</li>
                        <li>Cliquer sur <strong>"Create app"</strong></li>
                        <li>Remplir :
                            <ul style="margin:6px 0 0 18px;">
                                <li>App name : <code>Netradio Now Playing</code></li>
                                <li>App description : <code>Affichage des pochettes du flux radio</code></li>
                                <li>Redirect URI : <code>https://netradio.fr</code> (peu importe, on ne s'en sert pas)</li>
                                <li>Cocher "Web API"</li>
                            </ul>
                        </li>
                        <li>Save → cliquer sur l'app créée → <strong>Settings</strong></li>
                        <li>Copier le <strong>Client ID</strong> et coller ci-dessous</li>
                        <li>Cliquer "View client secret" → copier et coller ci-dessous</li>
                        <li>Enregistrer + Tester</li>
                    </ol>
                </details>

                <div class="netradio-row">
                    <label for="spotify_client_id">Client ID</label>
                    <div>
                        <input type="text" id="spotify_client_id" name="netradio_settings[spotify_client_id]" value="<?php echo esc_attr( $options['spotify_client_id'] ); ?>" placeholder="ex: 1a2b3c4d5e6f7g8h9i0j..." />
                    </div>
                </div>

                <div class="netradio-row">
                    <label for="spotify_client_secret">Client Secret</label>
                    <div>
                        <input type="password" id="spotify_client_secret" name="netradio_settings[spotify_client_secret]" value="<?php echo esc_attr( $options['spotify_client_secret'] ); ?>" placeholder="ex: 0z9y8x7w6v5u4t3s2r1q..." />
                        <button type="button" class="netradio-toggle-pw" onclick="var f=document.getElementById('spotify_client_secret');f.type=f.type==='password'?'text':'password';">Afficher / Masquer</button>
                    </div>
                </div>

                <div class="netradio-row">
                    <label>Test Spotify</label>
                    <div>
                        <button type="button" class="netradio-test-btn" id="netradio-spotify-test-btn" style="background:#1DB954;">🎧 Tester Spotify</button>
                        <div id="netradio-spotify-test-result"></div>
                    </div>
                </div>
            </div>

            <!-- ====== RACCOURCIS ====== -->
            <div class="netradio-card">
                <h2>🔗 Raccourcis</h2>
                <div class="netradio-shortcut">
                    <strong>URLs importantes de votre station :</strong><br>
                    🎧 Stream : <a href="<?php echo esc_url( $options['stream_url'] ); ?>" target="_blank" style="color:#ff7c91;"><?php echo esc_html( $options['stream_url'] ); ?></a><br>
                    🖼 Now-playing artwork : <a href="<?php echo esc_url( $options['api_base'] . '/w/artwork/' . $options['station_id'] . '.jpg' ); ?>" target="_blank" style="color:#ff7c91;"><?php echo esc_html( $options['api_base'] . '/w/artwork/' . $options['station_id'] . '.jpg' ); ?></a><br>
                    🏷 Logo station : <a href="<?php echo esc_url( $options['api_base'] . '/stationlogo/png/' . $options['station_id'] . '.png' ); ?>" target="_blank" style="color:#ff7c91;"><?php echo esc_html( $options['api_base'] . '/stationlogo/png/' . $options['station_id'] . '.png' ); ?></a><br>
                    📡 Admin RadioBoss : <a href="https://radioboss.fm" target="_blank" style="color:#ff7c91;">https://radioboss.fm</a>
                </div>
                <p style="margin-top:16px;">
                    <button type="button" class="button" id="netradio-flush-cache">🗑 Vider le cache des titres</button>
                    <button type="button" class="button button-primary" id="netradio-debug-api" style="margin-left:8px;">🔌 Tester &amp; diagnostiquer l'API</button>
                    <?php // L'historique maison ne sert qu'en mode RadioBoss : RadioAirplay le fournit déjà. ?>
                    <?php if ( $options['api_provider'] === 'radioboss' ) : ?>
                        <button type="button" class="button" id="netradio-flush-history" style="margin-left:8px;">🧹 Vider l'historique des titres</button>
                    <?php endif; ?>
                </p>
                <div id="netradio-debug-result" style="display:none;margin-top:16px;background:#1d1d1d;color:#f4efe6;padding:16px;border-radius:6px;font-family:monospace;font-size:11px;line-height:1.5;max-height:500px;overflow:auto;white-space:pre-wrap;"></div>
            </div>

            <?php submit_button( '💾 Enregistrer les réglages' ); ?>
        </form>
    </div>

    <script>
    (function(){
        var testBtn = document.getElementById('netradio-test-btn');
        var resultBox = document.getElementById('netradio-test-result');

        testBtn.addEventListener('click', function() {
            testBtn.disabled = true;
            testBtn.textContent = '⏳ Test en cours…';
            resultBox.className = '';
            resultBox.style.display = 'none';

            var formData = new FormData();
            formData.append('action', 'netradio_test_api');
            formData.append('nonce', '<?php echo wp_create_nonce( "netradio_test_api" ); ?>');

            fetch(ajaxurl, {
                method: 'POST',
                body: formData,
                credentials: 'same-origin'
            })
            .then(r => r.json())
            .then(data => {
                resultBox.style.display = 'block';
                if (data.success) {
                    resultBox.className = 'success';
                    var historyInfo = '';
                    if (typeof data.data.history_found !== 'undefined') {
                        historyInfo = '<br><br><strong>📋 Historique :</strong> ' + data.data.history_found + ' items détectés';
                        if (data.data.history_sample && data.data.history_sample.length > 0) {
                            historyInfo += '<br><em style="font-size:11px;">Aperçu : ' +
                                data.data.history_sample.map(function(h) {
                                    var artist = h.ARTIST || h.artist || '';
                                    var title = h.TITLE || h.title || '';
                                    var cast = h.CASTTITLE || h.casttitle || h.track || '';
                                    return (artist || title) ? (artist + ' – ' + title) : (cast || '(vide)');
                                }).join(' | ') + '</em>';
                        }
                    }
                    var keysInfo = '';
                    if (data.data.keys_in_response && data.data.keys_in_response.length) {
                        keysInfo = '<br><span style="font-size:10px;color:#666;">Clés dans /api/info : ' + data.data.keys_in_response.join(', ') + '</span>';
                    }
                    resultBox.innerHTML = '✅ <strong>' + (data.data.message || 'Connecté') + '</strong><br>' +
                        'Station : ' + (data.data.station || '—') + '<br>' +
                        'En cours : ' + (data.data.nowplaying || '—') + '<br>' +
                        'Auditeurs : ' + (data.data.listeners || 0) +
                        historyInfo + keysInfo;
                } else {
                    resultBox.className = 'error';
                    resultBox.innerHTML = '❌ <strong>Échec :</strong> ' + (data.data.message || 'Erreur inconnue');
                }
            })
            .catch(err => {
                resultBox.style.display = 'block';
                resultBox.className = 'error';
                resultBox.innerHTML = '❌ Erreur réseau : ' + err.message;
            })
            .finally(() => {
                testBtn.disabled = false;
                testBtn.textContent = '🔌 Tester la connexion API';
            });
        });

        var flushBtn = document.getElementById('netradio-flush-cache');
        if (flushBtn) {
            flushBtn.addEventListener('click', function() {
                var fd = new FormData();
                fd.append('action', 'netradio_flush_cache');
                fd.append('nonce', '<?php echo wp_create_nonce( "netradio_flush_cache" ); ?>');
                fetch(ajaxurl, { method: 'POST', body: fd, credentials: 'same-origin' })
                    .then(r => r.json())
                    .then(d => alert(d.data.message || 'Cache vidé'))
                    .catch(e => alert('Erreur: ' + e.message));
            });
        }

        var flushHistoryBtn = document.getElementById('netradio-flush-history');
        if (flushHistoryBtn) {
            flushHistoryBtn.addEventListener('click', function() {
                if (!confirm('Vider l\'historique des titres ? Il se reconstruira automatiquement au fil du temps.')) return;
                var fd = new FormData();
                fd.append('action', 'netradio_flush_history');
                fd.append('nonce', '<?php echo wp_create_nonce( "netradio_flush_history" ); ?>');
                fetch(ajaxurl, { method: 'POST', body: fd, credentials: 'same-origin' })
                    .then(r => r.json())
                    .then(d => alert(d.data.message || 'Historique vidé'))
                    .catch(e => alert('Erreur: ' + e.message));
            });
        }

        // Debug API
        var debugBtn = document.getElementById('netradio-debug-api');
        var debugResult = document.getElementById('netradio-debug-result');
        if (debugBtn) {
            debugBtn.addEventListener('click', function() {
                debugBtn.disabled = true;
                debugBtn.textContent = '⏳ Interrogation des endpoints…';
                debugResult.style.display = 'block';
                debugResult.textContent = 'Chargement…';

                var fd = new FormData();
                fd.append('action', 'netradio_debug_api');
                fd.append('nonce', '<?php echo wp_create_nonce( "netradio_debug_api" ); ?>');

                fetch(ajaxurl, { method: 'POST', body: fd, credentials: 'same-origin' })
                    .then(r => r.json())
                    .then(data => {
                        if (data.success) {
                            var output = '';
                            Object.keys(data.data).forEach(function(endpoint) {
                                var r = data.data[endpoint];
                                output += '═══════════════════════════════════════\n';
                                output += (endpoint === 'nowplaying' ? '📡 DIAGNOSTIC — Now Playing' : '📡 /api/' + endpoint + '/') + '\n';
                                output += '═══════════════════════════════════════\n';
                                output += 'HTTP Status : ' + r.status + '\n';
                                output += 'Est-ce du JSON : ' + (r.is_json ? '✅ oui' : '❌ non') + '\n';
                                if (r.keys && r.keys.length) {
                                    output += 'Clés trouvées : ' + r.keys.join(', ') + '\n';
                                }
                                if (r.error) {
                                    output += 'Erreur : ' + r.error + '\n';
                                }
                                output += '\n--- Réponse ---\n';
                                output += (r.sample || '(vide)').substring(0, 2000);
                                if ((r.sample || '').length > 2000) output += '\n[...tronqué...]';
                                output += '\n\n';
                            });
                            debugResult.textContent = output;
                        } else {
                            debugResult.textContent = '❌ Erreur : ' + (data.data.message || 'inconnue');
                        }
                    })
                    .catch(err => {
                        debugResult.textContent = '❌ Erreur réseau : ' + err.message;
                    })
                    .finally(() => {
                        debugBtn.disabled = false;
                        debugBtn.textContent = '🔌 Tester & diagnostiquer l\'API';
                    });
            });
        }

        // Test Spotify
        var spotifyTestBtn = document.getElementById('netradio-spotify-test-btn');
        var spotifyResult = document.getElementById('netradio-spotify-test-result');
        if (spotifyTestBtn) {
            spotifyTestBtn.addEventListener('click', function() {
                spotifyTestBtn.disabled = true;
                spotifyTestBtn.textContent = '⏳ Test en cours…';
                spotifyResult.className = '';
                spotifyResult.style.display = 'none';

                var fd = new FormData();
                fd.append('action', 'netradio_spotify_test');
                fd.append('nonce', '<?php echo wp_create_nonce( "netradio_test_spotify" ); ?>');

                fetch(ajaxurl, { method: 'POST', body: fd, credentials: 'same-origin' })
                    .then(r => r.json())
                    .then(data => {
                        spotifyResult.style.display = 'block';
                        if (data.success) {
                            spotifyResult.className = 'success';
                            spotifyResult.innerHTML = '✅ <strong>' + data.data.message + '</strong><br>' +
                                'Test recherche : <em>Daft Punk – ' + (data.data.test_album || 'Get Lucky') + '</em>' +
                                (data.data.test_cover ? '<br><img src="' + data.data.test_cover + '" style="width:80px;height:80px;border-radius:4px;margin-top:8px;">' : '');
                        } else {
                            spotifyResult.className = 'error';
                            spotifyResult.innerHTML = '❌ <strong>Échec :</strong> ' + (data.data.message || 'Erreur inconnue');
                        }
                    })
                    .catch(err => {
                        spotifyResult.style.display = 'block';
                        spotifyResult.className = 'error';
                        spotifyResult.innerHTML = '❌ Erreur : ' + err.message;
                    })
                    .finally(() => {
                        spotifyTestBtn.disabled = false;
                        spotifyTestBtn.textContent = '🎧 Tester Spotify';
                    });
            });
        }
    })();
    </script>
    <?php
}

/**
 * Page documentation Magazine
 */
function netradio_render_magazine_doc() {
    include NETRADIO_PATH . '/plugin-mag/templates/doc.php';
}
