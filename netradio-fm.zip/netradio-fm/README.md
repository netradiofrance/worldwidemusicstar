# Netradio FM — Thème WordPress

Thème éditorial pour **Netradio.fr** avec lecteur radio intégré, polling RadioBoss Cloud, mise en page magazine, et CPT Podcasts.

## 🚀 Installation

1. **Téléverser** : `Apparence → Thèmes → Ajouter → Téléverser un thème → netradio-fm.zip`
2. **Activer** le thème (les réglages sont préconfigurés pour la station 847)
3. **Vérifier** dans `Réglages → 📻 Netradio FM` que la connexion fonctionne (bouton "Tester la connexion API")

## ⚙️ Configuration

Tous les réglages sont sous **📻 Netradio FM** dans le menu admin :

- **Station ID** : `847` (déjà rempli)
- **Clé API** : préconfigurée à `80R7MS53YOOY` — **régénérez-la après installation** dans RadioBoss Cloud, puis collez la nouvelle ici
- **URL de base API** : `https://c22.radioboss.fm`
- **URL stream** : `https://c22.radioboss.fm/stream/847`

## 📰 Articles Magazine

Pour publier un article en mise en page magazine :

1. Dans l'éditeur de l'article : cocher la case **"Activer la mise en page magazine"** (encart à droite)
2. Insérer les shortcodes dans le contenu :

```
[mag_hero kicker="DOSSIER · ENERGY" dek="Sous-titre"]
Le grand titre[/mag_hero]

[mag_lead]Chapeau d'introduction.[/mag_lead]

[mag_section num="01" title="Titre de section"]
Texte de la section, paragraphes, etc.
[/mag_section]

[mag_quote cite="—Source"]
Une citation marquante.
[/mag_quote]

[mag_stats]
[mag_stat num="23M€" label="CA 2025"]
[mag_stat num="100M" label="Abonnés" style="accent"]
[/mag_stats]

[mag_fiche title="Spécifications"]
[mag_spec key="Prix" val="1,49€"]
[mag_spec key="Volume" val="250ml"]
[/mag_fiche]
```

Voir la **documentation complète** sous `📻 Netradio FM → Magazine Article`.

## 🎙 Podcasts

Le thème enregistre un Custom Post Type **Podcast** (menu `🎙 Podcasts`) avec :
- Champ durée
- Champ fréquence (Quotidien, Hebdo, etc.)
- URL audio MP3

Affichés automatiquement dans la section Podcasts de la home.

## 🎨 Personnalisation

`Apparence → Personnaliser` :
- Couleur primaire (rouge Netradio)
- Slogan
- Catégorie utilisée pour le hero (par défaut = dernier article)

## 🔌 Intégration RadioBoss

- **Polling** toutes les 15s du now-playing
- **Cache** transient WordPress (10s) pour ne pas spammer l'API
- **Clé API jamais exposée** au navigateur (proxy AJAX)
- **Fallback** automatique sur les artworks publics si l'API ne répond pas

## 📂 Structure

```
netradio-fm/
├── style.css                      (header WP + reset)
├── functions.php                  (setup, enqueue, helpers)
├── header.php / footer.php
├── front-page.php                 (home avec hero + sections)
├── single.php / archive.php / index.php / page.php / 404.php
├── screenshot.png                 (visuel WP admin)
├── assets/
│   ├── css/main.css               (CSS principal ~25 KB)
│   ├── css/magazine.css           (CSS articles magazine)
│   ├── js/player.js               (lecteur audio HTML5)
│   ├── js/radioboss.js            (polling API + historique)
│   ├── js/main.js                 (menu mobile)
│   └── images/placeholder*.svg
├── inc/
│   ├── radioboss-api.php          (classe API avec cache)
│   ├── ajax-endpoints.php         (proxy sécurisé)
│   ├── admin-settings.php         (page Réglages → Netradio FM)
│   ├── customizer.php             (couleurs, slogan)
│   ├── widgets.php                (widget joués récemment)
│   └── custom-post-types.php      (Podcasts, Émissions)
├── template-parts/
│   ├── card.php                   (carte article)
│   └── player.php                 (lecteur fixe)
└── plugin-mag/
    ├── magazine.php               (module shortcodes magazine)
    ├── assets/magazine.css
    └── templates/
        ├── doc.php                (documentation admin)
        └── article-ciao-energy.txt (exemple)
```

## ⚠️ Prérequis SiteGround

- **PHP 8.1+** recommandé (vérifiez dans Site Tools → DevOps → PHP Manager)
- **WordPress 6.0+**
- Memory limit : 256M minimum

## 🔄 Mise à jour

Pour mettre à jour le thème : téléverser à nouveau le zip via `Apparence → Thèmes → Ajouter → Téléverser` (cochez "Remplacer le thème existant"). Les réglages sont conservés.

---

**v1.0.0** · Netradio · 2026
