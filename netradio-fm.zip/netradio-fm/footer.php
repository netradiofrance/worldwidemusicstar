<?php
/**
 * Footer
 *
 * @package NetradioFM
 */
?>

<!-- Footer -->
<footer class="nr-footer">
    <div class="nr-footer-inner">
        <div class="nr-footer-brand">
            <div class="nr-logo">net<span>radio</span></div>
            <p><?php echo esc_html( get_theme_mod( 'netradio_tagline', 'Like Station. La radio des actus musicales, des youtubeurs et des influenceurs préférés des Français.' ) ); ?></p>
            <address>
                Groupe Netradio<br>
                58 rue de Monceau, 75008 Paris<br>
                <a href="mailto:contact@netradio.fr" style="color:inherit;">contact@netradio.fr</a>
            </address>
        </div>

        <?php if ( is_active_sidebar( 'footer-2' ) ) : ?>
            <?php dynamic_sidebar( 'footer-2' ); ?>
        <?php else : ?>
            <div class="nr-footer-col">
                <h5>Le site</h5>
                <ul>
                    <li><a href="<?php echo esc_url( home_url( '/ecouter-netradio/' ) ); ?>">Radio Live</a></li>
                    <li><a href="https://tackendo.com/netradio-vision/" target="_blank">Netradio Vision</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/category/musique/' ) ); ?>">Musique</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/category/influenceurs/' ) ); ?>">Influenceurs</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/podcasts/' ) ); ?>">Podcasts</a></li>
                </ul>
            </div>
        <?php endif; ?>

        <?php if ( is_active_sidebar( 'footer-3' ) ) : ?>
            <?php dynamic_sidebar( 'footer-3' ); ?>
        <?php else : ?>
            <div class="nr-footer-col">
                <h5>Écouter</h5>
                <ul>
                    <li><a href="#">App iOS</a></li>
                    <li><a href="#">App Android</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/ecouter-netradio/' ) ); ?>">DAB+</a></li>
                    <li><a href="#">Apple TV</a></li>
                    <li><a href="https://www.amazon.fr/Hosttec-Solutions-Netradio-France/dp/B083XT62MB" target="_blank">Amazon Fire TV</a></li>
                    <li><a href="https://channelstore.roku.com/details/c24b4d43df3ae951a391e62f8002a414/netradio" target="_blank">Roku</a></li>
                </ul>
            </div>
        <?php endif; ?>

        <?php if ( is_active_sidebar( 'footer-4' ) ) : ?>
            <?php dynamic_sidebar( 'footer-4' ); ?>
        <?php else : ?>
            <div class="nr-footer-col">
                <h5>Le groupe</h5>
                <ul>
                    <li><a href="https://distro.airplayradio.com" target="_blank">Music Distribution</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/submit-your-song-to-netradio/' ) ); ?>">Add a Song</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/labels/' ) ); ?>">Music Labels</a></li>
                    <li><a href="https://radiotarget.fr" target="_blank">Advertising</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/politique-de-confidentialite/' ) ); ?>">Politique de confidentialité</a></li>
                </ul>
            </div>
        <?php endif; ?>
    </div>
    <div class="nr-footer-bottom">
        <span>© <?php echo date( 'Y' ); ?> NETRADIO · Tous droits réservés</span>
        <span>Made with ❤ in Paris</span>
    </div>
</footer>

<!-- Lecteur fixe -->
<?php get_template_part( 'template-parts/player' ); ?>

<?php wp_footer(); ?>
</body>
</html>
