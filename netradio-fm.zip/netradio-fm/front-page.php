<?php
/**
 * Front Page (Home)
 *
 * @package NetradioFM
 */

get_header();

// Article en hero
$hero_cat = get_theme_mod( 'netradio_hero_category', '' );
$hero_args = array(
    'posts_per_page' => 1,
    'post_status'    => 'publish',
);
if ( ! empty( $hero_cat ) ) {
    $hero_args['category_name'] = $hero_cat;
}
$hero_query = new WP_Query( $hero_args );
$hero_post = $hero_query->have_posts() ? $hero_query->posts[0] : null;

// Récupérer ensuite les articles à la une (en excluant le hero)
$exclude_ids = $hero_post ? array( $hero_post->ID ) : array();
?>

<!-- HERO -->
<section class="nr-hero">
    <div class="nr-hero-main" <?php if ( $hero_post && has_post_thumbnail( $hero_post->ID ) ) echo 'style="--nr-bg: url(' . esc_url( get_the_post_thumbnail_url( $hero_post->ID, 'netradio-hero' ) ) . ');" data-bg'; ?>>
        <?php if ( $hero_post ) :
            $cat = get_the_category( $hero_post->ID );
            $cat_name = ! empty( $cat ) ? $cat[0]->name : '';
        ?>
            <div class="nr-hero-kicker">
                <span class="nr-tag">À la une</span>
                <?php if ( $cat_name ) : ?><span><?php echo esc_html( $cat_name ); ?></span><?php endif; ?>
            </div>
            <h1 class="nr-hero-title"><a href="<?php echo esc_url( get_permalink( $hero_post->ID ) ); ?>" style="color:inherit;"><?php echo get_the_title( $hero_post->ID ); ?></a></h1>
            <p class="nr-hero-dek"><?php echo esc_html( wp_trim_words( get_the_excerpt( $hero_post->ID ), 28 ) ); ?></p>
            <div class="nr-hero-byline">
                <span><?php echo esc_html( get_the_author_meta( 'display_name', $hero_post->post_author ) ); ?></span>
                <span><?php echo esc_html( netradio_format_date( $hero_post->ID ) ); ?></span>
                <span><?php echo esc_html( netradio_reading_time( $hero_post->ID ) ); ?></span>
            </div>
        <?php else : ?>
            <h1 class="nr-hero-title">Bienvenue sur <em>Netradio</em></h1>
            <p class="nr-hero-dek">La radio des actus musicales, des youtubeurs et des influenceurs. Publiez votre premier article pour qu'il s'affiche ici.</p>
        <?php endif; ?>
    </div>

    <aside class="nr-hero-side">
        <?php echo netradio_get_radioboss_widget_html( 12 ); ?>
    </aside>
</section>

<!-- À LA UNE : 4 derniers articles -->
<section class="nr-section">
    <div class="nr-section-head">
        <h2 class="nr-section-title"><span class="nr-section-num">01</span>À LA UNE</h2>
        <a href="<?php echo esc_url( home_url( '/blog/' ) ); ?>" class="nr-section-link">Toutes les actus →</a>
    </div>

    <div class="nr-grid">
        <?php
        $query = new WP_Query( array(
            'posts_per_page' => 4,
            'post__not_in'   => $exclude_ids,
            'post_status'    => 'publish',
        ) );
        if ( $query->have_posts() ) :
            while ( $query->have_posts() ) : $query->the_post();
                $exclude_ids[] = get_the_ID();
                get_template_part( 'template-parts/card' );
            endwhile;
            wp_reset_postdata();
        else : ?>
            <p style="grid-column: 1 / -1; text-align: center; color: #888;">Aucun article publié pour l'instant.</p>
        <?php endif; ?>
    </div>
</section>

<!-- GRANDE UNE : article "Magazine" récent -->
<?php
$mag_query = new WP_Query( array(
    'posts_per_page' => 1,
    'post__not_in'   => $exclude_ids,
    'meta_query'     => array(
        array( 'key' => '_netradio_magazine_mode', 'value' => 'yes' )
    ),
) );
if ( $mag_query->have_posts() ) :
    $mag_query->the_post();
    $exclude_ids[] = get_the_ID();
    $cat = netradio_primary_category();
?>
<section class="nr-feature">
    <div class="nr-feature-inner">
        <div class="nr-feature-image">
            <img src="<?php echo esc_url( netradio_thumbnail_url( 'netradio-feature' ) ); ?>" alt="">
        </div>
        <div>
            <div class="nr-feature-kicker">⚡ Dossier · <?php echo $cat ? esc_html( $cat->name ) : ''; ?></div>
            <h2 class="nr-feature-title"><a href="<?php the_permalink(); ?>" style="color:inherit;"><?php the_title(); ?></a></h2>
            <p class="nr-feature-dek"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 30 ) ); ?></p>
            <a href="<?php the_permalink(); ?>" class="nr-feature-cta">Lire le dossier →</a>
        </div>
    </div>
</section>
<?php wp_reset_postdata(); endif; ?>

<!-- INFLUENCEURS (fond noir) -->
<?php
$inf_cat = netradio_smart_category( 'Influenceurs', array( 'influenceurs', 'influenceur', 'influencers', 'influencer' ) );
$inf_cat_url = $inf_cat ? get_category_link( $inf_cat->term_id ) : '';
?>
<section class="nr-influencers">
    <div class="nr-influencers-inner">
        <div class="nr-section-head">
            <h2 class="nr-section-title"><span class="nr-section-num">02</span>INFLUENCEURS</h2>
            <?php if ( $inf_cat_url ) : ?>
                <a href="<?php echo esc_url( $inf_cat_url ); ?>" class="nr-section-link">Tout voir →</a>
            <?php endif; ?>
        </div>

        <?php
        if ( $inf_cat ) {
            $inf_query = new WP_Query( array(
                'posts_per_page' => 5,
                'cat'            => $inf_cat->term_id,
                'post__not_in'   => $exclude_ids,
            ) );
        } else {
            $inf_query = new WP_Query( array( 'posts_per_page' => 0 ) ); // pas de résultat
        }
        if ( $inf_query->have_posts() ) : ?>
        <div class="nr-inf-grid">
            <?php $count = 0;
            while ( $inf_query->have_posts() ) : $inf_query->the_post(); $count++;
                $is_large = ( $count === 1 );
            ?>
                <article class="nr-inf-card <?php echo $is_large ? 'large' : ''; ?>">
                    <a href="<?php the_permalink(); ?>">
                        <div class="nr-inf-image">
                            <img src="<?php echo esc_url( netradio_thumbnail_url( $is_large ? 'netradio-feature' : 'netradio-card' ) ); ?>" alt="">
                        </div>
                        <div class="nr-inf-content">
                            <div class="nr-inf-kicker"><?php $tags = get_the_tags(); echo $tags ? esc_html( $tags[0]->name ) : 'Influenceurs'; ?></div>
                            <h3><?php the_title(); ?></h3>
                        </div>
                    </a>
                </article>
                <?php $exclude_ids[] = get_the_ID(); ?>
            <?php endwhile; ?>
        </div>
        <?php wp_reset_postdata(); else : ?>
            <p style="opacity: 0.6;">Aucun article dans la catégorie "Influenceurs" pour l'instant.</p>
        <?php endif; ?>
    </div>
</section>

<!-- MUSIQUE -->
<?php
$mus_cat = netradio_smart_category( 'Musique', array( 'musique', 'music' ) );
$mus_cat_url = $mus_cat ? get_category_link( $mus_cat->term_id ) : '';
?>
<section class="nr-section">
    <div class="nr-section-head">
        <h2 class="nr-section-title"><span class="nr-section-num">03</span>ACTU MUSIQUE</h2>
        <?php if ( $mus_cat_url ) : ?>
            <a href="<?php echo esc_url( $mus_cat_url ); ?>" class="nr-section-link">Plus de musique →</a>
        <?php endif; ?>
    </div>

    <div class="nr-grid">
        <?php
        if ( $mus_cat ) {
            $music_query = new WP_Query( array(
                'posts_per_page' => 4,
                'cat'            => $mus_cat->term_id,
                'post__not_in'   => $exclude_ids,
            ) );
        } else {
            $music_query = new WP_Query( array( 'posts_per_page' => 0 ) );
        }
        if ( $music_query->have_posts() ) :
            while ( $music_query->have_posts() ) : $music_query->the_post();
                $exclude_ids[] = get_the_ID();
                get_template_part( 'template-parts/card' );
            endwhile;
            wp_reset_postdata();
        endif;
        ?>
    </div>
</section>

<!-- PODCASTS -->
<?php
// URL intelligente : archive CPT podcast en priorité, sinon catégorie podcasts
$podcasts_url = '';
if ( post_type_exists( 'podcast' ) ) {
    $podcasts_url = get_post_type_archive_link( 'podcast' );
}
if ( ! $podcasts_url ) {
    $podcasts_url = netradio_smart_category_url( 'Podcasts', array( 'podcasts', 'podcast' ) );
}
?>
<section class="nr-podcasts">
    <div class="nr-section-head">
        <h2 class="nr-section-title"><span class="nr-section-num">04</span>PODCASTS</h2>
        <?php if ( $podcasts_url ) : ?>
            <a href="<?php echo esc_url( $podcasts_url ); ?>" class="nr-section-link">Tous les podcasts →</a>
        <?php endif; ?>
    </div>

    <div class="nr-podcast-grid">
        <?php
        // Essayer d'abord le CPT podcast
        $pod_query = new WP_Query( array(
            'post_type'      => 'podcast',
            'posts_per_page' => 3,
        ) );

        // Si le CPT est vide, fallback sur la catégorie "Podcasts"
        if ( ! $pod_query->have_posts() ) {
            $pod_cat = netradio_smart_category( 'Podcasts', array( 'podcasts', 'podcast' ) );
            if ( $pod_cat ) {
                $pod_query = new WP_Query( array(
                    'posts_per_page' => 3,
                    'cat'            => $pod_cat->term_id,
                ) );
            }
        }

        if ( $pod_query->have_posts() ) :
            while ( $pod_query->have_posts() ) : $pod_query->the_post();
                $duration  = get_post_meta( get_the_ID(), '_podcast_duration', true );
                $frequency = get_post_meta( get_the_ID(), '_podcast_frequency', true );
                $meta = array_filter( array( $frequency, $duration ) );
        ?>
            <article class="nr-podcast">
                <a href="<?php the_permalink(); ?>" style="display:flex; gap:20px; align-items:flex-start;">
                    <div class="nr-podcast-cover">
                        <img src="<?php echo esc_url( netradio_thumbnail_url( 'netradio-thumb' ) ); ?>" alt="">
                    </div>
                    <div class="nr-podcast-info">
                        <?php if ( ! empty( $meta ) ) : ?>
                            <div class="nr-podcast-meta"><?php echo esc_html( implode( ' · ', $meta ) ); ?></div>
                        <?php endif; ?>
                        <h4><?php the_title(); ?></h4>
                        <p class="nr-podcast-dek"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 20 ) ); ?></p>
                    </div>
                </a>
            </article>
        <?php endwhile; wp_reset_postdata(); else : ?>
            <p style="grid-column: 1 / -1; opacity: 0.6;">Aucun podcast publié pour l'instant.</p>
        <?php endif; ?>
    </div>
</section>

<!-- NEWSLETTER -->
<section class="nr-newsletter">
    <div class="nr-newsletter-inner">
        <div class="nr-newsletter-kicker">⚡ Ne ratez plus rien</div>
        <h2>Le meilleur de Netradio,<br><em>tous les vendredis.</em></h2>
        <p>Les sorties musicales, les histoires d'influenceurs, les dossiers et nos coups de cœur. Directement dans votre boîte mail.</p>
        <form class="nr-newsletter-form" onsubmit="event.preventDefault(); this.querySelector('input').value=''; alert('Merci ! Inscription à connecter à Mailchimp/Brevo via plugin.');">
            <input type="email" placeholder="votre@email.fr" required>
            <button type="submit">S'inscrire</button>
        </form>
    </div>
</section>

<?php get_footer(); ?>
