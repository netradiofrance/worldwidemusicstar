<?php
/**
 * Index (fallback)
 *
 * @package NetradioFM
 */

get_header();
?>

<section class="nr-section">
    <h1 class="nr-section-title" style="margin-bottom: 30px;">Articles récents</h1>

    <?php if ( have_posts() ) : ?>
        <div class="nr-grid">
            <?php while ( have_posts() ) : the_post(); ?>
                <?php get_template_part( 'template-parts/card' ); ?>
            <?php endwhile; ?>
        </div>

        <div class="nr-pagination">
            <?php the_posts_pagination( array( 'prev_text' => '← Précédent', 'next_text' => 'Suivant →' ) ); ?>
        </div>
    <?php else : ?>
        <p style="text-align: center;">Aucun article publié.</p>
    <?php endif; ?>
</section>

<?php get_footer(); ?>
