<?php
/**
 * Header
 *
 * @package NetradioFM
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- Topbar -->
<div class="nr-topbar">
    <div class="nr-live">
        <span class="nr-livedot"></span>
        <span>DAB+ · FM · Web</span>
    </div>
    <div class="nr-social">
        <a href="https://www.instagram.com/netradio.fr/" target="_blank" rel="noopener">Instagram</a>
        <a href="https://www.tiktok.com/@netradio.france" target="_blank" rel="noopener">TikTok</a>
        <a href="https://www.youtube.com/@NETRADIODAB" target="_blank" rel="noopener">YouTube</a>
        <a href="https://twitter.com/netradiofr" target="_blank" rel="noopener">Twitter</a>
    </div>
</div>

<!-- Header principal -->
<header class="nr-header">
    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="nr-logo">
        <?php if ( has_custom_logo() ) : ?>
            <?php the_custom_logo(); ?>
        <?php else : ?>
            net<span>radio</span>
        <?php endif; ?>
    </a>

    <button class="nr-menu-toggle" aria-label="Menu"><span></span><span></span><span></span></button>

    <nav class="nr-nav">
        <?php
        if ( has_nav_menu( 'primary' ) ) {
            wp_nav_menu( array(
                'theme_location' => 'primary',
                'container'      => false,
                'menu_class'     => '',
                'items_wrap'     => '%3$s',
                'fallback_cb'    => false,
            ) );
        } else {
            // Menu par défaut intelligent : auto-mapping des catégories existantes
            ?>
            <li class="<?php echo is_front_page() ? 'current-menu-item' : ''; ?>"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a></li>
            <?php
            // Catégories : on cherche par nom et on n'affiche que si elles existent
            $menu_cats = array(
                'Musique'      => array( 'musique', 'music' ),
                'Influenceurs' => array( 'influenceurs', 'influenceur', 'influencers', 'influencer' ),
                'Vidéo'        => array( 'video', 'videos', 'vidéo', 'vidéos' ),
                'Culture'      => array( 'culture' ),
            );
            foreach ( $menu_cats as $label => $slugs ) {
                $url = netradio_smart_category_url( $label, $slugs );
                if ( $url ) {
                    printf( '<li><a href="%s">%s</a></li>', esc_url( $url ), esc_html( $label ) );
                }
            }

            // Podcasts : on essaie d'abord l'archive CPT, sinon la catégorie
            $podcasts_url = '';
            if ( post_type_exists( 'podcast' ) ) {
                $podcasts_url = get_post_type_archive_link( 'podcast' );
            }
            if ( ! $podcasts_url ) {
                $podcasts_url = netradio_smart_category_url( 'Podcasts', array( 'podcasts', 'podcast' ) );
            }
            if ( $podcasts_url ) {
                printf( '<li><a href="%s">Podcasts</a></li>', esc_url( $podcasts_url ) );
            }

            // Netradio Vision : lien externe vers Tackendo
            ?>
            <li><a href="https://tackendo.com/netradio-vision/" target="_blank" rel="noopener noreferrer">Netradio Vision</a></li>
            <?php
            // Note : on retire "Radio" du menu — doublon avec le player permanent en bas
        }
        ?>
    </nav>

    <div class="nr-header-cta">
        <button class="nr-listen-btn" id="nr-listen-btn">Écouter live</button>
    </div>
</header>
