/**
 * Netradio FM — Polling des données radio
 *
 * v2.1 : compatible RadioAirplay + RadioBoss (legacy)
 *  - Barre de progression temps réel calculée côté client
 *    à partir de started_at + duration (aucune requête réseau)
 *  - Correction du décalage d'horloge client/serveur via server_now
 *  - Re-fetch anticipé à la fin d'un morceau → changement quasi instantané
 *  - Affichage neutre pendant les jingles / pubs (type ≠ music)
 */
(function() {
    'use strict';

    var config       = window.NetradioConfig || {};
    var interval     = config.pollInterval || 12000;
    var stationName  = config.stationName || 'Netradio';
    // Cap strict : jamais plus de 12 items (3 lignes × 4 colonnes)
    var historyCount = Math.min(config.historyCount || 12, 12);

    // Image fallback (SVG dégradé rouge) en data-URI : ne peut JAMAIS échouer
    var FALLBACK_COVER = 'data:image/svg+xml;utf8,' + encodeURIComponent(
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200">' +
        '<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">' +
        '<stop offset="0" stop-color="#e10a16"/><stop offset="1" stop-color="#ff3b1f"/>' +
        '</linearGradient></defs>' +
        '<rect width="200" height="200" fill="url(#g)"/>' +
        '<g transform="translate(100,100)" fill="white" opacity="0.9">' +
        '<circle r="36" fill="none" stroke="white" stroke-width="3"/>' +
        '<circle r="6"/></g></svg>'
    );

    var lastTrack = null;

    /* -----------------------------------------------------------------
     * Synchronisation avec ce que l'auditeur entend
     *
     * En HLS, le son est reçu avec un retard (segments + insertion
     * publicitaire) : l'API annonce le bord du direct, mais l'auditeur
     * en est plusieurs dizaines de secondes derrière. On remonte donc la
     * chronologie (now + historique, tous horodatés) pour afficher le
     * titre effectivement diffusé dans les oreilles.
     * -------------------------------------------------------------- */

    var displayDelay = Math.max(0, parseInt(config.metadataDelay, 10) || 0);
    var fetchedAt    = Date.now();   // instant de réception de la dernière réponse

    /**
     * Choisit, dans la chronologie, l'élément entendu à l'instant présent.
     * Retourne l'objet à afficher et le nombre d'éléments d'historique à
     * masquer (ceux que l'auditeur n'a pas encore entendus).
     */
    function pickHeard(now, history) {
        if (!displayDelay || !now || !now.server_now) {
            return { now: now, skip: 0 };
        }

        // Temps serveur estimé, corrigé de la dérive depuis la réponse.
        var serverNow = now.server_now + (Date.now() - fetchedAt) / 1000;
        var target    = serverNow - displayDelay;

        // Le titre du direct a-t-il déjà atteint les oreilles ?
        if (!now.started_at || now.started_at <= target) {
            return { now: now, skip: 0 };
        }

        if (!Array.isArray(history)) return { now: now, skip: 0 };

        for (var i = 0; i < history.length; i++) {
            var it = history[i];
            if (it && it.played_at && it.played_at <= target) {
                return {
                    now: {
                        artist:     it.artist,
                        title:      it.title,
                        cover:      it.cover,
                        is_music:   true,
                        is_break:   false,
                        listeners:  now.listeners,
                        // Durée inconnue pour un titre passé : on masque la
                        // barre de progression plutôt que d'afficher un faux.
                        started_at: 0,
                        duration:   0,
                        server_now: now.server_now
                    },
                    skip: i + 1
                };
            }
        }
        return { now: now, skip: 0 };
    }


    /* -----------------------------------------------------------------
     * Barre de progression
     * -------------------------------------------------------------- */

    var progress = {
        startedAt: 0,   // timestamp Unix (s) du début du morceau
        duration:  0,   // durée du morceau (s)
        offset:    0,   // décalage horloge serveur - client (s)
        refetched: false
    };

    function nowSeconds() {
        return (Date.now() / 1000) + progress.offset;
    }

    function setProgressFrom(data) {
        var started   = parseInt(data.started_at, 10) || 0;
        var duration  = parseInt(data.duration, 10) || 0;
        var serverNow = parseInt(data.server_now, 10) || 0;

        // L'horloge du visiteur peut être décalée : on se cale sur le serveur.
        if (serverNow) {
            progress.offset = serverNow - (Date.now() / 1000);
        }

        var changed = (started !== progress.startedAt);
        progress.startedAt = started;
        progress.duration  = duration;
        if (changed) progress.refetched = false;

        var available = (started > 0 && duration > 0);
        document.querySelectorAll('[data-nr-progress]').forEach(function(el) {
            el.classList.toggle('is-available', available);
        });
        if (!available) {
            document.querySelectorAll('[data-nr-progress-bar]').forEach(function(el) {
                el.style.width = '0%';
            });
        }
    }

    function formatTime(seconds) {
        seconds = Math.floor(seconds || 0);
        var m = Math.floor(seconds / 60);
        var s = seconds % 60;
        return m + ':' + (s < 10 ? '0' : '') + s;
    }

    function tickProgress() {
        var bars = document.querySelectorAll('[data-nr-progress-bar]');
        if (!bars.length) return;
        if (progress.startedAt <= 0 || progress.duration <= 0) return;

        var elapsed = nowSeconds() - progress.startedAt;
        var pct     = (elapsed / progress.duration) * 100;
        if (pct < 0)   pct = 0;
        if (pct > 100) pct = 100;

        bars.forEach(function(el) { el.style.width = pct.toFixed(2) + '%'; });

        document.querySelectorAll('[data-nr-elapsed]').forEach(function(el) {
            el.textContent = formatTime(Math.min(Math.max(elapsed, 0), progress.duration));
        });
        document.querySelectorAll('[data-nr-duration]').forEach(function(el) {
            el.textContent = formatTime(progress.duration);
        });

        // Le morceau est fini : on va chercher le suivant sans attendre le
        // prochain cycle de polling.
        if (pct >= 100 && !progress.refetched) {
            progress.refetched = true;
            setTimeout(fetchRadioData, 1500);
        }
    }

    /* -----------------------------------------------------------------
     * Récupération des données
     * -------------------------------------------------------------- */

    function fetchRadioData() {
        var url = config.ajaxUrl + '?action=netradio_get_radio_data&nonce=' + encodeURIComponent(config.nonce) + '&history=' + historyCount;
        fetch(url, { credentials: 'same-origin' })
            .then(function(r) { return r.json(); })
            .then(function(data) {
                if (data && data.success && data.data) {
                    fetchedAt = Date.now();
                    var heard = pickHeard(data.data.now, data.data.history);
                    updateNowPlaying(heard.now);
                    // On retire de l'historique les titres que l'auditeur
                    // n'a pas encore entendus, sinon le titre en cours y
                    // apparaîtrait en double.
                    var hist = Array.isArray(data.data.history) ? data.data.history.slice(heard.skip) : [];
                    updateHistory(hist);
                } else {
                    fallbackArtworks();
                }
            })
            .catch(function(err) {
                console.warn('Netradio: erreur fetch', err);
                fallbackArtworks();
            });
    }

    function setImgWithFallback(imgEl, primaryUrl) {
        if (!imgEl) return;
        imgEl.onerror = function() {
            if (this.src.indexOf('?') > -1 && this.dataset.tried !== '1') {
                this.dataset.tried = '1';
                this.src = primaryUrl.split('?')[0];
                return;
            }
            this.onerror = null;
            this.src = FALLBACK_COVER;
        };
        imgEl.src = primaryUrl;
    }

    function setBgWithFallback(el, primaryUrl) {
        if (!el) return;
        var test = new Image();
        test.onload = function() {
            el.style.backgroundImage = 'url(' + primaryUrl + ')';
            el.style.backgroundSize = 'cover';
            el.style.backgroundPosition = 'center';
        };
        test.onerror = function() {
            el.style.backgroundImage = 'url("' + FALLBACK_COVER + '")';
            el.style.backgroundSize = 'cover';
            el.style.backgroundPosition = 'center';
        };
        test.src = primaryUrl;
    }

    /* -----------------------------------------------------------------
     * Rendu
     * -------------------------------------------------------------- */

    function updateNowPlaying(data) {
        if (!data) return;

        var trackKey   = (data.artist || '') + '|' + (data.title || '');
        var hasChanged = trackKey !== lastTrack;
        lastTrack = trackKey;

        // Le serveur envoie déjà des libellés prêts à afficher : pendant un
        // jingle ou une pub, title vaut le nom de la station et artist est vide.
        var isBreak = (data.is_break === true);

        document.querySelectorAll('[data-nr-title]').forEach(function(el) {
            el.textContent = data.title || stationName;
        });
        document.querySelectorAll('[data-nr-artist]').forEach(function(el) {
            el.textContent = data.artist || '';
        });

        // Permet de styliser différemment les moments « hors musique »
        document.querySelectorAll('[data-nr-player]').forEach(function(el) {
            el.classList.toggle('nr-is-break', isBreak);
            el.classList.toggle('nr-is-music', data.is_music !== false);
        });

        if (hasChanged && data.cover) {
            document.querySelectorAll('[data-nr-cover]').forEach(function(el) {
                setImgWithFallback(el, data.cover);
            });
            document.querySelectorAll('[data-nr-cover-bg]').forEach(function(el) {
                setBgWithFallback(el, data.cover);
            });
        }

        document.querySelectorAll('[data-nr-listeners]').forEach(function(el) {
            if (typeof data.listeners === 'number') el.textContent = data.listeners;
        });

        setProgressFrom(data);
        tickProgress();

        // Hook Spotify (repli quand la plateforme ne fournit pas de pochette)
        if (window.NetradioSpotify && typeof window.NetradioSpotify.enrich === 'function') {
            window.NetradioSpotify.enrich(data);
        }
    }

    function updateHistory(items) {
        if (!Array.isArray(items)) return;
        // CAP STRICT : maximum 12 items (3 lignes × 4 colonnes)
        var MAX_ITEMS = 12;
        items = items.slice(0, MAX_ITEMS);

        var containers = document.querySelectorAll('[data-nr-history]');
        containers.forEach(function(container) {
            container.innerHTML = '';
            items.forEach(function(item) {
                if (!item) return;
                var div = document.createElement('div');
                div.className = 'nr-history-cover';
                var img = document.createElement('img');
                img.alt = (item.title || '') + (item.artist ? ' — ' + item.artist : '');
                img.loading = 'lazy';
                setImgWithFallback(img, item.cover || FALLBACK_COVER);
                div.appendChild(img);

                // Heure de diffusion, si la plateforme la fournit
                if (item.played_at) {
                    var d = new Date(item.played_at * 1000);
                    var time = document.createElement('time');
                    time.className = 'nr-history-time';
                    time.dateTime = d.toISOString();
                    time.textContent = ('0' + d.getHours()).slice(-2) + 'h' + ('0' + d.getMinutes()).slice(-2);
                    div.appendChild(time);
                }

                if (item.title || item.artist) {
                    var info = document.createElement('div');
                    info.className = 'nr-history-info';
                    var strong = document.createElement('strong');
                    strong.textContent = item.title || '';
                    var span = document.createElement('span');
                    span.textContent = item.artist || '';
                    info.appendChild(strong);
                    info.appendChild(span);
                    div.appendChild(info);
                }
                container.appendChild(div);
            });
        });
    }

    function fallbackArtworks() {
        var placeholder = config.placeholder || FALLBACK_COVER;
        document.querySelectorAll('[data-nr-cover]').forEach(function(el) {
            setImgWithFallback(el, placeholder);
        });
        document.querySelectorAll('[data-nr-cover-bg]').forEach(function(el) {
            setBgWithFallback(el, placeholder);
        });
        var containers = document.querySelectorAll('[data-nr-history]');
        // CAP STRICT : maximum 12 placeholders en fallback
        var MAX_ITEMS = 12;
        containers.forEach(function(container) {
            container.innerHTML = '';
            for (var i = 1; i <= MAX_ITEMS; i++) {
                var div = document.createElement('div');
                div.className = 'nr-history-cover';
                var img = document.createElement('img');
                img.loading = 'lazy';
                setImgWithFallback(img, placeholder);
                div.appendChild(img);
                container.appendChild(div);
            }
        });
    }

    /* -----------------------------------------------------------------
     * Démarrage
     * -------------------------------------------------------------- */

    document.addEventListener('DOMContentLoaded', function() {
        fetchRadioData();
        setInterval(fetchRadioData, interval);
        setInterval(tickProgress, 250);

        // Les navigateurs gèlent les timers des onglets en arrière-plan :
        // on resynchronise dès le retour sur l'onglet.
        document.addEventListener('visibilitychange', function() {
            if (!document.hidden) fetchRadioData();
        });
    });

    window.NetradioRadio = {
        refresh: fetchRadioData,
        getLastTrack: function() { return lastTrack; },
        getProgress: function() { return progress; }
    };
})();
