/**
 * Netradio FM — Interactions générales
 */
(function() {
    'use strict';

    // Menu mobile
    document.addEventListener('DOMContentLoaded', function() {
        var toggle = document.querySelector('.nr-menu-toggle');
        var nav = document.querySelector('.nr-nav');

        if (toggle && nav) {
            toggle.addEventListener('click', function() {
                nav.classList.toggle('active');
                toggle.classList.toggle('active');
            });
        }
    });
})();
