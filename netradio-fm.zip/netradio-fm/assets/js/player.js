/**
 * Netradio FM — Lecteur audio
 *
 * v2.2 : support du flux HLS (.m3u8) en plus du MP3/AAC direct.
 *
 * Stratégie :
 *   1. Flux non-HLS (.mp3, .aac…)        → <audio> natif, comme avant
 *   2. Flux HLS + Safari / iOS           → <audio> natif (HLS supporté nativement)
 *   3. Flux HLS + Chrome/Firefox/Edge    → hls.js, chargé EN DIFFÉRÉ au premier
 *                                          clic sur Lecture (jamais au chargement
 *                                          de la page)
 *   4. Échec HLS                          → repli automatique sur l'URL de secours
 *                                          (MP3) si elle est renseignée
 *
 * En radio live, on se recale toujours sur le direct : pas de lecture en
 * différé après une pause ou une mise en veille de l'onglet.
 */
(function() {
    'use strict';

    var audio        = document.getElementById('nr-audio');
    var playBtn      = document.getElementById('nr-play-btn');
    var listenBtn    = document.getElementById('nr-listen-btn');
    var volumeSlider = document.getElementById('nr-volume-slider');
    var volumeBar    = document.getElementById('nr-volume-bar');

    if (!audio || !playBtn) return;

    var cfg          = window.NetradioConfig || {};
    var streamUrl    = cfg.streamUrl || audio.getAttribute('data-stream') || '';
    var fallbackUrl  = cfg.streamFallbackUrl || '';
    var hlsScriptUrl = cfg.hlsScriptUrl || '';

    var isPlaying    = false;
    var hls          = null;   // instance hls.js courante
    var hlsLoading   = null;   // promesse de chargement de la lib
    var usingFallback = false;
    var hardRestartDone = false;  // une seule relance complète autorisée

    /* -----------------------------------------------------------------
     * Détection
     * -------------------------------------------------------------- */

    function isHlsUrl(url) {
        return /\.m3u8(\?|#|$)/i.test(url || '');
    }

    /**
     * Safari/iOS lisent le HLS nativement.
     *
     * Attention : ce test ne suffit PAS à décider quoi utiliser. Chrome
     * répond « maybe » à x-mpegURL par tolérance sur le type MIME, alors
     * qu'il est incapable de lire une playlist dans une balise <audio>.
     * S'y fier provoque un échec silencieux. Voir preferNativeHls().
     */
    function hasNativeHls() {
        return audio.canPlayType('application/vnd.apple.mpegurl') !== '' ||
               audio.canPlayType('application/x-mpegURL') !== '';
    }

    /** iPhone, iPad (y compris iPadOS qui se déclare macOS tactile). */
    function isAppleMobile() {
        var ua = navigator.userAgent || '';
        return /iPad|iPhone|iPod/.test(ua) ||
               (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
    }

    /**
     * Choix du moteur de lecture, dans l'ordre recommandé par hls.js :
     * on privilégie hls.js dès que MediaSource est disponible, et on ne
     * garde la lecture native que là où elle est la seule option — iOS,
     * où MediaSource n'est pas exposé aux éléments média.
     */
    function preferNativeHls() {
        if (!hasNativeHls()) return false;
        if (isAppleMobile()) return true;
        return !('MediaSource' in window);
    }

    function setBusy(busy) {
        playBtn.classList.toggle('loading', !!busy);
    }

    function setPlayingState(playing) {
        isPlaying = playing;
        playBtn.classList.toggle('playing', playing);
        playBtn.setAttribute('aria-label', playing ? 'Pause' : 'Lecture');
    }

    /* -----------------------------------------------------------------
     * Chargement différé de hls.js
     * -------------------------------------------------------------- */

    function loadHlsLibrary() {
        if (window.Hls) return Promise.resolve(window.Hls);
        if (hlsLoading) return hlsLoading;

        hlsLoading = new Promise(function(resolve, reject) {
            if (!hlsScriptUrl) {
                reject(new Error('URL de hls.js non configurée'));
                return;
            }
            var s = document.createElement('script');
            s.src = hlsScriptUrl;
            s.async = true;
            s.onload = function() {
                window.Hls ? resolve(window.Hls) : reject(new Error('hls.js chargé mais indisponible'));
            };
            s.onerror = function() { reject(new Error('Impossible de charger hls.js')); };
            document.head.appendChild(s);
        });

        return hlsLoading;
    }

    /* -----------------------------------------------------------------
     * Nettoyage
     * -------------------------------------------------------------- */

    function destroyHls() {
        if (hls) {
            try { hls.destroy(); } catch (e) {}
            hls = null;
        }
    }

    /** Coupe le flux et libère la connexion (important sur mobile / données). */
    function teardown() {
        destroyHls();
        try {
            audio.pause();
            audio.removeAttribute('src');
            audio.load();
        } catch (e) {}
    }

    /* -----------------------------------------------------------------
     * Lecture
     * -------------------------------------------------------------- */

    function attemptPlay() {
        var p = audio.play();
        if (p && typeof p.catch === 'function') {
            p.catch(function(err) {
                console.warn('Netradio : lecture impossible', err);
                setBusy(false);
                setPlayingState(false);
            });
        }
    }

    /** Bascule sur le flux de secours (MP3) si le HLS échoue. */
    function switchToFallback(reason) {
        if (usingFallback || !fallbackUrl) {
            setBusy(false);
            setPlayingState(false);
            return false;
        }
        console.warn('Netradio : repli sur le flux de secours (' + reason + ')');
        usingFallback = true;
        destroyHls();
        playDirect(fallbackUrl);
        return true;
    }

    /**
     * Dernier recours : on relance le flux depuis zéro, une seule fois.
     * Cela ouvre une nouvelle session côté AdServer — d'où la prudence : on
     * n'y vient qu'après échec des reprises internes de hls.js, et on
     * n'insiste pas si ça échoue encore.
     */
    function hardRestart(reason) {
        if (switchToFallback(reason)) return;   // un flux de secours prime
        if (hardRestartDone) {
            console.warn('Netradio : lecture interrompue (' + reason + ')');
            setBusy(false);
            setPlayingState(false);
            return;
        }
        hardRestartDone = true;
        console.warn('Netradio : relance complète du flux (' + reason + ')');
        destroyHls();
        setTimeout(function() {
            if (isPlaying) playWithHlsJs(streamUrl);
        }, 2000);
    }

    /** Lecture via l'élément <audio> natif (MP3, AAC, ou HLS sur Safari). */
    function playDirect(url) {
        // Cache-buster sur les flux continus uniquement : sur une playlist
        // HLS, hls.js/Safari gèrent eux-mêmes le rafraîchissement.
        audio.src = isHlsUrl(url) ? url : url + (url.indexOf('?') > -1 ? '&' : '?') + 't=' + Date.now();
        attemptPlay();
    }

    /** Lecture HLS via hls.js (Chrome, Firefox, Edge). */
    function playWithHlsJs(url) {
        setBusy(true);

        loadHlsLibrary().then(function(Hls) {
            if (!Hls.isSupported()) {
                switchToFallback('MediaSource indisponible');
                return;
            }

            destroyHls();

            hls = new Hls({
                /**
                 * Réglages pensés pour un flux avec publicité insérée côté
                 * serveur (SSAI / GAM).
                 *
                 * Les spots sont raccordés au direct par des marqueurs
                 * EXT-X-DISCONTINUITY. Un buffer trop serré provoque une
                 * coupure à chaque entrée et sortie de pub : on garde donc
                 * volontairement un coussin, et on n'active pas le mode
                 * basse latence (inutile en radio, et fragile aux raccords).
                 */
                lowLatencyMode: false,
                liveSyncDurationCount: 4,
                liveMaxLatencyDurationCount: 12,
                backBufferLength: 30,
                manifestLoadingTimeOut: 15000,
                manifestLoadingMaxRetry: 4,
                levelLoadingMaxRetry: 6,
                fragLoadingMaxRetry: 8
            });

            hls.on(Hls.Events.MANIFEST_PARSED, function() {
                setBusy(false);
                attemptPlay();
            });

            // Affiche le débit réel du flux à la place de la valeur figée.
            hls.on(Hls.Events.LEVEL_LOADED, function(evt, data) {
                var idx   = (data && typeof data.level === 'number') ? data.level : hls.currentLevel;
                var level = (hls.levels && idx >= 0) ? hls.levels[idx] : null;
                if (level && level.bitrate) {
                    var kbps = Math.round(level.bitrate / 1000);
                    document.querySelectorAll('[data-nr-bitrate]').forEach(function(el) {
                        el.textContent = kbps + ' kbps';
                    });
                }
            });

            hls.on(Hls.Events.ERROR, function(evt, data) {
                if (!data.fatal) return;

                switch (data.type) {
                    case Hls.ErrorTypes.NETWORK_ERROR:
                        // Coupure réseau : hls.js repart sur la session en cours.
                        console.warn('Netradio : erreur réseau HLS, reprise…');
                        try { hls.startLoad(); } catch (e) { hardRestart('réseau'); }
                        break;
                    case Hls.ErrorTypes.MEDIA_ERROR:
                        console.warn('Netradio : erreur média HLS, récupération…');
                        try { hls.recoverMediaError(); } catch (e) { hardRestart('média'); }
                        break;
                    default:
                        hardRestart('erreur fatale');
                }
            });

            hls.loadSource(url);
            hls.attachMedia(audio);

        }).catch(function(err) {
            console.warn('Netradio : ' + err.message);
            if (!switchToFallback('hls.js indisponible')) {
                setBusy(false);
            }
        });
    }

    function play() {
        var url = usingFallback && fallbackUrl ? fallbackUrl : streamUrl;
        if (!url) return;

        hardRestartDone = false;   // un clic manuel réarme la relance de secours
        setPlayingState(true);

        if (isHlsUrl(url) && !preferNativeHls()) {
            playWithHlsJs(url);          // Chrome, Firefox, Edge, Safari desktop
        } else {
            playDirect(url);             // MP3/AAC, ou HLS sur iOS
        }
    }

    function pause() {
        teardown();
        setBusy(false);
        setPlayingState(false);
    }

    function toggle() {
        isPlaying ? pause() : play();
    }

    /* -----------------------------------------------------------------
     * Événements
     * -------------------------------------------------------------- */

    playBtn.addEventListener('click', toggle);

    if (listenBtn) {
        listenBtn.addEventListener('click', function() {
            if (!isPlaying) play();
            var el = document.getElementById('nr-player');
            if (el) el.scrollIntoView({ behavior: 'smooth' });
        });
    }

    // Volume
    audio.volume = 0.7;
    if (volumeSlider) {
        volumeSlider.addEventListener('click', function(e) {
            var rect = volumeSlider.getBoundingClientRect();
            var pct = (e.clientX - rect.left) / rect.width;
            pct = Math.max(0, Math.min(1, pct));
            audio.volume = pct;
            if (volumeBar) volumeBar.style.width = (pct * 100) + '%';
        });
    }

    // Erreur sur l'élément <audio> (flux direct ou HLS natif Safari)
    audio.addEventListener('error', function() {
        if (!isPlaying) return;
        // En mode hls.js, les erreurs sont gérées par le handler ERROR ci-dessus.
        if (hls) return;
        console.warn('Netradio : erreur de lecture audio');
        if (!switchToFallback('lecture directe')) {
            setPlayingState(false);
        }
    });

    audio.addEventListener('playing', function() {
        setBusy(false);
        setPlayingState(true);
    });

    audio.addEventListener('waiting', function() {
        if (isPlaying) setBusy(true);
    });

    /**
     * Retour sur l'onglet : en radio, on ne veut pas écouter en différé.
     * Si le buffer a pris du retard pendant la mise en veille, on se
     * repositionne sur le direct.
     */
    document.addEventListener('visibilitychange', function() {
        if (document.hidden || !isPlaying) return;
        try {
            if (hls && hls.liveSyncPosition != null) {
                if (audio.currentTime < hls.liveSyncPosition - 2) {
                    audio.currentTime = hls.liveSyncPosition;
                }
            } else if (audio.buffered.length) {
                var end = audio.buffered.end(audio.buffered.length - 1);
                if (end - audio.currentTime > 5) audio.currentTime = end - 0.5;
            }
        } catch (e) {}
    });

    // Persistance du volume entre les pages
    window.addEventListener('beforeunload', function() {
        try {
            sessionStorage.setItem('nr_playing', isPlaying ? '1' : '0');
            sessionStorage.setItem('nr_volume', audio.volume);
        } catch (e) {}
    });

    document.addEventListener('DOMContentLoaded', function() {
        try {
            var savedVol = sessionStorage.getItem('nr_volume');
            if (savedVol !== null) {
                audio.volume = parseFloat(savedVol);
                if (volumeBar) volumeBar.style.width = (parseFloat(savedVol) * 100) + '%';
            }
        } catch (e) {}
        // L'autoplay sans interaction est bloqué par les navigateurs :
        // on n'essaie pas de reprendre automatiquement la lecture.
    });

    // API publique (debug console)
    window.NetradioPlayer = {
        play: play,
        pause: pause,
        toggle: toggle,
        isPlaying: function() { return isPlaying; },
        isHls: function() { return isHlsUrl(usingFallback ? fallbackUrl : streamUrl); },
        usingFallback: function() { return usingFallback; },
        nativeHls: hasNativeHls,
        preferNative: preferNativeHls
    };
})();
