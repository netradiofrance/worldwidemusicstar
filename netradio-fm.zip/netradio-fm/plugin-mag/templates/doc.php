<?php
/**
 * Page de documentation admin pour le plugin Netradio Magazine
 */
if ( ! defined( 'ABSPATH' ) ) exit;
?>
<style>
.nrmag-doc { max-width: 1100px; margin: 20px 0; font-family: -apple-system, BlinkMacSystemFont, sans-serif; }
.nrmag-doc h1 { font-size: 32px; margin-bottom: 8px; }
.nrmag-doc .nrmag-sub { color: #666; margin-bottom: 30px; font-size: 14px; }
.nrmag-doc h2 { margin-top: 40px; padding-bottom: 8px; border-bottom: 2px solid #ff3b1f; }
.nrmag-doc pre { background: #1a1a1a; color: #f4efe6; padding: 16px; border-radius: 4px; overflow-x: auto; font-size: 13px; line-height: 1.6; }
.nrmag-doc code { background: #f0f0f0; padding: 2px 6px; border-radius: 3px; font-size: 13px; }
.nrmag-doc .nrmag-box { background: #fff; border-left: 4px solid #ff3b1f; padding: 16px 20px; margin: 20px 0; }
.nrmag-doc .nrmag-warn { background: #fffbea; border-left: 4px solid #f59e0b; padding: 16px 20px; margin: 20px 0; }
.nrmag-doc table { border-collapse: collapse; width: 100%; margin: 15px 0; }
.nrmag-doc th, .nrmag-doc td { border: 1px solid #ddd; padding: 10px; text-align: left; font-size: 13px; }
.nrmag-doc th { background: #f4f4f4; }
.nrmag-doc .nrmag-copybtn { background: #ff3b1f; color: white; border: 0; padding: 6px 14px; cursor: pointer; border-radius: 3px; font-size: 12px; margin-bottom: 8px; }
</style>

<div class="wrap nrmag-doc">
    <h1>📰 Netradio Magazine — Documentation</h1>
    <p class="nrmag-sub">Comment publier des articles en mise en page éditoriale "magazine" sur netradio.fr</p>

    <div class="nrmag-box">
        <strong>⚡ Démarrage rapide en 3 étapes :</strong>
        <ol>
            <li>Créer un nouvel article dans <a href="<?php echo esc_url( admin_url( 'post-new.php' ) ); ?>">Articles → Ajouter</a></li>
            <li>Dans la colonne de droite, cocher <strong>"Activer la mise en page magazine"</strong></li>
            <li>Coller le contenu de l'article ci-dessous dans un <strong>bloc HTML personnalisé</strong> (Gutenberg) ou en mode Texte (éditeur classique)</li>
        </ol>
    </div>

    <h2>Les 9 shortcodes disponibles</h2>

    <h3>1. <code>[mag_hero]</code> — Titre principal de l'article</h3>
    <pre>[mag_hero kicker="Boissons / Influence" 
          dek="Squeezie, Inoxtag et Léna lancent Ciao Energy..." 
          byline="Par la rédaction Netradio"
          date="1er juin 2026"]
Ciao Bella, &lt;em&gt;bonjour&lt;/em&gt; la caféine.
[/mag_hero]</pre>
    <p><strong>Attributs :</strong> <code>kicker</code> (catégorie), <code>dek</code> (chapeau), <code>byline</code> (auteur), <code>date</code> (laissez vide pour la date du jour).</p>

    <h3>2. <code>[mag_section]</code> — Section numérotée</h3>
    <pre>[mag_section num="01 — LE LANCEMENT" 
             title="Trois influenceurs, &lt;em&gt;une seule promesse&lt;/em&gt;"]
Texte de la section ici, plusieurs paragraphes possibles.

On peut faire des sauts de ligne normaux.
[/mag_section]</pre>

    <h3>3. <code>[mag_lead]</code> — Paragraphe d'ouverture avec drop cap</h3>
    <pre>[mag_lead]Il y a des matins où l'on se réveille en se disant que la France a, décidément, des manières bien à elle...[/mag_lead]</pre>

    <h3>4. <code>[mag_quote]</code> — Citation pleine largeur</h3>
    <pre>[mag_quote cite="Cyrille Jacques · DG de Ciao Kombucha"]
Squeezie trouvait que les kombuchas français étaient trop fermentés. On a fait une recette plus douce.
[/mag_quote]</pre>

    <h3>5. <code>[mag_stats]</code> + <code>[mag_stat]</code> — Grille de chiffres clés</h3>
    <pre>[mag_stats]
  [mag_stat num="6" label="Saveurs lancées" style="accent"]
  [mag_stat num="1,49 €" label="Prix public conseillé"]
  [mag_stat num="~50M" label="Followers cumulés" style="citrus"]
[/mag_stats]</pre>
    <p><strong>Styles disponibles :</strong> par défaut (noir), <code>accent</code> (rouge), <code>citrus</code> (jaune).</p>

    <h3>6. <code>[mag_fiche]</code> + <code>[mag_spec]</code> — Fiche technique</h3>
    <pre>[mag_fiche title="Ciao Energy — Ce qu'il y a dans la canette"]
  [mag_spec key="Sucre" val="4 g / 100 ml"]
  [mag_spec key="Caféine" val="32 mg / 100 ml"]
  [mag_spec key="Calories" val="17 kcal / 100 ml"]
[/mag_fiche]</pre>

    <h3>7. <code>[mag_divider]</code> — Séparateur entre sections</h3>
    <pre>[mag_divider]
[mag_divider symbol="— ★ —"]</pre>

    <h3>8. <code>[mag_highlight]</code> — Surlignage jaune dans le texte</h3>
    <pre>C'est la [mag_highlight]suite logique d'une opération industrielle[/mag_highlight] qui a déjà fait ses preuves.</pre>

    <h3>9. <code>[mag_cans]</code> — Hero visuel canettes Ciao Energy</h3>
    <pre>[mag_cans]</pre>
    <p>Affiche les 6 canettes 3D en CSS (utilisé pour l'article Ciao Energy).</p>

    <h2>Modèle complet — Article Ciao Energy</h2>
    <p>Cliquez sur "Copier" puis collez dans un bloc HTML personnalisé Gutenberg, ou dans l'onglet "Texte" de l'éditeur classique.</p>

    <button class="nrmag-copybtn" onclick="document.getElementById('nrmag-tpl').select(); document.execCommand('copy'); this.textContent='✓ Copié';">📋 Copier le modèle complet</button>

    <textarea id="nrmag-tpl" style="width:100%; height:300px; font-family:monospace; font-size:12px; padding:12px;">
[mag_hero kicker="Boissons / Influence / Grande distribution" 
          dek="Squeezie, Inoxtag et Léna Situations lancent aujourd'hui Ciao Energy : six saveurs, 1,49 €, et 50 millions d'abonnés cumulés en force de frappe." 
          byline="Par la rédaction Netradio"
          date="1er juin 2026"]
Ciao Bella, &lt;em&gt;bonjour&lt;/em&gt; la caféine.
[/mag_hero]

[mag_cans]

[mag_section num="01 — LE LANCEMENT" 
             title="Trois influenceurs, six canettes, &lt;em&gt;une seule promesse&lt;/em&gt;"]

[mag_lead]Il y a des matins où l'on se réveille en se disant que la France a des manières bien à elle de fabriquer ses empires.[/mag_lead]

Le pitch tient en une ligne : 2,7 fois moins de sucre, arômes naturels...

[mag_stats]
  [mag_stat num="6" label="Saveurs lancées en simultané" style="accent"]
  [mag_stat num="1,49 €" label="Prix public conseillé"]
  [mag_stat num="~50M" label="Followers cumulés" style="citrus"]
[/mag_stats]

[/mag_section]

[mag_divider]

[mag_section num="02 — LE PRÉCÉDENT" title="Ciao Kombucha, ou comment &lt;em&gt;cramer&lt;/em&gt; la GMS."]

Pour comprendre Ciao Energy, il faut remonter à mai 2025...

[mag_quote cite="Cyrille Jacques · DG de Ciao Kombucha"]
Squeezie trouvait que les kombuchas français étaient trop fermentés.
[/mag_quote]

[/mag_section]
    </textarea>

    <h2>Conseils d'écriture</h2>
    <ul>
        <li>Pour mettre un mot en italique rouge dans un titre, utilisez <code>&lt;em&gt;mot&lt;/em&gt;</code> directement dans le shortcode.</li>
        <li>Pour le gras dans le texte, utilisez les balises HTML <code>&lt;strong&gt;mot&lt;/strong&gt;</code>.</li>
        <li><strong>N'utilisez PAS le Markdown</strong> (les <code>**mot**</code>) — WordPress ne le convertit pas. Utilisez <code>&lt;strong&gt;</code>.</li>
        <li>Les paragraphes se créent automatiquement avec un saut de ligne double dans <code>[mag_section]</code>.</li>
        <li>N'oubliez pas de cocher la case "Activer la mise en page magazine" dans la colonne de droite de l'éditeur.</li>
    </ul>

    <h3>Insérer une vidéo YouTube / Vimeo / MP4</h3>
    <pre>[mag_video url="https://www.youtube.com/watch?v=Ki_zL-eYvzY"]

[mag_video url="https://vimeo.com/123456789" caption="Le making-of"]

[mag_video url="https://example.com/video.mp4" ratio="16:9"]</pre>
    <p><strong>Attributs :</strong></p>
    <ul>
        <li><code>url</code> — l'URL de la vidéo (YouTube, Vimeo, ou fichier MP4 direct)</li>
        <li><code>caption</code> — légende facultative en italique sous la vidéo</li>
        <li><code>ratio</code> — format : <code>16:9</code> (défaut), <code>4:3</code>, <code>1:1</code>, <code>21:9</code></li>
    </ul>
    <div class="nrmag-warn">
        <strong>💡 Pourquoi utiliser <code>[mag_video]</code> au lieu de coller un &lt;iframe&gt; ?</strong> WordPress filtre les iframes par défaut dans les articles (pour la sécurité). Le shortcode <code>[mag_video]</code> est le moyen sûr et propre d'intégrer une vidéo dans un article magazine.
    </div>

    <div class="nrmag-warn">
        <strong>⚠️ Important :</strong> Si vous utilisez l'éditeur classique (TinyMCE), restez en mode <strong>"Texte"</strong> et ne basculez pas en mode "Visuel" avant publication, sinon WordPress va modifier les shortcodes et casser la mise en page.
    </div>

    <h2>Désactiver la mise en page magazine</h2>
    <p>Pour revenir au style normal de votre thème, décochez simplement la case "Activer la mise en page magazine" dans l'éditeur. Les shortcodes resteront fonctionnels même sans cette option.</p>

</div>
