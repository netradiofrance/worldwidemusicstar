<?php
/**
 * Netradio Magazine Article — Module intégré au thème
 *
 * @package NetradioFM
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class Netradio_Magazine_Module {

    public function __construct() {
        add_action( 'init', array( $this, 'register_shortcodes' ) );
        add_action( 'add_meta_boxes', array( $this, 'add_meta_box' ) );
        add_action( 'save_post', array( $this, 'save_meta_box' ) );
    }

    public function register_shortcodes() {
        add_shortcode( 'mag_hero',     array( $this, 'sc_hero' ) );
        add_shortcode( 'mag_section',  array( $this, 'sc_section' ) );
        add_shortcode( 'mag_quote',    array( $this, 'sc_quote' ) );
        add_shortcode( 'mag_stats',    array( $this, 'sc_stats' ) );
        add_shortcode( 'mag_stat',     array( $this, 'sc_stat' ) );
        add_shortcode( 'mag_fiche',    array( $this, 'sc_fiche' ) );
        add_shortcode( 'mag_spec',     array( $this, 'sc_spec' ) );
        add_shortcode( 'mag_divider',  array( $this, 'sc_divider' ) );
        add_shortcode( 'mag_lead',     array( $this, 'sc_lead' ) );
        add_shortcode( 'mag_cans',     array( $this, 'sc_cans' ) );
        add_shortcode( 'mag_highlight',array( $this, 'sc_highlight' ) );
        add_shortcode( 'mag_video',    array( $this, 'sc_video' ) );
    }

    public function sc_hero( $atts, $content = null ) {
        $atts = shortcode_atts( array(
            'kicker' => '', 'dek' => '',
            'byline' => 'Par la rédaction Netradio', 'date' => '',
        ), $atts, 'mag_hero' );

        $date_display = $atts['date'] ? esc_html( $atts['date'] ) : esc_html( date_i18n( 'j F Y' ) );

        $output  = '<header class="ciao-hero" itemscope itemtype="https://schema.org/Article">';
        if ( $atts['kicker'] ) {
            $output .= '<div class="ciao-kicker" itemprop="articleSection">' . esc_html( $atts['kicker'] ) . '</div>';
        }
        $output .= '<h1 class="ciao-title" itemprop="headline">' . do_shortcode( wp_kses_post( $content ) ) . '</h1>';
        if ( $atts['dek'] ) {
            $output .= '<p class="ciao-dek" itemprop="description">' . wp_kses_post( $atts['dek'] ) . '</p>';
        }
        $output .= '<div class="ciao-byline">';
        $output .= '<div class="ciao-author" itemprop="author" itemscope itemtype="https://schema.org/Person"><span itemprop="name">' . esc_html( $atts['byline'] ) . '</span></div>';
        $output .= '<div class="ciao-meta">' . $date_display . '</div>';
        $output .= '</div></header>';
        return $output;
    }

    public function sc_section( $atts, $content = null ) {
        $atts = shortcode_atts( array( 'num' => '', 'title' => '' ), $atts, 'mag_section' );
        // <section> au lieu de <div> pour la sémantique HTML5
        $output = '<section class="ciao-section">';
        if ( $atts['num'] ) $output .= '<div class="ciao-section-num" aria-hidden="true">' . esc_html( $atts['num'] ) . '</div>';
        if ( $atts['title'] ) {
            // ID auto-généré pour le TOC (slug à partir du titre)
            $title_text = wp_strip_all_tags( $atts['title'] );
            $anchor_id  = 'section-' . sanitize_title( $title_text );
            $output .= '<h2 class="ciao-section-title" id="' . esc_attr( $anchor_id ) . '">' . wp_kses_post( $atts['title'] ) . '</h2>';
        }
        $output .= '<div class="ciao-section-body">' . do_shortcode( wpautop( $content ) ) . '</div>';
        $output .= '</section>';
        return $output;
    }

    public function sc_quote( $atts, $content = null ) {
        $atts = shortcode_atts( array( 'cite' => '' ), $atts, 'mag_quote' );
        // <figure> + <blockquote> + <figcaption> = pattern sémantique recommandé
        $output = '<figure class="ciao-quote-wrap"><blockquote class="ciao-bq" itemprop="quotation">' . wp_kses_post( $content ) . '</blockquote>';
        if ( $atts['cite'] ) $output .= '<figcaption><cite>' . esc_html( $atts['cite'] ) . '</cite></figcaption>';
        $output .= '</figure>';
        return $output;
    }

    public function sc_stats( $atts, $content = null ) {
        return '<aside class="ciao-stat-grid" aria-label="Statistiques clés">' . do_shortcode( $content ) . '</aside>';
    }

    public function sc_stat( $atts ) {
        $atts = shortcode_atts( array( 'num' => '', 'label' => '', 'style' => '' ), $atts, 'mag_stat' );
        $class = 'ciao-stat';
        if ( $atts['style'] === 'accent' )  $class .= ' ciao-accent';
        if ( $atts['style'] === 'citrus' )  $class .= ' ciao-citrus-bg';
        return '<div class="' . esc_attr( $class ) . '"><div class="ciao-stat-num">' . wp_kses_post( $atts['num'] ) . '</div><div class="ciao-stat-label">' . esc_html( $atts['label'] ) . '</div></div>';
    }

    public function sc_fiche( $atts, $content = null ) {
        $atts = shortcode_atts( array( 'title' => 'Fiche technique' ), $atts, 'mag_fiche' );
        // <aside> + h3 + <dl> est plus sémantique que <ul>
        return '<aside class="ciao-infobox" aria-labelledby="fiche-' . sanitize_title( $atts['title'] ) . '"><h3 id="fiche-' . sanitize_title( $atts['title'] ) . '">' . esc_html( $atts['title'] ) . '</h3><dl class="ciao-spec-list">' . do_shortcode( $content ) . '</dl></aside>';
    }

    public function sc_spec( $atts ) {
        $atts = shortcode_atts( array( 'key' => '', 'val' => '' ), $atts, 'mag_spec' );
        // <dt>/<dd> au lieu de <li> = sémantique d'une fiche descriptive
        return '<dt class="ciao-spec-key">' . esc_html( $atts['key'] ) . '</dt><dd class="ciao-spec-val">' . wp_kses_post( $atts['val'] ) . '</dd>';
    }

    public function sc_divider( $atts ) {
        $atts = shortcode_atts( array( 'symbol' => '— ⚡ —' ), $atts, 'mag_divider' );
        return '<hr class="ciao-divider" aria-hidden="true" data-symbol="' . esc_attr( $atts['symbol'] ) . '">';
    }

    public function sc_lead( $atts, $content = null ) {
        // Le chapeau est <p class="lead"> reconnu sémantiquement
        return '<p class="ciao-lead" role="doc-introduction">' . wp_kses_post( $content ) . '</p>';
    }

    public function sc_highlight( $atts, $content = null ) {
        return '<mark class="ciao-highlight">' . wp_kses_post( $content ) . '</mark>';
    }

    public function sc_cans( $atts ) {
        $cans = array(
            array( 'c1', 'Double', 'Litchi' ),
            array( 'c2', 'Coco', 'Citron Vert' ),
            array( 'c3', 'Kiwi', 'Concombre' ),
            array( 'c4', 'Pêche', 'Blanche' ),
            array( 'c5', 'Pomme', 'Rhubarbe' ),
            array( 'c6', 'Abricot', 'Framboise' ),
        );
        $output = '<div class="ciao-hero-visual" aria-hidden="true">';
        $i = 1;
        foreach ( $cans as $c ) {
            $output .= '<div class="ciao-can ciao-' . esc_attr( $c[0] ) . '">';
            $output .= '<span class="ciao-can-label">N°' . $i . '</span>';
            $output .= '<span class="ciao-can-ciao">Ciao</span>';
            $output .= '<span class="ciao-can-flavor">' . esc_html( $c[1] ) . '<br>' . esc_html( $c[2] ) . '</span>';
            $output .= '</div>';
            $i++;
        }
        $output .= '</div>';
        return $output;
    }

    /**
     * Shortcode [mag_video url="https://..."]
     * Gère YouTube, Vimeo, et MP4 direct
     * Usage : [mag_video url="https://www.youtube.com/watch?v=XXX"]
     *      ou [mag_video url="https://vimeo.com/123456"]
     *      ou [mag_video url="https://example.com/video.mp4"]
     */
    public function sc_video( $atts ) {
        $atts = shortcode_atts( array(
            'url'     => '',
            'caption' => '',
            'ratio'   => '16:9',
        ), $atts, 'mag_video' );

        if ( empty( $atts['url'] ) ) return '';

        $url = trim( $atts['url'] );
        $embed_html = '';

        // YouTube
        if ( preg_match( '#(?:youtube\.com/(?:watch\?v=|embed/|v/)|youtu\.be/)([a-zA-Z0-9_-]+)#', $url, $matches ) ) {
            $video_id = $matches[1];
            $embed_html = sprintf(
                '<iframe src="https://www.youtube.com/embed/%s?rel=0" allowfullscreen allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" loading="lazy" frameborder="0"></iframe>',
                esc_attr( $video_id )
            );
        }
        // Vimeo
        elseif ( preg_match( '#vimeo\.com/(?:video/)?(\d+)#', $url, $matches ) ) {
            $video_id = $matches[1];
            $embed_html = sprintf(
                '<iframe src="https://player.vimeo.com/video/%s" allowfullscreen allow="autoplay; fullscreen; picture-in-picture" loading="lazy" frameborder="0"></iframe>',
                esc_attr( $video_id )
            );
        }
        // MP4 direct
        elseif ( preg_match( '/\.(mp4|webm|ogg)(\?.*)?$/i', $url ) ) {
            $embed_html = sprintf(
                '<video controls preload="metadata" playsinline><source src="%s"></video>',
                esc_url( $url )
            );
        }
        else {
            // Fallback : utiliser wp_oembed_get pour d'autres providers
            $oembed = wp_oembed_get( $url );
            if ( $oembed ) {
                $embed_html = $oembed;
            } else {
                return '<p style="color:#a00;">[mag_video] URL non reconnue : ' . esc_html( $url ) . '</p>';
            }
        }

        // Calculer le padding-bottom selon le ratio
        $padding = '56.25%'; // 16:9 par défaut
        if ( $atts['ratio'] === '4:3' )  $padding = '75%';
        if ( $atts['ratio'] === '1:1' )  $padding = '100%';
        if ( $atts['ratio'] === '21:9' ) $padding = '42.85%';

        // Injecter du style inline dans l'iframe/video pour qu'il remplisse le wrapper
        $embed_html = str_replace( '<iframe ', '<iframe style="position:absolute;top:0;left:0;width:100%;height:100%;border:0;" ', $embed_html );
        $embed_html = str_replace( '<video ',  '<video style="position:absolute;top:0;left:0;width:100%;height:100%;" ',  $embed_html );

        $output = '<figure class="mag-video-wrap" style="margin: 32px 0;">';
        $output .= '<div class="mag-video-embed" style="position:relative; padding-bottom:' . $padding . '; height:0; overflow:hidden; border-radius:6px; background:#000;">';
        $output .= $embed_html;
        $output .= '</div>';
        if ( ! empty( $atts['caption'] ) ) {
            $output .= '<figcaption style="margin-top:10px; font-family:Georgia,serif; font-style:italic; font-size:14px; color:rgba(10,10,10,0.6); text-align:center;">' . esc_html( $atts['caption'] ) . '</figcaption>';
        }
        $output .= '</figure>';

        return $output;
    }

    public function add_meta_box() {
        add_meta_box( 'netradio_magazine_mode', '📰 Mode Magazine', array( $this, 'render_meta_box' ), 'post', 'side', 'high' );
    }

    public function render_meta_box( $post ) {
        wp_nonce_field( 'netradio_magazine_save', 'netradio_magazine_nonce' );
        $value = get_post_meta( $post->ID, '_netradio_magazine_mode', true );
        echo '<p><label><input type="checkbox" name="netradio_magazine_mode" value="yes" ' . checked( $value, 'yes', false ) . '> <strong>Activer la mise en page magazine</strong></label></p>';
        echo '<p style="font-size:11px;color:#666;line-height:1.5;">Active la typographie éditoriale Fraunces.<br><a href="' . esc_url( admin_url( 'admin.php?page=netradio-magazine-doc' ) ) . '">📖 Documentation</a></p>';
    }

    public function save_meta_box( $post_id ) {
        if ( ! isset( $_POST['netradio_magazine_nonce'] ) ) return;
        if ( ! wp_verify_nonce( $_POST['netradio_magazine_nonce'], 'netradio_magazine_save' ) ) return;
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
        if ( ! current_user_can( 'edit_post', $post_id ) ) return;
        $value = isset( $_POST['netradio_magazine_mode'] ) ? 'yes' : 'no';
        update_post_meta( $post_id, '_netradio_magazine_mode', $value );
    }
}

new Netradio_Magazine_Module();
