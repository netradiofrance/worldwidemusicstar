<?php
/**
 * Page
 *
 * @package NetradioFM
 */

get_header();

while ( have_posts() ) : the_post(); ?>
<article class="nr-single">
    <header class="nr-single-header">
        <h1 class="nr-single-title"><?php the_title(); ?></h1>
    </header>
    <div class="entry-content">
        <?php the_content(); ?>
    </div>
</article>
<?php endwhile;

get_footer();
