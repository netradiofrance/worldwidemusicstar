<?php
/**
 * Archive
 *
 * @package NetradioFM
 */

get_header();
?>

<header class="nr-archive-header">
    <div class="nr-archive-kicker">
        <?php
        if ( is_category() ) echo 'Catégorie';
        elseif ( is_tag() ) echo 'Tag';
        elseif ( is_author() ) echo 'Auteur';
        elseif ( is_date() ) echo 'Archives';
        else echo 'Articles';
        ?>
    </div>
    <h1 class="nr-archive-title"><?php
        if ( is_category() || is_tag() || is_tax() ) single_term_title();
        elseif ( is_author() ) the_author();
        elseif ( is_date() ) echo get_the_date();
        else echo 'Tous les articles';
    ?></h1>
    <?php $desc = is_category() || is_tag() ? term_description() : ''; ?>
    <?php if ( $desc ) : ?>
        <div class="nr-archive-desc"><?php echo wp_kses_post( $desc ); ?></div>
    <?php endif; ?>
</header>

<section class="nr-section">
    <?php if ( have_posts() ) : ?>
        <div class="nr-grid">
            <?php while ( have_posts() ) : the_post(); ?>
                <?php get_template_part( 'template-parts/card' ); ?>
            <?php endwhile; ?>
        </div>

        <div class="nr-pagination">
            <?php
            the_posts_pagination( array(
                'prev_text' => '← Précédent',
                'next_text' => 'Suivant →',
                'mid_size'  => 2,
            ) );
            ?>
        </div>
    <?php else : ?>
        <p style="text-align: center; color: #888;">Aucun article trouvé.</p>
    <?php endif; ?>
</section>

<?php get_footer(); ?>
