<?php
/**
 * Template part : carte article (utilisée dans les grilles)
 *
 * @package NetradioFM
 */
if ( ! defined( 'ABSPATH' ) ) exit;

$cat = netradio_primary_category();
?>
<article class="nr-card">
    <a href="<?php the_permalink(); ?>" style="display:flex; flex-direction:column;">
        <div class="nr-card-image">
            <?php if ( $cat ) : ?>
                <span class="nr-card-tag"><?php echo esc_html( $cat->name ); ?></span>
            <?php endif; ?>
            <img src="<?php echo esc_url( netradio_thumbnail_url( 'netradio-card' ) ); ?>" alt="<?php the_title_attribute(); ?>">
        </div>
        <?php
        $tags = get_the_tags();
        if ( $tags ) :
        ?>
            <div class="nr-card-kicker"><?php echo esc_html( $tags[0]->name ); ?></div>
        <?php endif; ?>
        <h3><?php the_title(); ?></h3>
        <div class="nr-card-meta">
            <?php echo esc_html( netradio_format_date() ); ?> · <?php echo esc_html( netradio_reading_time() ); ?>
        </div>
    </a>
</article>
