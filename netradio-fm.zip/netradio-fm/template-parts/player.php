<?php
/**
 * Lecteur radio fixe en bas d'écran
 *
 * @package NetradioFM
 */
if ( ! defined( 'ABSPATH' ) ) exit;

$stream_url = netradio_get_option( 'stream_url', NETRADIO_DEFAULT_STREAM_URL );
// Détection du format : une playlist .m3u8 = flux HLS
$is_hls = (bool) preg_match( '#\.m3u8(\?|\#|$)#i', $stream_url );
?>
<div class="nr-player" id="nr-player" data-nr-player>
    <?php // Barre de progression du morceau — alimentée par started_at + duration ?>
    <div class="nr-player-progress" data-nr-progress role="progressbar" aria-label="Progression du morceau">
        <div class="nr-player-progress-bar" data-nr-progress-bar></div>
    </div>
    <div class="nr-player-left">
        <div class="nr-player-cover" id="nr-player-cover" data-nr-cover-bg></div>
        <div class="nr-player-info">
            <div class="nr-player-label">En direct sur <?php echo esc_html( netradio_get_option( 'station_name', 'Netradio' ) ); ?></div>
            <div class="nr-player-title" data-nr-title>Chargement…</div>
            <div class="nr-player-artist" data-nr-artist></div>
        </div>
    </div>
    <div class="nr-player-controls">
        <button class="nr-play-btn" id="nr-play-btn" aria-label="Lecture/Pause">
            <span class="nr-play-icon"></span>
        </button>
        <div class="nr-volume">
            <span>🔊</span>
            <div class="nr-volume-slider" id="nr-volume-slider">
                <div class="nr-volume-bar" id="nr-volume-bar"></div>
            </div>
        </div>
    </div>
    <div class="nr-player-right">
        <span class="nr-player-time"><span data-nr-elapsed>0:00</span> / <span data-nr-duration>0:00</span></span>
        <span class="nr-player-bitrate" data-nr-bitrate><?php echo $is_hls ? 'HLS' : '128 kbps'; ?></span>
    </div>
    <?php
    // Pas de <source type="…"> figé : le type MIME dépend du flux (HLS, MP3,
    // AAC…) et c'est player.js qui affecte la source selon les capacités du
    // navigateur. Un type erroné ferait échouer la lecture.
    //
    // Pas de crossorigin="anonymous" non plus : le flux est servi par un autre
    // domaine (radioairplay.fr), et cet attribut imposerait un contrôle CORS à
    // la lecture native de Safari/iOS. Sans lui, Safari lit le HLS même si le
    // serveur n'envoie pas d'en-tête CORS. Il ne serait utile que pour lire les
    // échantillons audio (visualiseur Web Audio), ce que le lecteur ne fait pas.
    ?>
    <audio id="nr-audio" preload="none" data-stream="<?php echo esc_url( $stream_url ); ?>"></audio>
</div>
