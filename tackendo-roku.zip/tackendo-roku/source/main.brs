Function Main(args as Dynamic) as Void
    showChannelSGScreen(args)
end Function

sub showChannelSGScreen(args)
    m.screen = CreateObject("roSGScreen")
    syslog = CreateObject("roSystemLog")

    syslog.EnableType("http.error")
    syslog.EnableType("http.connect")
    syslog.EnableType("bandwidth.minute")

    metrics = CreateObject("roAssociativeArray")
    metrics.streamStartTimer = CreateObject("roTimespan")
    metrics.timeSpentBuffering = 0
    metrics.errorCount = 0

    m.port = CreateObject("roMessagePort")
    m.screen.setMessagePort(m.port)
    m.global = m.screen.getGlobalNode()
    deeplink={}
    if args.contentId <> Invalid and args.mediaType <> Invalid and (args.mediaType = "movie")
        deeplink = {
            id: args.contentId
            type: args.mediaType
        }
    end if
    m.global.addFields({deeplinkValues:deeplink})

    scene = m.screen.CreateScene("MainScene")
    syslog.SetMessagePort(m.port)
    m.screen.show()
    scene.observeField("exitValue", m.port)
    while(true)
        msg = wait(0, m.port)
        msgType = type(msg)
        if msgType = "roSGScreenEvent"
            if msg.isScreenClosed() then return
        else if msgType = "roSGNodeEvent"
            if(msg.GetData() = "exitApp")
                m.screen.Close()
                m.screen = invalid
            end if
        else if msgType = "roSystemLogEvent"
            i = msg.GetInfo()
            if i.Bandwidth<>invalid
                scene.bandwidth = i.Bandwidth.toStr()
            end if
        end if
    end while
    if m.screen <> invalid then
        m.screen.Close()
        m.screen = invalid
    end if
end sub

Function SetRegValue(parameter as String,value As String) As Void
    secToken = CreateObject("roRegistrySection", "storyTeller")
    secToken.Write(parameter,value)
    secToken.Flush()
End Function

Function GetRegValue(parameter as String) As Dynamic
    secToken = CreateObject("roRegistrySection", "storyTeller")
    if secToken.Exists(parameter)
        return secToken.Read(parameter)
    endif
    return invalid
End Function

Function DeleteRegValue(parameter as String) As Dynamic
    secToken = CreateObject("roRegistrySection", "storyTeller")
    if secToken.Exists(parameter)
        return secToken.Delete(parameter)
    endif
    return invalid
End Function

function scale(fromVal = 1 as Integer) as Dynamic
    dInfo = CreateObject("roDeviceInfo")
    mode = getDisplayMode()
    if mode = "FHD" then
        return (fromVal)
    else if mode = "HD" then
        return (fromVal)
    else if mode = "SD" then
        return (fromVal * 0.44444)
    end if
end function

function getDisplayMode() as String
    gaa = getGlobalAA()
    if gaa.displayMode = Invalid then
        deviceinfo = CreateObject("roDeviceInfo")
        displaySize = deviceinfo.getDisplaySize()
        if displaySize.h = 1080
            gaa.displayMode = "FHD"
        else if displaySize.h = 720
            gaa.displayMode = "HD"
        else if displaySize.h = 480
            gaa.displayMode = "SD"
        end if
        return gaa.displayMode
    else
        return gaa.displayMode
    end if
end function

Function getDeepLinks(args) as Object
    deeplink = {}
    return deeplink
end Function