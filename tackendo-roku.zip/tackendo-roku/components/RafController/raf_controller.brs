Library "Roku_Ads.brs"

Sub init()
    m.contentRetriever = m.global.contentRetriever

    m.appInfo = CreateObject("roAppInfo")
    m.dInfo = CreateObject("roDeviceInfo")

    m.top.observeFieldScoped("viewNode", "setViewNode")
    m.top.observeFieldScoped("response", "setRafConfig")

    m.baseHost = "https://pubads.g.doubleclick.net"

    m.podsQueue = []

    m.adIface = Roku_Ads()

    m.measurementEnabled = false
    m.adsLoadStarted = false
    m.top.functionName = "mainFunction"

    ' Initialize RIDA (Roku ID for Advertising)
    m.deviceRIDA = m.dInfo.GetRIDA()
    
    ' Generate session ID for this app session
    m.sessionId = CreateObject("roDeviceInfo").GetRandomUUID()
    
    ' Initialize givn value for SSAI
    m.givnValue = generateGivnForSSAI()
    
    print "TACKENDO: RAF Controller initialized"
    print "TACKENDO: RIDA = " + m.deviceRIDA
    print "TACKENDO: Session ID = " + m.sessionId
    print "TACKENDO: givn generated for SSAI"
End Sub

' Generate givn parameter for Server-Side Ad Insertion (SSAI)
Function generateGivnForSSAI() as String
    ' Get current timestamp
    timestamp = CreateObject("roDateTime").AsSeconds().ToStr()
    
    ' Get device model info
    deviceInfo = m.dInfo.GetModelDetails()
    modelName = ""
    if deviceInfo <> invalid and deviceInfo.ModelName <> invalid
        modelName = deviceInfo.ModelName
    end if
    
    ' Create a unique identifier for SSAI
    ' Format: RIDA_SessionID_Timestamp_Model
    givnData = m.deviceRIDA + "_" + m.sessionId.Left(8) + "_" + timestamp + "_" + modelName.Left(10)
    
    ' Make it URL-safe
    givnData = givnData.Replace(" ", "")
    givnData = givnData.Replace(":", "")
    givnData = givnData.Replace("/", "")
    
    return givnData
End Function

sub fetchVastUrl()
    if ((m.top.publisher <> invalid and m.top.publisher <> "") and (m.top.channel <> invalid and m.top.channel <> ""))
        getVastUrl = m.baseHost + "/getRafConfig/sg/roku/" + m.top.publisher + "/" + m.top.channel
        getVastUrl += "?bundleId=" + m.appInfo.GetID() + "&testMode=" + m.top.testMode.toStr()

        m.top.addFields({
          parameters: {uri: getVastUrl},
        })
        m.contentRetriever.requestGet = { context: m.top }
    end if
end sub

sub setRafConfig(requestDataMsg)
    m.top.unobserveFieldScoped("response")
    reqData = requestDataMsg.getData()
    if (reqData.code = 200)
        config = parseJson(reqData.content)
        if (config.is_active)
            m.getAdsIntervalMs = config.get_ads_interval_ms
            m.maxAdsInPod = config.max_ads_in_pod

            setVastMacros(config.vast_url)
            setIsReady()
        end if
    else
        print("Failed to fetch Raf config from the server")
    end if
end sub

sub setBaseHost(hostMsg)
    m.baseHost = hostMsg.getData()
end sub

function setVastMacros(vast_url)
    m.vastUrl = vast_url.Replace("[APP_NAME]", m.appInfo.GetTitle())
    m.vastUrl = m.vastUrl.Replace("[COUNTRY]", m.dInfo.GetUserCountryCode())
    m.vastUrl = m.vastUrl.Replace("[IDFA]", m.deviceRIDA)
    m.vastUrl = m.vastUrl.Replace("[ADID]", m.deviceRIDA)
    m.vastUrl = m.vastUrl.Replace("[LAT]","")
    m.vastUrl = m.vastUrl.Replace("[LON]","")
    m.vastUrl = m.vastUrl.Replace("[OS]","Roku_OS_" + m.dInfo.GetOSVersion().major+"."+m.dInfo.GetOSVersion().minor)
    m.vastUrl = m.vastUrl.Replace("[US_PRIVACY]","")
    
    ' Add givn parameter for SSAI
    addGivnParameterToVastUrl()
    
    m.vastUrl = m.vastUrl.EncodeUri()
    
    print "TACKENDO: VAST URL with givn = " + m.vastUrl
end function

' Add givn parameter to VAST URL for SSAI
sub addGivnParameterToVastUrl()
    if m.givnValue <> invalid and m.givnValue <> ""
        ' Regenerate givn for each new ad request
        m.givnValue = generateGivnForSSAI()
        
        ' Add givn parameter
        separator = "&"
        if m.vastUrl.Instr("?") = -1
            separator = "?"
        end if
        m.vastUrl = m.vastUrl + separator + "givn=" + m.givnValue
        
        print "TACKENDO: Added givn parameter for SSAI: " + m.givnValue
    end if
end sub

sub setMeasurementDataObj(contentDataMsg = invalid)
    if m.mData = invalid
        initMeasurementData()
    end if

    if contentDataMsg <> invalid
        contentData = contentDataMsg.getData()
        if contentData.genresArray <> invalid and contentData.genresArray.Count() > 0
            m.mData.genresArray = contentData.genresArray
        end if
        if contentData.contentID <> invalid and contentData.contentID <> ""
            m.mData.contentID = contentData.contentID
        end if
        if contentData.contentLength <> invalid and contentData.contentLength > 0
            m.mData.contentLength = contentData.contentLength
        end if
    end if

    setRafMeasurement(m.mData)
    
    ' Regenerate givn for new content
    m.givnValue = generateGivnForSSAI()
    print "TACKENDO: New givn generated for content: " + m.mData.contentID
    
    setIsReady()
end sub

sub initMeasurementData()
    m.adIface.enableAdMeasurements(true)
    m.mData = {
        genresArray: []
        contentID: ""
        contentLength: 0
    }
end sub

sub setRafMeasurement(mData)
    m.adIface.setContentGenre(m.mData.genresArray)
    m.adIface.setContentId(m.mData.contentID)
    m.adIface.setContentLength(Cint(m.mData.contentLength))
end sub

sub setIsReady()
     if (m.vastUrl <> invalid and m.mData <> invalid)
        m.adIface.setAdUrl(m.vastUrl)
        m.top.isReady = true
     end if
end sub

function prepareNewAdsSubTask()
    while true
        tempAdPods = m.adIface.getAds()
        if (m.maxAdsInPod <> invalid)
            isAdReady = fillPodsQueueByBatches(m.adIface.getAds())
            if (isAdReady)
                exit while
            end if
        else if (tempAdPods <> invalid and tempAdPods.Count() > 0)
            m.podsQueue.push(tempAdPods)
            m.top.podsQueue = m.podsQueue
            exit while
        end if
        sleep(m.getAdsIntervalMs)
    end while
end function

function fillPodsQueueByBatches(adPods)
    isAdReady = false
    if (adPods <> invalid and adPods.Count() > 0)
        for i = 0 to adPods.Count() -1
            ads = []
            totalAdsCount = 0
            adsNextInPod = MathUtil().min(m.maxAdsInPod, adPods[i].ads.Count())
            for j = 0 to adPods[i].ads.Count() -1
                ads.push(adPods[i].ads[j])
                totalAdsCount++
                if (ads.Count() = adsNextInPod) 'ads array is full
                    enqueueNewPod(adPods[i], ads)
                    ads = []
                    isAdReady = true
                    adsNextInPod = MathUtil().min(m.maxAdsInPod, adPods[i].ads.Count() - totalAdsCount)
                end if
            end for
        end for
    end if
    return isAdReady
end function

sub enqueueNewPod(otherPod, adsArray)
    podDuration = 0
    for i = 0 to adsArray.Count() -1
        ad = adsArray[i]
        podDuration += ad.duration
    end for
    m.podsQueue.push({
        ads: adsArray,
        duration: podDuration,
        rendersequence: otherPod.rendersequence
        rendertime: otherPod.rendertime
        tracking: otherPod.tracking
        viewed: otherPod.viewed
    })
    m.top.podsQueue = m.podsQueue
end sub

function StartPrepareAdsLoop()
    if (m.top.isReady and m.top.isAdsReady = false and m.adsLoadStarted = false)
        m.adsLoadStarted = true
        m.top.control = "RUN"
    end if
end function

function showAd()
    if (m.top.isReady and m.top.isAdsReady = true)
        m.top.control = "RUN"
    end if
end function

sub showAdsSubTask()
    m.podsQueue = m.top.podsQueue
    adPods = m.podsQueue.shift()
    m.top.podsQueue = m.podsQueue
    m.top.adStarted = true

    print "TACKENDO: Ad playback started with givn tracking"

    shouldPlayContent = m.adIface.showAds(adPods, invalid, invalid)

    print "TACKENDO: Ad playback finished"

    m.top.adFinished = true
end sub

function mainFunction()
    if (m.top.isAdsReady = false)
        prepareNewAdsSubTask()
        m.top.isAdsReady = true
    else if (m.top.isAdsReady = true)
        showAdsSubTask()
        if m.top.podsQueue.Count() = 0
            m.top.isAdsReady = false
            prepareNewAdsSubTask()
            m.top.isAdsReady = true
        end if
    end if
end function