package com.amazon.rialto.webapp.Tackendo.activity

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.widget.ImageView
import androidx.appcompat.widget.AppCompatTextView
import com.amazon.rialto.webapp.Tackendo.BuildConfig
import com.amazon.rialto.webapp.Tackendo.R
import com.bumptech.glide.Glide

/**
 * Ecran d'ouverture.
 *
 * Le visuel est charge depuis le serveur : il peut ainsi etre change sans
 * republier l'application, ce qui compte sur des magasins ou chaque mise a
 * jour demande plusieurs jours de certification.
 *
 * L'ecran reste affiche trois secondes, que l'image arrive ou non : on ne
 * fait jamais attendre le spectateur pour un element decoratif.
 */
class Splash : Activity() {

    companion object {
        private const val SPLASH_URL =
            "https://radiotool.fr/tackendo/images/Tackendo_Splashscreen.png"
        private const val DURATION_MS = 3000L
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )

        val img = findViewById<ImageView>(R.id.imgSplash)
        Glide.with(this).load(SPLASH_URL).into(img)

        findViewById<AppCompatTextView>(R.id.tvVersion).text =
            "v" + BuildConfig.VERSION_NAME

        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }, DURATION_MS)
    }
}
