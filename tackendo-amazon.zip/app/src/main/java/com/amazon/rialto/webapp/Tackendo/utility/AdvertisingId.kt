package com.amazon.rialto.webapp.Tackendo.utility

import android.content.Context
import android.provider.Settings
import android.util.Log

object AdvertisingId {

    @Volatile var id: String = ""
    @Volatile var limitAdTracking: Boolean = false
    @Volatile var loaded: Boolean = false
    @Volatile var source: String = "aucune"

    fun loadAsync(context: Context, onDone: (() -> Unit)? = null) {
        Thread {
            val ctx = context.applicationContext
            try {
                if (!readAmazon(ctx)) {
                    Log.w("TACKENDO", "Aucun identifiant publicitaire")
                    id = ""; limitAdTracking = true; source = "aucune"
                }
                Log.i("TACKENDO", "IFA = " + id + "  (source=" + source +
                        ", limitAdTracking=" + limitAdTracking + ")")
            } catch (e: Exception) {
                Log.w("TACKENDO", "Erreur IFA: " + e.message)
                id = ""; limitAdTracking = true
            } finally {
                loaded = true; onDone?.invoke()
            }
        }.start()
    }

    private fun readAmazon(ctx: Context): Boolean {
        return try {
            val cr = ctx.contentResolver
            val afai = Settings.Secure.getString(cr, "advertising_id")
            if (afai.isNullOrEmpty() || afai == "00000000-0000-0000-0000-000000000000") return false
            val lat = try { Settings.Secure.getInt(cr, "limit_ad_tracking", 0) } catch (e: Exception) { 0 }
            id = afai; limitAdTracking = (lat == 1); source = "amazon"; true
        } catch (e: Exception) {
            Log.w("TACKENDO", "AFAI indisponible: " + e.message); false
        }
    }

    /**
     * Tag publicitaire pour un palier donne de la cascade de prix.
     *
     * Le palier est passe en parametre plutot que fixe ici : le lecteur
     * redescend d'un cran quand Google ne remplit pas, et c'est lui qui
     * sait ou il en est dans la cascade.
     */
    @JvmOverloads
    fun vastTag(
        tier: Api.Tier,
        correlator: String = System.currentTimeMillis().toString()
    ): String = Api.buildVastTag(tier, id, limitAdTracking, correlator)
}
