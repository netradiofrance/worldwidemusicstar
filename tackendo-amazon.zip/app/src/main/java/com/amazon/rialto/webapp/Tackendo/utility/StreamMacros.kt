package com.amazon.rialto.webapp.Tackendo.utility

import android.os.Build
import android.util.Log
import java.net.URLEncoder
import java.util.UUID

/**
 * Macros ajoutees a l'URL du flux.
 *
 * L'application Fire TV jouait jusqu'ici l'URL brute du feed. Les quatorze
 * chaines partaient donc sans la moindre identite : ni identifiant
 * publicitaire, ni nonce, ni contexte applicatif. Cote SSAI - Aniview comme
 * VizChoice - une requete sans identite ne trouve pas d'acheteur.
 *
 * Le nonce PAL, lui, n'etait present que dans le tag GAM appele par l'IMA,
 * c'est-a-dire uniquement sur la publicite cote client. La SSAI n'en voyait
 * rien.
 *
 * Les deux fournisseurs n'attendent pas les memes noms : Aniview veut ses
 * AV_xxx, VizChoice une nomenclature en minuscules. On choisit selon le
 * domaine, exactement comme dans l'application Roku.
 */
object StreamMacros {

    private const val TAG = "TACKENDO"

    /** ASIN de la fiche Amazon : c'est lui qui sert d'identifiant de bundle. */
    private const val ASIN = "B0DGNFS8N9"
    private const val STORE_URL = "https://www.amazon.com/gp/product/$ASIN"

    /**
     * Identifiant de session, stable pour toute la duree d'execution.
     *
     * Il permet a la regie de relier les demandes d'une meme session sans
     * rien apprendre de durable sur le spectateur : il disparait avec le
     * processus.
     */
    private val sessionId: String by lazy { UUID.randomUUID().toString() }

    private fun enc(v: String?): String =
        try { URLEncoder.encode(v ?: "", "UTF-8") } catch (e: Exception) { "" }

    /**
     * Ajoute les macros a une URL de flux.
     *
     * @param url URL brute issue du feed
     * @param userAgent la chaine que le lecteur envoie reellement, pour que
     *                  ce qu'on declare corresponde a ce que le serveur lit
     *                  dans l'en-tete HTTP
     */
    @JvmStatic
    fun inject(url: String?, userAgent: String): String {
        if (url.isNullOrEmpty()) return ""

        /* Deja traitee ? Chaque fournisseur a son marqueur. */
        if (url.contains("&ifa=") || url.contains("AV_IDFA=")) return url

        val lat = AdvertisingId.limitAdTracking || AdvertisingId.id.isEmpty()
        val ifa = if (lat) "00000000-0000-0000-0000-000000000000" else AdvertisingId.id
        val lmt = if (lat) "1" else "0"

        val brand = if (Build.MANUFACTURER.isNullOrEmpty()) "Amazon" else Build.MANUFACTURER
        val model = Build.MODEL ?: ""
        val osVers = Build.VERSION.RELEASE ?: ""
        val givn = PalNonce.nonce
        val cb = System.currentTimeMillis().toString() + (0..99999).random().toString()

        val p = ArrayList<String>()

        if (url.contains("aniview.com")) {
            p.add("cb=$cb")
            p.add("AV_WIDTH=1920")
            p.add("AV_HEIGHT=1080")
            p.add("AV_IDFA=${enc(ifa)}")
            /* Alias introduit par Aniview pour ne plus dependre du champ
               disponible selon l'appareil. */
            p.add("AV_IFA=${enc(ifa)}")
            /* afai, et non rida : c'est le code Amazon Fire. Le meme
               parametre vaut rida sur Roku. */
            p.add("AV_IFA_TYPE=afai")
            /* Suivi limite : Aniview ne peut pas le deviner, leur
               documentation le donne pour non detectable et attendu du
               client. Sans lui, un identifiant nul part sans explication. */
            p.add("AV_LMT=$lmt")
            p.add("AV_APPPKGNAME=$ASIN")
            p.add("AV_APPSTOREURL=${enc(STORE_URL)}")
            p.add("AV_GDPR=0")
            p.add("AV_CCPA=1---")
            p.add("AV_CONTENT_URL=${enc("https://tackendo.com")}")
            p.add("AV_DOMAIN=tackendo.com")
            /* Emplacement video. In-Stream vaut 1. Non detecte hors de leur
               propre lecteur, et beaucoup d'acheteurs CTV filtrent dessus. */
            p.add("AV_PLCMT=1")
            p.add("AV_PLACEMENT=1")
            p.add("AV_MAKE=${enc(brand)}")
            p.add("AV_MODEL=${enc(model)}")
            p.add("AV_OS=Android")
            if (osVers.isNotEmpty()) p.add("AV_OSVERS=${enc(osVers)}")
            p.add("AV_USERAGENT=${enc(userAgent)}")
            p.add("AV_CATEGORY=IAB1-6")
            if (givn.isNotEmpty()) p.add("AV_GIVN=${enc(givn)}")
        } else {
            p.add("ifa=${enc(ifa)}")
            p.add("ifa_type=afai")
            p.add("lmt=$lmt")
            p.add("coppa=0")
            p.add("gdpr=0")
            p.add("os_name=android_${enc(osVers)}")
            p.add("device_type_name=ctv")
            p.add("device_brand_name=${enc(brand)}")
            p.add("device_model=${enc(model)}")
            p.add("player_name=firetv")
            p.add("inapp_browser=inapp")
            p.add("app_name=tackendo")
            p.add("app_domain=tackendo.com")
            p.add("app_storeid=$ASIN")
            p.add("app_storeurl=${enc(STORE_URL)}")
            p.add("site_name=tackendo.com")
            p.add("site_domain=tackendo.com")
            p.add("ua=${enc(userAgent)}")
            p.add("w=1920")
            p.add("h=1080")
            p.add("cb=$cb")
            p.add("session_id=$sessionId")
            p.add("stream_id=${UUID.randomUUID()}")
            if (givn.isNotEmpty()) p.add("givn=${enc(givn)}")
        }

        val sep = if (url.contains("?")) "&" else "?"
        val provider = if (url.contains("aniview.com")) "Aniview" else "VizChoice"
        Log.i(TAG, "macros $provider injectees (${p.size} parametres)")
        return url + sep + p.joinToString("&")
    }
}
