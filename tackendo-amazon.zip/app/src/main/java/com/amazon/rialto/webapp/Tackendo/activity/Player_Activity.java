package com.amazon.rialto.webapp.Tackendo.activity;

import android.app.Activity;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ProgressBar;

import com.amazon.rialto.webapp.Tackendo.R;
import com.amazon.rialto.webapp.Tackendo.utility.AdvertisingId;
import com.amazon.rialto.webapp.Tackendo.utility.Api;
import com.amazon.rialto.webapp.Tackendo.utility.PalNonce;
import com.amazon.rialto.webapp.Tackendo.utility.StreamMacros;

import com.google.ads.interactivemedia.v3.api.AdErrorEvent;
import com.google.ads.interactivemedia.v3.api.AdEvent;

import com.google.android.exoplayer2.DefaultLoadControl;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.LoadControl;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.source.DefaultMediaSourceFactory;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.upstream.DefaultHttpDataSource;
import com.google.android.exoplayer2.ext.ima.ImaAdsLoader;

/**
 * Lecteur Fire TV : pre-roll, coupures periodiques, cascade de prix.
 *
 * Le tag publicitaire est appele DIRECTEMENT par l'IMA SDK depuis la box :
 * Google ne sert aucune demande venant d'un datacenter.
 *
 * CASCADE DE PRIX
 * On demande d'abord au tarif fort. Si Google ne remplit pas, on redescend
 * d'un palier plutot que de laisser le creneau vide. Chaque tentative est
 * remontee au serveur avec son plancher et son resultat, ce qui permet de
 * mesurer la part reelle du tarif fort.
 *
 * COUPURES
 * Sur un flux en direct, l'IMA ne sait pas placer de points de coupure :
 * ils supposent une duree connue. La coupure est donc declenchee par un
 * minuteur, qui relance la cascade depuis le premier palier.
 */
public class Player_Activity extends Activity {

    private static final String TAG = "TACKENDO";

    /**
     * Intervalle entre deux coupures. Fixe.
     *
     * Un espacement automatique avait ete ajoute pour epargner au spectateur
     * les coupures vides. Il n'a plus lieu d'etre : depuis que la cascade se
     * resout hors du lecteur, une coupure vide ne se voit pas. Six minutes,
     * toujours.
     */
    private static final long MIDROLL_MS = 6 * 60 * 1000L;

    public ProgressBar progressBar;
    private ExoPlayer player;
    private PlayerView playerView;
    private ImaAdsLoader adsLoader;
    private String streamUrl;
    private String channelName;

    private final Handler midrollHandler = new Handler(Looper.getMainLooper());
    private Runnable midrollTask;

    /** Palier courant dans la cascade. */
    private int tierIndex = 0;
    /** Vrai tant qu'une publicite du palier courant n'a pas ete servie. */
    private boolean tierPending = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player_);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        playerView = findViewById(R.id.sPalyer);
        progressBar = findViewById(R.id.playerProgress);
        /* Macros ajoutees ici, et non a l'endroit du clic : les deux
           chemins de lancement - grille et fragment de mot de passe -
           passent par cette activite, et un seul point d'injection ne peut
           pas etre oublie par l'un des deux.

           L'agent utilisateur passe est celui que le lecteur enverra
           reellement, pour que ce qu'on declare corresponde a ce que le
           serveur lit dans l'en-tete. */
        streamUrl = StreamMacros.inject(getIntent().getStringExtra("video_url"), userAgent());
        channelName = getIntent().getStringExtra("name");

        /* La derniere image reste affichee quand le lecteur est reconstruit.
           Sans ca, PlayerView efface sa surface a chaque prepare() et le
           spectateur voit un ecran noir a chaque tentative de la cascade. */
        playerView.setKeepContentOnPlayerReset(true);

        /* Les ecouteurs sont poses des la construction : passe cette etape,
           l'IMA ne les accepte plus. */
        adsLoader = new ImaAdsLoader.Builder(this)
                .setAdErrorListener(new AdErrorEvent.AdErrorListener() {
                    @Override
                    public void onAdError(AdErrorEvent e) {
                        String floor = currentFloor();
                        String code = String.valueOf(e.getError().getErrorCode());
                        Log.w(TAG, "PALIER " + floor + " $ : echec IMA (" + code + ")");
                        Api.reportEvent(floor, "nofill", channelName);
                        tierPending = false;

                        /* Aucune condition sur ce chemin.
                           Deux gardes y ont ete posees, et retirees toutes les
                           deux. La premiere triait les codes d'erreur :
                           UNKNOWN_ERROR 900 etant le fourre-tout de Google,
                           elle coupait la cascade sur le cas le plus frequent.
                           La seconde ne descendait d'un palier que si la chaine
                           n'avait pas encore demarre : or quand le tarif fort
                           ne repond pas, ExoPlayer se lasse d'attendre et lance
                           le contenu AVANT que l'erreur n'arrive. Le repli a
                           0,10 $ n'etait donc jamais tente - la ou Roku et
                           Samsung remplissent precisement a ce palier.

                           Un echec fait descendre d'un palier. Toujours. La
                           seule sortie est le dernier palier. */
                        nextTier();
                    }
                })
                .setAdEventListener(new AdEvent.AdEventListener() {
                    @Override
                    public void onAdEvent(AdEvent e) {
                        if (e.getType() == AdEvent.AdEventType.LOADED && tierPending) {
                            tierPending = false;
                            String floor = currentFloor();
                            Log.i(TAG, "PALIER " + floor + " $ : PUB SERVIE");
                            Api.reportEvent(floor, "fill", channelName);
                        }

                        /* Signaux PAL. Le nonce ne vaut pour l'acheteur que si
                           la boucle est refermee : sans impression remontee, le
                           jeton prouve que l'appareil est reel, jamais que la
                           publicite a ete vue. Ces deux appels existaient dans
                           PalNonce et n'etaient invoques nulle part. */
                        if (e.getType() == AdEvent.AdEventType.STARTED) {
                            PalNonce.INSTANCE.onAdStart();
                        } else if (e.getType() == AdEvent.AdEventType.CLICKED) {
                            PalNonce.INSTANCE.onAdClick();
                        }

                        Log.i(TAG, "IMA evenement : " + e.getType());
                    }
                })
                .build();
    }

    private String currentFloor() {
        if (tierIndex >= 0 && tierIndex < Api.TIERS.size())
            return Api.TIERS.get(tierIndex).getFloor();
        return "?";
    }

    /**
     * Passe au palier suivant. Si la cascade est epuisee, la chaine demarre
     * sans publicite — on ne laisse jamais le spectateur devant un ecran
     * vide sous pretexte qu'aucune regie n'a repondu.
     */
    private void nextTier() {
        tierIndex++;
        if (tierIndex >= Api.TIERS.size()) {
            Log.i(TAG, "cascade epuisee - lecture sans publicite");
            tierPending = false;
            return;
        }
        Log.i(TAG, "repli sur le palier " + currentFloor() + " $");
        runOnUiThread(this::requestCurrentTier);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (player == null) initPlayer();
    }

    private void initPlayer() {
        if (streamUrl == null || streamUrl.isEmpty()) {
            Log.e(TAG, "Aucune URL de flux");
            finish();
            return;
        }
        requestNonceThen(this::startPlayback);
    }

    /**
     * Un seul nonce pour toute la session de contenu.
     *
     * La specification PAL demande un jeton par session, partage par toutes
     * les demandes de cette session - pas un par tentative. Le demander a
     * chaque palier ajoutait un aller-retour reseau au chemin critique de
     * chaque coupure, pour un jeton que Google attendait identique.
     */
    private void requestNonceThen(Runnable next) {
        int w = playerView.getWidth()  > 0 ? playerView.getWidth()  : 1920;
        int h = playerView.getHeight() > 0 ? playerView.getHeight() : 1080;
        PalNonce.INSTANCE.request(w, h, () -> {
            runOnUiThread(next);
            return null;
        });
    }

    private MediaItem buildItem() {
        MediaItem.Builder item = new MediaItem.Builder().setUri(Uri.parse(streamUrl));

        if (AdvertisingId.INSTANCE.getLoaded() && tierIndex < Api.TIERS.size()) {
            Api.Tier tier = Api.TIERS.get(tierIndex);
            /* Un correlateur neuf a chaque requete.
               Le partager entre deux appels sur la meme unite revient a
               demander un doublon : GAM s'en sert pour dedupliquer, et la
               seconde demande repart vide. */
            String tag = AdvertisingId.INSTANCE.vastTag(tier);
            Log.i(TAG, "palier " + tier.getFloor() + " $ - VAST tag = " + tag);
            tierPending = true;
            item.setAdsConfiguration(
                    new MediaItem.AdsConfiguration.Builder(Uri.parse(tag)).build());
        } else {
            Log.w(TAG, "AFAI indisponible - lecture sans publicite");
        }
        return item.build();
    }

    /** Relance la lecture sur le palier courant. */
    private void requestCurrentTier() {
        if (player == null || isFinishing()) return;
        player.setMediaItem(buildItem());
        player.prepare();
        player.setPlayWhenReady(true);
    }

    /**
     * Agent utilisateur explicite.
     *
     * Sans lui, ExoPlayer envoie sa chaine par defaut, que les CDN et les
     * regies lisent mal. Celle-ci porte le nom de l'application, la version
     * d'Android et le modele de box - de quoi reconnaitre le trafic dans les
     * journaux de Broadpeak comme dans ceux d'Aniview.
     */
    private static String userAgent() {
        return "Tackendo (Linux; Android " + Build.VERSION.RELEASE
                + "; " + Build.MODEL + ") ExoPlayer/2.18.7";
    }

    private void startPlayback() {
        /* Redirections entre protocoles autorisees.
           Les URL de flux et de publicite passent presque toujours par une
           redirection, souvent d'http vers https. ExoPlayer les refuse par
           defaut : la requete echoue et la lecture cale sans rien dire. */
        DefaultHttpDataSource.Factory dsf = new DefaultHttpDataSource.Factory()
                .setUserAgent(userAgent())
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(15000);

        DefaultMediaSourceFactory msf = new DefaultMediaSourceFactory(dsf)
                .setLocalAdInsertionComponents(unusedAdTagUri -> adsLoader, playerView);

        /* Memoire tampon elargie.
           Une cle Fire TV encaisse mal les a-coups du reseau avec les
           reglages d'origine. On garde davantage d'avance - trente secondes
           au lieu de rien de garanti - et on repart apres un vidage sur cinq
           secondes de contenu plutot que deux et demie. */
        LoadControl loadControl = new DefaultLoadControl.Builder()
                .setBufferDurationsMs(30000, 60000, 2500, 5000)
                .setPrioritizeTimeOverSizeThresholds(true)
                .build();

        player = new ExoPlayer.Builder(this)
                .setMediaSourceFactory(msf)
                .setLoadControl(loadControl)
                .build();

        adsLoader.setPlayer(player);
        playerView.setPlayer(player);
        playerView.setUseController(true);
        playerView.requestFocus();

        tierIndex = 0;

        player.setMediaItem(buildItem());
        player.prepare();
        player.setPlayWhenReady(true);

        player.addListener(new Player.Listener() {
            @Override
            public void onIsPlayingChanged(boolean isPlaying) {
                progressBar.setVisibility(isPlaying ? View.GONE : View.VISIBLE);
            }
            @Override
            public void onPlayerError(com.google.android.exoplayer2.PlaybackException e) {
                Log.e(TAG, "Erreur de lecture: " + e.getMessage());
                progressBar.setVisibility(View.GONE);
            }
        });

        scheduleMidroll();
    }

    /**
     * Programme la prochaine coupure.
     *
     * Toutes les six minutes, du premier palier au dernier.
     *
     * Le sondage HTTP hors lecteur a ete retire. L'intention etait bonne - ne
     * pas figer l'image pour une coupure vide - mais il interrogeait le tag
     * avant l'IMA, et c'est lui qui recoltait la publicite : plafond de
     * repetition consomme d'un cote, demande vue comme un doublon de l'autre.
     * Vingt-quatre heures sans un spot, quand Roku et Samsung remplissaient
     * sur la meme adresse.
     *
     * Reprendre ce chantier demandera de confier a l'IMA la reponse VAST deja
     * obtenue, au lieu de la lui faire redemander.
     */
    private void scheduleMidroll() {
        clearMidroll();
        midrollTask = new Runnable() {
            @Override
            public void run() {
                if (player == null || isFinishing()) return;

                /* Rien a demander sans identifiant publicitaire. */
                if (!AdvertisingId.INSTANCE.getLoaded()) {
                    Log.w(TAG, "AFAI indisponible - coupure sautee");
                    scheduleMidroll();
                    return;
                }

                Log.i(TAG, "coupure publicitaire");
                tierIndex = 0;
                requestCurrentTier();
                scheduleMidroll();
            }
        };
        midrollHandler.postDelayed(midrollTask, MIDROLL_MS);
    }

    private void clearMidroll() {
        if (midrollTask != null) {
            midrollHandler.removeCallbacks(midrollTask);
            midrollTask = null;
        }
    }

    private void releasePlayer() {
        clearMidroll();
        if (player != null) {
            /* Fin de session de contenu cote PAL, avant de tout defaire. */
            PalNonce.INSTANCE.onPlaybackEnd();
            adsLoader.setPlayer(null);
            playerView.setPlayer(null);
            player.release();
            player = null;
        }
    }

    @Override protected void onPause()   { super.onPause();   releasePlayer(); }
    @Override protected void onStop()    { super.onStop();    releasePlayer(); }
    @Override protected void onDestroy() { releasePlayer(); if (adsLoader != null) adsLoader.release(); super.onDestroy(); }
    @Override public void onBackPressed(){ releasePlayer(); super.onBackPressed(); }

    private void showControls() {
        playerView.showController();
        playerView.setUseController(true);
        playerView.setControllerShowTimeoutMs(5000);
        if (player != null) player.setPlayWhenReady(true);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_DPAD_DOWN
                || keyCode == KeyEvent.KEYCODE_DPAD_CENTER
                || keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) {
            showControls();
        }
        return super.onKeyDown(keyCode, event);
    }
}