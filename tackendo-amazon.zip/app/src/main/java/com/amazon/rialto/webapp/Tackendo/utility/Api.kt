package com.amazon.rialto.webapp.Tackendo.utility

import android.util.Log
import java.net.HttpURLConnection
import java.net.URL

/**
 * Configuration publicitaire et cascade de prix.
 *
 * Declare comme object plutot que comme class avec companion : l'acces
 * depuis le code Java en devient direct (Api.getTIERS()) au lieu de passer
 * par Api.Companion, ce qui evite une source d'erreurs de compilation.
 */
object Api {

    private const val TAG = "TACKENDO"

    const val api: String = "https://radiotool.fr/tackendo/tackendo_fire.json"

    /** Un palier de la cascade : un plancher de prix et son unite GAM. */
    data class Tier(val floor: String, val unit: String)

    /**
     * Cascade de prix.
     *
     * On demande d'abord au tarif fort. Si Google ne remplit pas, on
     * redescend plutot que de laisser le creneau vide : une impression a
     * 0,10 $ vaut mieux qu'un creneau perdu. Le journal indique quel palier
     * a servi, ce qui permet de mesurer la part reelle du tarif fort et de
     * la discuter avec la regie sur des chiffres.
     */
    @JvmField
    val TIERS: List<Tier> = listOf(
        Tier("5.00",
            "/23124331701,12626570/NetRadio/" +
                    "NetRadio-Tackendo_Open-Video-OpenG-5_AmazonFireTV-20Aug26"),
        Tier("0.10",
            "/23124331701,12626570/NetRadio/" +
                    "NetRadio-tackendo.com_Open-Video-Multi_Web-07Jan26")
    )

    /** Fiche Amazon de l'application, attendue comme contexte. */
    private const val STORE_URL =
        "https%3A%2F%2Fwww.amazon.com%2Fgp%2Fproduct%2FB0DGNFS8N9"

    /** Ou remonter le resultat de chaque demande. */
    private const val STATS_URL = "https://tackendo.tv/ssai/csai-event"

    /**
     * Construit le tag pour un palier donne.
     *
     * L'appel part DIRECTEMENT de la box : Google ne sert aucune demande
     * venant d'un datacenter. Le contexte reel de l'appareil — IP
     * residentielle, User-Agent, AFAI — doit l'atteindre sans intermediaire.
     */
    @JvmStatic
    @JvmOverloads
    fun buildVastTag(
        tier: Tier,
        ifa: String,
        limitAdTracking: Boolean,
        /* Correlateur impose plutot que tire ici.
           La cascade sonde le tag avant de le confier a l'IMA : les deux
           appels doivent porter le meme correlateur, sinon GAM les compte
           comme deux sessions publicitaires distinctes et peut repondre
           differemment a la seconde. */
        correlator: String = System.currentTimeMillis().toString()
    ): String {
        val id = if (limitAdTracking || ifa.isEmpty())
            "00000000-0000-0000-0000-000000000000" else ifa

        /* L'unite a 0,10 $ est une unite WEB : elle refuse msid et an, qui
           declarent un contexte applicatif — c'est ce qui bloquait le
           remplissage. L'unite a 5 $ est applicative et les attend. */
        val isAppUnit = tier.unit.contains("AmazonFireTV")

        var u = "https://pubads.g.doubleclick.net/gampad/ads" +
                "?iu=" + tier.unit +
                "&description_url=" + STORE_URL +
                "&url=" + STORE_URL +
                "&tfcd=0&npa=0" +
                "&sz=640x480%7C1920x1080%7C1280x720" +
                "&vad_type=linear&linearity=1" +
                "&gdfp_req=1&unviewed_position_start=1" +
                "&output=vast&env=vp&impl=s" +
                "&plcmt=1&vpmute=0&vpa=auto&hl=en" +
                "&rdid=" + id +
                "&idtype=afai" +
                "&is_lat=" + (if (limitAdTracking) "1" else "0")

        if (isAppUnit) u += "&msid=B0DGNFS8N9&an=Tackendo"

        u += "&correlator=" + correlator
        if (PalNonce.nonce.isNotEmpty()) u += "&givn=" + PalNonce.nonce
        return u
    }

    /**
     * Remonte le resultat d'une demande au serveur de statistiques.
     *
     * Sans cette trace, impossible de savoir quelle part des impressions
     * vient du tarif fort — et donc impossible de discuter le plancher avec
     * la regie autrement que sur une impression subjective.
     *
     * L'appel est silencieux : une panne du serveur de stats ne doit jamais
     * perturber la lecture.
     */
    @JvmStatic
    fun reportEvent(floor: String, result: String, channel: String?) {
        Thread {
            try {
                val u = STATS_URL +
                        "?plat=fire" +
                        "&floor=" + floor +
                        "&result=" + result +
                        "&ch=" + (channel ?: "") +
                        "&ts=" + System.currentTimeMillis()
                val c = URL(u).openConnection() as HttpURLConnection
                c.connectTimeout = 4000
                c.readTimeout = 4000
                c.requestMethod = "GET"
                c.responseCode
                c.disconnect()
            } catch (e: Exception) {
                Log.w(TAG, "stats non remontees : " + e.message)
            }
        }.start()
    }
}