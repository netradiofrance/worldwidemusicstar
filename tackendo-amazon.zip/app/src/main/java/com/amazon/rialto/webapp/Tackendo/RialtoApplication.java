package com.amazon.rialto.webapp.Tackendo;

import android.app.Application;

import io.paperdb.Paper;

public class RialtoApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        Paper.init(this);
    }
}
