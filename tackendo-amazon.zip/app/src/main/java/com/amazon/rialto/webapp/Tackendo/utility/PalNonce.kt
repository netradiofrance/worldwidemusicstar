package com.amazon.rialto.webapp.Tackendo.utility

import android.content.Context
import android.util.Log
import com.google.ads.interactivemedia.pal.ConsentSettings
import com.google.ads.interactivemedia.pal.NonceLoader
import com.google.ads.interactivemedia.pal.NonceManager
import com.google.ads.interactivemedia.pal.NonceRequest

/**
 * Nonce PAL de Google.
 *
 * Google exige ce jeton pour servir de la demande programmatique sur
 * l'inventaire CTV : il prouve que l'impression vient d'un appareil reel.
 * Il ne peut pas etre genere cote serveur — il est produit ici, puis
 * transmis a notre ad server qui l'injecte dans le parametre `givn`.
 */
object PalNonce {

    private const val TAG = "TACKENDO"

    @Volatile private var nonceLoader: NonceLoader? = null
    @Volatile private var manager: NonceManager? = null
    @Volatile var nonce: String = ""
    @Volatile var ready: Boolean = false

    fun init(context: Context) {
        try {
            val consent = ConsentSettings.builder()
                .allowStorage(!AdvertisingId.limitAdTracking)
                .build()
            nonceLoader = NonceLoader(context.applicationContext, consent)
            Log.i(TAG, "PAL NonceLoader initialise")
        } catch (e: Throwable) {
            Log.w(TAG, "PAL indisponible: " + e.message)
            nonceLoader = null
        }
    }

    fun request(widthPx: Int, heightPx: Int, onDone: (() -> Unit)? = null) {
        val loader = nonceLoader
        if (loader == null) {
            ready = true
            onDone?.invoke()
            return
        }
        try {
            val req = NonceRequest.builder()
                .descriptionURL("https://tackendo.com/")
                .iconsSupported(false)
                .playerType("ExoPlayer")
                .playerVersion("2.18.7")
                .ppid("")
                .videoPlayerHeight(heightPx)
                .videoPlayerWidth(widthPx)
                .willAdAutoPlay(true)
                .willAdPlayMuted(false)
                .continuousPlayback(true)
                .build()

            loader.loadNonceManager(req)
                .addOnSuccessListener { m: NonceManager ->
                    manager = m
                    nonce = m.nonce
                    ready = true
                    Log.i(TAG, "PAL nonce genere (" + nonce.length + " car.)")
                    onDone?.invoke()
                }
                .addOnFailureListener { e ->
                    Log.w(TAG, "PAL echec: " + e.message)
                    nonce = ""
                    ready = true
                    onDone?.invoke()
                }
        } catch (e: Throwable) {
            Log.w(TAG, "PAL erreur: " + e.message)
            nonce = ""
            ready = true
            onDone?.invoke()
        }
    }

    fun onAdStart() {
        try { manager?.sendAdImpression() } catch (e: Throwable) { Log.w(TAG, "impression: " + e.message) }
    }

    fun onAdClick() {
        try { manager?.sendAdClick() } catch (e: Throwable) { Log.w(TAG, "click: " + e.message) }
    }

    fun onPlaybackEnd() {
        try { manager?.sendPlaybackEnd() } catch (e: Throwable) { Log.w(TAG, "playbackEnd: " + e.message) }
    }
}