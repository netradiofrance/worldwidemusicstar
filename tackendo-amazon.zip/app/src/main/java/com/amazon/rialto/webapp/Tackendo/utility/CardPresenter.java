package com.amazon.rialto.webapp.Tackendo.utility;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;

import androidx.core.content.ContextCompat;
import androidx.leanback.widget.BaseCardView;
import androidx.leanback.widget.Presenter;

import com.amazon.rialto.webapp.Tackendo.R;
import com.amazon.rialto.webapp.Tackendo.model.trial.TvSpecials;
import com.bumptech.glide.Glide;

import static android.widget.ImageView.ScaleType.FIT_XY;

public class CardPresenter extends Presenter {
    private int mSelectedBackgroundColor = -1;
    private int mDefaultBackgroundColor = -1;

    private static Context mContext;
    public static boolean visible = false;

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup) {
        mDefaultBackgroundColor = ContextCompat.getColor(viewGroup.getContext(), R.color.transparent);
        mSelectedBackgroundColor = ContextCompat.getColor(viewGroup.getContext(), R.color.transparent);
        CustomCardView cardView = new CustomCardView(viewGroup.getContext()) {
            @Override
            public void setSelected(boolean selected) {
                super.setSelected(selected);
                updateCardBackgroundColor(this, selected);
            }
        };

        cardView.setFocusable(true);
        cardView.setCardType(BaseCardView.CARD_TYPE_INFO_UNDER);
        cardView.setFocusableInTouchMode(true);
        updateCardBackgroundColor(cardView, false);
        return new ViewHolder(cardView);
    }

    @Override
    public void onBindViewHolder(Presenter.ViewHolder viewHolder, Object item) {
        CustomCardView cardView = (CustomCardView) viewHolder.view;
        TvSpecials data = (TvSpecials) item;
        cardView.setCardType(BaseCardView.CARD_TYPE_INFO_UNDER);
        cardView.setMainImageScaleType(FIT_XY);
        cardView.setMainImageAdjustViewBounds(false);
        cardView.setTitleText(data.getTitle());
//        cardView.setDescText(data.getDesc());
//        ((ViewHolder) viewHolder).updateCardViewImage(data.getPoster());
//        cardView.setMainImageAdjustViewBounds(false);
        Glide.with(viewHolder.view.getContext())
                .load(data.getThumbnail())
                .error(R.drawable.img_6)
                .into(cardView.getMainImageView());
    }

    @Override
    public void onUnbindViewHolder(Presenter.ViewHolder viewHolder) {

    }

    private void updateCardBackgroundColor(CustomCardView imageCardView, boolean selected) {
        int color = selected ? mSelectedBackgroundColor : mDefaultBackgroundColor;
        int visibility = selected ? View.VISIBLE : View.GONE;
        int show = selected ? View.VISIBLE : View.VISIBLE;
        int playicon = selected ? View.GONE : View.VISIBLE;
        imageCardView.setBackgroundColor(color);
//        imageCardView.setPadding(5,5,5,5);
//        imageCardView.getLayoutfade().setVisibility(visibility);
//        if( visible == true){
//            visible=false;
//            imageCardView.getLayoutfade().setVisibility(View.GONE);
//        }

    }

    static class ViewHolder extends Presenter.ViewHolder {
        private CustomCardView mCardView;

        public ViewHolder(View view) {
            super(view);
            mCardView = (CustomCardView) view;
        }

        public CustomCardView getCardView() {
            return mCardView;
        }

        protected void updateCardViewImage(String url) {
            Glide.with(mCardView.getContext())
                    .load(url)
                    .error(R.drawable.img_6)
                    .into(mCardView.getMainImageView());

        }
    }
}

