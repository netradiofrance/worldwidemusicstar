package com.amazon.rialto.webapp.Tackendo.fragment

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.fragment.app.FragmentTransaction
import androidx.leanback.app.BrowseSupportFragment
import androidx.leanback.widget.*
import com.amazon.rialto.webapp.Tackendo.R
import com.amazon.rialto.webapp.Tackendo.activity.HomeActivity
import com.amazon.rialto.webapp.Tackendo.activity.Player_Activity
import com.amazon.rialto.webapp.Tackendo.model.trial.AllResponse
import com.amazon.rialto.webapp.Tackendo.model.trial.Playlists
import com.amazon.rialto.webapp.Tackendo.model.trial.TvSpecials
import com.amazon.rialto.webapp.Tackendo.utility.Api
import com.amazon.rialto.webapp.Tackendo.utility.CardPresenter
import com.amazon.rialto.webapp.Tackendo.utility.CustomHeaderRowPresenter
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.gson.GsonBuilder
import io.paperdb.Paper
import org.apache.commons.collections4.CollectionUtils
import java.util.*
import kotlin.collections.ArrayList
import kotlin.collections.set

class HomeFragment : BrowseSupportFragment() {

    private var mCategoryRowAdapter: ArrayObjectAdapter? = null
    private var cardRowAdapter: ArrayObjectAdapter? = null
    var catArrayHeader: ArrayList<String>? = ArrayList()
    private val cardPresenter = CardPresenter()
    val customHeaderRowPresenter = CustomHeaderRowPresenter()
    lateinit var cardPresenterHeader: HeaderItem

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupUIElements()
        customHeaderRowPresenter.setNullItemVisibilityGone(true)
        val listRowPresenter = ListRowPresenter(FocusHighlight.ZOOM_FACTOR_NONE, false)
        listRowPresenter.headerPresenter = customHeaderRowPresenter
        listRowPresenter.selectEffectEnabled = false
        mCategoryRowAdapter = ArrayObjectAdapter(listRowPresenter)
    }

    private fun setupUIElements() {
        headersState = HEADERS_DISABLED
        isHeadersTransitionOnBackEnabled = true
        setUpEvents()
        loadDataTrial()
    }

    var index = 0

    /**
     * Le nom affichable d'une chaine.
     *
     * Le champ title a longtemps ete vide dans le feed, le nom se trouvant
     * en tete de shortDescription. On accepte les deux : ainsi un feed
     * ancien continue de fonctionner.
     */
    private fun nameOf(t: TvSpecials): String =
        if (t.title.isNullOrEmpty())
            t.shortDescription.substringBefore(" - ").trim()
        else
            t.title

    /** La description, sans le nom qui la precede. */
    private fun descOf(t: TvSpecials): String =
        t.shortDescription.substringAfter(" - ", "").trim()

    private fun loadDataTrial() {
        val request = StringRequest(Request.Method.GET, Api.api, fun(response: String) {
            val gsonBuilder = GsonBuilder()
            gsonBuilder.setDateFormat("M/d/yy hh:mm a")
            val gson = gsonBuilder.create()
            val allResponse = gson.fromJson(response, AllResponse::class.java)

            val linkedHashMapList: MutableList<LinkedHashMap<String, List<TvSpecials>>> =
                java.util.ArrayList()

            for (category in allResponse.categories) {
                val stringListLinkedHashMap: LinkedHashMap<String, List<TvSpecials>> =
                    LinkedHashMap()
                var playlistSelected: Playlists?
                for (playlist in allResponse.playlists) {
                    if (playlist.name == category.playlistName) {
                        playlistSelected = playlist
                        val tvSpecialList: MutableList<TvSpecials> = java.util.ArrayList()
                        for (itemId in playlistSelected.itemIds) {
                            for (tvSpecial in allResponse.tvSpecials) {
                                if (itemId == tvSpecial.id) {
                                    tvSpecialList.add(tvSpecial)
                                }
                            }
                        }
                        stringListLinkedHashMap[category.name] = tvSpecialList
                    }
                }
                linkedHashMapList.add(stringListLinkedHashMap)
            }

            val iterator = linkedHashMapList.listIterator()
            for (stringListLinkedHashMap in iterator) {
                stringListLinkedHashMap.forEach { (name: String, tvSpecialList: List<TvSpecials>) ->
                    catArrayHeader!!.add(name)
                    cardPresenterHeader = HeaderItem(name)
                    cardRowAdapter = ArrayObjectAdapter(cardPresenter)
                    cardRowAdapter!!.addAll(0, tvSpecialList)
                    mCategoryRowAdapter!!.add(index, ListRow(cardPresenterHeader, cardRowAdapter))
                    index++
                }
            }

            adapter = mCategoryRowAdapter
            HomeActivity.progressBar.visibility = View.GONE
        }, {
            Toast.makeText(activity, "Something went wrong.", Toast.LENGTH_SHORT).show()
            HomeActivity.progressBar.visibility = View.GONE
        })

        val requestQueue = Volley.newRequestQueue(activity)
        requestQueue.add(request)
    }

    fun setUpEvents() {

        /* Le survol ne modifie plus la banniere : elle presente les mises
           en avant editoriales et tourne en continu. Le nom de la chaine
           n'est pas affiche non plus — les vignettes le portent deja, et
           le repeter en gros par-dessus la banniere faisait doublon. */
        onItemViewSelectedListener = OnItemViewSelectedListener { _, _, _, _ -> }

        onItemViewClickedListener = OnItemViewClickedListener { _, item, _, _ ->
            if (item is TvSpecials) {
                val storedPasswords = Paper.book().read<List<String>>(item.id)
                if (item.password.isNullOrEmpty() ||
                    (storedPasswords != null &&
                            CollectionUtils.containsAny(storedPasswords, item.password))
                ) {
                    val intent = Intent(activity, Player_Activity::class.java)
                    intent.putExtra("video_url", item.content.videos[0].url)
                    /* Le nom sert au suivi publicitaire : les statistiques
                       indiquent quelle chaine a genere quelle impression. */
                    intent.putExtra("name", nameOf(item))
                    startActivity(intent)
                } else {
                    showPasswordFragment(item.password, item.content.videos[0].url, item.id)
                }
            }
        }
    }

    fun showPasswordFragment(password: List<String>, url: String, id: String) {
        val passwordFragment = PasswordFragment()
        HomeActivity.passwords = password
        HomeActivity.currentIDForPassword = id
        HomeActivity.itemAfterPasswordVerification = url
        val fragmentManager = fragmentManager
        val fragmentTransaction: FragmentTransaction
        if (fragmentManager != null) {
            fragmentTransaction = fragmentManager.beginTransaction()
            fragmentTransaction.add(R.id.passwordFragment, passwordFragment)
            fragmentTransaction.addToBackStack("PasswordFragment")
            fragmentTransaction.commit()
        }
    }
}

