package com.amazon.rialto.webapp.Tackendo.model;
public class PlaylistModel
{

    String catname;
    String id;
//    ArrayList<TempModel> idlist=new ArrayList<>();

    public String getCatname() {
        return catname;
    }

    public void setCatname(String catname) {
        this.catname = catname;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }


//    public ArrayList<TempModel> getIdlist() {
//        return idlist;
//    }
//
//    public void setIdlist(ArrayList<TempModel> idlist) {
//        this.idlist = idlist;
//    }
}
