package com.amazon.rialto.webapp.Tackendo.activity

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.WindowManager
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.RelativeLayout
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import com.amazon.rialto.webapp.Tackendo.R
import com.amazon.rialto.webapp.Tackendo.fragment.HomeFragment
import com.amazon.rialto.webapp.Tackendo.fragment.PasswordFragment
import com.amazon.rialto.webapp.Tackendo.utility.AdvertisingId
import com.amazon.rialto.webapp.Tackendo.utility.PalNonce
import com.bumptech.glide.Glide

class HomeActivity : FragmentActivity() {

    companion object {
        lateinit var homeFragment: HomeFragment
        lateinit var progressBar: ProgressBar
        lateinit var textTitle: androidx.appcompat.widget.AppCompatTextView
        lateinit var textRDate: androidx.appcompat.widget.AppCompatTextView
        lateinit var textquality: androidx.appcompat.widget.AppCompatTextView
        lateinit var textDesc: androidx.appcompat.widget.AppCompatTextView
        lateinit var textSpecial: androidx.appcompat.widget.AppCompatTextView
        lateinit var banner: ImageView
        lateinit var tvof: androidx.appcompat.widget.AppCompatTextView
        lateinit var tvtotalItem: androidx.appcompat.widget.AppCompatTextView
        lateinit var tvfocuson: androidx.appcompat.widget.AppCompatTextView
        lateinit var home_layout: RelativeLayout
        lateinit var passwords: List<String>
        lateinit var itemAfterPasswordVerification: String
        lateinit var currentIDForPassword: String

        /**
         * Bannieres de mise en avant, chargees depuis le serveur : elles
         * peuvent ainsi changer sans republier l'application.
         */
        private val BANNERS = listOf(
            "https://radiotool.fr/tackendo/images/Banner_1.jpg",
            "https://radiotool.fr/tackendo/images/Banner_2.jpg",
            "https://radiotool.fr/tackendo/images/Banner_3.jpg"
        )

        private const val ROTATE_MS = 8000L

        /**
         * Conserve pour compatibilite. La rotation ne s'arrete plus quand
         * le spectateur parcourt la grille : les bannieres sont des mises
         * en avant editoriales, elles tournent en permanence.
         */
        @Volatile
        var bannerIdle: Boolean = true
    }

    private val rotator = Handler(Looper.getMainLooper())
    private var rotateTask: Runnable? = null
    private var bannerIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        home_layout = findViewById(R.id.home_layout)
        progressBar = findViewById(R.id.progress_home)
        textTitle = findViewById(R.id.tvTitle)
        textRDate = findViewById(R.id.tvRelease)
        textquality = findViewById(R.id.tvQuality)
        textDesc = findViewById(R.id.tvDescription)
        textSpecial = findViewById(R.id.tvSpecial)
        banner = findViewById(R.id.imgBanner)
        tvfocuson = findViewById(R.id.tvFocuson)
        tvof = findViewById(R.id.tvof)
        tvtotalItem = findViewById(R.id.tvtotalItem)

        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )

        homeFragment = supportFragmentManager.findFragmentById(R.id.homeFragment) as HomeFragment

        AdvertisingId.loadAsync(applicationContext) {
            PalNonce.init(applicationContext)
        }

        startBannerRotation()
    }

    /** Fait defiler les bannieres tant que la grille n'est pas parcourue. */
    private fun startBannerRotation() {
        showBanner(0)
        rotateTask = object : Runnable {
            override fun run() {
                bannerIndex = (bannerIndex + 1) % BANNERS.size
                showBanner(bannerIndex)
                rotator.postDelayed(this, ROTATE_MS)
            }
        }
        rotator.postDelayed(rotateTask!!, ROTATE_MS)
    }

    private fun showBanner(i: Int) {
        if (isFinishing) return
        Glide.with(this)
            .load(BANNERS[i])
            .into(banner)
    }

    private fun stopBannerRotation() {
        rotateTask?.let { rotator.removeCallbacks(it) }
        rotateTask = null
    }

    override fun onDestroy() {
        stopBannerRotation()
        /* Une boite encore attachee a une activite detruite fuit la fenetre. */
        exitDialog?.takeIf { it.isShowing }?.dismiss()
        exitDialog = null
        super.onDestroy()
    }

    private var exitDialog: android.app.AlertDialog? = null

    /**
     * Confirmation avant de quitter l'application.
     *
     * Le retour depuis la grille fermait l'application sans rien demander.
     * Un appui de trop sur la telecommande, et le spectateur se retrouvait
     * sur l'accueil Fire TV. Les applications Roku et Samsung posent la
     * question ; celle-ci ne le faisait pas.
     *
     * Un second appui sur Retour ferme la boite : la sortie reste a deux
     * gestes, jamais a un seul par accident.
     */
    override fun onBackPressed() {
        /* Un fragment ouvert - la saisie de mot de passe - se ferme d'abord :
           Retour doit remonter d'un cran avant de proposer de sortir. */
        val current = getCurrentFragment()
        if (current != null && current.isVisible) {
            super.onBackPressed()
            return
        }

        if (exitDialog?.isShowing == true) return

        exitDialog = android.app.AlertDialog.Builder(this)
            .setTitle(getString(R.string.exit_title))
            .setMessage(getString(R.string.exit_message))
            .setNegativeButton(getString(R.string.exit_cancel)) { d, _ -> d.dismiss() }
            .setPositiveButton(getString(R.string.exit_confirm)) { d, _ ->
                d.dismiss()
                finish()
            }
            .setOnDismissListener { exitDialog = null }
            .create()
        exitDialog?.show()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        return when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> {
                val test = getCurrentFragment()
                if (test != null && test.isVisible) {
                    home_layout.isFocusable = false
                    (test as? PasswordFragment)?.edittext_password?.requestFocus() ?: false
                } else {
                    home_layout.isFocusable = true
                    super.onKeyDown(keyCode, event)
                }
            }
            else -> super.onKeyDown(keyCode, event)
        }
    }

    private fun getCurrentFragment(): Fragment? {
        return supportFragmentManager.findFragmentById(R.id.passwordFragment)
    }
}
