package com.amazon.rialto.webapp.Tackendo.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.appcompat.widget.AppCompatButton;
import androidx.fragment.app.Fragment;

import com.amazon.rialto.webapp.Tackendo.R;
import com.amazon.rialto.webapp.Tackendo.activity.HomeActivity;
import com.amazon.rialto.webapp.Tackendo.activity.Player_Activity;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import io.paperdb.Paper;

public class PasswordFragment extends Fragment {

    public EditText edittext_password;
    AppCompatButton button_submit;
    RelativeLayout rl_password;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_password_layout, container, false);
        edittext_password = view.findViewById(R.id.edittext_password);
        button_submit = view.findViewById(R.id.button_submit);
        rl_password = view.findViewById(R.id.rl_password);
        edittext_password.requestFocus();
        button_submit.setOnClickListener(v -> {

            if (HomeActivity.passwords.contains(edittext_password.getText().toString())) {
                List<String> storedPasswords = Paper.book().read(HomeActivity.currentIDForPassword);
                if (storedPasswords == null) {
                    storedPasswords = new ArrayList<>();
                }
                storedPasswords.add(edittext_password.getText().toString());
                Paper.book().write(HomeActivity.currentIDForPassword, storedPasswords);
                Intent intent = new Intent(PasswordFragment.this.getActivity(), Player_Activity.class);
                intent.putExtra("video_url", HomeActivity.itemAfterPasswordVerification);
                startActivity(intent);
                Objects.requireNonNull(getActivity()).onBackPressed();
            } else {
                Toast.makeText(PasswordFragment.this.getContext(), "Please enter correct password", Toast.LENGTH_LONG).show();
            }
        });
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        edittext_password.requestFocus();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

}
