<?php
if ( ! defined( 'ABSPATH' ) ) exit;

// ── MASTER TOPIC POOL ─────────────────────────────────────────────
// 60+ unique topics across 8 categories. Each has a unique slug for dedup tracking.
function tcore_topic_pool() {
    return array(
        // ── CTV INDUSTRY (12) ──
        array( 'slug' => 'what-is-fast-tv', 'tag' => 'CTV Industry', 'kw' => 'FAST TV explained, free ad-supported streaming TV', 'brief' => 'Define FAST TV, explain how it differs from SVOD and cable, how it works technically with linear streams and ad breaks, key benefits for viewers, market size in 2026, major platforms, and how TACKENDO fits.' ),
        array( 'slug' => 'fast-tv-growth-2026', 'tag' => 'CTV Industry', 'kw' => 'FAST TV growth 2026, CTV trends streaming', 'brief' => 'Cord-cutting acceleration, lean-back viewing habits returning, advertiser demand for brand-safe CTV inventory, audience growth stats, why independent FAST platforms like TACKENDO thrive.' ),
        array( 'slug' => 'fast-vs-cable', 'tag' => 'CTV Industry', 'kw' => 'FAST TV vs cable TV comparison 2026, cord cutting', 'brief' => 'Head-to-head: cost, content variety, on-demand vs linear, ad experience, device availability, how FAST fills the gap left by cable cancellations.' ),
        array( 'slug' => 'psychology-lean-back', 'tag' => 'CTV Industry', 'kw' => 'lean-back viewing TV psychology, linear TV comeback', 'brief' => 'Psychological difference between lean-forward YouTube/TikTok and lean-back TV, why audiences return to passive linear viewing, why FAST channels capture this.' ),
        array( 'slug' => 'start-fast-channel', 'tag' => 'CTV Industry', 'kw' => 'how to start FAST TV channel 2026, create linear TV channel', 'brief' => 'FAST channel creation process: content requirements, distribution platforms, monetization, technical setup, what it takes to build a sustainable FAST business.' ),
        array( 'slug' => 'economics-free-tv', 'tag' => 'CTV Industry', 'kw' => 'FAST TV business model, how free TV makes money', 'brief' => 'Revenue model: CPMs, ad fill rates, programmatic vs direct, revenue sharing, viewer engagement metrics, what sustainable FAST economics look like.' ),
        array( 'slug' => 'fast-tv-europe', 'tag' => 'CTV Industry', 'kw' => 'FAST TV Europe 2026, free streaming channels Europe', 'brief' => 'FAST TV adoption in Europe vs US, European viewer preferences, regulatory landscape, localization challenges, why European FAST platforms like TACKENDO are emerging.' ),
        array( 'slug' => 'ctv-landscape-2026', 'tag' => 'CTV Industry', 'kw' => 'CTV landscape 2026, connected TV market overview', 'brief' => 'State of CTV in 2026: device penetration, viewing hours, SVOD fatigue, FAST growth, how the ecosystem is maturing, where TACKENDO positions itself.' ),
        array( 'slug' => 'future-linear-tv', 'tag' => 'CTV Industry', 'kw' => 'future of linear TV streaming, linear vs on-demand 2026', 'brief' => 'Why linear TV is not dead but transforming. The shift from broadcast to IP-delivered linear, why scheduledcuration still works, FAST as the new linear.' ),
        array( 'slug' => 'fast-tv-vs-youtube', 'tag' => 'CTV Industry', 'kw' => 'FAST TV vs YouTube free content comparison', 'brief' => 'Compare FAST TV channels with YouTube: content quality, ad experience, brand safety, viewing context, lean-back vs lean-forward, why both can coexist.' ),
        array( 'slug' => 'cord-cutting-guide', 'tag' => 'CTV Industry', 'kw' => 'cord cutting guide 2026, cancel cable keep watching free', 'brief' => 'Practical guide to cutting the cord: what you lose vs gain, free alternatives including FAST TV, how to build a streaming setup, why TACKENDO replaces cable music channels.' ),
        array( 'slug' => 'fast-tv-smart-tv', 'tag' => 'CTV Industry', 'kw' => 'FAST TV smart TV integration, built-in free channels', 'brief' => 'How FAST channels are being integrated into smart TV interfaces by Samsung, LG, Vizio, how this changes discovery, what it means for platforms like TACKENDO.' ),

        // ── ADVERTISING (10) ──
        array( 'slug' => 'what-is-ctv-advertising', 'tag' => 'Advertising', 'kw' => 'CTV advertising explained, connected TV ad spend 2026', 'brief' => 'Define CTV advertising, ad formats (pre-roll, mid-roll, VAST, VPAID, VMAP), viewability advantages, completion rates, targeting, why FAST channels are premium inventory.' ),
        array( 'slug' => 'fast-advertising-guide', 'tag' => 'Advertising', 'kw' => 'FAST TV advertising guide, buy ads FAST channels', 'brief' => 'How advertising works on FAST channels, CPM comparisons vs linear TV and digital, programmatic vs direct deals, brand safety, how to reach the TACKENDO audience.' ),
        array( 'slug' => 'brand-safety-streaming', 'tag' => 'Advertising', 'kw' => 'brand safety streaming TV, FAST channels advertisers', 'brief' => 'Brand safety crisis in social/UGC platforms, how FAST channels with curated content solve this, what brand safe means in CTV, TACKENDO curated positioning.' ),
        array( 'slug' => 'music-channels-engagement', 'tag' => 'Advertising', 'kw' => 'music FAST TV viewing sessions, CTV engagement music channels', 'brief' => 'Why music channels drive longer dwell times: background viewing, mood-based consumption, genre loyalty, no decision fatigue, implications for CTV ad buyers.' ),
        array( 'slug' => 'programmatic-ctv', 'tag' => 'Advertising', 'kw' => 'programmatic CTV advertising 2026, automated TV ad buying', 'brief' => 'How programmatic buying works for CTV/FAST inventory, DSPs and SSPs in the CTV ecosystem, targeting capabilities, measurement challenges, TACKENDO ad integration.' ),
        array( 'slug' => 'ctv-cpms-guide', 'tag' => 'Advertising', 'kw' => 'CTV CPM rates 2026, connected TV advertising costs', 'brief' => 'Breakdown of CTV CPM rates across different genres and platforms, what drives premium pricing, music vs news vs entertainment CPMs, value proposition of FAST inventory.' ),
        array( 'slug' => 'ssai-vs-csai', 'tag' => 'Advertising', 'kw' => 'SSAI vs CSAI CTV advertising, server-side ad insertion', 'brief' => 'Technical comparison of SSAI and CSAI for FAST channels, viewer experience impact, ad blocking considerations, why SSAI dominates FAST, how TACKENDO implements ads.' ),
        array( 'slug' => 'ctv-measurement', 'tag' => 'Advertising', 'kw' => 'CTV ad measurement attribution 2026, connected TV analytics', 'brief' => 'How CTV ad effectiveness is measured: viewability, completion rates, reach and frequency, attribution models, cross-device challenges, the measurement gap vs digital.' ),
        array( 'slug' => 'advertise-music-tv', 'tag' => 'Advertising', 'kw' => 'advertise on music TV channels, music channel sponsorship', 'brief' => 'Why music TV channels are attractive for advertisers: demographics, mood alignment, longer sessions, contextual targeting, how brands can advertise on TACKENDO music channels.' ),
        array( 'slug' => 'ctv-addressable-ads', 'tag' => 'Advertising', 'kw' => 'addressable TV advertising CTV 2026, targeted TV ads', 'brief' => 'How addressable advertising works on CTV, household-level targeting, data sources, privacy considerations, how FAST channels enable better targeting than broadcast.' ),

        // ── MUSIC (12) ──
        array( 'slug' => 'best-music-fast-channels', 'tag' => 'Music', 'kw' => 'best music channels streaming free, music FAST TV', 'brief' => 'Roundup of best music FAST channels in 2026, TACKENDO lineup (EDM, Lo-Fi, Synthwave, Urban Street, Epic, Rising), what makes each unique, how to access free.' ),
        array( 'slug' => 'lofi-dominating-ctv', 'tag' => 'Music', 'kw' => 'lo-fi music channel streaming, lo-fi TV free', 'brief' => 'Lo-fi aesthetic phenomenon, origins, why it resonates with Gen Z/millennials, anime-style lo-fi for CTV, study/relax context, TACKENDO Lo-Fi channel.' ),
        array( 'slug' => 'synthwave-neon-dreams', 'tag' => 'Music', 'kw' => 'Synthwave channel free streaming, retro-futuristic music TV', 'brief' => 'Synthwave culture, 1980s aesthetic revival origins, cinematic visual language, why it works as TV, audience profile, TACKENDO Synthwave channel.' ),
        array( 'slug' => 'edm-nonstop', 'tag' => 'Music', 'kw' => 'EDM channel free streaming, electronic dance music TV', 'brief' => 'EDM culture and festivals, why EDM works as linear FAST TV, audience profile, TACKENDO EDM channel, advertising context and demographics.' ),
        array( 'slug' => 'urban-street-hiphop', 'tag' => 'Music', 'kw' => 'Hip-Hop channel free streaming, Urban Street rap TV', 'brief' => 'Urban music culture, appeal of continuous Hip-Hop linear TV, curation vs Spotify playlists, audience loyalty, TACKENDO Urban Street deep dive.' ),
        array( 'slug' => 'epic-cinematic-music', 'tag' => 'Music', 'kw' => 'epic music channel streaming, cinematic music free TV', 'brief' => 'Rise of epic/cinematic music connected to gaming, consumer profile, how it translates to FAST TV, TACKENDO Epic Music overview.' ),
        array( 'slug' => 'linear-vs-playlists', 'tag' => 'Music', 'kw' => 'linear music TV vs Spotify, music discovery FAST channels', 'brief' => 'Linear TV music vs Spotify/Apple Music playlists: lean-back vs lean-forward, session times, music discovery advantages, the TV experience difference.' ),
        array( 'slug' => 'music-discovery-fast', 'tag' => 'Music', 'kw' => 'music discovery FAST TV, discover new music online free', 'brief' => 'Algorithm bubble problem on streaming services, how curated linear FAST music TV exposes viewers to new genres and artists, TACKENDO role in discovery.' ),
        array( 'slug' => 'ambient-music-tv', 'tag' => 'Music', 'kw' => 'ambient music TV channel, background music streaming free', 'brief' => 'Rise of ambient and background TV channels, how ambient music increases focus and reduces stress, cozy aesthetic trend, TACKENDO Winter Ambience and Fireplace channels.' ),
        array( 'slug' => 'independent-artists-fast', 'tag' => 'Music', 'kw' => 'independent artists FAST TV exposure, unsigned music television', 'brief' => 'How FAST TV gives independent and unsigned artists TV exposure they could never afford, the democratization of music television, TACKENDO Rising and Tzik channels.' ),
        array( 'slug' => 'summer-vibes-channel', 'tag' => 'Music', 'kw' => 'Summer Vibes music channel, summer chill beats streaming free', 'brief' => 'The appeal of seasonal mood-based music channels, why Summer Vibes captures endless summer energy, beach culture and chill beats, how to watch on TACKENDO.' ),
        array( 'slug' => 'music-tv-comeback', 'tag' => 'Music', 'kw' => 'music TV comeback 2026, MTV alternative free streaming', 'brief' => 'How FAST channels are reviving the music TV format MTV abandoned, visual music consumption habits of Gen Z, why music television never really died, TACKENDO as the new MTV.' ),

        // ── CHANNEL SPOTLIGHTS (8) ──
        array( 'slug' => 'spotlight-netradio-vision', 'tag' => 'Channel Spotlight', 'kw' => 'Netradio Vision channel, pop culture FAST TV', 'brief' => 'Deep dive into Netradio Vision: programming philosophy, MARCY BEAUCOUP interview show hosted by Christophe Marcy, La Team gaming show, rising artists, digital creators.' ),
        array( 'slug' => 'spotlight-made-in-france', 'tag' => 'Channel Spotlight', 'kw' => 'Made in France TV channel, French culture streaming', 'brief' => 'Made in France TV: French heritage, gastronomy, artisanal craftsmanship, innovative entrepreneurs, chateaux, how it brings French savoir-faire to international CTV audiences.' ),
        array( 'slug' => 'spotlight-good-lifestyle', 'tag' => 'Channel Spotlight', 'kw' => 'Good Lifestyle TV channel, lifestyle streaming free', 'brief' => 'Good Lifestyle TV: social awareness, inspiring originals, feature shows, audience profile, programming philosophy, how to watch free on TACKENDO.' ),
        array( 'slug' => 'spotlight-tzik', 'tag' => 'Channel Spotlight', 'kw' => 'Tzik TV channel, independent music FAST TV', 'brief' => 'Tzik: from satellite to FAST TV, mission to celebrate unsigned artists, programming philosophy, how it differs from mainstream, how to watch on TACKENDO.' ),
        array( 'slug' => 'spotlight-winter-ambience', 'tag' => 'Channel Spotlight', 'kw' => 'Winter Ambience TV channel, ambient music streaming free', 'brief' => 'Rise of ambient/background TV, why winter jazz and ambient music increases focus, cozy aesthetic trend, TACKENDO Winter Ambience 24/7 atmospheric content.' ),
        array( 'slug' => 'spotlight-fireplace', 'tag' => 'Channel Spotlight', 'kw' => 'Fireplace TV channel free streaming, virtual fireplace', 'brief' => 'Virtual fireplace channels as the ultimate ambient TV, psychology of fire watching, ASMR crossover, why Fireplace channels are top performers on CTV, TACKENDO Fireplace.' ),
        array( 'slug' => 'spotlight-expat-tv', 'tag' => 'Channel Spotlight', 'kw' => 'Expat TV channel, expatriate life abroad streaming', 'brief' => 'Expat TV: resources for expats worldwide, visa guides, cultural integration stories, housing tips, building community abroad, unique positioning in FAST TV landscape.' ),
        array( 'slug' => 'spotlight-summer-vibes', 'tag' => 'Channel Spotlight', 'kw' => 'Summer Vibes TV channel, summer music free streaming', 'brief' => 'Summer Vibes channel deep dive: sun-kissed beats, chill vibes, beach culture, why seasonal mood channels work on FAST TV, programming approach, how to watch on TACKENDO.' ),

        // ── PLATFORM GUIDES (6) ──
        array( 'slug' => 'guide-roku', 'tag' => 'Platform Guide', 'kw' => 'TACKENDO Roku channel, add free channels Roku', 'brief' => 'Step-by-step: finding TACKENDO in Roku Channel Store, adding it, navigating, channels available, tips for best experience.' ),
        array( 'slug' => 'guide-firetv', 'tag' => 'Platform Guide', 'kw' => 'TACKENDO Fire TV, free channels Amazon Fire TV Stick', 'brief' => 'Fire TV guide: download TACKENDO from Amazon Appstore, channels, remote navigation tips, why FAST TV is perfect for Fire TV.' ),
        array( 'slug' => 'guide-complete', 'tag' => 'Platform Guide', 'kw' => 'TACKENDO complete guide, free live TV channels music lifestyle', 'brief' => 'Comprehensive guide: what TACKENDO is, all 20+ channels described, how to watch on web/Roku/Fire TV, what is coming next.' ),
        array( 'slug' => 'guide-web-watching', 'tag' => 'Platform Guide', 'kw' => 'watch free TV online browser, TACKENDO web player', 'brief' => 'How to watch TACKENDO directly in your browser, no download needed, best browser settings, mobile vs desktop experience, bookmarking channels.' ),
        array( 'slug' => 'guide-family-setup', 'tag' => 'Platform Guide', 'kw' => 'family friendly free TV channels, safe streaming kids', 'brief' => 'Setting up TACKENDO for the whole family: kid-safe music channels, ambient channels for focus, lifestyle channels for adults, no inappropriate content.' ),
        array( 'slug' => 'guide-how-watch-free', 'tag' => 'Streaming Guide', 'kw' => 'how to watch free TV online, free streaming channels 2026', 'brief' => 'Step-by-step: what FAST TV is, accessing on web/Roku/Fire TV without account or subscription, best channels to start with, viewing experience tips.' ),

        // ── STREAMING GUIDES (5) ──
        array( 'slug' => 'best-free-streaming-2026', 'tag' => 'Streaming Guide', 'kw' => 'best free streaming services 2026, watch TV without paying', 'brief' => 'Roundup of every free streaming option in 2026: FAST platforms, free tiers of paid services, which has the best content, where TACKENDO fits.' ),
        array( 'slug' => 'streaming-without-subscription', 'tag' => 'Streaming Guide', 'kw' => 'streaming without subscription 2026, no sign up free TV', 'brief' => 'How to access quality streaming content without any subscription or account, the rise of no-login FAST TV, privacy benefits, TACKENDO zero-friction approach.' ),
        array( 'slug' => 'second-screen-experience', 'tag' => 'Streaming Guide', 'kw' => 'second screen TV experience, background TV streaming', 'brief' => 'How people use TV as a second screen while working/studying, why FAST music and ambient channels are perfect for this, productivity benefits, TACKENDO ambient lineup.' ),
        array( 'slug' => 'ctv-devices-comparison', 'tag' => 'Streaming Guide', 'kw' => 'best CTV devices 2026, Roku vs Fire TV vs Chromecast', 'brief' => 'Compare streaming devices for FAST TV: Roku, Fire TV, Chromecast, Apple TV, smart TVs. Which is best for free channels, ease of use, TACKENDO availability.' ),
        array( 'slug' => 'christmas-music-channel', 'tag' => 'Streaming Guide', 'kw' => 'Christmas music channel free streaming, holiday TV channel', 'brief' => 'Why dedicated Christmas music channels are top seasonal content, TACKENDO Christmas Music with holiday classics and indie songs, available year-round.' ),

        // ── CREATOR ECONOMY / SHOWS (5) ──
        array( 'slug' => 'marcy-beaucoup-show', 'tag' => 'Channel Spotlight', 'kw' => 'Marcy Beaucoup interview show, FAST TV talk show', 'brief' => 'Inside Marcy Beaucoup: the weekly interview show on Netradio Vision, hosted by Christophe Marcy, featuring emerging artists and creators, format and philosophy, how it brings talk-show TV to FAST.' ),
        array( 'slug' => 'la-team-gaming', 'tag' => 'Channel Spotlight', 'kw' => 'La Team gaming show FAST TV, video game TV show free', 'brief' => 'La Team: the gaming and pop culture show on Netradio Vision, covering new game releases, industry news, gamer culture, why gaming content works on linear FAST TV.' ),
        array( 'slug' => 'creator-economy-tv', 'tag' => 'CTV Industry', 'kw' => 'creator economy television 2026, creators on FAST TV', 'brief' => 'How the creator economy intersects with FAST TV, creators producing channel content, new revenue models, how TACKENDO supports emerging creators and artists.' ),
        array( 'slug' => 'original-shows-fast', 'tag' => 'CTV Industry', 'kw' => 'original programming FAST TV, original shows free streaming', 'brief' => 'The trend of original programming on FAST channels, how it differentiates platforms, cost of production vs licensing, TACKENDO original shows strategy with Marcy Beaucoup and La Team.' ),
        array( 'slug' => 'music-video-tv-revival', 'tag' => 'Music', 'kw' => 'music video television 2026, music video channels streaming', 'brief' => 'The revival of music video consumption on TV screens, why CTV brought back the music video format, visual music experience on big screens, TACKENDO music video curation.' ),
    );
}

// ── ANTI-DUPLICATE: check if topic was already published ──────────
function tcore_is_topic_published( $slug ) {
    $existing = get_posts( array(
        'post_type'   => 'post',
        'post_status' => array( 'publish', 'draft', 'pending', 'private' ),
        'meta_key'    => '_tcore_topic_slug',
        'meta_value'  => $slug,
        'numberposts' => 1,
    ) );
    return ! empty( $existing );
}

// ── GET NEXT UNPUBLISHED TOPIC ───────────────────────────────────
function tcore_next_topic() {
    $pool = tcore_topic_pool();
    // Shuffle deterministically by day so different topics get priority each day
    $seed = (int) date('Ymd');
    mt_srand( $seed );
    $indices = range( 0, count($pool) - 1 );
    shuffle( $indices );
    mt_srand(); // Reset

    foreach ( $indices as $i ) {
        if ( ! tcore_is_topic_published( $pool[$i]['slug'] ) ) {
            return $pool[$i];
        }
    }
    // All topics published — generate a fresh angle
    return tcore_generate_fresh_topic();
}

// ── GENERATE FRESH TOPIC when pool is exhausted ──────────────────
function tcore_generate_fresh_topic() {
    $categories = array( 'CTV Industry', 'Advertising', 'Music', 'Channel Spotlight', 'Streaming Guide', 'Platform Guide' );
    $tag = $categories[ array_rand( $categories ) ];

    $angles = array(
        'CTV Industry' => array(
            'The role of AI in FAST TV channel curation and scheduling',
            'How 5G is transforming mobile FAST TV consumption',
            'FAST TV and the death of the traditional TV remote',
            'Why Gen Z prefers FAST channels over social media for music',
            'The global expansion of FAST TV beyond North America',
        ),
        'Advertising' => array(
            'How contextual advertising is evolving on FAST music channels',
            'The future of interactive ads on connected TV platforms',
            'Why CTV ad fraud rates are lower than digital display',
            'Cross-screen attribution challenges for CTV advertisers',
            'Dynamic ad insertion trends in FAST TV 2026',
        ),
        'Music' => array(
            'How FAST music channels are supporting emerging artists worldwide',
            'The psychology of music genre selection in lean-back viewing',
            'Why 24/7 music channels outperform curated playlists for retention',
            'The visual aesthetics of music TV channels and viewer engagement',
            'How ambient music channels became a wellness phenomenon',
        ),
        'Channel Spotlight' => array(
            'Behind the scenes of programming a 24/7 music TV channel',
            'How TACKENDO selects and curates content for its channels',
            'The art of channel branding in the FAST TV era',
            'Interview shows on FAST TV: a new format for the creator era',
            'Building community around niche FAST TV channels',
        ),
        'Streaming Guide' => array(
            'Setting up the perfect ambient TV experience at home',
            'How to discover new FAST channels you will love',
            'The best free TV channels for every mood and moment',
            'FAST TV for remote workers: background channels that boost productivity',
            'Your weekend binge guide: 48 hours of free FAST TV',
        ),
        'Platform Guide' => array(
            'Optimizing your Roku for the best FAST TV experience',
            'Fire TV tips and tricks for FAST channel viewers',
            'How to cast FAST TV channels to your smart TV',
            'Building a free TV setup: no subscriptions needed',
            'Parental controls and FAST TV: what parents need to know',
        ),
    );

    $options = isset( $angles[$tag] ) ? $angles[$tag] : $angles['Music'];
    $title = $options[ array_rand( $options ) ];

    // Check this generated title doesn't already exist
    $existing = get_posts( array(
        'post_type'   => 'post',
        'post_status' => array( 'publish', 'draft', 'pending', 'private' ),
        'title'       => $title,
        'numberposts' => 1,
    ) );
    if ( ! empty( $existing ) ) {
        // Try another
        $title = $options[ array_rand( $options ) ] . ' in ' . date('Y');
    }

    return array(
        'slug'  => 'gen-' . sanitize_title( substr( $title, 0, 40 ) ) . '-' . date('ymd'),
        'tag'   => $tag,
        'kw'    => strtolower( str_replace( array(':', ',', '.'), '', $title ) ) . ', FAST TV, CTV, TACKENDO',
        'brief' => $title . '. Write an authoritative, helpful article that provides genuine value to readers interested in FAST TV, CTV, and streaming. Mention TACKENDO naturally as a leading FAST TV platform with 20+ free channels covering music, pop culture, and lifestyle.',
    );
}

// ── INITIAL TOPICS (kept for backward compat) ────────────────────
function tcore_initial_topics() {
    return array_slice( tcore_topic_pool(), 0, 20 );
}

// ── DAILY TOPIC (replaced with smart picker) ─────────────────────
function tcore_daily_topic() {
    return tcore_next_topic();
}

// ── Claude API call ──────────────────────────────────────────────
function tcore_call_claude( $topic ) {
    $key  = get_option( 'tcore_claude_key', '' );
    $lang = get_option( 'tcore_article_lang', 'en' );

    if ( empty( $key ) ) {
        error_log( '[TackendoCore] Claude API key not set.' );
        return false;
    }

    $lang_name = ( $lang === 'fr' ) ? 'French' : 'English';

    $prompt = 'Write a complete blog article for TACKENDO.com, a free FAST TV platform with 20+ live channels covering music, pop culture, and lifestyle.' . "\n\n"
        . 'Requirements:' . "\n"
        . '- Language: ' . $lang_name . "\n"
        . '- Length: 800 to 1000 words' . "\n"
        . '- Start directly with the introduction paragraph, no preamble' . "\n"
        . '- Use H2 subheadings formatted as: ## Heading Title' . "\n"
        . '- Be genuinely helpful and informative, not just promotional' . "\n"
        . '- Mention TACKENDO naturally 2 to 3 times as a concrete example' . "\n"
        . '- Include specific data, trends, or insights when relevant' . "\n"
        . '- End with a soft call-to-action to explore TACKENDO channels' . "\n"
        . '- Integrate these keywords naturally: ' . $topic['kw'] . "\n\n"
        . 'Article brief: ' . $topic['brief'] . "\n\n"
        . 'Category: ' . $topic['tag'] . "\n\n"
        . 'Write a compelling, unique title for this article, then begin the article. Format the title on the first line prefixed with "TITLE: " followed by the article body.';

    $response = wp_remote_post(
        'https://api.anthropic.com/v1/messages',
        array(
            'timeout' => 120,
            'headers' => array(
                'Content-Type'      => 'application/json',
                'x-api-key'         => $key,
                'anthropic-version' => '2023-06-01',
            ),
            'body' => wp_json_encode( array(
                'model'      => 'claude-sonnet-4-6',
                'max_tokens' => 1500,
                'messages'   => array(
                    array( 'role' => 'user', 'content' => $prompt ),
                ),
            ) ),
        )
    );

    if ( is_wp_error( $response ) ) {
        error_log( '[TackendoCore] HTTP error: ' . $response->get_error_message() );
        return false;
    }

    $code = wp_remote_retrieve_response_code( $response );
    if ( $code !== 200 ) {
        error_log( '[TackendoCore] Claude API HTTP ' . $code . ': ' . wp_remote_retrieve_body( $response ) );
        return false;
    }

    $body = json_decode( wp_remote_retrieve_body( $response ), true );

    if ( empty( $body['content'][0]['text'] ) ) {
        error_log( '[TackendoCore] Unexpected Claude response: ' . wp_json_encode( $body ) );
        return false;
    }

    return $body['content'][0]['text'];
}

// ── Create WP post from Claude content ───────────────────────────
function tcore_write_post( $topic ) {
    // Anti-duplicate check
    if ( ! empty( $topic['slug'] ) && tcore_is_topic_published( $topic['slug'] ) ) {
        error_log( '[TackendoCore] Topic already published: ' . $topic['slug'] );
        return false;
    }

    $raw = tcore_call_claude( $topic );
    if ( ! $raw ) return false;

    // Extract title if Claude generated one
    $title = '';
    $content_body = $raw;
    if ( preg_match( '/^TITLE:\s*(.+)$/m', $raw, $m ) ) {
        $title = trim( $m[1] );
        $content_body = trim( preg_replace( '/^TITLE:\s*.+$/m', '', $raw, 1 ) );
    }
    if ( empty( $title ) ) {
        $title = isset( $topic['title'] ) ? $topic['title'] : 'FAST TV Insights: ' . $topic['tag'];
    }

    // Check title doesn't already exist
    $existing = get_posts( array(
        'post_type'   => 'post',
        'post_status' => array( 'publish', 'draft', 'pending', 'private' ),
        'title'       => $title,
        'numberposts' => 1,
    ) );
    if ( ! empty( $existing ) ) {
        error_log( '[TackendoCore] Article with this title already exists: ' . $title );
        return false;
    }

    // Convert markdown to HTML
    $content = preg_replace( '/^### (.+)$/m', '<h3>$1</h3>', $content_body );
    $content = preg_replace( '/^## (.+)$/m',  '<h2>$1</h2>', $content );
    $content = preg_replace( '/^# (.+)$/m',   '<h1>$1</h1>', $content );
    $content = preg_replace( '/\*\*(.+?)\*\*/s', '<strong>$1</strong>', $content );
    $content = preg_replace( '/\*([^*\n]+?)\*/s', '<em>$1</em>', $content );
    $content = wpautop( $content );

    $post_status = get_option( 'tcore_article_status', 'publish' );
    if ( empty( $post_status ) ) $post_status = get_option( 'tcore_post_status', 'publish' );
    $cat_id = (int) get_option( 'tcore_article_cat', 0 );

    $data = array(
        'post_title'     => wp_strip_all_tags( $title ),
        'post_content'   => $content,
        'post_status'    => $post_status,
        'post_type'      => 'post',
        'post_author'    => 1,
        'comment_status' => 'closed',
        'ping_status'    => 'closed',
        'tags_input'     => array_map( 'trim', explode( ',', $topic['kw'] ) ),
        'meta_input'     => array(
            '_tcore_generated'  => 1,
            '_tcore_topic_tag'  => $topic['tag'],
            '_tcore_topic_slug' => ! empty( $topic['slug'] ) ? $topic['slug'] : sanitize_title( $title ),
        ),
    );
    if ( $cat_id > 0 ) {
        $data['post_category'] = array( $cat_id );
    }

    $post_id = wp_insert_post( $data );
    if ( is_wp_error( $post_id ) || ! $post_id ) {
        error_log( '[TackendoCore] Post creation failed: ' . ( is_wp_error( $post_id ) ? $post_id->get_error_message() : 'empty ID' ) );
        return false;
    }

    error_log( '[TackendoCore] Article created: #' . $post_id . ' - ' . $title );
    update_option( 'tcore_last_article', current_time( 'Y-m-d H:i' ) );

    // Fetch Pexels photo
    $kw_map = array(
        'Music'             => 'music streaming television concert stage',
        'CTV Industry'      => 'connected television streaming screen',
        'Advertising'       => 'digital advertising marketing screen',
        'Platform Guide'    => 'streaming platform smart tv remote',
        'Channel Spotlight' => 'television broadcast studio media',
        'Streaming Guide'   => 'streaming tv couch watching relaxing',
    );
    tcore_fetch_pexels_image(
        isset( $kw_map[ $topic['tag'] ] ) ? $kw_map[ $topic['tag'] ] : $topic['kw'],
        $post_id,
        $title
    );

    return $post_id;
}

// ── Cron: initial batch ──────────────────────────────────────────
add_action( 'tcore_make_article', 'tcore_cron_make_article' );
function tcore_cron_make_article( $index ) {
    $topics = tcore_initial_topics();
    $done   = (int) get_option( 'tcore_articles_done', 0 );
    if ( $done > $index ) return;
    if ( ! isset( $topics[ $index ] ) ) return;
    $result = tcore_write_post( $topics[ $index ] );
    if ( $result ) {
        update_option( 'tcore_articles_done', $index + 1 );
    }
}

// ── Cron: daily articles ─────────────────────────────────────────
add_action( 'tcore_daily_article',    'tcore_cron_daily' );
add_action( 'tcore_midnight_article', 'tcore_cron_daily' );
function tcore_cron_daily() {
    tcore_write_post( tcore_next_topic() );
}

// Schedule cron events
add_action( 'init', 'tcore_ensure_schedules', 5 );
function tcore_ensure_schedules() {
    if ( ! wp_next_scheduled( 'tcore_daily_article' ) ) {
        $next = strtotime( 'today 12:00 UTC' );
        if ( $next <= time() ) $next = strtotime( 'tomorrow 12:00 UTC' );
        wp_schedule_event( $next, 'daily', 'tcore_daily_article' );
    }
    if ( ! wp_next_scheduled( 'tcore_midnight_article' ) ) {
        $next = strtotime( 'today 00:00 UTC' );
        if ( $next <= time() ) $next = strtotime( 'tomorrow 00:00 UTC' );
        wp_schedule_event( $next, 'daily', 'tcore_midnight_article' );
    }
}

// ── PEXELS IMAGE FETCHING ────────────────────────────────────────
function tcore_fetch_pexels_image( $keywords, $post_id, $title = '' ) {
    $key = get_option( 'tcore_pexels_key', '' );
    if ( empty( $key ) ) return false;

    if ( ! empty( $title ) ) {
        $stop = array( 'the','and','for','that','with','are','how','why','what','your','from','will','into','this','have','its','their','more','than','when','which','best','free','complete','guide' );
        $words = preg_split( '/\s+/', strtolower( strip_tags( $title ) ) );
        $words = array_filter( $words, function($w) use ($stop) {
            return strlen($w) > 3 && ! in_array($w, $stop);
        });
        $query = implode( ' ', array_slice( array_values($words), 0, 4 ) );
    } else {
        $query = strtolower( trim( $keywords ) );
    }

    $page = rand( 1, 8 );
    $response = wp_remote_get(
        "https://api.pexels.com/v1/search?query=" . urlencode($query) . "&per_page=1&page={$page}&orientation=landscape&size=medium",
        array(
            'timeout' => 15,
            'headers' => array( 'Authorization' => $key ),
        )
    );

    if ( is_wp_error( $response ) ) {
        error_log( '[TackendoCore] Pexels error: ' . $response->get_error_message() );
        return false;
    }

    $body  = json_decode( wp_remote_retrieve_body( $response ), true );
    $photo = isset($body['photos'][0]['src']['large2x']) ? $body['photos'][0]['src']['large2x'] : (isset($body['photos'][0]['src']['large']) ? $body['photos'][0]['src']['large'] : '');

    if ( empty( $photo ) ) return false;

    require_once ABSPATH . 'wp-admin/includes/media.php';
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';

    $img_id = media_sideload_image( $photo, $post_id, get_the_title( $post_id ), 'id' );
    if ( is_wp_error( $img_id ) ) {
        error_log( '[TackendoCore] Pexels sideload error: ' . $img_id->get_error_message() );
        return false;
    }

    set_post_thumbnail( $post_id, $img_id );
    error_log( "[TackendoCore] Pexels image set for post $post_id" );
    return $img_id;
}

// ── CRON: Retroactively add images ───────────────────────────────
add_action( 'tcore_retroactive_images', 'tcore_cron_add_images' );
function tcore_cron_add_images() {
    $posts = get_posts( array(
        'post_type'   => 'post',
        'post_status' => 'publish',
        'numberposts' => 50,
        'meta_query'  => array(
            array( 'key' => '_tcore_generated', 'value' => 1 ),
        ),
    ) );
    foreach ( $posts as $post ) {
        if ( has_post_thumbnail( $post->ID ) ) continue;
        $kw = get_post_meta( $post->ID, '_tcore_topic_tag', true );
        $kw_map = array(
            'Music'             => 'music streaming television concert',
            'CTV Industry'      => 'streaming television connected tv screen',
            'Advertising'       => 'digital advertising marketing television',
            'Platform Guide'    => 'streaming platform smart tv devices',
            'Channel Spotlight' => 'television channel broadcast studio',
            'Streaming Guide'   => 'streaming tv remote control couch',
        );
        $search = isset( $kw_map[ $kw ] ) ? $kw_map[ $kw ] : wp_strip_all_tags( $post->post_title );
        tcore_fetch_pexels_image( $search, $post->ID, get_the_title($post->ID) );
        sleep( 1 );
    }
}

// ── ONE-TIME FIXER ───────────────────────────────────────────────
add_action( 'init', 'tcore_fix_existing_articles', 20 );
function tcore_fix_existing_articles() {
    if ( get_option( 'tcore_articles_fixed_v3', false ) ) return;
    $posts = get_posts( array(
        'post_type'      => 'post',
        'post_status'    => 'publish',
        'numberposts'    => 100,
        'meta_key'       => '_tcore_generated',
        'meta_value'     => 1,
    ) );
    foreach ( $posts as $post ) {
        $content = $post->post_content;
        $new_content = preg_replace( '/\*\*(.+?)\*\*/s', '<strong>$1</strong>', $content );
        $new_content = preg_replace( '/\*([^*\n]+?)\*/s', '<em>$1</em>', $new_content );
        wp_update_post( array(
            'ID'             => $post->ID,
            'post_content'   => $new_content,
            'comment_status' => 'closed',
            'ping_status'    => 'closed',
        ) );
        // Add slug meta if missing (for existing articles)
        if ( ! get_post_meta( $post->ID, '_tcore_topic_slug', true ) ) {
            update_post_meta( $post->ID, '_tcore_topic_slug', sanitize_title( $post->post_title ) );
        }
    }
    update_option( 'tcore_articles_fixed_v3', true );
}
