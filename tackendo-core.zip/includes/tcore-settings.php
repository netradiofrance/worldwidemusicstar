<?php
if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'admin_menu', 'tcore_admin_menu' );
function tcore_admin_menu() {
    add_menu_page( 'Tackendo Core', 'Tackendo Core', 'manage_options', 'tcore', 'tcore_settings_page', 'dashicons-video-alt3', 25 );
    add_submenu_page( 'tcore', 'General Settings', 'General', 'manage_options', 'tcore', 'tcore_settings_page' );
    add_submenu_page( 'tcore', 'Channel Settings', 'Channels', 'manage_options', 'tcore-channels', 'tcore_channels_page' );
}

// ── GENERAL SETTINGS ──────────────────────────────────────────────
add_action( 'admin_init', 'tcore_register_settings' );
function tcore_register_settings() {
    foreach ( array('tcore_claude_key','tcore_pexels_key','tcore_vast_url','tcore_article_lang','tcore_post_status','tcore_article_cat') as $opt ) {
        register_setting( 'tcore_options', $opt, array('sanitize_callback' => 'sanitize_text_field') );
    }
    register_setting( 'tcore_options', 'tcore_vast_url', array('sanitize_callback' => 'sanitize_text_field') );
}

function tcore_settings_page() {
    // Handle actions
    if ( isset($_GET['tcore_do']) && check_admin_referer('tcore_action') ) {
        $do = $_GET['tcore_do'];
        if ( $do === 'gen1'       ) {
            require_once TCORE_PATH . 'includes/tcore-articles.php';
            echo '<div class="notice notice-info"><p>⏳ Generating article via Claude AI... please wait (15-30 seconds).</p></div>';
            if ( ob_get_level() ) ob_flush();
            flush();
            $result = tcore_write_post( tcore_daily_topic() );
            if ( $result ) {
                $post_title = get_the_title( $result );
                echo '<div class="notice notice-success is-dismissible"><p>✅ Article <strong>#' . $result . '</strong> generated: <a href="' . get_edit_post_link($result) . '">' . esc_html($post_title) . '</a></p></div>';
            } else {
                echo '<div class="notice notice-error is-dismissible"><p>❌ Article generation failed. Check <code>wp-content/debug.log</code> for details.</p></div>';
            }
        }
        if ( $do === 'gen20'      ) {
            require_once TCORE_PATH . 'includes/tcore-articles.php';
            $topics = tcore_initial_topics();
            $done = (int) get_option('tcore_articles_done', 0);
            if ($done < count($topics)) {
                $result = tcore_write_post($topics[$done]);
                if ($result) {
                    update_option('tcore_articles_done', $done + 1);
                    echo '<div class="notice notice-success is-dismissible"><p>Article ' . ($done+1) . '/20 generated! Click again for the next one.</p></div>';
                } else {
                    echo '<div class="notice notice-error is-dismissible"><p>Generation failed. Check debug.log.</p></div>';
                }
            } else {
                echo '<div class="notice notice-info is-dismissible"><p>All 20 initial articles already generated.</p></div>';
            }
        }
        if ( $do === 'addimgs'    ) {
            require_once TCORE_PATH . 'includes/tcore-articles.php';
            tcore_cron_add_images();
            echo '<div class="notice notice-success is-dismissible"><p>Photos added to articles!</p></div>';
        }
        if ( $do === 'recachelogos' ) { delete_option('tcore_logos_cached_v2'); delete_option('tcore_logo_urls'); echo '<div class="notice notice-info is-dismissible"><p>Logo cache cleared — logos will re-download on next page load.</p></div>'; }
    }

    if ( isset($_POST['tcore_options_nonce']) && wp_verify_nonce($_POST['tcore_options_nonce'],'tcore_options') ) {
        foreach ( array('tcore_claude_key','tcore_pexels_key','tcore_vast_url','tcore_article_lang','tcore_post_status') as $k ) {
            if ( isset($_POST[$k]) ) update_option( $k, sanitize_text_field($_POST[$k]) );
        }
        if ( isset($_POST['tcore_article_cat']) ) update_option('tcore_article_cat', absint($_POST['tcore_article_cat']));
        echo '<div class="notice notice-success is-dismissible"><p>Settings saved.</p></div>';
    }

    $last  = get_option('tcore_last_article','—');
    $init  = get_option('tcore_initial_done', 0);
    $total = wp_count_posts('post');
    ?>
    <div class="wrap">
    <h1 style="display:flex;align-items:center;gap:10px">⚡ Tackendo Core <span style="font-size:13px;color:#999;font-weight:400">v<?php echo TCORE_VERSION; ?></span></h1>

    <form method="POST" style="max-width:700px">
    <?php wp_nonce_field('tcore_options','tcore_options_nonce'); ?>
    <h2>🤖 Claude AI</h2>
    <table class="form-table">
      <tr><th>Claude API Key</th><td><input type="password" name="tcore_claude_key" value="<?php echo esc_attr(get_option('tcore_claude_key','')); ?>" class="regular-text"><p class="description">Get yours at <a href="https://console.anthropic.com" target="_blank">console.anthropic.com</a>. Never share this key.</p></td></tr>
      <tr><th>Pexels API Key <small>(free photos)</small></th><td><input type="password" name="tcore_pexels_key" value="<?php echo esc_attr(get_option('tcore_pexels_key','')); ?>" class="regular-text"><p class="description">Free key at <a href="https://www.pexels.com/api/" target="_blank">pexels.com/api</a>. Auto-illustrates each article.</p></td></tr>
      <tr><th>Article Language</th><td><select name="tcore_article_lang"><option value="en" <?php selected(get_option('tcore_article_lang','en'),'en'); ?>>🇬🇧 English</option><option value="fr" <?php selected(get_option('tcore_article_lang','en'),'fr'); ?>>🇫🇷 French</option></select></td></tr>
      <tr><th>Post Status</th><td><select name="tcore_post_status"><option value="publish" <?php selected(get_option('tcore_post_status','publish'),'publish'); ?>>Published immediately</option><option value="draft" <?php selected(get_option('tcore_post_status','publish'),'draft'); ?>>Draft</option></select></td></tr>
      <tr><th>WordPress Category</th><td>
        <?php wp_dropdown_categories(array('name'=>'tcore_article_cat','selected'=>get_option('tcore_article_cat',0),'show_option_none'=>'— Select —','option_none_value'=>0,'hide_empty'=>0)); ?>
        <p class="description">Create a "TACKENDO Magazine" category first if needed.</p>
      </td></tr>
    </table>

    <h2>📺 Player &amp; Advertising</h2>
    <table class="form-table">
      <tr><th>Default VAST Tag URL</th><td>
        <input type="text" name="tcore_vast_url" value="<?php echo esc_attr(get_option('tcore_vast_url','')); ?>" class="large-text" placeholder="https://pubads.g.doubleclick.net/gampad/ads?...">
        <p class="description">Default VAST tag used when no channel-specific VAST is set. From VoiseTech / Google Ad Manager.<br>Use <code>[timestamp]</code> macro for cache busting.</p>
      </td></tr>
    </table>

    <?php submit_button('Save Settings'); ?>
    </form>

    <hr>
    <h2>📊 Generation Status</h2>
    <table class="widefat" style="max-width:500px">
      <tr><td>Initial articles generated</td><td><strong><?php echo min($init,20); ?> / 20</strong> <?php if($init>=20) echo '✅'; ?></td></tr>
      <tr><td>Last article</td><td><?php echo esc_html($last); ?></td></tr>
      <tr><td>Next daily article</td><td><?php $next=wp_next_scheduled('tcore_daily_article'); echo $next ? date('d/m/Y H:i', $next) . ' UTC' : '—'; ?></td></tr>
    </table>

    <h2>⚡ Manual Actions</h2>
    <p>
      <a href="<?php echo wp_nonce_url(add_query_arg('tcore_do','gen1',admin_url('admin.php?page=tcore')),'tcore_action'); ?>" class="button button-primary">🖊 Generate 1 article now</a>
      &nbsp;
      <a href="<?php echo wp_nonce_url(add_query_arg('tcore_do','gen20',admin_url('admin.php?page=tcore')),'tcore_action'); ?>" class="button button-primary" onclick="return confirm('Launch 20 initial articles? This will schedule 1 article every 2 minutes.')">🚀 Launch 20 initial articles</a>
      &nbsp;
      <a href="<?php echo wp_nonce_url(add_query_arg('tcore_do','addimgs',admin_url('admin.php?page=tcore')),'tcore_action'); ?>" class="button">🖼️ Add photos to existing articles</a>
      &nbsp;
      <a href="<?php echo wp_nonce_url(add_query_arg('tcore_do','recachelogos',admin_url('admin.php?page=tcore')),'tcore_action'); ?>" class="button">🔄 Re-download partner logos</a>
      &nbsp;
      <a href="<?php echo wp_nonce_url(add_query_arg('tcore_do','fixvast',admin_url('admin.php?page=tcore')),'tcore_action'); ?>" class="button button-primary" onclick="return confirm('Reset VAST URL to clean default in database?')">🔧 Fix VAST URL (reset DB)</a>
      &nbsp;
      <a href="<?php echo wp_nonce_url(add_query_arg('tcore_do','clearepgcache',admin_url('admin.php?page=tcore')),'tcore_action'); ?>" class="button">🗑️ Clear EPG cache</a>
    </p>
    </div>
    <?php
}

// ── CHANNEL SETTINGS PAGE ─────────────────────────────────────────
function tcore_channels_page() {
    require_once TCORE_PATH . 'includes/tcore-channels.php';
    $channels = tcore_channels();

    if ( isset($_POST['tcore_ch_nonce']) && wp_verify_nonce($_POST['tcore_ch_nonce'],'tcore_ch_settings') ) {
        foreach ( $channels as $slug => $ch ) {
            foreach ( array('hls','vast','poster','epg') as $field ) {
                $key = 'tcore_ch_' . $field . '_' . sanitize_key($slug);
                if ( isset($_POST[$key]) ) {
                    update_option( $key, esc_url_raw(trim($_POST[$key])) );
                }
            }
        }
        echo '<div class="notice notice-success is-dismissible"><p>Channel settings saved.</p></div>';
    }

    ?>
    <div class="wrap">
    <h1>📺 Channel Settings</h1>
    <p style="color:#666;margin-bottom:16px">Leave any field blank to use the default value shown in the placeholder.</p>
    <form method="POST">
    <?php wp_nonce_field('tcore_ch_settings','tcore_ch_nonce'); ?>
    <style>
      .tcore-ch-table{width:100%;border-collapse:collapse;font-size:12px}
      .tcore-ch-table th{background:#f0f0f1;padding:8px 10px;text-align:left;border-bottom:2px solid #ccc;white-space:nowrap}
      .tcore-ch-table td{padding:6px 8px;border-bottom:1px solid #eee;vertical-align:middle}
      .tcore-ch-table tr:hover td{background:#fafafa}
      .tcore-ch-table input[type=url]{width:100%;padding:4px 6px;font-size:11px;border:1px solid #ccc;border-radius:3px;box-sizing:border-box}
      .tcore-ch-table input[type=url]:focus{border-color:#2271b1;outline:none}
      .tcore-src-playout{color:#2271b1;font-weight:700;font-size:10px;letter-spacing:.05em}
      .tcore-src-viloud{color:#888;font-size:10px}
    </style>
    <table class="tcore-ch-table">
      <thead>
        <tr>
          <th style="width:48px">Logo</th>
          <th style="width:130px">Channel</th>
          <th style="width:60px">Source</th>
          <th>HLS Stream URL</th>
          <th>EPG URL</th>
          <th>Poster/Thumbnail</th>
          <th>VAST Tag URL</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ( $channels as $slug => $ch ) :
        $saved = array();
        foreach ( array('hls','vast','poster','epg') as $f ) {
            $saved[$f] = get_option( 'tcore_ch_' . $f . '_' . sanitize_key($slug), '' );
        }
        $default_epg = ! empty($ch['epg_url']) ? $ch['epg_url'] : '';
        $source = $default_epg
          ? '<span class="tcore-src-playout">🟢 PLAYOUT</span>'
          : '<span class="tcore-src-viloud">🔵 Viloud</span>';
      ?>
      <tr>
        <td>
          <img src="<?php echo esc_url($ch['logo']); ?>"
               style="width:44px;height:44px;object-fit:cover;border-radius:5px;display:block;border:1px solid #ddd">
        </td>
        <td>
          <strong><?php echo esc_html($ch['name']); ?></strong><br>
          <small style="color:#999"><?php echo esc_html($slug); ?></small>
        </td>
        <td><?php echo $source; ?></td>
        <td>
          <input type="text" name="tcore_ch_hls_<?php echo sanitize_key($slug); ?>"
                 value="<?php echo esc_attr($saved['hls']); ?>"
                 placeholder="<?php echo esc_attr($ch['hls'] ?? ''); ?>">
        </td>
        <td>
          <input type="text" name="tcore_ch_epg_<?php echo sanitize_key($slug); ?>"
                 value="<?php echo esc_attr($saved['epg']); ?>"
                 placeholder="<?php echo esc_attr($default_epg ?: 'No EPG'); ?>"
                 <?php echo $default_epg ? '' : 'style="color:#aaa"'; ?>>
        </td>
        <td>
          <input type="text" name="tcore_ch_poster_<?php echo sanitize_key($slug); ?>"
                 value="<?php echo esc_attr($saved['poster']); ?>"
                 placeholder="<?php echo esc_attr($ch['logo'] ?? ''); ?>">
        </td>
        <td>
          <input type="text" name="tcore_ch_vast_<?php echo sanitize_key($slug); ?>" type="text"
                 value="<?php echo esc_attr($saved['vast']); ?>"
                 placeholder="Default VAST (General Settings)">
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <p style="margin-top:16px"><?php submit_button('Save Channel Settings','primary','',false); ?></p>
    </form>
    </div>
    <?php
}


// ── CRON HANDLERS ─────────────────────────────────────────────────
add_action( 'tcore_manual_article', function() {
    require_once TCORE_PATH . 'includes/tcore-articles.php';
    tcore_write_post( tcore_daily_topic() );
});

// ── LOGO CACHER ────────────────────────────────────────────────────
add_action( 'admin_init', 'tcore_cache_logos' );
function tcore_cache_logos() {
    if ( get_option( 'tcore_logos_cached_v2', false ) ) return;

    $logos = array(
        'roku.png'        => 'https://groupenetradio.fr/wp-content/uploads/2025/01/Roku-Logo.png',
        'firetv.png'      => 'https://groupenetradio.fr/wp-content/uploads/2025/01/Amazon-Fire-TV-tUiO2b.png',
        'bouygues.png'    => 'https://groupenetradio.fr/wp-content/uploads/2025/01/Bouygues_Telecom.png',
        'netgem.jpg'      => 'https://groupenetradio.fr/wp-content/uploads/2025/01/netgem_logo.jpg',
        'cloudtv.jpg'     => 'https://groupenetradio.fr/wp-content/uploads/2025/01/cloudtvos_logo.jpg',
        'neotv.webp'      => 'https://groupenetradio.fr/wp-content/uploads/2025/01/temp_image_20250307_074757_3bcd16cc-fc58-4900-849c-2e7b981bcd4d.webp',
        'zeop.jpg'        => 'https://groupenetradio.fr/wp-content/uploads/2025/01/zeop_logo.jpg',
        'vialis.svg'      => 'https://www.vialis.net/themes/custom/vialis/images/logotype-vialis.svg',
        'viznet.png'      => 'https://viznet.tv/wp-content/uploads/2023/09/logo-viznet-blanc.png',
        'vodfactory.png'  => 'https://cdn.prod.website-files.com/5d1b4c09d7f0159a77c39cb1/5d1b4c51d7f0154fa4c3a021_logoVodFactory-RVB.png',
        'viloud.png'      => 'https://dm0801zzlveea.cloudfront.net/wp-content/uploads/2019/02/logo_viloud_web_mini.png',
        'broadpeak.svg'   => 'https://broadpeak.tv/wp-content/uploads/Broadpeak_Logo.svg',
        'hosttec.png'     => 'https://hosttec.online/img/cropped-hosttecnovologosite.png',
        'slingtv.png'     => 'https://upload.wikimedia.org/wikipedia/commons/e/e4/Sling_TV_logo.svg',
    );

    $upload_dir = wp_upload_dir();
    $logo_dir   = $upload_dir['basedir'] . '/tcore-logos/';
    $logo_url   = $upload_dir['baseurl'] . '/tcore-logos/';
    if ( ! file_exists( $logo_dir ) ) wp_mkdir_p( $logo_dir );

    $cached = array();
    foreach ( $logos as $filename => $remote_url ) {
        $local_path = $logo_dir . $filename;
        if ( ! file_exists( $local_path ) ) {
            $response = wp_remote_get( $remote_url, array( 'timeout' => 10 ) );
            if ( ! is_wp_error( $response ) && wp_remote_retrieve_response_code( $response ) === 200 ) {
                file_put_contents( $local_path, wp_remote_retrieve_body( $response ) );
            }
        }
        if ( file_exists( $local_path ) && filesize( $local_path ) > 500 ) {
            $cached[ $filename ] = $logo_url . $filename;
        }
    }
    update_option( 'tcore_logo_urls', $cached );
    update_option( 'tcore_logos_cached_v2', true );
}

function tcore_logo_url( $filename ) {
    $cached = get_option( 'tcore_logo_urls', array() );
    return isset( $cached[ $filename ] ) ? $cached[ $filename ] : '';
}
