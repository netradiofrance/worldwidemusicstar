<?php
if ( ! defined( 'ABSPATH' ) ) exit;

// ── Register all custom page templates ───────────────────────────
add_filter( 'theme_page_templates', 'tcore_register_template' );
function tcore_register_template( $templates ) {
    $templates['tcore-homepage'] = 'Tackendo Homepage';
    $templates['tcore-blog']     = 'Tackendo Blog';
    $templates['tcore-channel']  = 'Tackendo Channel';
    $templates['tcore-about']    = 'Tackendo About';
    $templates['tcore-advertise'] = 'Tackendo Advertise';
    $templates['tcore-privacy']    = 'Tackendo Privacy';
    $templates['tcore-contact']   = 'Tackendo Contact';
    return $templates;
}

// ── Load the correct template file ───────────────────────────────
add_filter( 'template_include', 'tcore_load_template' );
function tcore_load_template( $template ) {
    if ( is_page() ) {
        $slug = get_page_template_slug();
        $map  = array(
            'tcore-homepage' => 'homepage.php',
            'tcore-blog'     => 'blog.php',
            'tcore-channel'  => 'channel.php',
            'tcore-about'    => 'about.php',
            'tcore-advertise' => 'advertise.php',
            'tcore-privacy'   => 'privacy.php',
            'tcore-contact'   => 'contact.php',
        );
        if ( isset( $map[ $slug ] ) ) {
            $file = TCORE_PATH . 'templates/' . $map[ $slug ];
            if ( file_exists( $file ) ) return $file;
        }
    }
    return $template;
}

// ── Disable Astra on all Tackendo templates ───────────────────────
add_action( 'wp', 'tcore_disable_astra', 1 );
function tcore_disable_astra() {
    $custom = array( 'tcore-homepage', 'tcore-blog', 'tcore-channel', 'tcore-about', 'tcore-advertise', 'tcore-privacy', 'tcore-contact' );
    if ( ! in_array( get_page_template_slug(), $custom, true ) ) return;

    add_filter( 'astra_header_markup_before',       '__return_empty_string', 99 );
    add_filter( 'astra_header_markup_after',        '__return_empty_string', 99 );
    add_filter( 'astra_footer_markup_before',       '__return_empty_string', 99 );
    add_filter( 'astra_footer_markup_after',        '__return_empty_string', 99 );
    add_filter( 'astra_dynamic_css',                '__return_empty_string', 999 );

    remove_action( 'astra_header', 'astra_hfb_markup' );
    remove_action( 'astra_masthead', 'astra_masthead_primary_header' );
    remove_action( 'astra_footer', 'astra_footer_content' );

    add_action( 'wp_body_open', function() {
        remove_all_actions( 'astra_header' );
        remove_all_actions( 'astra_masthead' );
        remove_all_actions( 'astra_footer' );
    }, 1 );

    add_action( 'wp_print_styles', function() {
        wp_dequeue_style( 'astra-theme-css' );
        wp_dequeue_style( 'astra-fonts' );
        wp_dequeue_style( 'astra-variable-fonts' );
        wp_dequeue_style( 'astra-google-fonts' );
    }, 99 );
}

// ── Auto-set Astra page meta (disable header/footer) ─────────────
add_action( 'init', 'tcore_fix_astra_meta' );
function tcore_fix_astra_meta() {
    if ( get_option( 'tcore_astra_meta_ok', false ) ) return;
    global $wpdb;
    $slugs = array( 'tcore-homepage', 'tcore-blog', 'tcore-channel' );
    $ids   = $wpdb->get_col(
        "SELECT post_id FROM {$wpdb->postmeta}
         WHERE meta_key = '_wp_page_template'
         AND meta_value IN ('tcore-homepage','tcore-blog','tcore-channel')"
    );
    foreach ( $ids as $pid ) {
        foreach ( array( 'ast-main-header-display', 'ast-hfb-above-header-display', 'ast-hfb-below-header-display', 'footer-sml-layout', 'site-post-title' ) as $key ) {
            update_post_meta( (int) $pid, $key, 'disabled' );
        }
    }
    update_option( 'tcore_astra_meta_ok', true );
}

// ── Create homepage on first activation ──────────────────────────
function tcore_create_home_page() {
    global $wpdb;
    $exists = $wpdb->get_var(
        "SELECT post_id FROM {$wpdb->postmeta}
         WHERE meta_key = '_wp_page_template'
         AND meta_value = 'tcore-homepage'
         LIMIT 1"
    );
    if ( $exists ) return;

    $page_id = wp_insert_post( array(
        'post_title'     => 'TACKENDO — Free FAST TV Channels',
        'post_name'      => 'tackendo-home',
        'post_status'    => 'publish',
        'post_type'      => 'page',
        'post_content'   => '',
        'comment_status' => 'closed',
    ) );

    if ( $page_id && ! is_wp_error( $page_id ) ) {
        update_post_meta( $page_id, '_wp_page_template', 'tcore-homepage' );
        foreach ( array( 'ast-main-header-display', 'ast-hfb-above-header-display', 'ast-hfb-below-header-display', 'footer-sml-layout', 'site-post-title' ) as $key ) {
            update_post_meta( $page_id, $key, 'disabled' );
        }
        update_option( 'show_on_front', 'page' );
        update_option( 'page_on_front', $page_id );
    }
}

// ── Clear WordPress template cache when plugin updates ────────────
add_action( 'upgrader_process_complete', 'tcore_clear_template_cache', 10, 2 );
function tcore_clear_template_cache( $upgrader, $options ) {
    if ( isset( $options['plugins'] ) && in_array( 'tackendo-core/tackendo-core.php', $options['plugins'], true ) ) {
        wp_cache_delete( 'page_templates', 'options' );
    }
}

// Force clear template cache now (on each page load, once)
add_action( 'init', function() {
    if ( get_option( 'tcore_template_cache_cleared', '' ) !== TCORE_VERSION ) {
        wp_cache_delete( 'page_templates', 'options' );
        // Also clear the theme-specific cache key
        $theme = get_option( 'stylesheet' );
        wp_cache_delete( 'page_templates-' . $theme, 'themes' );
        delete_transient( 'page_templates-' . $theme );
        update_option( 'tcore_template_cache_cleared', TCORE_VERSION );
    }
}, 5 );

// ── Load custom template for single blog posts ────────────────────
add_filter( 'single_template', 'tcore_single_template' );
function tcore_single_template( $template ) {
    if ( is_single() && get_post_type() === 'post' ) {
        $custom = TCORE_PATH . 'templates/single.php';
        if ( file_exists( $custom ) ) return $custom;
    }
    return $template;
}

// ── Disable Astra on single posts too ────────────────────────────
add_action( 'wp', 'tcore_disable_astra_single' );
function tcore_disable_astra_single() {
    if ( ! is_single() || get_post_type() !== 'post' ) return;

    add_filter( 'astra_header_markup_before',  '__return_empty_string', 99 );
    add_filter( 'astra_header_markup_after',   '__return_empty_string', 99 );
    add_filter( 'astra_footer_markup_before',  '__return_empty_string', 99 );
    add_filter( 'astra_footer_markup_after',   '__return_empty_string', 99 );
    add_filter( 'astra_dynamic_css',           '__return_empty_string', 999 );

    add_action( 'wp_body_open', function() {
        remove_all_actions( 'astra_header' );
        remove_all_actions( 'astra_masthead' );
        remove_all_actions( 'astra_footer' );
    }, 1 );

    add_action( 'wp_print_styles', function() {
        wp_dequeue_style( 'astra-theme-css' );
        wp_dequeue_style( 'astra-fonts' );
    }, 99 );
}
