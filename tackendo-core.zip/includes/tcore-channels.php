<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * TACKENDO channel data.
 * Channels on tackendo.tv playout have epg_url + hls set.
 * Channels not yet migrated have epg_url=null, hls=''.
 * Monetized channels (SCTE-35 / Broadpeak SSAI) use their cdn.broadpeak.io
 * master URL as 'hls' so the player hits Broadpeak, not the raw playout.
 */
function tcore_channels() {
    return array(
        // -- ON TACKENDO.TV PLAYOUT ------------------------------------------
        'fast-music-rising' => array(
            'name'    => 'Fast Music Rising',
            'epg_url' => 'https://tackendo.tv/api/epg/channel-01?days=3',
            'hls'     => 'https://tackendo.tv/live/channel-01/master.m3u8',
            'cat'     => 'Music',
            'logo'    => 'https://tackendo.com/wp-content/uploads/2025/06/FAST-MUSIC-RISING-1080-x-1080-300x300.jpg',
            'desc'    => 'Unsigned & independent artists from around the world.',
        ),
        'made-in-france' => array(
            'name'    => 'Made in France',
            'epg_url' => 'https://tackendo.tv/api/epg/channel-15?days=3',
            'hls'     => 'https://362a33c2f23b3df742bb9fbf179ce4fae10de92a.cdn.broadpeak.io/live/channel-15/master.m3u8?bpkio_serviceid=f23b3df742bb9fbf7322b2b4d8d2504d&distribution_platform_code=tackendo&insertion_platform_code=broadpeak&network_name=netradio&channel_code=madeinfrance&context=linear&response_type=break&output=vast&site_name=tackendo&site_domain=tackendo.com&inapp_browser=browser&os_name=macos&device_type_name=desktop&device_brand_name=Apple&player_name=web&ifa_type=ppid&w=1280&h=720&cb=4345645702&stream_id=5719286762&session_id=4386345152&ppid=tackendo-test-user-005&gdpr=0&lmt=0&coppa=0',
            'cat'     => 'Lifestyle',
            'logo'    => 'https://tackendo.com/wp-content/uploads/2026/04/Made-in-France-TV-1024x576.png',
            'desc'    => "Immersive tour of France's heritage.",
        ),
        'expat-tv' => array(
            'name'    => 'Expat TV',
            'epg_url' => 'https://tackendo.tv/api/epg/channel-03?days=3',
            'hls'     => 'https://tackendo.tv/live/channel-03/master.m3u8',
            'cat'     => 'Lifestyle',
            'logo'    => 'https://tackendo.com/wp-content/uploads/2026/04/EXPAT-TV-1920-x-1080-px-1-1024x576.png',
            'desc'    => 'Resources for expats and life abroad.',
        ),
        'lo-fi' => array(
            'name'    => 'Lo-Fi Music',
            'epg_url' => 'https://tackendo.tv/api/epg/channel-04?days=3',
            'hls'     => 'https://tackendo.tv/live/channel-04/master.m3u8',
            'cat'     => 'Music',
            'logo'    => 'https://tackendo.com/wp-content/uploads/2025/06/lofi-thumbnail-square-300x300.jpg',
            'desc'    => 'Cinematic lo-fi soundscapes.',
        ),
        'summer-vibes' => array(
            'name'    => 'Summer Vibes',
            'epg_url' => 'https://tackendo.tv/api/epg/channel-05?days=3',
            'hls'     => 'https://362a33c2f23b3df742bb9fbfc25d3ee09ff0b1bc.cdn.broadpeak.io/live/channel-05/master.m3u8?bpkio_serviceid=f23b3df742bb9fbf924064537fe40b0d&distribution_platform_code=tackendo&insertion_platform_code=broadpeak&network_name=netradio&channel_code=summerchillvibes&context=linear&response_type=break&output=vast&site_name=tackendo&site_domain=tackendo.com&inapp_browser=browser&os_name=macos&device_type_name=desktop&device_brand_name=Apple&player_name=web&ifa_type=ppid&w=1280&h=720&cb=4345645682&stream_id=5719286742&session_id=4386345132&ppid=tackendo-test-user-003&gdpr=0&lmt=0&coppa=0',
            'cat'     => 'Music',
            'logo'    => 'https://tackendo.com/wp-content/uploads/2026/05/Summer-Chill-Vibes-logo-2.jpg',
            'desc'    => 'Sun-kissed beats and chill vibes all day long.',
        ),
        'fireplace' => array(
            'name'    => 'Fireplace',
            'epg_url' => 'https://tackendo.tv/api/epg/channel-06?days=3',
            'hls'     => 'https://tackendo.tv/live/channel-06/master.m3u8',
            'cat'     => 'Lifestyle',
            'logo'    => 'https://tackendo.com/wp-content/uploads/2026/04/Fireplace_Channel.jpg',
            'desc'    => 'A warm, relaxing fireplace - perfect ambience 24/7.',
        ),
        'winter-ambience' => array(
            'name'    => 'Winter Ambience',
            'epg_url' => 'https://tackendo.tv/api/epg/channel-07?days=3',
            'hls'     => 'https://tackendo.tv/live/channel-07/master.m3u8',
            'cat'     => 'Music',
            'logo'    => 'https://tackendo.com/wp-content/uploads/2026/02/Cover-1000x1000-1-300x300.png',
            'desc'    => '24/7 winter jazz and ambient music.',
        ),
        'synthwave' => array(
            'name'    => 'Synthwave',
            'epg_url' => 'https://tackendo.tv/api/epg/channel-08?days=3',
            'hls'     => 'https://tackendo.tv/live/channel-08/master.m3u8',
            'cat'     => 'Music',
            'logo'    => 'https://tackendo.com/wp-content/uploads/2025/06/thumbnail-square-300x300.jpg',
            'desc'    => 'Neon-drenched retrofuturistic soundscapes.',
        ),
        'epic' => array(
            'name'    => 'Epic Music',
            'epg_url' => 'https://tackendo.tv/api/epg/channel-09?days=3',
            'hls'     => 'https://tackendo.tv/live/channel-09/master.m3u8',
            'cat'     => 'Music',
            'logo'    => 'https://tackendo.com/wp-content/uploads/2025/06/Fast-Music-Epic-PNG-300x300.png',
            'desc'    => 'Epic scores, cinematic soundtracks, heroic music.',
        ),
        // -- AWE: COSMOS (Broadpeak SSAI) ------------------------------------
        'awe-cosmos' => array(
            'name'    => 'AWE: COSMOS',
            'epg_url' => 'https://tackendo.tv/api/channels/channel-16/epg?days_backward=3&days_forward=7',
            'hls'     => 'https://362a33c2f23b3df742bb9fbffde33758b3646842.cdn.broadpeak.io/live/channel-16/master.m3u8?bpkio_serviceid=f23b3df742bb9fbf1e7e6b0d2ee26760&distribution_platform_code=tackendo&insertion_platform_code=broadpeak&network_name=netradio&channel_code=cosmos&context=linear&response_type=break&output=vast&site_name=tackendo&site_domain=tackendo.com&inapp_browser=browser&os_name=macos&device_type_name=desktop&device_brand_name=Apple&player_name=web&ifa_type=ppid&w=1280&h=720&cb=4345645692&stream_id=5719286752&session_id=4386345142&ppid=tackendo-test-user-004&gdpr=0&lmt=0&coppa=0',
            'cat'     => 'Lifestyle',
            'logo'    => 'https://tackendo.com/wp-content/uploads/2026/06/Thumb_AWE_COSMOS_1920x1080.png',
            'desc'    => 'Immersive journeys through the cosmos.',
        ),
        // -- VODFACTORY (Netradio Vision) ------------------------------------
        'netradio-vision' => array(
            'name'    => 'Netradio Vision',
            'epg_url' => 'https://tackendo.tv/api/epg/channel-11?days=3',
            'hls'     => 'https://362a33c2f23b3df742bb9fbf570763d7c089a379.cdn.broadpeak.io/live/channel-11/master.m3u8?bpkio_serviceid=f23b3df742bb9fbf23d016024ae3b895&distribution_platform_code=tackendo&insertion_platform_code=broadpeak&network_name=netradio&channel_code=netradiovision&context=linear&response_type=break&output=vast&site_name=tackendo&site_domain=tackendo.com&inapp_browser=browser&os_name=macos&device_type_name=desktop&device_brand_name=Apple&player_name=web&ifa_type=ppid&w=1280&h=720&cb=4345645671&stream_id=5719286732&session_id=4386345122&ppid=tackendo-test-user-002&gdpr=0&lmt=0&coppa=0',
            'cat'     => 'Pop Culture',
            'logo'    => 'https://tackendo.com/wp-content/uploads/2025/06/Netradio-Vision-1080x1080-1-300x300.jpg',
            'desc'    => 'Pop culture, emerging music & the creator economy.',
        ),
        // -- MIGRATING TO PLAYOUT - set HLS+EPG in admin when ready ----------
        'urban-street'   => array( 'name'=>'Urban Street',    'epg_url'=>'https://tackendo.tv/api/epg/channel-12?days=3', 'hls'=>'https://tackendo.tv/live/channel-12/master.m3u8', 'cat'=>'Music',     'logo'=>'https://tackendo.com/wp-content/uploads/2025/06/street-1920-x-1080-px-1080-x-1080-px-300x300.png', 'desc'=>'Rap, Hip-Hop, and urban sounds.' ),
        'edm'            => array( 'name'=>'EDM',             'epg_url'=>'https://tackendo.tv/api/epg/channel-10?days=3', 'hls'=>'https://tackendo.tv/live/channel-10/master.m3u8', 'cat'=>'Music',     'logo'=>'https://tackendo.com/wp-content/uploads/2025/06/Fast-Music-EDM-1080-x-1080-300x300.jpg',           'desc'=>'Non-stop electronic dance music.' ),
        'tzik'           => array( 'name'=>'Tzik',            'epg_url'=>null, 'hls'=>'', 'cat'=>'Music',     'logo'=>'https://tackendo.com/wp-content/uploads/2025/06/TZIK-Square-PNG-300x300.png',                    'desc'=>'Celebrating emerging unsigned artists.' ),
        'zweester'       => array( 'name'=>'Zweester',        'epg_url'=>'https://tackendo.tv/api/epg/channel-13?days=3', 'hls'=>'https://tackendo.tv/live/channel-13/master.m3u8', 'cat'=>'Music',     'logo'=>'https://tackendo.com/wp-content/uploads/2026/01/ChatGPT-Image-7-janv.-2026-13_04_48.png','desc'=>'Non-stop independent music.' ),
        'halloween'      => array( 'name'=>'Halloween Music', 'epg_url'=>null, 'hls'=>'', 'cat'=>'Music',     'logo'=>'https://tackendo.com/wp-content/uploads/2025/08/fast-music-halloween-smth-300x300.png',          'desc'=>'Gothic and fantasy music universe.' ),
        'christmas'      => array( 'name'=>'Christmas Music', 'epg_url'=>null, 'hls'=>'', 'cat'=>'Music',     'logo'=>'https://tackendo.com/wp-content/uploads/2025/12/Christmas-1080x1080-1-300x300.jpg',              'desc'=>'Holiday classics and indie Christmas songs.' ),
        'good-lifestyle' => array( 'name'=>'Good Lifestyle',  'epg_url'=>null, 'hls'=>'', 'cat'=>'Lifestyle', 'logo'=>'https://tackendo.com/wp-content/uploads/2026/04/GOOD-1920-x-1080-px-1024x576.png',              'desc'=>'Inspiring social awareness productions.' ),
        'finance-vous'   => array( 'name'=>'Finance & You',   'epg_url'=>null, 'hls'=>'', 'cat'=>'Lifestyle', 'logo'=>'https://tackendo.com/wp-content/uploads/2026/04/Finance-Vous.-1920-x-1080-px-1-1024x576.png',   'desc'=>'Financial independence and wealth building.' ),
        'just-do-biz'    => array( 'name'=>'Just Do Biz',     'epg_url'=>null, 'hls'=>'', 'cat'=>'Lifestyle', 'logo'=>'https://tackendo.com/wp-content/uploads/2026/04/JustDoBiz-square-white-1-1024x576.png',          'desc'=>'Entrepreneurship and business culture.' ),
        'chic-tv'        => array( 'name'=>'Chic TV',         'epg_url'=>null, 'hls'=>'', 'cat'=>'Lifestyle', 'logo'=>'https://tackendo.com/wp-content/uploads/2026/04/Chic-TV-1024x576.png',                          'desc'=>'Luxury, fashion, gastronomy, design.' ),
        'zanimo'         => array( 'name'=>'Zanimo',          'epg_url'=>null, 'hls'=>'', 'cat'=>'Lifestyle', 'logo'=>'https://tackendo.com/wp-content/uploads/2026/04/zanimo-1920-x-1080-px-300x169.png',              'desc'=>'Wildlife, nature, and animal stories.' ),
        'green-life-tv'  => array( 'name'=>'Green Life TV',   'epg_url'=>null, 'hls'=>'', 'cat'=>'Lifestyle', 'logo'=>'https://tackendo.com/wp-content/uploads/2026/04/LIFE-TV-1920-x-1080-px-1024x576.png',           'desc'=>'Sustainable living and eco culture.' ),
    );
}
function tcore_get_channel( $slug ) {
    $channels = tcore_channels();
    return isset( $channels[$slug] ) ? $channels[$slug] : null;
}
