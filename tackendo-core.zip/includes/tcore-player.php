<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * TACKENDO PLAYER — HLS + VAST CSAI + Google PAL SDK
 * Shortcode: [tackendo_player channel="fast-music-rising"]
 */

add_action( 'wp_enqueue_scripts', 'tcore_enqueue_player' );
function tcore_enqueue_player() {
    // HLS.js for stream playback
    wp_enqueue_script( 'hls-js', 'https://cdn.jsdelivr.net/npm/hls.js@1.5.7/dist/hls.min.js', array(), null, true );
    // Google IMA SDK — required for Google Ad Manager VAST (same as Radiant)
    wp_enqueue_script( 'google-ima', 'https://imasdk.googleapis.com/js/sdkloader/ima3.js', array(), null, true );
    wp_enqueue_script( 'tackendo-player', TCORE_URL . 'assets/tackendo-player.js',
        array( 'hls-js', 'google-ima' ), TCORE_VERSION, true );
}

add_shortcode( 'tackendo_player', 'tcore_player_shortcode' );
function tcore_player_shortcode( $atts ) {
    $atts = shortcode_atts(array('channel'=>'','hls'=>'','vast'=>'','poster'=>'','name'=>''), $atts);
    return tcore_player_html( $atts['channel'], $atts );
}

function tcore_player_html( $channel_slug, $overrides = array() ) {
    require_once TCORE_PATH . 'includes/tcore-channels.php';
    $channels = tcore_channels();
    $ch       = isset($channels[$channel_slug]) ? $channels[$channel_slug] : null;

    // ── HLS: priority order: override → admin setting → channel default ──
    $hls = ! empty($overrides['hls']) ? $overrides['hls'] : '';
    if ( ! $hls && $channel_slug ) {
        $hls = get_option( 'tcore_ch_hls_' . sanitize_key($channel_slug), '' );
    }
    if ( ! $hls && $ch ) {
        $hls = ! empty($ch['hls']) ? $ch['hls'] : 'https://app.viloud.tv/hls/channel/' . $ch['viloud'] . '.m3u8';
    }

    // ── VAST URL ─────────────────────────────────────────────────────
    // Hardcoded correct default — always valid, never corrupted
    $default_vast = 'https://pubads.g.doubleclick.net/gampad/ads?iu=/23124331701,12626570/NetRadio/NetRadio-tackendo.com_Open-Video-Multi_Web-07Jan26&description_url=https%3A%2F%2Ftackendo.com%2F&tfcd=0&npa=0&sz=1x1%7C300x250%7C320x480%7C400x300%7C480x360%7C640x480&gdfp_req=1&unviewed_position_start=1&output=vast&env=vp&impl=s&plcmt=1&vpmute=0&vpa=auto&correlator=[timestamp]&hl=en';

    // Validation: URL must have [timestamp] AND proper description_url encoding
    // Corrupted URLs have 'description_url=httpsdomain.com' (missing ://) or 'sz=1x1300x250' (missing |)
    $is_valid_vast = function($url) {
        if (empty($url)) return false;
        if (strpos($url, '[timestamp]') === false) return false;
        // description_url value must be percent-encoded (contain %3A for colon)
        if (strpos($url, 'description_url=https%3A') === false &&
            strpos($url, 'description_url=http%3A') === false) return false;
        return true;
    };

    $vast = $default_vast; // Start with known-good default

    // Try channel-specific override first
    if ( $channel_slug ) {
        $ch_vast = get_option( 'tcore_ch_vast_' . sanitize_key($channel_slug), '' );
        $ch_vast = str_replace( array('%5Btimestamp%5D','%5btimestamp%5d'), '[timestamp]', $ch_vast );
        if ( $is_valid_vast($ch_vast) ) $vast = $ch_vast;
    }

    // Try general admin VAST setting
    $gen_vast = get_option( 'tcore_vast_url', '' );
    $gen_vast = str_replace( array('%5Btimestamp%5D','%5btimestamp%5d'), '[timestamp]', $gen_vast );
    $gen_vast = html_entity_decode( $gen_vast, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
    if ( $is_valid_vast($gen_vast) ) $vast = $gen_vast;

    // Final check — if still corrupted somehow, use hardcoded default
    if ( ! $is_valid_vast($vast) ) $vast = $default_vast;

    // ── Poster & name ──
    $poster = ! empty($overrides['poster']) ? $overrides['poster'] : '';
    if ( ! $poster && $channel_slug ) {
        $poster = get_option( 'tcore_ch_poster_' . sanitize_key($channel_slug), '' );
    }
    if ( ! $poster ) $poster = $ch ? $ch['logo'] : '';
    $name   = ! empty($overrides['name'])   ? $overrides['name']   : ($ch ? $ch['name'] : 'TACKENDO Live');

    static $n = 0; $n++;
    $cid = 'tp-' . $n;

    // Decode HTML entities that WordPress may have introduced when saving URLs
    $hls    = html_entity_decode( $hls,    ENT_QUOTES | ENT_HTML5, 'UTF-8' );
    $vast   = html_entity_decode( $vast,   ENT_QUOTES | ENT_HTML5, 'UTF-8' );
    $poster = html_entity_decode( $poster, ENT_QUOTES | ENT_HTML5, 'UTF-8' );

    ob_start(); ?>
    <div id="<?php echo esc_attr($cid); ?>" style="width:100%;max-width:100%;line-height:0"></div>
    <script>
    (function(){
      // Use JSON-encoded values to avoid any HTML entity issues
      var cfg = {
        hls:         <?php echo wp_json_encode($hls); ?>,
        vast:        <?php echo wp_json_encode($vast); ?>,
        poster:      <?php echo wp_json_encode($poster); ?>,
        channelName: <?php echo wp_json_encode($name); ?>,
        proxyBase:   <?php echo wp_json_encode(rest_url('tcore/v1')); ?>,
        midrollEvery: 360
      };
      function init(){
        if (typeof TackendoPlayer === 'undefined') { setTimeout(init, 200); return; }
        new TackendoPlayer('<?php echo esc_js($cid); ?>', cfg);
      }
      document.readyState === 'loading'
        ? document.addEventListener('DOMContentLoaded', init)
        : init();
    })();
    </script>
    <?php
    return ob_get_clean();
}
