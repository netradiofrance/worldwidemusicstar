<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * EPG Proxy — dual source support:
 *   1. tackendo.tv JSON API (new playout)  → /wp-json/tcore/v1/epg/{slug}
 *   2. Viloud XMLTV (legacy)               → /wp-json/tcore/v1/epg/{viloud_id}
 *
 * The JS always calls /epg/{id} — this proxy auto-detects the source.
 * Response format is always the same JSON regardless of source.
 */

add_action( 'rest_api_init', 'tcore_register_rest' );
function tcore_register_rest() {
    register_rest_route( 'tcore/v1', '/epg/(?P<cid>[a-z0-9\-]+)', array(
        'methods'             => 'GET',
        'callback'            => 'tcore_epg_proxy',
        'permission_callback' => '__return_true',
    ) );
}

function tcore_epg_proxy( WP_REST_Request $req ) {
    $cid = $req->get_param( 'cid' );

    require_once TCORE_PATH . 'includes/tcore-channels.php';
    $channels = tcore_channels();

    $admin_epg = get_option( 'tcore_ch_epg_' . sanitize_key($cid), '' );

    $channel = null;
    if ( isset( $channels[ $cid ] ) ) {
        $channel = $channels[ $cid ];
    } else {
        foreach ( $channels as $slug => $ch ) {
            if ( ! empty($ch['epg_url']) ) {
                preg_match( '#/epg/([^?]+)#', $ch['epg_url'], $m );
                if ( isset($m[1]) && $m[1] === $cid ) { $channel = $ch; break; }
            }
            if ( isset($ch['viloud']) && $ch['viloud'] === $cid ) { $channel = $ch; break; }
        }
    }

    // Cache
    $cache_key = 'tcore_epg3_' . md5( $cid );
    $cached    = get_transient( $cache_key );
    if ( $cached !== false ) {
        return new WP_REST_Response( $cached, 200 );
    }

    // Route to correct source
    $epg_url = $admin_epg ?: ( $channel ? ( $channel['epg_url'] ?? null ) : null );

    if ( $epg_url ) {
        $result = tcore_epg_from_playout( $epg_url );
    } elseif ( $channel && ! empty( $channel['viloud'] ) ) {
        $result = tcore_epg_from_viloud( $channel['viloud'] );
    } elseif ( preg_match( '/^[a-f0-9]{32}$/', $cid ) ) {
        $result = tcore_epg_from_viloud( $cid );
    } else {
        // Channel exists but has no EPG source — return empty instead of 404
        if ( $channel ) {
            return new WP_REST_Response( array(
                'programs'   => array(),
                'source'     => 'none',
                'server_utc' => gmdate('c'),
            ), 200 );
        }
        return new WP_REST_Response( array( 'error' => 'Unknown channel: ' . $cid ), 404 );
    }

    if ( isset( $result['error'] ) ) {
        return new WP_REST_Response( $result, 502 );
    }

    set_transient( $cache_key, $result, 5 * MINUTE_IN_SECONDS );
    return new WP_REST_Response( $result, 200 );
}

// ─────────────────────────────────────────────────────────────────
//  SOURCE 1: tackendo.tv JSON API (new playout)
// ─────────────────────────────────────────────────────────────────
function tcore_epg_from_playout( $epg_url ) {
    // URL already includes ?days=3 — use as-is
    $url = $epg_url;

    $res = wp_remote_get( $url, array(
        'timeout'   => 30,
        'sslverify' => false,
    ) );

    if ( is_wp_error( $res ) ) {
        return array( 'error' => $res->get_error_message(), 'source' => 'playout' );
    }

    $code = (int) wp_remote_retrieve_response_code( $res );
    $body = json_decode( wp_remote_retrieve_body( $res ), true );

    if ( $code !== 200 ) {
        return array( 'error' => 'Playout API error', 'code' => $code, 'source' => 'playout' );
    }

    // If no programs, return empty array (not an error)
    if ( empty( $body['programs'] ) ) {
        return array(
            'programs'   => array(),
            'source'     => 'playout',
            'server_utc' => gmdate('c'),
        );
    }

    $programs = array();
    foreach ( $body['programs'] as $p ) {
        $programs[] = array(
            'title' => isset($p['title'])  ? $p['title']  : '',
            'desc'  => isset($p['desc'])   ? $p['desc']   : ( isset($p['artist']) ? $p['artist'] : '' ),
            'icon'  => isset($p['icon'])   ? $p['icon']   : '',
            'start' => isset($p['start'])  ? $p['start']  : '',
            'stop'  => isset($p['stop'])   ? $p['stop']   : '',
        );
    }

    usort( $programs, function($a, $b) {
        return strcmp( $a['start'], $b['start'] );
    });

    return array(
        'programs'   => $programs,
        'source'     => 'playout',
        'server_utc' => gmdate('c'),
    );
}

// ─────────────────────────────────────────────────────────────────
//  SOURCE 2: Viloud XMLTV (legacy)
// ─────────────────────────────────────────────────────────────────
function tcore_epg_from_viloud( $viloud_id ) {
    $url = 'https://deliver.viloud.tv/channel/' . $viloud_id . '/epg?format=xmltv&days_backward=1&days_forward=3';
    $res = wp_remote_get( $url, array( 'timeout' => 15 ) );

    if ( is_wp_error( $res ) ) {
        // Viloud down — return empty instead of error
        return array(
            'programs'   => array(),
            'source'     => 'viloud',
            'server_utc' => gmdate('c'),
        );
    }

    $code    = (int) wp_remote_retrieve_response_code( $res );
    $xml_str = wp_remote_retrieve_body( $res );

    if ( $code !== 200 || empty( $xml_str ) ) {
        return array(
            'programs'   => array(),
            'source'     => 'viloud',
            'server_utc' => gmdate('c'),
        );
    }

    libxml_use_internal_errors( true );
    $xml = simplexml_load_string( $xml_str );
    if ( ! $xml ) {
        return array(
            'programs'   => array(),
            'source'     => 'viloud',
            'server_utc' => gmdate('c'),
        );
    }

    $programs = array();
    foreach ( $xml->programme as $p ) {
        $start = tcore_parse_xmltv( (string) $p['start'] );
        $stop  = tcore_parse_xmltv( (string) $p['stop']  );
        if ( ! $start || ! $stop ) continue;

        $icon = '';
        if ( isset($p->icon) && isset($p->icon['src']) ) {
            $icon = (string) $p->icon['src'];
        }

        $programs[] = array(
            'title' => (string) $p->title,
            'desc'  => (string) $p->desc,
            'icon'  => $icon,
            'start' => gmdate( 'c', $start ),
            'stop'  => gmdate( 'c', $stop  ),
        );
    }

    usort( $programs, function($a, $b) { return strcmp($a['start'], $b['start']); });

    return array(
        'programs'   => $programs,
        'source'     => 'viloud',
        'server_utc' => gmdate('c'),
    );
}

function tcore_parse_xmltv( $s ) {
    $s = trim( $s );
    if ( preg_match( '/^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})\s*([+-]\d{2}):?(\d{2})$/', $s, $m ) ) {
        return strtotime( "{$m[1]}-{$m[2]}-{$m[3]}T{$m[4]}:{$m[5]}:{$m[6]}{$m[7]}:{$m[8]}" );
    }
    if ( preg_match( '/^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})$/', $s, $m ) ) {
        return strtotime( "{$m[1]}-{$m[2]}-{$m[3]}T{$m[4]}:{$m[5]}:{$m[6]}+00:00" );
    }
    return false;
}


// ── VAST Proxy ───────────────────────────────────────────────────
add_action( 'rest_api_init', 'tcore_register_vast_proxy' );
function tcore_register_vast_proxy() {
    register_rest_route( 'tcore/v1', '/vast', array(
        'methods'             => 'GET',
        'callback'            => 'tcore_vast_proxy',
        'permission_callback' => '__return_true',
        'args'                => array(
            'url' => array( 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ),
        ),
    ) );
}

function tcore_vast_proxy( WP_REST_Request $req ) {
    $url = $req->get_param( 'url' );

    $allowed = array( 'pubads.g.doubleclick.net', 'doubleclick.net', 'voisetech.io', 'viznet.tv', 'tackendo.com', 'tackendo.tv', 'adtelligent.com' );
    $host    = parse_url( $url, PHP_URL_HOST );
    $ok      = false;
    foreach ( $allowed as $a ) { if ( strpos( $host, $a ) !== false ) { $ok = true; break; } }
    if ( ! $ok ) return new WP_REST_Response( array('error'=>'Domain not allowed'), 403 );

    $res = wp_remote_get( $url, array( 'timeout' => 8, 'sslverify' => false ) );
    if ( is_wp_error( $res ) ) return new WP_REST_Response( array('error'=>$res->get_error_message()), 502 );

    $body = wp_remote_retrieve_body( $res );
    $code = (int) wp_remote_retrieve_response_code( $res );

    return new WP_REST_Response( $body, $code, array(
        'Content-Type'                => 'application/xml; charset=utf-8',
        'Access-Control-Allow-Origin' => '*',
    ) );
}
