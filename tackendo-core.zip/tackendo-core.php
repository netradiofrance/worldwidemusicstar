<?php
/**
 * Plugin Name:  Tackendo Core
 * Plugin URI:   https://tackendo.com
 * Description:  Homepage custom, EPG Viloud en temps réel, génération automatique d'articles via Claude AI.
 * Version:      1.1.0
 * Author:       Tackendo / Netradio Network
 * License:      GPL-2.0+
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// Évite les conflits si le plugin est inclus deux fois
if ( defined( 'TCORE_VERSION' ) ) return;

define( 'TCORE_VERSION', '6.4.0' );
define( 'TCORE_PATH',    plugin_dir_path( __FILE__ ) );
define( 'TCORE_URL',     plugin_dir_url( __FILE__ ) );

require_once TCORE_PATH . 'includes/tcore-channels.php';
require_once TCORE_PATH . 'includes/tcore-player.php';
require_once TCORE_PATH . 'includes/tcore-settings.php';
require_once TCORE_PATH . 'includes/tcore-template.php';
require_once TCORE_PATH . 'includes/tcore-epg.php';
require_once TCORE_PATH . 'includes/tcore-articles.php';

// ── ACTIVATION ───────────────────────────────────────────────────
register_activation_hook( __FILE__, 'tcore_activate' );
function tcore_activation_check() {
    if ( get_option( 'tcore_version' ) !== TCORE_VERSION ) {
        delete_option( 'tcore_logos_cached_v2' );
        delete_option( 'tcore_logo_urls' );
        update_option( 'tcore_version', TCORE_VERSION );
    }
}
add_action( 'init', 'tcore_activation_check', 1 );

function tcore_activate() {
    // Crée la page d'accueil custom si elle n'existe pas
    tcore_create_home_page();

    // Planifie les 20 articles initiaux (1 toutes les 2 min)
    $done = (int) get_option( 'tcore_articles_done', 0 );
    for ( $i = $done; $i < 20; $i++ ) {
        wp_schedule_single_event(
            time() + ( ( $i - $done + 1 ) * 120 ),
            'tcore_make_article',
            array( $i )
        );
    }

    // Cron quotidien à 8h UTC
    if ( ! wp_next_scheduled( 'tcore_daily_article' ) ) {
        wp_schedule_event( strtotime( 'tomorrow 08:00:00' ), 'daily', 'tcore_daily_article' );
    }

    flush_rewrite_rules();
}

// ── DESACTIVATION ────────────────────────────────────────────────
register_deactivation_hook( __FILE__, 'tcore_deactivate' );
function tcore_deactivate() {
    wp_clear_scheduled_hook( 'tcore_daily_article' );
    for ( $i = 0; $i < 20; $i++ ) {
        wp_clear_scheduled_hook( 'tcore_make_article', array( $i ) );
    }
    flush_rewrite_rules();
}

// ── ASSETS FRONT-END ─────────────────────────────────────────────
add_action( 'wp_enqueue_scripts', 'tcore_enqueue_assets' );
function tcore_enqueue_assets() {
    if ( ! is_page_template( 'tcore-homepage' ) ) return;
    // CSS only — JS is loaded directly in homepage.php template to avoid double-loading
    wp_enqueue_style( 'tcore-front', TCORE_URL . 'assets/tcore.css', array(), TCORE_VERSION );
}

// ── Strip external scripts from channel page content ─────────────
// Prevents old Radiant player scripts from executing on channel pages
add_filter( 'the_content', 'tcore_strip_player_scripts', 1 );
function tcore_strip_player_scripts( $content ) {
    if ( ! is_page() ) return $content;
    $template = get_page_template_slug();
    if ( $template !== 'tcore-channel' ) return $content;
    $content = preg_replace( '#<script[^>]*>.*?</script>#is', '', $content );
    return $content;
}
