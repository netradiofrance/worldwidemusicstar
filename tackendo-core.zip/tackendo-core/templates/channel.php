<?php
/* Template Name: Tackendo Channel */
if ( ! defined( 'ABSPATH' ) ) exit;

require_once TCORE_PATH . 'includes/tcore-channels.php';

$logo_url = 'https://tackendo.com/wp-content/uploads/2025/06/Tackendo-logo-white-on-transparent-262x76-1.png';
$site_url = esc_url( home_url('/') );

// Get current channel from page slug
$slug    = get_post_field('post_name', get_the_ID());
$channel = tcore_get_channel($slug);

/* Le gabarit lisait $channel sans verifier : une page dont l'identifiant
   ne correspond a aucune chaine produisait une avalanche d'avertissements
   et une mise en page vide. On complete les champs manquants. */
if ( ! $channel ) {
    $channel = array( 'name' => get_the_title(), 'cat' => '', 'desc' => '',
                      'logo' => '', 'hls' => '', 'epg_url' => '' );
} else {
    $channel = array_merge(
        array( 'name' => '', 'cat' => '', 'desc' => '', 'logo' => '',
               'hls' => '', 'epg_url' => '' ),
        $channel
    );
}

// Related articles
$related = get_posts(array(
    'post_type'      => 'post',
    'post_status'    => 'publish',
    'numberposts'    => 17,
    'meta_query'     => array(array('key' => '_tcore_generated', 'value' => 1)),
    'orderby'        => 'rand',
));

/* Deux blocs, comme sur la page d'accueil : une grille illustree qui
   donne envie, puis une liste compacte qui montre la profondeur du fonds.
   Un evaluateur AdSense doit voir qu'il y a une redaction derriere, pas
   quatre articles de vitrine. */
$rel_lead = ! empty($related) ? $related[0] : null;
$rel_grid = array_slice($related, 1, 8);
$rel_list = array_slice($related, 9, 8);

// Other channels for discovery
$all_channels = tcore_channels();
$other_channels = array_filter($all_channels, function($k) use ($slug) { return $k !== $slug; }, ARRAY_FILTER_USE_KEY);
// Toutes les autres chaines, pas seulement huit : la grille les absorbe.
$other_channels = array_slice($other_channels, 0, 13);
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php if ($channel) : ?>
<title><?php echo esc_html($channel['name']); ?> &mdash; Free FAST TV Channel on TACKENDO</title>
<meta name="description" content="<?php echo esc_attr($channel['desc']); ?> Available free on Roku, Fire TV, and web.">
<?php else : ?>
<title><?php the_title(); ?> &mdash; TACKENDO</title>
<?php endif; ?>
<meta name="robots" content="index, follow">
<link rel="canonical" href="<?php the_permalink(); ?>">
<?php if ($channel) : ?>
<meta property="og:title" content="<?php echo esc_attr($channel['name']); ?> — Free on TACKENDO">
<meta property="og:description" content="<?php echo esc_attr($channel['desc']); ?>">
<meta property="og:image" content="<?php echo esc_url($channel['logo']); ?>">
<meta property="og:type" content="website">
<?php endif; ?>
<meta name="theme-color" content="#E8001C">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Figtree:wght@400;500;600;700&display=swap" rel="stylesheet">
<?php wp_head(); ?>
<style>
:root{--bg:#07070f;--surface:#0d0d18;--card:#111120;--red:#E8001C;--white:#fff;--text:#d8d8e8;--grey:#7a7a90;--muted:#4a4a60;--border:#1c1c2e}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body.tackendo-channel{background:var(--bg);color:var(--text);font-family:'Figtree','Segoe UI',sans-serif;font-size:15px;line-height:1.6}
body.tackendo-channel h1,body.tackendo-channel h2,body.tackendo-channel h3{color:#fff!important;font-weight:400!important}
body.tackendo-channel a{text-decoration:none;color:inherit}
/* Hide Astra */
body.tackendo-channel .site-header,body.tackendo-channel #masthead,body.tackendo-channel #ast-fixed-header,body.tackendo-channel .site-footer,body.tackendo-channel #astra-footer-area{display:none!important}
/* Header */
#ch-header{position:sticky;top:0;z-index:200;background:rgba(7,7,15,.92);backdrop-filter:blur(18px);border-bottom:1px solid var(--border);height:64px;padding:0 48px;display:flex;align-items:center;justify-content:space-between}
#ch-header .logo img{height:34px;display:block}
#ch-header nav{display:flex;gap:28px}
#ch-header nav a{color:var(--grey);font-size:12px;font-weight:700;letter-spacing:.08em;text-transform:uppercase}
#ch-header nav a:hover{color:#fff}
.hdr-btns{display:flex;gap:8px}
.btn-sm{padding:7px 14px;border-radius:6px;font-size:11px;font-weight:700;border:1px solid var(--border);background:var(--surface);color:var(--text);transition:all .2s}
.btn-sm:hover{background:var(--red);border-color:var(--red);color:#fff}
/* Channel hero */
.ch-hero{position:relative;overflow:hidden;padding:0}
.ch-hero-bg{position:absolute;inset:0;background:linear-gradient(160deg,#090912 0%,#0c0818 100%);z-index:0}
.ch-hero-inner{position:relative;z-index:1;display:grid;grid-template-columns:1fr 1fr;min-height:340px}
.ch-hero-left{padding:52px 40px 52px 48px;display:flex;flex-direction:column;justify-content:center;align-items:flex-start}
.ch-cat-badge{display:inline-block;align-self:flex-start;background:rgba(232,0,28,.15);border:1px solid rgba(232,0,28,.4);color:var(--red);font-size:10px;font-weight:800;letter-spacing:.14em;text-transform:uppercase;padding:4px 12px;border-radius:3px;margin-bottom:16px}
.ch-title{font-family:'Bebas Neue',sans-serif;font-size:clamp(44px,5.5vw,72px);color:#fff!important;line-height:.92;margin-bottom:16px;letter-spacing:.02em}
.ch-desc{font-size:15px;color:var(--grey);max-width:480px;margin-bottom:28px;line-height:1.75}
.ch-actions{display:flex;gap:12px;flex-wrap:wrap}
.btn-watch{display:inline-flex;align-items:center;gap:8px;background:var(--red);color:#fff!important;font-weight:700;font-size:14px;padding:13px 28px;border-radius:8px;transition:all .2s;letter-spacing:.03em}
.btn-watch:hover{background:#c8001a;transform:translateY(-2px)}
.btn-outline{display:inline-flex;align-items:center;gap:8px;color:var(--text)!important;font-size:14px;font-weight:600;padding:12px 20px;border-radius:8px;border:1px solid var(--border);transition:all .2s}
.btn-outline:hover{border-color:var(--grey);color:#fff!important}
/* Channel logo */
.ch-hero-right{display:flex;align-items:center;justify-content:center;padding:40px}
/* 16:9, format des vignettes du feed. Le cadre etait carre : une image
   panoramique y etait rognee de moitie, ou etiree. */
.ch-logo-wrap{width:min(420px,100%);aspect-ratio:16/9;border-radius:16px;overflow:hidden;box-shadow:0 0 0 1px rgba(232,0,28,.3),0 0 60px rgba(232,0,28,.15),0 40px 80px rgba(0,0,0,.6);animation:chfloat 7s ease-in-out infinite;background:#12121c}
.ch-logo-wrap img{width:100%;height:100%;object-fit:cover;display:block}
@keyframes chfloat{0%,100%{transform:translateY(0) rotate(-1deg)}50%{transform:translateY(-10px) rotate(1deg)}}
/* EPG Now */
.epg-now-section{background:var(--surface);border-bottom:1px solid var(--border);padding:28px 48px}
.epg-now-inner{display:grid;grid-template-columns:auto 1fr auto;align-items:center;gap:24px;max-width:1000px}
.epg-now-badge{display:inline-flex;align-items:center;gap:6px;background:var(--red);color:#fff;font-size:10px;font-weight:800;letter-spacing:.14em;padding:4px 10px;border-radius:3px;text-transform:uppercase;white-space:nowrap}
.live-dot{display:inline-block;width:7px;height:7px;background:#fff;border-radius:50%;animation:blink 1.6s ease-in-out infinite}
@keyframes blink{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.4;transform:scale(.7)}}
.epg-now-content{display:flex;align-items:center;gap:16px}
.epg-now-thumb{width:80px;height:50px;border-radius:6px;object-fit:cover;background:var(--card);flex-shrink:0}
.epg-now-title{font-size:16px;font-weight:700;color:#fff;margin-bottom:2px}
.epg-now-time{font-size:12px;color:var(--grey)}
.epg-next{font-size:12px;color:var(--muted);text-align:right}
.epg-next strong{color:var(--grey);display:block}
/* Schedule strip */
.schedule-section{padding:36px 48px;border-bottom:1px solid var(--border)}
.schedule-section h2{font-family:'Bebas Neue',sans-serif;font-size:26px;color:#fff!important;letter-spacing:.04em;margin-bottom:20px}
.schedule-list{display:flex;flex-direction:column;gap:0}
.schedule-item{display:grid;grid-template-columns:90px auto 1fr;align-items:center;gap:16px;padding:12px 0;border-bottom:1px solid rgba(255,255,255,.04)}
.schedule-item:last-child{border-bottom:none}
.schedule-item.is-current{background:rgba(232,0,28,.06);border-radius:8px;padding:12px 12px;margin:0 -12px}
.sch-time{font-size:13px;font-weight:700;color:var(--grey);font-family:'Figtree',monospace}
.sch-live-badge{display:inline-flex;align-items:center;gap:4px;background:var(--red);color:#fff;font-size:9px;font-weight:800;padding:2px 7px;border-radius:2px;letter-spacing:.08em;text-transform:uppercase}
.sch-live-dot{width:5px;height:5px;background:#fff;border-radius:50%;animation:blink 1.6s infinite}
.sch-title{font-size:14px;font-weight:600;color:var(--text)}
.schedule-item.is-current .sch-title{color:#fff}
/* Player section */
.ch-bar{display:flex;align-items:center;justify-content:space-between;gap:28px;
  flex-wrap:wrap;padding:22px 48px;border-bottom:1px solid var(--border);
  background:linear-gradient(160deg,#090912,#0c0818)}
.ch-bar-left{display:flex;align-items:center;gap:14px;flex-wrap:wrap}
.ch-bar .ch-title{font-family:'Bebas Neue',sans-serif;font-size:clamp(30px,3.4vw,44px);
  color:#fff!important;line-height:1;margin:0;letter-spacing:.02em}
.ch-bar-now{display:flex;align-items:center;gap:14px;min-width:280px}
.ch-now-thumb{width:104px;height:59px;border-radius:8px;object-fit:cover;
  background:var(--card);flex-shrink:0}
.ch-now-badge{display:inline-flex;align-items:center;gap:6px;font-size:10px;
  letter-spacing:.16em;text-transform:uppercase;color:var(--red);font-weight:700}
.ch-now-title{font-size:15px;font-weight:600;color:#fff;margin:5px 0 0;line-height:1.35}
.ch-now-time{font-size:12px;color:var(--muted);margin:3px 0 0}
.ch-bar-next{border-left:1px solid var(--border);padding-left:20px;min-width:190px}
.ch-next-label{display:block;font-size:10px;letter-spacing:.16em;text-transform:uppercase;
  color:var(--muted);font-weight:700;margin-bottom:6px}
.ch-next-title{display:block;font-size:13.5px;color:var(--grey);line-height:1.4}
@media(max-width:900px){.ch-bar-next{border-left:0;padding-left:0;min-width:0}}
.ch-desc-under{padding:0 48px 30px;margin:0;color:var(--grey);font-size:15px;
  line-height:1.7;max-width:70ch}
@media(max-width:900px){
  .ch-bar{padding:18px 20px;gap:16px}
  .ch-bar-now{min-width:0;width:100%}
  .ch-desc-under{padding:0 20px 24px}
}

/* Le lecteur affichait une barre de progression rouge qui defilait en
   permanence : sur un flux en direct, elle ne mesure rien et donne
   l'impression d'un chargement sans fin. */
.player-section .rmp-progress-bar,
.player-section .vjs-progress-control,
.player-section .tk-progress,
.player-section progress{display:none!important}

.player-section{padding:26px 48px 36px;border-bottom:1px solid var(--border);background:var(--surface)}.player-wrapper{max-width:100%;aspect-ratio:16/9}
.player-section h2{font-family:'Bebas Neue',sans-serif;font-size:26px;color:#fff!important;letter-spacing:.04em;margin-bottom:20px}
.player-wrapper{border-radius:12px;overflow:hidden;background:#000}
.player-wrapper iframe,.player-wrapper video{display:block}
/* Related articles */
.related-section{padding:36px 48px;border-bottom:1px solid var(--border)}
.rel-label{font-size:11px;letter-spacing:.2em;text-transform:uppercase;color:var(--red);margin:0 0 6px}
.related-section h2{font-family:'Bebas Neue',sans-serif;font-size:26px;color:#fff!important;letter-spacing:.04em;margin-bottom:20px}
/* Meme grille auto-remplie que la page d'accueil : quatre colonnes fixes
   laissaient du vide sur large ecran et serraient tout sur petit. */
.related-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:22px}
.rel-card{background:var(--card);border:1px solid var(--border);border-radius:10px;overflow:hidden;transition:all .2s}
.rel-card:hover{transform:translateY(-3px);border-color:rgba(232,0,28,.35)}
.rel-card-img{aspect-ratio:16/9;overflow:hidden}
.rel-card-img img{width:100%;height:100%;object-fit:cover;display:block}
.rel-card-body{padding:14px 16px 17px}
.rel-tag{font-size:10px;font-weight:900;letter-spacing:.14em;text-transform:uppercase;color:var(--red);margin-bottom:4px}
.rel-title{font-size:15px;font-weight:700;color:#fff!important;line-height:1.35;margin-bottom:7px}
.rel-excerpt{font-size:13px;line-height:1.6;color:var(--grey)}
.rel-lead{display:grid;grid-template-columns:1.35fr 1fr;gap:30px;margin-bottom:34px;align-items:center;text-decoration:none}
.rel-lead-img{border-radius:14px;overflow:hidden;aspect-ratio:16/9;background:var(--card)}
.rel-lead-img img{width:100%;height:100%;object-fit:cover;display:block}
.rel-lead-title{font-size:30px;line-height:1.2;margin:10px 0 13px;font-weight:800;color:#fff!important;letter-spacing:-.015em}
.rel-lead-excerpt{font-size:15.5px;line-height:1.7;color:var(--grey);margin:0 0 15px}
.rel-more{font-size:13px;letter-spacing:.08em;text-transform:uppercase;color:#fff;border-bottom:1px solid var(--red);padding-bottom:2px}
@media(max-width:900px){.rel-lead{grid-template-columns:1fr;gap:16px}.rel-lead-title{font-size:23px}}
.rel-list{display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:2px 32px}
.rel-li{display:flex;gap:14px;padding:14px 0;border-bottom:1px solid var(--border);text-decoration:none}
.rel-li-img{width:100px;height:63px;border-radius:8px;overflow:hidden;flex-shrink:0;background:var(--card)}
.rel-li-img img{width:100%;height:100%;object-fit:cover;display:block}
.rel-li-title{font-size:14.5px;font-weight:600;color:#fff!important;line-height:1.4;margin:4px 0 0}
.rel-date{font-size:11px;color:var(--muted);letter-spacing:.08em;text-transform:uppercase}
/* Other channels */
.other-section{padding:36px 48px}
.other-section h2{font-family:'Bebas Neue',sans-serif;font-size:26px;color:#fff!important;letter-spacing:.04em;margin-bottom:20px}
/* Grille complete plutot qu'une rangee de pastilles : les vignettes du
   feed sont en 16:9 et meritent d'etre lues, pas reduites a un rond. */
.other-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:14px}
.other-card{display:block;border-radius:11px;overflow:hidden;background:var(--card);border:1px solid var(--border);text-decoration:none;transition:transform .2s,border-color .2s}
.other-card:hover{transform:translateY(-3px);border-color:var(--red)}
.other-logo{width:100%;aspect-ratio:16/9;object-fit:cover;display:block;background:#0d0d18}
.other-name{display:block;padding:9px 11px 11px;font-size:13px;font-weight:700;color:#fff;line-height:1.3;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.other-card:hover .other-name{color:#fff}
/* Footer */
#ch-footer{background:#050509;border-top:1px solid var(--border);padding:46px 48px 30px}
.ft-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:34px;margin-bottom:34px}
#ch-footer h6{font-size:11px;letter-spacing:.18em;text-transform:uppercase;color:var(--muted);margin:0 0 14px;font-weight:600}
#ch-footer ul{list-style:none;margin:0;padding:0}
#ch-footer li{margin-bottom:9px}
#ch-footer li a{font-size:14px;color:var(--grey);text-decoration:none}
#ch-footer li a:hover{color:var(--red)}
.ft-bottom{border-top:1px solid var(--border);padding-top:22px;display:flex;justify-content:space-between;gap:16px;flex-wrap:wrap;font-size:13px;color:var(--muted)}
.ft-bottom a{color:var(--grey);text-decoration:none}
.ft-bottom a:hover{color:#fff}
/* Skeleton */
.skel{background:linear-gradient(90deg,var(--card) 25%,#181828 50%,var(--card) 75%);background-size:200%;animation:sk 1.4s infinite;border-radius:4px;display:inline-block}
@keyframes sk{0%{background-position:200% 0}100%{background-position:-200% 0}}
/* Responsive */
@media(max-width:900px){#ch-header{padding:0 20px}#ch-header nav{display:none}.epg-now-section,.schedule-section,.player-section,.related-section,.other-section{padding-left:20px;padding-right:20px}.related-grid{grid-template-columns:repeat(2,1fr)}.other-grid{grid-template-columns:repeat(4,1fr)}}
@media(max-width:600px){.related-grid{grid-template-columns:1fr}.other-grid{grid-template-columns:repeat(3,1fr)}.epg-now-inner{grid-template-columns:auto 1fr}}
</style>
</head>
<body class="tackendo-channel">

<!-- HEADER -->
<header id="ch-header">
  <a href="<?php echo $site_url; ?>" class="logo">
    <img src="<?php echo esc_url($logo_url); ?>" alt="TACKENDO" loading="eager" style="height:36px;width:auto">
  </a>
  <nav>
    <a href="<?php echo $site_url; ?>">Home</a>
    <a href="<?php echo esc_url(home_url('/blog')); ?>">Magazine</a>
    <a href="<?php echo $site_url; ?>#channels">Channels</a>
    <a href="<?php echo esc_url(home_url('/about')); ?>">About</a>
  </nav>
  <div class="hdr-btns">
    <a href="https://channelstore.roku.com/details/8244e521d238b28c45271329a3ebe907/tackendo" class="btn-sm" target="_blank" rel="noopener">Roku</a>
    <a href="https://www.amazon.com/gp/product/B0DGNFS8N9" class="btn-sm" target="_blank" rel="noopener">Fire TV</a>
  </div>
</header>

<!-- BANDEAU DE CHAINE -->
<?php if ($channel) : ?>
<?php /* Bandeau compact.

     La version precedente presentait une vignette flottante a droite,
     entouree de vide, et repoussait le lecteur sous la ligne de flottaison.
     Le spectateur venait pour regarder : le lecteur remonte, et le bandeau
     se reduit a ce qui l'informe — le nom de la chaine, et ce qui passe
     en ce moment. */ ?>
<section class="ch-bar">
  <div class="ch-bar-left">
    <span class="ch-cat-badge"><?php echo esc_html($channel['cat']); ?></span>
    <h1 class="ch-title"><?php echo esc_html($channel['name']); ?></h1>
  </div>

  <div class="ch-bar-now">
    <img id="epg-thumb" class="ch-now-thumb" src="" alt="" style="display:none">
    <div class="ch-now-txt">
      <span class="ch-now-badge"><span class="live-dot"></span>On air now</span>
      <p class="ch-now-title" id="epg-title"><span class="skel" style="width:190px;height:15px">&nbsp;</span></p>
      <p class="ch-now-time" id="epg-time"><span class="skel" style="width:110px;height:11px;margin-top:4px">&nbsp;</span></p>
    </div>
  </div>

  <?php /* Une seule entree a venir, et non toute la grille : le spectateur
           veut savoir ce qui suit, pas parcourir un programme. */ ?>
  <div class="ch-bar-next" id="epg-next">
    <span class="ch-next-label">Up next</span>
    <span class="ch-next-title"><span class="skel" style="width:150px;height:13px">&nbsp;</span></span>
  </div>
</section>

<!-- TACKENDO PLAYER (replaces Radiant Media Player) -->
<section class="player-section" id="watch-live">
  <div class="player-wrapper" style="border-radius:12px;overflow:hidden;background:#000;line-height:0;width:100%">
    <?php echo tcore_player_html( $slug ); ?>
  </div>
  <?php if ( has_blocks( get_the_content() ) || trim(get_the_content()) ) : ?>
  <!-- Legacy Radiant embed (shown only if page still has it) -->
  <div style="display:none"><?php the_content(); ?></div>
  <?php endif; ?>
</section>

<!-- OTHER CHANNELS -->
<?php if (!empty($other_channels)) : ?>
<section class="other-section">
  <h2>Explore More Channels</h2>
  <div class="other-grid">
    <?php foreach ($other_channels as $ch_slug => $och) : ?>
    <a href="<?php echo esc_url(home_url('/' . $ch_slug . '/')); ?>" class="other-card">
      <img class="other-logo" src="<?php echo esc_url($och['logo']); ?>" alt="<?php echo esc_attr($och['name']); ?>" loading="lazy">
      <span class="other-name"><?php echo esc_html($och['name']); ?></span>
    </a>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>


<?php else : ?>
<!-- Fallback: just show page content -->
<section style="padding:60px 48px">
  <h1><?php the_title(); ?></h1>
  <div><?php the_content(); ?></div>
</section>
<?php endif; ?>

<!-- MAGAZINE -->
<?php if (!empty($rel_grid)) : ?>
<section class="related-section">
  <p class="rel-label">Published daily</p>
  <h2>TACKENDO Magazine</h2>

  <?php if ($rel_lead) :
    $lead_thumb = get_the_post_thumbnail_url($rel_lead->ID, 'large');
    $lead_tag   = get_post_meta($rel_lead->ID, '_tcore_topic_tag', true) ?: 'FAST TV';
  ?>
  <a class="rel-lead" href="<?php echo get_permalink($rel_lead->ID); ?>">
    <div class="rel-lead-img">
      <?php if ($lead_thumb) : ?>
        <img src="<?php echo esc_url($lead_thumb); ?>" alt="<?php echo esc_attr(get_the_title($rel_lead->ID)); ?>" loading="lazy">
      <?php else : ?>
        <div style="width:100%;height:100%;background:linear-gradient(135deg,#180824,#080c24);display:flex;align-items:center;justify-content:center"><span style="font-size:12px;letter-spacing:.14em;color:rgba(255,255,255,.28);text-transform:uppercase"><?php echo esc_html($lead_tag); ?></span></div>
      <?php endif; ?>
    </div>
    <div>
      <p class="rel-tag"><?php echo esc_html($lead_tag); ?>&nbsp;&middot;&nbsp;<?php echo esc_html( get_the_date( 'M j, Y', $rel_lead->ID ) ); ?></p>
      <h3 class="rel-lead-title"><?php echo esc_html(get_the_title($rel_lead->ID)); ?></h3>
      <p class="rel-lead-excerpt"><?php echo esc_html( wp_trim_words( strip_tags( $rel_lead->post_content ), 42 ) ); ?></p>
      <span class="rel-more">Read the article</span>
    </div>
  </a>
  <?php endif; ?>

  <div class="related-grid">
    <?php foreach ($rel_grid as $rpost) :
      $rthumb = get_the_post_thumbnail_url($rpost->ID, 'medium');
      $rtag   = get_post_meta($rpost->ID, '_tcore_topic_tag', true) ?: 'FAST TV';
    ?>
    <a href="<?php echo get_permalink($rpost->ID); ?>" class="rel-card">
      <?php if ($rthumb) : ?>
      <div class="rel-card-img"><img src="<?php echo esc_url($rthumb); ?>" alt="<?php echo esc_attr(get_the_title($rpost->ID)); ?>" loading="lazy"></div>
      <?php else : ?>
      <div class="rel-card-img" style="background:linear-gradient(135deg,#180824,#080c24);display:flex;align-items:center;justify-content:center"><span style="font-size:11px;color:rgba(255,255,255,.2)"><?php echo esc_html($rtag); ?></span></div>
      <?php endif; ?>
      <div class="rel-card-body">
        <p class="rel-tag"><?php echo esc_html($rtag); ?>&nbsp;&middot;&nbsp;<?php echo esc_html( get_the_date( 'M j', $rpost->ID ) ); ?></p>
        <h3 class="rel-title"><?php echo esc_html(get_the_title($rpost->ID)); ?></h3>
        <p class="rel-excerpt"><?php echo esc_html( wp_trim_words( strip_tags( $rpost->post_content ), 20 ) ); ?></p>
      </div>
    </a>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<!-- MAGAZINE — SUITE -->
<?php if (!empty($rel_list)) : ?>
<section class="related-section" style="padding-top:8px">
  <p class="rel-label">Keep reading</p>
  <h2>More from the magazine</h2>
  <div class="rel-list">
    <?php foreach ($rel_list as $rpost) :
      $lthumb = get_the_post_thumbnail_url($rpost->ID, 'medium');
      $ltag   = get_post_meta($rpost->ID, '_tcore_topic_tag', true) ?: 'FAST TV';
    ?>
    <a href="<?php echo get_permalink($rpost->ID); ?>" class="rel-li">
      <div class="rel-li-img">
        <?php if ($lthumb) : ?>
          <img src="<?php echo esc_url($lthumb); ?>" alt="<?php echo esc_attr(get_the_title($rpost->ID)); ?>" loading="lazy">
        <?php else : ?>
          <div style="width:100%;height:100%;background:linear-gradient(135deg,#180824,#080c24)"></div>
        <?php endif; ?>
      </div>
      <div>
        <p class="rel-tag"><?php echo esc_html($ltag); ?>&nbsp;&middot;&nbsp;<?php echo esc_html( get_the_date( 'M j', $rpost->ID ) ); ?></p>
        <h3 class="rel-li-title"><?php echo esc_html(get_the_title($rpost->ID)); ?></h3>
      </div>
    </a>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>


<?php /* Meme pied de page que la page d'accueil : le precedent tenait sur
         une ligne et n'offrait aucun chemin vers le reste du site. */ ?>
<footer id="ch-footer">
  <div class="ft-grid">
    <div>
      <img src="<?php echo esc_url($logo_url); ?>" alt="TACKENDO" style="height:30px;width:auto;margin-bottom:14px">
      <p style="font-size:14px;color:var(--grey);line-height:1.7;margin:0;max-width:280px">
        A magazine about music, streaming and the culture around them,
        published alongside fourteen free live channels.
      </p>
    </div>
    <div>
      <h6>Channels</h6>
      <ul>
        <?php $fn = 0; foreach ( $all_channels as $fslug => $fc ) {
            if ( $fn++ >= 7 ) break; ?>
          <li><a href="<?php echo esc_url(home_url('/' . $fslug . '/')); ?>"><?php echo esc_html($fc['name']); ?></a></li>
        <?php } ?>
        <li><a href="<?php echo $site_url; ?>#channels">All channels &rarr;</a></li>
      </ul>
    </div>
    <div>
      <h6>Platform</h6>
      <ul>
        <li><a href="<?php echo esc_url(home_url('/about')); ?>">About TACKENDO</a></li>
        <li><a href="<?php echo esc_url(home_url('/advertise')); ?>">Advertise with us</a></li>
        <li><a href="<?php echo esc_url(home_url('/blog')); ?>">Magazine</a></li>
        <li><a href="<?php echo esc_url(home_url('/contact')); ?>">Contact</a></li>
        <li><a href="<?php echo esc_url(home_url('/privacy-policy')); ?>">Privacy policy</a></li>
      </ul>
    </div>
    <div>
      <h6>Watch now</h6>
      <ul>
        <li><a href="https://channelstore.roku.com/details/8244e521d238b28c45271329a3ebe907/tackendo" target="_blank" rel="noopener">Roku &mdash; watch free</a></li>
        <li><a href="https://www.amazon.com/gp/product/B0DGNFS8N9" target="_blank" rel="noopener">Fire TV &mdash; watch free</a></li>
        <li><a href="https://play.google.com/store/apps/details?id=com.netradio.tackendo" target="_blank" rel="noopener">Android TV &mdash; watch free</a></li>
        <li><a href="https://play.google.com/store/apps/details?id=com.netradio.tackendo.mobile" target="_blank" rel="noopener">Android Mobile &mdash; watch free</a></li>
        <li><a href="<?php echo $site_url; ?>#channels">Web &mdash; watch online</a></li>
      </ul>
    </div>
  </div>
  <div class="ft-bottom">
    <span>&copy; 2024&ndash;<?php echo date('Y'); ?> TACKENDO &mdash; Netradio Network. All rights reserved.</span>
    <span>
      <a href="<?php echo esc_url(home_url('/privacy-policy')); ?>">Privacy</a>
      &nbsp;&nbsp;
      <a href="<?php echo esc_url(home_url('/contact')); ?>">Contact</a>
    </span>
  </div>
</footer>

<?php if ($channel) : ?>
<?php
$ch_epg_admin  = get_option( 'tcore_ch_epg_' . sanitize_key($slug), '' );
$ch_epg_direct = $ch_epg_admin ?: ( $channel['epg_url'] ?? '' );
$ch_proxy_url  = rest_url( 'tcore/v1/epg/' . $slug );

/* Identifiant du playout — channel-11, channel-19...
   Il n'est stocke nulle part en clair : on le retrouve dans l'adresse du
   flux ou dans celle de l'EPG, toutes deux construites autour de lui. */
$ch_playout_id = '';
foreach ( array( $channel['hls'] ?? '', $ch_epg_direct ) as $u ) {
    if ( $u && preg_match( '/(channel-\d+)/', $u, $m ) ) {
        $ch_playout_id = $m[1];
        break;
    }
}
?>
<script>
(function() {
  var EPG_DIRECT = <?php echo wp_json_encode($ch_epg_direct); ?>;
  var EPG_PROXY  = <?php echo wp_json_encode($ch_proxy_url); ?>;
  var NOWPLAYING_URL = <?php echo wp_json_encode(
        $ch_playout_id ? rest_url( 'tcore/v1/nowplaying/' . $ch_playout_id ) : ''
      ); ?>;

  /* Titre d'un programme.

     L'API ne renvoie pas toujours le meme champ : les chaines a grille
     construite portent un "title", celles qui enchainent des titres
     musicaux portent "artist" et "desc". Le script ne lisait que "title",
     et ces chaines-la affichaient donc un bloc vide qui clignotait. */
  function progTitle(p) {
    if (!p) return '';
    if (p.title) return p.title;
    if (p.artist && p.desc) {
      var d = String(p.desc);
      // "Zelie - Je ne serai jamais" : on evite de repeter l'artiste.
      if (d.indexOf(p.artist + ' - ') === 0) return d;
      return p.artist + ' \u2014 ' + d;
    }
    return p.desc || p.artist || '';
  }

  var cdTimer = null, nextTimer = null;

  /* Decompte local. Il part de la valeur du serveur et descend seul :
     interroger le serveur chaque seconde pour afficher un chiffre qui
     baisse serait absurde. */
  function startCountdown(el, seconds) {
    if (cdTimer) { clearInterval(cdTimer); cdTimer = null; }
    var rem = Math.max(0, seconds);
    function paint() {
      var m = Math.floor(rem / 60), s = rem % 60;
      el.textContent = m > 0 ? (m + ' min ' + s + ' s remaining')
                             : (s + ' s remaining');
    }
    paint();
    cdTimer = setInterval(function () {
      rem--;
      if (rem <= 0) { clearInterval(cdTimer); cdTimer = null; el.textContent = 'Up next…'; return; }
      paint();
    }, 1000);
  }

  function scheduleNext(seconds) {
    if (nextTimer) clearTimeout(nextTimer);
    nextTimer = setTimeout(loadChannelEPG, seconds * 1000);
  }

  async function loadChannelEPG() {
    if (!EPG_DIRECT) { console.warn('[EPG] No EPG URL for this channel'); return; }
    /* Ce qui passe reellement, lu depuis le playout via notre propre
       domaine : ni origine croisee, ni grille theorique.

       L'EPG reste interroge en second : il porte les emissions construites,
       que le playout ne distingue pas d'un titre musical. */
    try {
      if (!NOWPLAYING_URL) throw new Error('identifiant de chaine inconnu');
      var rn = await fetch(NOWPLAYING_URL, {cache:'no-store'});
      if (rn.ok) {
        var np = await rn.json();
        if (np && np.now) {
          var $t = document.getElementById('epg-title'),
              $m = document.getElementById('epg-time'),
              $i = document.getElementById('epg-thumb'),
              $n = document.getElementById('epg-next');

          if ($t) $t.textContent = np.now.artist
                ? np.now.artist + ' \u2014 ' + np.now.title : np.now.title;
          /* Compte a rebours.

             Sans lui, l'affichage reste fige plusieurs minutes sur une
             chaine qui, elle, avance : le spectateur voit un site qui ne
             suit pas ce qu'il regarde. Le decompte se met a jour chaque
             seconde a partir de la valeur du serveur, sans le rappeler. */
          if ($m) startCountdown($m, np.now.remaining|0);

          /* Relance a la fin du titre.

             Cale sur le programme plutot que sur un intervalle fixe : on
             redemande une seconde apres la bascule, ni trop tot ni trop
             tard. Une minute au minimum pour ne pas marteler le serveur si
             une duree etait aberrante. */
          scheduleNext(Math.max(60, (np.now.remaining|0) + 1));
          if ($i && np.now.thumb) { $i.src = np.now.thumb; $i.style.display = 'block'; }
          if ($n && np.next) {
            $n.innerHTML = '<span class="ch-next-label">Up next</span>'
                         + '<span class="ch-next-title">'
                         + (np.next.artist ? np.next.artist + ' \u2014 ' : '')
                         + np.next.title + '</span>';
          }
          return;   // rien de plus a chercher
        }
      }
    } catch(e) { console.warn('[NOW] playout indisponible :', e.message); }

    var data = null;

    /* Appel direct, puis relais interne.

       Le script n'essayait que l'adresse directe. Or elle pointe vers
       tackendo.tv alors que la page est servie depuis tackendo.com : le
       navigateur bloque la lecture de la reponse quand le serveur ne
       declare pas l'origine croisee, et rien ne prenait le relais. Le
       squelette clignotait alors indefiniment.

       EPG_PROXY existait deja dans le plugin sans etre appele : c'est le
       meme contenu, servi depuis le domaine du site, donc sans restriction
       d'origine. */
    try {
      var r = await fetch(EPG_DIRECT, {cache:'no-store'});
      if (r.ok) data = await r.json();
    } catch(e) { console.warn('[EPG] direct indisponible :', e.message); }

    if (!data || !data.programs || !data.programs.length) {
      try {
        var r2 = await fetch(EPG_PROXY, {cache:'no-store'});
        if (r2.ok) data = await r2.json();
      } catch(e2) { console.warn('[EPG] relais indisponible :', e2.message); }
    }

    if (!data || !data.programs || !data.programs.length) {
      console.warn('[EPG] aucun programme');
      var $sk = document.querySelectorAll('.skel');
      for (var z = 0; z < $sk.length; z++) $sk[z].classList.remove('skel');
      return;
    }

    var progs = data.programs || [];
    var now = Date.now();
    var current = null, upcoming = [];

    for (var i = 0; i < progs.length; i++) {
      var p = progs[i];
      var start = new Date(p.start).getTime();
      var stop  = new Date(p.stop).getTime();
      if (start <= now && stop > now) { current = p; }
      else if (start > now) { upcoming.push(p); }
    }

    if (current) {
      var $title = document.getElementById('epg-title');
      var $time  = document.getElementById('epg-time');
      // Retire du bandeau : la suite du programme a sa propre section
      // sous le lecteur, ou elle est lisible plutot que reduite a une ligne.
      var $next  = document.getElementById('epg-next');
      var $thumb = document.getElementById('epg-thumb');
      if ($title) $title.textContent = progTitle(current);
      var s = new Date(current.start), e = new Date(current.stop);
      var fmt = function(d){ return d.toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit',hour12:false}); };
      if ($time) $time.textContent = fmt(s) + ' – ' + fmt(e);
      if ($thumb && current.icon) { $thumb.src = current.icon; $thumb.style.display='block'; }
      if ($next && upcoming[0]) {
        var ns = new Date(upcoming[0].start);
        $next.innerHTML = '<span class="ch-next-label">Up next</span>'
                        + '<span class="ch-next-title">' + progTitle(upcoming[0])
                        + ' &middot; ' + fmt(ns) + '</span>';
      }
    }

    /* La grille des horaires a ete retiree : une seule entree a venir
       suffit dans le bandeau, et la place sous le lecteur revient aux
       autres chaines, plus utiles a ce moment-la. */
  }

  // Init
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', loadChannelEPG);
  } else {
    loadChannelEPG();
  }
  /* Plus d'intervalle fixe : la relance est calee sur la fin du titre.
     Un secours toutes les cinq minutes couvre le cas ou le serveur n'a rien
     renvoye et n'a donc pu programmer aucune relance. */
  setInterval(function () {
    if (!nextTimer) loadChannelEPG();
  }, 5 * 60 * 1000);

  /* Onglet remis au premier plan : le decompte a continue de tourner mais
     le navigateur a pu ralentir les minuteurs. On resynchronise. */
  document.addEventListener('visibilitychange', function () {
    if (!document.hidden) loadChannelEPG();
  });
})();
</script>
<?php endif; ?>

<?php wp_footer(); ?>
</body>
</html>
