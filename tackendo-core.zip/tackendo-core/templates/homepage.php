<?php
/* Template Name: Tackendo Homepage */
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * PAGE D'ACCUEIL — refonte editoriale.
 *
 * L'ancienne version presentait cinq articles en bas de page, sous une
 * banniere occupant la moitie de l'ecran pour une seule chaine. AdSense a
 * refuse le site pour contenu insuffisant : ce qu'un evaluateur y voyait,
 * c'etait une plaquette commerciale avec un blog en decoration.
 *
 * Le rapport est inverse ici. Les chaines restent accessibles en trois
 * secondes par une bande compacte en tete, mais le corps de la page est
 * editorial : dix-huit articles, avec assez de texte visible pour qu'on
 * comprenne qu'il y a une redaction derriere.
 *
 * Le logo et l'identite visuelle sont inchanges.
 */

// Dix-huit articles au lieu de cinq : la une, la grille, puis la liste.
$posts_all = get_posts( array(
    'numberposts' => 18,
    'post_status' => 'publish',
    'meta_key'    => '_tcore_generated',
    'meta_value'  => 1,
) );
if ( count( $posts_all ) < 6 ) {
    $posts_all = get_posts( array( 'numberposts' => 18, 'post_status' => 'publish' ) );
}

$lead    = ! empty( $posts_all ) ? array_shift( $posts_all ) : null;
$grid    = array_slice( $posts_all, 0, 8 );
$listing = array_slice( $posts_all, 8, 9 );

/** Rubrique d'un article, telle que le generateur la pose. */
function tackendo_topic( $post_id ) {
    $t = get_post_meta( $post_id, '_tcore_topic_tag', true );
    return $t ? $t : 'FAST TV';
}

/** Vignette d'un article, avec repli sur un degrade par rubrique. */
function tackendo_thumb( $post_id, $min_height = 180 ) {
    $url = get_the_post_thumbnail_url( $post_id, 'large' );
    if ( $url ) {
        printf(
            '<img src="%s" alt="%s" loading="lazy" style="width:100%%;height:100%%;object-fit:cover;display:block;min-height:%dpx">',
            esc_url( $url ), esc_attr( get_the_title( $post_id ) ), (int) $min_height
        );
        return;
    }
    $tag  = tackendo_topic( $post_id );
    $maps = array(
        'Music'             => 'linear-gradient(135deg,#1a0533 0%,#4a1080 100%)',
        'CTV Industry'      => 'linear-gradient(135deg,#020617 0%,#1e3a5f 100%)',
        'Advertising'       => 'linear-gradient(135deg,#001a0d 0%,#005c28 100%)',
        'Platform Guide'    => 'linear-gradient(135deg,#05010d 0%,#1a0860 100%)',
        'Channel Spotlight' => 'linear-gradient(135deg,#200004 0%,#8c0018 100%)',
        'Streaming Guide'   => 'linear-gradient(135deg,#020920 0%,#0a2540 100%)',
    );
    $bg = isset( $maps[ $tag ] ) ? $maps[ $tag ]
        : 'linear-gradient(135deg,#180824 0%,#080c24 100%)';
    printf(
        '<div style="width:100%%;min-height:%dpx;height:100%%;background:%s;display:flex;align-items:center;justify-content:center"><span style="font-size:12px;letter-spacing:.14em;color:rgba(255,255,255,.28);text-transform:uppercase">%s</span></div>',
        (int) $min_height, esc_attr( $bg ), esc_html( $tag )
    );
}

/**
 * Chaines a l'antenne.
 *
 * Le feed JSON fait autorite sur ce qui est diffuse : c'est lui qui pilote
 * deja les applications Roku, Fire TV, Android TV et mobile. La liste PHP,
 * elle, se desynchronise des qu'une chaine change — c'est ce qui faisait
 * apparaitre ici des chaines eteintes et manquer les nouvelles.
 *
 * On prend donc du feed ce qu'il sait : les noms, les vignettes, l'ordre
 * editorial. Et de la base ce qu'il ignore : les adresses de lecture web,
 * qui different de celles des applications — le feed porte des macros
 * d'application (identifiant publicitaire, paquet, magasin) qui n'ont
 * aucun sens dans un navigateur.
 */
function tackendo_live_channels() {

    $feed = get_transient( 'tackendo_feed_channels' );

    if ( false === $feed ) {
        $feed = array();
        $r = wp_remote_get(
            'https://radiotool.fr/tackendo/tackendo_fire.json',
            array( 'timeout' => 8 )
        );
        if ( ! is_wp_error( $r ) && 200 === wp_remote_retrieve_response_code( $r ) ) {
            $d = json_decode( wp_remote_retrieve_body( $r ), true );
            if ( ! empty( $d['tvSpecials'] ) ) {
                foreach ( $d['tvSpecials'] as $t ) {

                    // Le titre a longtemps ete vide, le nom se trouvant en
                    // tete de shortDescription. On accepte les deux formes.
                    $name = ! empty( $t['title'] ) ? $t['title'] : '';
                    if ( '' === $name && ! empty( $t['shortDescription'] ) ) {
                        $name = trim( strstr( $t['shortDescription'] . ' - ', ' - ', true ) );
                    }
                    if ( '' === $name ) continue;

                    $thumb = '';
                    foreach ( array( 'thumbnail', 'image', 'poster' ) as $k ) {
                        if ( ! empty( $t[ $k ] ) ) { $thumb = $t[ $k ]; break; }
                    }

                    $desc = '';
                    if ( ! empty( $t['shortDescription'] ) ) {
                        $desc = trim( substr( strstr( $t['shortDescription'], ' - ' ), 3 ) );
                        if ( '' === $desc ) $desc = $t['shortDescription'];
                    }

                    $feed[] = array(
                        'name'  => $name,
                        'thumb' => $thumb,
                        'desc'  => $desc,
                    );
                }
            }
        }
        // Quart d'heure de cache : le feed change rarement, et la page
        // d'accueil ne doit pas dependre d'un appel reseau a chaque visite.
        set_transient( 'tackendo_feed_channels', $feed, 15 * MINUTE_IN_SECONDS );
    }

    $db = function_exists( 'tcore_channels' ) ? tcore_channels() : array();

    /* Correspondances explicites.
     *
     * Le feed et la base ne nomment pas toujours une meme chaine de la
     * meme facon : la grille a ete renommee cote diffusion sans que les
     * pages web suivent, et renommer ici casserait les adresses deja
     * indexees. On rapproche donc par identifiant plutot que par
     * ressemblance.
     *
     * Piano Dreams et Underwater Wonder n'ont pas encore de page : elles
     * pointent vers la liste des chaines en attendant. */
    $alias = array(
        'musicrising'         => 'fast-music-rising',
        'madeinfrancechannel' => 'made-in-france',
        'halloween'           => 'halloween',
        'pianodreams'         => 'piano-dreams',
        'underwaterwonder'    => 'underwater-wonder',
    );

    // Rapprochement par nom : le feed ne porte pas nos identifiants.
    $index = array();
    foreach ( $db as $slug => $c ) {
        $index[ strtolower( preg_replace( '/[^a-z0-9]/i', '', $c['name'] ) ) ] =
            array( 'slug' => $slug, 'data' => $c );
    }

    $out = array();
    $i   = 0;
    foreach ( $feed as $f ) {
        $k = strtolower( preg_replace( '/[^a-z0-9]/i', '', $f['name'] ) );

        $slug = '';
        $c    = array();
        if ( isset( $alias[ $k ] ) ) {
            $slug = $alias[ $k ];
            if ( $slug && isset( $db[ $slug ] ) ) $c = $db[ $slug ];
        } elseif ( isset( $index[ $k ] ) ) {
            $slug = $index[ $k ]['slug'];
            $c    = $index[ $k ]['data'];
        }

        // Chaine du feed sans page dediee : on la montre quand meme, elle
        // est a l'antenne. Le clic mene a la liste des chaines.
        $key = $slug ? $slug : ( '_feed' . $i++ );

        $out[ $key ] = array(
            'name' => $f['name'],
            'cat'  => isset( $c['cat'] ) ? $c['cat'] : '',
            'link' => $slug ? home_url( '/' . $slug . '/' ) : home_url( '/' ) . '#channels',
            // La vignette du feed prime : c'est celle des applications, au
            // bon format et tenue a jour.
            'logo' => $f['thumb'] ? $f['thumb'] : ( isset( $c['logo'] ) ? $c['logo'] : '' ),
            'desc' => $f['desc'] ? $f['desc'] : ( isset( $c['desc'] ) ? $c['desc'] : '' ),
        );
    }

    // Feed injoignable : on retombe sur la liste PHP plutot que d'afficher
    // une page sans chaines.
    if ( empty( $out ) ) {
        foreach ( $db as $slug => $c ) {
            if ( empty( $c['hls'] ) ) continue;
            $c['link']    = home_url( '/' . $slug . '/' );
            $out[ $slug ] = $c;
        }
    }
    return $out;
}

$channels = tackendo_live_channels();
$site_url = esc_url( home_url( '/' ) );
$logo_url = 'https://tackendo.com/wp-content/uploads/2025/06/Tackendo-logo-white-on-transparent-262x76-1.png';
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>TACKENDO &mdash; Music, Culture &amp; Streaming Magazine | Free Live TV</title>
<meta name="description" content="Daily writing on music, streaming culture and the business of free TV, alongside 14 live channels you can watch free with no account.">
<meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">
<link rel="canonical" href="<?php echo $site_url; ?>">
<meta property="og:type" content="website">
<meta property="og:site_name" content="TACKENDO">
<meta property="og:url" content="<?php echo $site_url; ?>">
<meta property="og:title" content="TACKENDO &mdash; Music, Culture &amp; Streaming Magazine">
<meta property="og:description" content="Daily editorial on music and streaming, plus 14 free live channels.">
<meta property="og:image" content="<?php echo esc_url( $logo_url ); ?>">
<meta property="og:locale" content="en_US">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="TACKENDO &mdash; Music, Culture &amp; Streaming Magazine">
<meta name="twitter:image" content="<?php echo esc_url( $logo_url ); ?>">
<meta name="theme-color" content="#E8001C">
<link rel="alternate" hreflang="en" href="<?php echo $site_url; ?>">
<link rel="alternate" hreflang="x-default" href="<?php echo $site_url; ?>">
<script type="application/ld+json">
{"@context":"https://schema.org","@graph":[
{"@type":"WebSite","url":"<?php echo $site_url; ?>","name":"TACKENDO","description":"Music, culture and streaming magazine with free live TV channels"},
{"@type":"Organization","name":"TACKENDO","legalName":"Netradio Network","url":"<?php echo $site_url; ?>","logo":{"@type":"ImageObject","url":"<?php echo esc_url( $logo_url ); ?>"}}]}
</script>

<style>
/* ------------------------------------------------------------------
   Mise en page.

   Une seule largeur de conteneur, appliquee partout : les rangees
   s'arretaient auparavant apres deux ou trois vignettes en laissant la
   moitie de l'ecran vide.

   Les grilles sont en repeat(auto-fill, minmax(...)) : elles se
   remplissent d'elles-memes quelle que soit la largeur, sans qu'on ait a
   fixer un nombre de colonnes par palier d'ecran.
   ------------------------------------------------------------------ */
body.tackendo-home{background:#08080c;color:#e8e8ee;margin:0;
  font:16px/1.65 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
  -webkit-font-smoothing:antialiased}
body.tackendo-home *{box-sizing:border-box}
body.tackendo-home a{color:inherit;text-decoration:none}
.tk-wrap{max-width:1320px;margin:0 auto;padding:0 32px}

#tackendo-header{position:sticky;top:0;z-index:80;display:flex;align-items:center;
  justify-content:space-between;gap:24px;padding:14px 32px;
  background:rgba(8,8,12,.92);backdrop-filter:blur(14px);
  border-bottom:1px solid rgba(255,255,255,.07)}
#tackendo-header .logo img{height:34px;width:auto;display:block}
#tackendo-header nav{display:flex;gap:26px;flex-wrap:wrap}
#tackendo-header nav a{font-size:13px;letter-spacing:.1em;text-transform:uppercase;
  color:#b6b6c2;transition:color .18s}
#tackendo-header nav a:hover{color:#fff}
.hdr-right{display:flex;gap:9px}
.btn-platform{font-size:12px;letter-spacing:.06em;padding:8px 15px;border-radius:8px;
  border:1px solid rgba(255,255,255,.16);color:#e8e8ee;transition:all .18s}
.btn-platform:hover{border-color:#E8001C;color:#fff}

/* ------------------------------------------------------------------
   Hero.

   Les bandeaux tournent en fondu, comme dans les applications. Chacun est
   cliquable et mene a la chaine qu'il presente : une image qui ne conduit
   nulle part n'est qu'une decoration, et elle occupait jusqu'ici la moitie
   de l'ecran.
   ------------------------------------------------------------------ */
.tk-hero{position:relative;height:min(52vh,440px);min-height:300px;overflow:hidden;
  background:#0b0b12}
/* pointer-events est indispensable : les trois bandeaux sont superposes,
   et une opacite nulle ne rend pas un lien inactif. Sans cela, celui du
   dessus captait tous les clics, quel que soit le visuel affiche. */
.tk-hero-slide{position:absolute;inset:0;opacity:0;pointer-events:none;
  transition:opacity 1.1s ease;background-size:cover;background-position:center}
.tk-hero-slide.on{opacity:1;pointer-events:auto}
.tk-hero::after{content:"";position:absolute;inset:0;pointer-events:none;
  background:linear-gradient(180deg,rgba(8,8,12,.15) 0%,rgba(8,8,12,.55) 55%,#08080c 100%)}
.tk-hero-txt{position:absolute;left:0;right:0;bottom:0;z-index:3;padding:0 0 34px}
.tk-hero-txt .tk-wrap{display:flex;align-items:flex-end;justify-content:space-between;
  gap:24px;flex-wrap:wrap}
.tk-kicker{font-size:11px;letter-spacing:.24em;text-transform:uppercase;
  color:#E8001C;margin:0 0 10px;font-weight:700}
.tk-tag{font-size:clamp(26px,3.4vw,42px);line-height:1.02;margin:0;font-weight:800;
  letter-spacing:-.02em;max-width:19ch;text-shadow:0 2px 24px rgba(0,0,0,.6)}
.tk-sub{font-size:15px;color:#c4c4d2;margin:12px 0 0;max-width:46ch;
  text-shadow:0 1px 12px rgba(0,0,0,.7)}
.tk-hero-cta{display:flex;gap:10px;flex-wrap:wrap}
.tk-btn{padding:12px 22px;border-radius:9px;font-size:14px;font-weight:700;
  letter-spacing:.03em;transition:all .18s}
.tk-btn-fill{background:#E8001C;color:#fff}
.tk-btn-fill:hover{background:#ff1030}
.tk-btn-ghost{border:1px solid rgba(255,255,255,.28);color:#fff}
.tk-btn-ghost:hover{border-color:#fff;background:rgba(255,255,255,.08)}
.tk-dots{position:absolute;right:32px;bottom:20px;z-index:4;display:flex;gap:7px}
.tk-dot{width:7px;height:7px;border-radius:50%;background:rgba(255,255,255,.3);
  cursor:pointer;transition:all .2s;border:0;padding:0}
.tk-dot.on{background:#E8001C;width:22px;border-radius:4px}

/* ------------------------------------------------------------------
   Bande des chaines.

   Elle remplace une banniere qui occupait la moitie de l'ecran pour une
   seule chaine, avec un large vide a droite. Quatorze vignettes tiennent
   ici dans la hauteur qu'occupait ce vide.
   ------------------------------------------------------------------ */
.tk-strip{border-bottom:1px solid rgba(255,255,255,.07);padding:34px 0 40px}
.tk-strip-head{display:flex;align-items:baseline;justify-content:space-between;
  gap:16px;margin-bottom:16px}
.tk-strip-head h2{font-size:15px;letter-spacing:.16em;text-transform:uppercase;
  margin:0;font-weight:700}
.tk-strip-head a{font-size:13px;color:#9a9aa8}
.tk-strip-head a:hover{color:#E8001C}
.tk-chan-row{display:grid;grid-template-columns:repeat(auto-fill,minmax(176px,1fr));gap:16px}
.tk-chan{border-radius:11px;overflow:hidden;background:#12121c;
  border:1px solid rgba(255,255,255,.07);transition:transform .2s,border-color .2s}
.tk-chan:hover{transform:translateY(-3px);border-color:#E8001C}
.tk-chan-img{aspect-ratio:16/9;background:#0d0d18;overflow:hidden}
.tk-chan-img img{width:100%;height:100%;object-fit:cover;display:block}
.tk-chan-body{padding:9px 11px 11px}
.tk-chan-name{font-size:13px;font-weight:700;line-height:1.3;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.tk-chan-cat{font-size:10px;letter-spacing:.12em;text-transform:uppercase;
  color:#E8001C;margin-top:3px}

.tk-sec{padding:56px 0}
.tk-sec-head{display:flex;align-items:flex-end;justify-content:space-between;
  gap:20px;margin-bottom:26px;padding-bottom:14px;
  border-bottom:1px solid rgba(255,255,255,.09)}
.tk-sec-label{font-size:11px;letter-spacing:.2em;text-transform:uppercase;
  color:#E8001C;margin:0 0 6px}
.tk-sec-title{font-size:30px;line-height:1.15;margin:0;font-weight:800;
  letter-spacing:-.01em}
.tk-sec-head a{font-size:13px;color:#9a9aa8;white-space:nowrap}
.tk-sec-head a:hover{color:#fff}

.tk-lead{display:grid;grid-template-columns:1.35fr 1fr;gap:32px;
  margin-bottom:38px;align-items:center}
.tk-lead-img{border-radius:14px;overflow:hidden;aspect-ratio:16/9;background:#12121c}
.tk-lead-img img{width:100%;height:100%;object-fit:cover;display:block}
.tk-lead h3{font-size:32px;line-height:1.2;margin:12px 0 14px;font-weight:800;
  letter-spacing:-.015em}
.tk-lead p{color:#a8a8b8;font-size:16px;line-height:1.7;margin:0 0 16px}
.tk-meta{font-size:12px;letter-spacing:.1em;text-transform:uppercase;
  color:#7a7a8a;margin:0}
.tk-meta b{color:#E8001C;font-weight:600}
.tk-more{font-size:13px;letter-spacing:.08em;text-transform:uppercase;
  color:#fff;border-bottom:1px solid #E8001C;padding-bottom:2px}

.tk-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(270px,1fr));gap:24px}
.tk-card{background:#0f0f18;border:1px solid rgba(255,255,255,.07);
  border-radius:13px;overflow:hidden;display:flex;flex-direction:column;
  transition:transform .2s,border-color .2s}
.tk-card:hover{transform:translateY(-4px);border-color:rgba(232,0,28,.55)}
.tk-card-img{aspect-ratio:16/9;overflow:hidden;background:#12121c}
.tk-card-body{padding:15px 17px 18px;flex:1;display:flex;flex-direction:column}
.tk-card h4{font-size:16px;line-height:1.35;margin:8px 0 8px;font-weight:700}
.tk-card p{font-size:13.5px;line-height:1.6;color:#9a9aa8;margin:0}

/* Liste compacte : de la densite sans encombrer */
.tk-list{display:grid;grid-template-columns:repeat(auto-fill,minmax(360px,1fr));
  gap:2px 34px}
.tk-li{display:flex;gap:15px;padding:15px 0;
  border-bottom:1px solid rgba(255,255,255,.06)}
.tk-li-img{width:104px;height:66px;border-radius:8px;overflow:hidden;
  flex-shrink:0;background:#12121c}
.tk-li h5{font-size:14.5px;line-height:1.4;margin:5px 0 0;font-weight:600}
.tk-li:hover h5{color:#fff}

.tk-foot{border-top:1px solid rgba(255,255,255,.08);padding:46px 0 30px;
  background:#0a0a10;margin-top:20px}
.tk-foot-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));
  gap:34px;margin-bottom:34px}
.tk-foot h6{font-size:11px;letter-spacing:.18em;text-transform:uppercase;
  color:#7a7a8a;margin:0 0 14px;font-weight:600}
.tk-foot ul{list-style:none;margin:0;padding:0}
.tk-foot li{margin-bottom:9px}
.tk-foot li a{font-size:14px;color:#b6b6c2}
.tk-foot li a:hover{color:#E8001C}
.tk-foot-bottom{border-top:1px solid rgba(255,255,255,.07);padding-top:22px;
  display:flex;justify-content:space-between;gap:16px;flex-wrap:wrap;
  font-size:13px;color:#7a7a8a}

@media(max-width:900px){
  .tk-lead{grid-template-columns:1fr;gap:18px}
  .tk-lead h3{font-size:25px}
  .tk-sec-title{font-size:24px}
  .tk-wrap{padding:0 20px}
  #tackendo-header{padding:12px 20px}
  #tackendo-header nav{display:none}
}
</style>
<?php wp_head(); ?>
</head>
<body class="tackendo-home">

<header id="tackendo-header">
  <a href="<?php echo $site_url; ?>" class="logo">
    <img src="<?php echo esc_url( $logo_url ); ?>" alt="TACKENDO" loading="eager">
  </a>
  <nav>
    <a href="#channels">Channels</a>
    <a href="#magazine">Magazine</a>
    <a href="<?php echo esc_url( home_url( '/blog' ) ); ?>">All Articles</a>
    <a href="<?php echo esc_url( home_url( '/about' ) ); ?>">About</a>
    <a href="<?php echo esc_url( home_url( '/advertise' ) ); ?>">Advertise</a>
  </nav>
  <div class="hdr-right">
    <a href="https://channelstore.roku.com/details/8244e521d238b28c45271329a3ebe907/tackendo" class="btn-platform" target="_blank" rel="noopener">Roku</a>
    <a href="https://www.amazon.com/gp/product/B0DGNFS8N9" class="btn-platform" target="_blank" rel="noopener">Fire TV</a>
  </div>
</header>

<?php
/* Bandeaux du hero.

   Memes visuels que les applications, servis depuis le meme endroit : une
   seule image a mettre a jour pour les cinq plateformes. Chacun renvoie
   vers une chaine mise en avant. */
$heroes = get_option( 'tcore_hero_banners', array() );

// Jamais configures : on repart des visuels des applications.
if ( empty( $heroes ) ) {
    $heroes = array(
        array( 'img' => 'https://radiotool.fr/tackendo/images/Banner_1.jpg', 'slug' => 'underwater-wonder' ),
        array( 'img' => 'https://radiotool.fr/tackendo/images/Banner_2.jpg', 'slug' => 'piano-dreams' ),
        array( 'img' => 'https://radiotool.fr/tackendo/images/Banner_3.jpg', 'slug' => 'awe-cosmos' ),
    );
}
?>
<section class="tk-hero" id="hero">
  <?php foreach ( $heroes as $i => $h ) :
    $h_link = ! empty( $h['slug'] ) ? home_url( '/' . $h['slug'] . '/' ) : '';
    $h_cls  = 'tk-hero-slide' . ( 0 === $i ? ' on' : '' );
  ?>
    <?php if ( $h_link ) : ?>
      <a class="<?php echo $h_cls; ?>" href="<?php echo esc_url( $h_link ); ?>"
         style="background-image:url('<?php echo esc_url( $h['img'] ); ?>')"
         aria-label="<?php echo esc_attr( $h['slug'] ); ?>"></a>
    <?php else : ?>
      <?php /* Sans chaine liee, un simple visuel : mieux vaut aucun lien
               qu'un lien qui ne mene nulle part. */ ?>
      <div class="<?php echo $h_cls; ?>"
           style="background-image:url('<?php echo esc_url( $h['img'] ); ?>')"></div>
    <?php endif; ?>
  <?php endforeach; ?>

  <div class="tk-hero-txt">
    <div class="tk-wrap">
      <div>
        <p class="tk-kicker">Free to watch &middot; No account</p>
        <h1 class="tk-tag">Channels for the mood you're in.</h1>
        <p class="tk-sub">Fourteen live channels &mdash; music, ambience and culture,
          running around the clock. Press play, that's all.</p>
      </div>
      <div class="tk-hero-cta">
        <a class="tk-btn tk-btn-fill" href="#channels">Browse channels</a>
        <a class="tk-btn tk-btn-ghost" href="#magazine">Read the magazine</a>
      </div>
    </div>
  </div>

  <div class="tk-dots">
    <?php foreach ( $heroes as $i => $h ) : ?>
      <button class="tk-dot<?php echo 0 === $i ? ' on' : ''; ?>" data-i="<?php echo (int) $i; ?>"
              aria-label="Slide <?php echo (int) $i + 1; ?>"></button>
    <?php endforeach; ?>
  </div>
</section>

<script>
/* Rotation des bandeaux.

   Huit secondes, comme dans les applications. La rotation s'arrete quand
   l'onglet passe en arriere-plan : inutile de faire tourner des images que
   personne ne regarde. */
(function(){
  var slides = document.querySelectorAll('.tk-hero-slide'),
      dots   = document.querySelectorAll('.tk-dot'),
      cur = 0, timer = null;
  if (slides.length < 2) return;

  function show(n){
    slides[cur].classList.remove('on'); dots[cur].classList.remove('on');
    cur = (n + slides.length) % slides.length;
    slides[cur].classList.add('on');    dots[cur].classList.add('on');
  }
  function start(){ stop(); timer = setInterval(function(){ show(cur+1); }, 8000); }
  function stop(){ if (timer) { clearInterval(timer); timer = null; } }

  for (var i = 0; i < dots.length; i++) {
    (function(k){
      dots[k].addEventListener('click', function(e){
        e.preventDefault(); show(k); start();
      });
    })(i);
  }
  document.addEventListener('visibilitychange', function(){
    document.hidden ? stop() : start();
  });
  start();
})();
</script>

<section class="tk-strip" id="channels">
  <div class="tk-wrap">
    <div class="tk-strip-head">
      <h2>All channels &middot; live now</h2>
      <a href="<?php echo esc_url( home_url( '/' ) ) . '#channels'; ?>">All channels &rarr;</a>
    </div>
    <div class="tk-chan-row">
      <?php
      $shown = 0;
      foreach ( $channels as $slug => $c ) {
          if ( $shown++ >= 14 ) break; ?>
        <a class="tk-chan" href="<?php echo esc_url( $c['link'] ); ?>">
          <div class="tk-chan-img">
            <?php if ( ! empty( $c['logo'] ) ) : ?>
              <img src="<?php echo esc_url( $c['logo'] ); ?>" alt="<?php echo esc_attr( $c['name'] ); ?>" loading="lazy">
            <?php endif; ?>
          </div>
          <div class="tk-chan-body">
            <div class="tk-chan-name"><?php echo esc_html( $c['name'] ); ?></div>
            <div class="tk-chan-cat"><?php echo esc_html( $c['cat'] ); ?></div>
          </div>
        </a>
      <?php } ?>
    </div>
  </div>
</section>

<section class="tk-sec" id="magazine">
  <div class="tk-wrap">
    <div class="tk-sec-head">
      <div>
        <p class="tk-sec-label">Published daily</p>
        <h2 class="tk-sec-title">TACKENDO Magazine</h2>
      </div>
      <a href="<?php echo esc_url( home_url( '/blog' ) ); ?>">All articles &rarr;</a>
    </div>

    <?php if ( $lead ) : ?>
    <a class="tk-lead" href="<?php echo esc_url( get_permalink( $lead->ID ) ); ?>">
      <div class="tk-lead-img"><?php tackendo_thumb( $lead->ID, 300 ); ?></div>
      <div>
        <p class="tk-meta"><b><?php echo esc_html( tackendo_topic( $lead->ID ) ); ?></b>
          &nbsp;&middot;&nbsp;<?php echo esc_html( get_the_date( 'M j, Y', $lead->ID ) ); ?></p>
        <h3><?php echo esc_html( get_the_title( $lead->ID ) ); ?></h3>
        <p><?php echo esc_html( wp_trim_words( strip_tags( $lead->post_content ), 42 ) ); ?></p>
        <span class="tk-more">Read the article</span>
      </div>
    </a>
    <?php endif; ?>

    <div class="tk-grid">
      <?php foreach ( $grid as $p ) : ?>
      <a class="tk-card" href="<?php echo esc_url( get_permalink( $p->ID ) ); ?>">
        <div class="tk-card-img"><?php tackendo_thumb( $p->ID, 170 ); ?></div>
        <div class="tk-card-body">
          <p class="tk-meta"><b><?php echo esc_html( tackendo_topic( $p->ID ) ); ?></b>
            &nbsp;&middot;&nbsp;<?php echo esc_html( get_the_date( 'M j', $p->ID ) ); ?></p>
          <h4><?php echo esc_html( get_the_title( $p->ID ) ); ?></h4>
          <p><?php echo esc_html( wp_trim_words( strip_tags( $p->post_content ), 22 ) ); ?></p>
        </div>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php if ( ! empty( $listing ) ) : ?>
<section class="tk-sec" style="padding-top:0">
  <div class="tk-wrap">
    <div class="tk-sec-head">
      <div>
        <p class="tk-sec-label">Keep reading</p>
        <h2 class="tk-sec-title">More from the magazine</h2>
      </div>
      <a href="<?php echo esc_url( home_url( '/blog' ) ); ?>">Browse the archive &rarr;</a>
    </div>
    <div class="tk-list">
      <?php foreach ( $listing as $p ) : ?>
      <a class="tk-li" href="<?php echo esc_url( get_permalink( $p->ID ) ); ?>">
        <div class="tk-li-img"><?php tackendo_thumb( $p->ID, 66 ); ?></div>
        <div>
          <p class="tk-meta"><b><?php echo esc_html( tackendo_topic( $p->ID ) ); ?></b>
            &nbsp;&middot;&nbsp;<?php echo esc_html( get_the_date( 'M j', $p->ID ) ); ?></p>
          <h5><?php echo esc_html( get_the_title( $p->ID ) ); ?></h5>
        </div>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<footer class="tk-foot">
  <div class="tk-wrap">
    <div class="tk-foot-grid">
      <div>
        <img src="<?php echo esc_url( $logo_url ); ?>" alt="TACKENDO" style="height:30px;width:auto;margin-bottom:14px">
        <p style="font-size:14px;color:#8a8a98;line-height:1.7;margin:0;max-width:280px">
          A magazine about music, streaming and the culture around them,
          published alongside fourteen free live channels.
        </p>
      </div>
      <div>
        <h6>Channels</h6>
        <ul>
          <?php
          $n = 0;
          foreach ( $channels as $slug => $c ) {
              if ( $n++ >= 7 ) continue; ?>
            <li><a href="<?php echo esc_url( $c['link'] ); ?>"><?php echo esc_html( $c['name'] ); ?></a></li>
          <?php } ?>
          <li><a href="<?php echo esc_url( home_url( '/' ) ) . '#channels'; ?>">All channels &rarr;</a></li>
        </ul>
      </div>
      <div>
        <h6>Platform</h6>
        <ul>
          <li><a href="<?php echo esc_url( home_url( '/about' ) ); ?>">About TACKENDO</a></li>
          <li><a href="<?php echo esc_url( home_url( '/advertise' ) ); ?>">Advertise with us</a></li>
          <li><a href="<?php echo esc_url( home_url( '/blog' ) ); ?>">Magazine</a></li>
          <li><a href="<?php echo esc_url( home_url( '/contact' ) ); ?>">Contact</a></li>
          <li><a href="<?php echo esc_url( home_url( '/privacy-policy' ) ); ?>">Privacy policy</a></li>
        </ul>
      </div>
      <div>
        <h6>Watch now</h6>
        <ul>
          <li><a href="https://channelstore.roku.com/details/8244e521d238b28c45271329a3ebe907/tackendo" target="_blank" rel="noopener">Roku &mdash; watch free</a></li>
          <li><a href="https://www.amazon.com/gp/product/B0DGNFS8N9" target="_blank" rel="noopener">Fire TV &mdash; watch free</a></li>
          <li><a href="https://play.google.com/store/apps/details?id=com.netradio.tackendo" target="_blank" rel="noopener">Android TV &mdash; watch free</a></li>
          <li><a href="https://play.google.com/store/apps/details?id=com.netradio.tackendo.mobile" target="_blank" rel="noopener">Android Mobile &mdash; watch free</a></li>
          <li><a href="<?php echo esc_url( home_url( '/' ) ) . '#channels'; ?>">Web &mdash; watch online</a></li>
        </ul>
      </div>
    </div>
    <div class="tk-foot-bottom">
      <span>&copy; 2024&ndash;<?php echo esc_html( date( 'Y' ) ); ?> TACKENDO &mdash; Netradio Network. All rights reserved.</span>
      <span>
        <a href="<?php echo esc_url( home_url( '/privacy-policy' ) ); ?>" style="color:#9a9aa8">Privacy</a>
        &nbsp;&nbsp;
        <a href="<?php echo esc_url( home_url( '/contact' ) ); ?>" style="color:#9a9aa8">Contact</a>
      </span>
    </div>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
