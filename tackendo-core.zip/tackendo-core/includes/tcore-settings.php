<?php
if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'admin_menu', 'tcore_admin_menu' );
function tcore_admin_menu() {
    add_menu_page( 'Tackendo Core', 'Tackendo Core', 'manage_options', 'tcore', 'tcore_settings_page', 'dashicons-video-alt3', 25 );
    add_submenu_page( 'tcore', 'General Settings', 'General', 'manage_options', 'tcore', 'tcore_settings_page' );
    add_submenu_page( 'tcore', 'Channel Settings', 'Channels', 'manage_options', 'tcore-channels', 'tcore_channels_page' );
}

// ── GENERAL SETTINGS ──────────────────────────────────────────────
add_action( 'admin_init', 'tcore_register_settings' );
function tcore_register_settings() {
    foreach ( array('tcore_claude_key','tcore_pexels_key','tcore_vast_url','tcore_article_lang','tcore_post_status','tcore_article_cat') as $opt ) {
        register_setting( 'tcore_options', $opt, array('sanitize_callback' => 'sanitize_text_field') );
    }
    register_setting( 'tcore_options', 'tcore_vast_url', array('sanitize_callback' => 'sanitize_text_field') );
}

function tcore_settings_page() {
    // Handle actions
    if ( isset($_GET['tcore_do']) && check_admin_referer('tcore_action') ) {
        $do = $_GET['tcore_do'];
        if ( $do === 'gen1'       ) {
            require_once TCORE_PATH . 'includes/tcore-articles.php';
            echo '<div class="notice notice-info"><p>⏳ Generating article via Claude AI... please wait (15-30 seconds).</p></div>';
            if ( ob_get_level() ) ob_flush();
            flush();
            $result = tcore_write_post( tcore_daily_topic() );
            if ( $result ) {
                $post_title = get_the_title( $result );
                echo '<div class="notice notice-success is-dismissible"><p>✅ Article <strong>#' . $result . '</strong> generated: <a href="' . get_edit_post_link($result) . '">' . esc_html($post_title) . '</a></p></div>';
            } else {
                echo '<div class="notice notice-error is-dismissible"><p>❌ Article generation failed. Check <code>wp-content/debug.log</code> for details.</p></div>';
            }
        }
        if ( $do === 'gen20'      ) {
            require_once TCORE_PATH . 'includes/tcore-articles.php';
            $topics = tcore_initial_topics();
            $done = (int) get_option('tcore_articles_done', 0);
            if ($done < count($topics)) {
                $result = tcore_write_post($topics[$done]);
                if ($result) {
                    update_option('tcore_articles_done', $done + 1);
                    echo '<div class="notice notice-success is-dismissible"><p>Article ' . ($done+1) . '/20 generated! Click again for the next one.</p></div>';
                } else {
                    echo '<div class="notice notice-error is-dismissible"><p>Generation failed. Check debug.log.</p></div>';
                }
            } else {
                echo '<div class="notice notice-info is-dismissible"><p>All 20 initial articles already generated.</p></div>';
            }
        }
        if ( $do === 'addimgs'    ) {
            require_once TCORE_PATH . 'includes/tcore-articles.php';
            tcore_cron_add_images();
            echo '<div class="notice notice-success is-dismissible"><p>Photos added to articles!</p></div>';
        }
        if ( $do === 'recachelogos' ) { delete_option('tcore_logos_cached_v2'); delete_option('tcore_logo_urls'); echo '<div class="notice notice-info is-dismissible"><p>Logo cache cleared — logos will re-download on next page load.</p></div>'; }
    }

    if ( isset($_POST['tcore_options_nonce']) && wp_verify_nonce($_POST['tcore_options_nonce'],'tcore_options') ) {
        foreach ( array('tcore_claude_key','tcore_pexels_key','tcore_vast_url','tcore_article_lang','tcore_post_status') as $k ) {
            if ( isset($_POST[$k]) ) update_option( $k, sanitize_text_field($_POST[$k]) );
        }
        if ( isset($_POST['tcore_article_cat']) ) update_option('tcore_article_cat', absint($_POST['tcore_article_cat']));
        echo '<div class="notice notice-success is-dismissible"><p>Settings saved.</p></div>';
    }

    $last  = get_option('tcore_last_article','—');
    $init  = get_option('tcore_initial_done', 0);
    $total = wp_count_posts('post');
    ?>
    <div class="wrap">
    <h1 style="display:flex;align-items:center;gap:10px">⚡ Tackendo Core <span style="font-size:13px;color:#999;font-weight:400">v<?php echo TCORE_VERSION; ?></span></h1>

    <form method="POST" style="max-width:700px">
    <?php wp_nonce_field('tcore_options','tcore_options_nonce'); ?>
    <h2>🤖 Claude AI</h2>
    <table class="form-table">
      <tr><th>Claude API Key</th><td><input type="password" name="tcore_claude_key" value="<?php echo esc_attr(get_option('tcore_claude_key','')); ?>" class="regular-text"><p class="description">Get yours at <a href="https://console.anthropic.com" target="_blank">console.anthropic.com</a>. Never share this key.</p></td></tr>
      <tr><th>Pexels API Key <small>(free photos)</small></th><td><input type="password" name="tcore_pexels_key" value="<?php echo esc_attr(get_option('tcore_pexels_key','')); ?>" class="regular-text"><p class="description">Free key at <a href="https://www.pexels.com/api/" target="_blank">pexels.com/api</a>. Auto-illustrates each article.</p></td></tr>
      <tr><th>Article Language</th><td><select name="tcore_article_lang"><option value="en" <?php selected(get_option('tcore_article_lang','en'),'en'); ?>>🇬🇧 English</option><option value="fr" <?php selected(get_option('tcore_article_lang','en'),'fr'); ?>>🇫🇷 French</option></select></td></tr>
      <tr><th>Post Status</th><td><select name="tcore_post_status"><option value="publish" <?php selected(get_option('tcore_post_status','publish'),'publish'); ?>>Published immediately</option><option value="draft" <?php selected(get_option('tcore_post_status','publish'),'draft'); ?>>Draft</option></select></td></tr>
      <tr><th>WordPress Category</th><td>
        <?php wp_dropdown_categories(array('name'=>'tcore_article_cat','selected'=>get_option('tcore_article_cat',0),'show_option_none'=>'— Select —','option_none_value'=>0,'hide_empty'=>0)); ?>
        <p class="description">Create a "TACKENDO Magazine" category first if needed.</p>
      </td></tr>
    </table>

    <h2>📺 Player &amp; Advertising</h2>
    <table class="form-table">
      <tr><th>Default VAST Tag URL</th><td>
        <input type="text" name="tcore_vast_url" value="<?php echo esc_attr(get_option('tcore_vast_url','')); ?>" class="large-text" placeholder="https://pubads.g.doubleclick.net/gampad/ads?...">
        <p class="description">Default VAST tag used when no channel-specific VAST is set. From VoiseTech / Google Ad Manager.<br>Use <code>[timestamp]</code> macro for cache busting.</p>
      </td></tr>
    </table>

    <?php submit_button('Save Settings'); ?>
    </form>

    <hr>
    <h2>📊 Generation Status</h2>
    <table class="widefat" style="max-width:500px">
      <tr><td>Initial articles generated</td><td><strong><?php echo min($init,20); ?> / 20</strong> <?php if($init>=20) echo '✅'; ?></td></tr>
      <tr><td>Last article</td><td><?php echo esc_html($last); ?></td></tr>
      <tr><td>Next daily article</td><td><?php $next=wp_next_scheduled('tcore_daily_article'); echo $next ? date('d/m/Y H:i', $next) . ' UTC' : '—'; ?></td></tr>
    </table>

    <h2>⚡ Manual Actions</h2>
    <p>
      <a href="<?php echo wp_nonce_url(add_query_arg('tcore_do','gen1',admin_url('admin.php?page=tcore')),'tcore_action'); ?>" class="button button-primary">🖊 Generate 1 article now</a>
      &nbsp;
      <a href="<?php echo wp_nonce_url(add_query_arg('tcore_do','gen20',admin_url('admin.php?page=tcore')),'tcore_action'); ?>" class="button button-primary" onclick="return confirm('Launch 20 initial articles? This will schedule 1 article every 2 minutes.')">🚀 Launch 20 initial articles</a>
      &nbsp;
      <a href="<?php echo wp_nonce_url(add_query_arg('tcore_do','addimgs',admin_url('admin.php?page=tcore')),'tcore_action'); ?>" class="button">🖼️ Add photos to existing articles</a>
      &nbsp;
      <a href="<?php echo wp_nonce_url(add_query_arg('tcore_do','recachelogos',admin_url('admin.php?page=tcore')),'tcore_action'); ?>" class="button">🔄 Re-download partner logos</a>
      &nbsp;
      <a href="<?php echo wp_nonce_url(add_query_arg('tcore_do','fixvast',admin_url('admin.php?page=tcore')),'tcore_action'); ?>" class="button button-primary" onclick="return confirm('Reset VAST URL to clean default in database?')">🔧 Fix VAST URL (reset DB)</a>
      &nbsp;
      <a href="<?php echo wp_nonce_url(add_query_arg('tcore_do','clearepgcache',admin_url('admin.php?page=tcore')),'tcore_action'); ?>" class="button">🗑️ Clear EPG cache</a>
    </p>
    </div>
    <?php
}

// ── CHANNEL SETTINGS PAGE ─────────────────────────────────────────
function tcore_channels_page() {
    require_once TCORE_PATH . 'includes/tcore-channels.php';

    /* ---- Import depuis le feed ---- */
    if ( isset($_POST['tcore_sync']) && check_admin_referer('tcore_ch_settings','tcore_ch_nonce') ) {
        $r = tcore_sync_from_feed();
        if ( isset($r['error']) ) {
            echo '<div class="notice notice-error"><p>' . esc_html($r['error']) . '</p></div>';
        } else {
            printf(
                '<div class="notice notice-success is-dismissible"><p>Feed importe : %d chaine(s) ajoutee(s), %d mise(s) a jour, %d desactivee(s).</p></div>',
                (int) $r['added'], (int) $r['updated'], (int) $r['disabled']
            );
        }
    }

    /* ---- Ajout manuel ---- */
    if ( isset($_POST['tcore_add_name']) && check_admin_referer('tcore_ch_settings','tcore_ch_nonce') ) {
        $name = sanitize_text_field( wp_unslash($_POST['tcore_add_name']) );
        if ( '' !== $name ) {
            $list = tcore_all_channels();
            $slug = sanitize_title( $name );
            if ( isset($list[$slug]) ) {
                echo '<div class="notice notice-error"><p>Cette chaine existe deja.</p></div>';
            } else {
                $list[$slug] = array(
                    'name' => $name, 'cat' => 'Music', 'logo' => '', 'desc' => '',
                    'hls' => '', 'epg_url' => '', 'active' => 1, 'order' => 900,
                );
                tcore_save_channels($list);
                echo '<div class="notice notice-success is-dismissible"><p>Chaine ajoutee : '
                   . esc_html($name) . '</p></div>';
            }
        }
    }

    /* ---- Suppression ---- */
    if ( isset($_POST['tcore_del']) && check_admin_referer('tcore_ch_settings','tcore_ch_nonce') ) {
        $slug = sanitize_key( wp_unslash($_POST['tcore_del']) );
        $list = tcore_all_channels();
        if ( isset($list[$slug]) ) {
            $n = $list[$slug]['name'];
            unset($list[$slug]);
            tcore_save_channels($list);
            echo '<div class="notice notice-success is-dismissible"><p>Chaine supprimee : '
               . esc_html($n) . '</p></div>';
        }
    }

    /* ---- Enregistrement de la grille ---- */
    if ( isset($_POST['tcore_save_all']) && check_admin_referer('tcore_ch_settings','tcore_ch_nonce') ) {
        $list = tcore_all_channels();
        foreach ( $list as $slug => $c ) {
            $k = sanitize_key($slug);

            foreach ( array('name','cat','desc') as $f ) {
                if ( isset($_POST["tc_{$f}_{$k}"]) ) {
                    $list[$slug][$f] = sanitize_text_field( wp_unslash($_POST["tc_{$f}_{$k}"]) );
                }
            }

            /* Adresses : nettoyage volontairement leger.
               esc_url_raw() retire les crochets, or nos adresses portent
               des macros — [TIMESTAMP_MACRO], [IDFA_MACRO] — que le
               lecteur remplace au moment de l'appel. Nettoyees, elles ne
               valaient plus rien, et le champ semblait ignore. */
            foreach ( array('hls','logo','epg_url') as $f ) {
                if ( ! isset($_POST["tc_{$f}_{$k}"]) ) continue;
                $v = wp_strip_all_tags( trim( wp_unslash($_POST["tc_{$f}_{$k}"]) ) );
                if ( '' !== $v && ! preg_match('#^https?://#i', $v) ) {
                    echo '<div class="notice notice-error"><p>'
                       . esc_html($c['name'] . ' — ' . strtoupper($f)
                                . ' ignore : l\'adresse doit commencer par http.')
                       . '</p></div>';
                    continue;
                }
                $list[$slug][$f] = $v;
            }

            $list[$slug]['active'] = ! empty($_POST["tc_active_{$k}"]) ? 1 : 0;
            if ( isset($_POST["tc_order_{$k}"]) ) {
                $list[$slug]['order'] = (int) $_POST["tc_order_{$k}"];
            }
        }
        tcore_save_channels($list);
        echo '<div class="notice notice-success is-dismissible"><p>Chaines enregistrees.</p></div>';
    }

    /* ---- Bandeaux du hero ---- */
    if ( isset($_POST['tcore_save_banners']) && check_admin_referer('tcore_ch_settings','tcore_ch_nonce') ) {
        $b = array();
        for ( $i = 0; $i < 6; $i++ ) {
            $img  = isset($_POST["tcb_img_$i"])  ? trim( wp_unslash($_POST["tcb_img_$i"]) )  : '';
            $slug = isset($_POST["tcb_slug_$i"]) ? sanitize_key( wp_unslash($_POST["tcb_slug_$i"]) ) : '';
            $img  = wp_strip_all_tags( $img );
            if ( '' === $img ) continue;
            if ( ! preg_match('#^https?://#i', $img) ) {
                echo '<div class="notice notice-error"><p>Bandeau ' . ($i+1)
                   . ' ignore : l\'adresse doit commencer par http.</p></div>';
                continue;
            }
            $b[] = array( 'img' => $img, 'slug' => $slug );
        }
        update_option( 'tcore_hero_banners', $b );
        echo '<div class="notice notice-success is-dismissible"><p>Bandeaux enregistres.</p></div>';
    }

    $channels = tcore_all_channels();
    $banners  = get_option( 'tcore_hero_banners', array() );
    ?>
    <div class="wrap">
    <h1>Chaines</h1>
    <p style="color:#666;max-width:760px">
      La liste vit en base : ajoutez, renommez ou desactivez une chaine sans
      toucher au code. <strong>Importer le feed</strong> aligne noms et vignettes
      sur ce qui est reellement diffuse — les adresses de lecture, elles, restent
      saisies ici, car celles du feed portent des macros d'application inutilisables
      dans un navigateur.
    </p>
    <p style="color:#666">Le tag publicitaire est commun a tout le site et se regle
      dans <a href="<?php echo esc_url( admin_url('admin.php?page=tcore') ); ?>">Reglages</a>.</p>

    <form method="POST">
    <?php wp_nonce_field('tcore_ch_settings','tcore_ch_nonce'); ?>

    <p style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:18px 0">
      <button type="submit" name="tcore_sync" value="1" class="button">Importer le feed</button>
      <span style="color:#999">|</span>
      <input type="text" name="tcore_add_name" placeholder="Nom d'une nouvelle chaine" style="width:250px">
      <button type="submit" class="button">Ajouter</button>
      <span style="flex:1"></span>
      <button type="submit" name="tcore_save_all" value="1" class="button button-primary">Enregistrer</button>
    </p>

    <h2 style="margin-top:26px">Bandeaux de la page d\'accueil</h2>
    <p style="color:#666;max-width:760px">
      Ils defilent en fondu toutes les huit secondes et sont cliquables.
      Format conseille : <strong>1920 &times; 620</strong>, sujet centre &mdash;
      l\'image est recadree en hauteur. Les 140 derniers pixels du bas portent
      la signature : gardez-y une zone calme.
    </p>
    <table class="tc-tbl" style="margin-bottom:26px">
      <thead><tr>
        <th style="width:110px">Apercu</th>
        <th>Adresse de l\'image</th>
        <th style="width:220px">Chaine liee</th>
      </tr></thead>
      <tbody>
      <?php for ( $i = 0; $i < 6; $i++ ) :
        $bi = isset($banners[$i]) ? $banners[$i] : array( 'img' => '', 'slug' => '' ); ?>
      <tr>
        <td><?php if ( $bi['img'] ) : ?>
              <img src="<?php echo esc_url($bi['img']); ?>" alt=""
                   style="width:100px;height:32px;object-fit:cover;border-radius:4px;border:1px solid #ddd">
            <?php else : ?>
              <div style="width:100px;height:32px;background:#eee;border-radius:4px"></div>
            <?php endif; ?></td>
        <td><input type="text" name="tcb_img_<?php echo $i; ?>"
                   value="<?php echo esc_attr($bi['img']); ?>"
                   placeholder="https://radiotool.fr/tackendo/images/Banner_1.jpg"></td>
        <td><select name="tcb_slug_<?php echo $i; ?>" style="width:100%">
              <option value="">&mdash; aucune &mdash;</option>
              <?php foreach ( $channels as $cslug => $cc ) : ?>
                <option value="<?php echo esc_attr($cslug); ?>" <?php selected( $bi['slug'], $cslug ); ?>>
                  <?php echo esc_html($cc['name']); ?>
                </option>
              <?php endforeach; ?>
            </select></td>
      </tr>
      <?php endfor; ?>
      </tbody>
    </table>
    <p style="margin-bottom:30px">
      <button type="submit" name="tcore_save_banners" value="1" class="button button-primary">Enregistrer les bandeaux</button>
    </p>

    <h2>Grille des chaines</h2>

    <style>
      .tc-tbl{width:100%;border-collapse:collapse;font-size:12px;background:#fff}
      .tc-tbl th{background:#f0f0f1;padding:8px;text-align:left;border-bottom:2px solid #ccc;white-space:nowrap}
      .tc-tbl td{padding:6px;border-bottom:1px solid #eee;vertical-align:middle}
      .tc-tbl tr.off td{opacity:.45}
      .tc-tbl input[type=text]{width:100%;padding:4px 6px;font-size:11px;border:1px solid #ccc;border-radius:3px;box-sizing:border-box}
      .tc-tbl input.num{width:52px;text-align:center}
      .tc-thumb{width:64px;height:36px;object-fit:cover;border-radius:4px;border:1px solid #ddd;display:block;background:#eee}
    </style>

    <table class="tc-tbl">
      <thead><tr>
        <th style="width:32px">On</th>
        <th style="width:52px">Ordre</th>
        <th style="width:70px">Image</th>
        <th style="width:150px">Nom</th>
        <th style="width:96px">Categorie</th>
        <th>Flux HLS (web)</th>
        <th>Vignette</th>
        <th>EPG</th>
        <th style="width:170px">Description</th>
        <th style="width:40px"></th>
      </tr></thead>
      <tbody>
      <?php foreach ( $channels as $slug => $c ) :
        $k = sanitize_key($slug); ?>
      <tr class="<?php echo empty($c['active']) ? 'off' : ''; ?>">
        <td><input type="checkbox" name="tc_active_<?php echo $k; ?>" value="1" <?php checked( ! empty($c['active']) ); ?>></td>
        <td><input class="num" type="text" name="tc_order_<?php echo $k; ?>" value="<?php echo esc_attr( isset($c['order']) ? $c['order'] : 999 ); ?>"></td>
        <td><?php if ( ! empty($c['logo']) ) : ?>
              <img class="tc-thumb" src="<?php echo esc_url($c['logo']); ?>" alt="">
            <?php else : ?><div class="tc-thumb"></div><?php endif; ?></td>
        <td><input type="text" name="tc_name_<?php echo $k; ?>" value="<?php echo esc_attr($c['name']); ?>">
            <small style="color:#999"><?php echo esc_html($slug); ?></small></td>
        <td><input type="text" name="tc_cat_<?php echo $k; ?>" value="<?php echo esc_attr( isset($c['cat']) ? $c['cat'] : '' ); ?>"></td>
        <td><input type="text" name="tc_hls_<?php echo $k; ?>" value="<?php echo esc_attr( isset($c['hls']) ? $c['hls'] : '' ); ?>" placeholder="https://ssai.aniview.com/api/v1/hls/stream.m3u8?..."></td>
        <td><input type="text" name="tc_logo_<?php echo $k; ?>" value="<?php echo esc_attr( isset($c['logo']) ? $c['logo'] : '' ); ?>"></td>
        <td><input type="text" name="tc_epg_url_<?php echo $k; ?>" value="<?php echo esc_attr( isset($c['epg_url']) ? $c['epg_url'] : '' ); ?>"></td>
        <td><input type="text" name="tc_desc_<?php echo $k; ?>" value="<?php echo esc_attr( isset($c['desc']) ? $c['desc'] : '' ); ?>"></td>
        <td><button type="submit" name="tcore_del" value="<?php echo esc_attr($slug); ?>"
              class="button button-small" style="color:#b32d2e"
              onclick="return confirm('Supprimer definitivement cette chaine ?')">X</button></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>

    <p style="margin-top:16px">
      <button type="submit" name="tcore_save_all" value="1" class="button button-primary">Enregistrer</button>
    </p>
    </form>
    </div>
    <?php
}

function tcore_cache_logos() {
    if ( get_option( 'tcore_logos_cached_v2', false ) ) return;

    $logos = array(
        'roku.png'        => 'https://groupenetradio.fr/wp-content/uploads/2025/01/Roku-Logo.png',
        'firetv.png'      => 'https://groupenetradio.fr/wp-content/uploads/2025/01/Amazon-Fire-TV-tUiO2b.png',
        'bouygues.png'    => 'https://groupenetradio.fr/wp-content/uploads/2025/01/Bouygues_Telecom.png',
        'netgem.jpg'      => 'https://groupenetradio.fr/wp-content/uploads/2025/01/netgem_logo.jpg',
        'cloudtv.jpg'     => 'https://groupenetradio.fr/wp-content/uploads/2025/01/cloudtvos_logo.jpg',
        'neotv.webp'      => 'https://groupenetradio.fr/wp-content/uploads/2025/01/temp_image_20250307_074757_3bcd16cc-fc58-4900-849c-2e7b981bcd4d.webp',
        'zeop.jpg'        => 'https://groupenetradio.fr/wp-content/uploads/2025/01/zeop_logo.jpg',
        'vialis.svg'      => 'https://www.vialis.net/themes/custom/vialis/images/logotype-vialis.svg',
        'viznet.png'      => 'https://viznet.tv/wp-content/uploads/2023/09/logo-viznet-blanc.png',
        'vodfactory.png'  => 'https://cdn.prod.website-files.com/5d1b4c09d7f0159a77c39cb1/5d1b4c51d7f0154fa4c3a021_logoVodFactory-RVB.png',
        'viloud.png'      => 'https://dm0801zzlveea.cloudfront.net/wp-content/uploads/2019/02/logo_viloud_web_mini.png',
        'broadpeak.svg'   => 'https://broadpeak.tv/wp-content/uploads/Broadpeak_Logo.svg',
        'hosttec.png'     => 'https://hosttec.online/img/cropped-hosttecnovologosite.png',
        'slingtv.png'     => 'https://upload.wikimedia.org/wikipedia/commons/e/e4/Sling_TV_logo.svg',
    );

    $upload_dir = wp_upload_dir();
    $logo_dir   = $upload_dir['basedir'] . '/tcore-logos/';
    $logo_url   = $upload_dir['baseurl'] . '/tcore-logos/';
    if ( ! file_exists( $logo_dir ) ) wp_mkdir_p( $logo_dir );

    $cached = array();
    foreach ( $logos as $filename => $remote_url ) {
        $local_path = $logo_dir . $filename;
        if ( ! file_exists( $local_path ) ) {
            $response = wp_remote_get( $remote_url, array( 'timeout' => 10 ) );
            if ( ! is_wp_error( $response ) && wp_remote_retrieve_response_code( $response ) === 200 ) {
                file_put_contents( $local_path, wp_remote_retrieve_body( $response ) );
            }
        }
        if ( file_exists( $local_path ) && filesize( $local_path ) > 500 ) {
            $cached[ $filename ] = $logo_url . $filename;
        }
    }
    update_option( 'tcore_logo_urls', $cached );
    update_option( 'tcore_logos_cached_v2', true );
}

function tcore_logo_url( $filename ) {
    $cached = get_option( 'tcore_logo_urls', array() );
    return isset( $cached[ $filename ] ) ? $cached[ $filename ] : '';
}
