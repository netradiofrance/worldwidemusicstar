<?php
/**
 * CE QUI PASSE MAINTENANT — lu depuis le playout.
 *
 * L'EPG publie une grille theorique qui n'a jamais correspondu a l'antenne :
 * il repart d'une heure de reference plutot que du dernier demarrage reel du
 * flux. Un redemarrage, une coupure, un rattrapage, et la grille derive sans
 * jamais se resynchroniser.
 *
 * On lit donc la source. Le playout enchaine un fichier de concatenation dont
 * chaque entree porte sa duree exacte ; il suffit de connaitre l'instant ou
 * la lecture a commence pour savoir ou l'on en est. Cet instant, le manifeste
 * HLS le donne : EXT-X-PROGRAM-DATE-TIME horodate le segment en cours de
 * diffusion.
 *
 * L'EPG reste en place : les distributeurs s'en servent, et ce n'est pas le
 * meme usage.
 *
 * Le relais est cote serveur. La page web interroge son propre domaine, ce
 * qui supprime la question des origines croisees — celle qui empechait
 * jusqu'ici l'affichage sur la moitie des chaines.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

/** Racine du playout, telle qu'exposee par tackendo.tv. */
const TCORE_PLAYOUT_BASE = 'https://tackendo.tv';


/* ====================================================================
   POINT DE TERMINAISON
   ==================================================================== */

add_action( 'rest_api_init', function () {
    register_rest_route( 'tcore/v1', '/nowplaying/(?P<channel>[a-z0-9-]+)', array(
        'methods'             => 'GET',
        'permission_callback' => '__return_true',
        'callback'            => 'tcore_nowplaying_rest',
    ) );
} );

function tcore_nowplaying_rest( $req ) {
    $chan = preg_replace( '/[^a-z0-9-]/', '', $req['channel'] );
    $data = tcore_nowplaying( $chan );

    if ( empty( $data ) ) {
        return new WP_REST_Response( array( 'error' => 'unavailable' ), 503 );
    }

    $r = new WP_REST_Response( $data, 200 );
    // Vingt secondes : assez pour absorber les rafales de visiteurs, assez
    // court pour qu'un changement de titre se voie presque tout de suite.
    $r->header( 'Cache-Control', 'public, max-age=20' );
    return $r;
}


/* ====================================================================
   CALCUL
   ==================================================================== */

/**
 * Ce qui passe et ce qui suit, sur une chaine donnee.
 *
 * @param string $chan Identifiant du playout, par exemple channel-11.
 */
function tcore_nowplaying( $chan ) {

    $cache_key = 'tcore_np_' . $chan;
    $cached    = get_transient( $cache_key );
    if ( false !== $cached ) return $cached;

    $items = tcore_playout_items( $chan );
    if ( empty( $items ) ) return array();

    $started = tcore_playout_started( $chan );
    if ( ! $started ) return array();

    $total = 0.0;
    foreach ( $items as $it ) $total += $it['dur'];
    if ( $total <= 0 ) return array();

    /* Position dans la liste.
     *
     * Le playout rejoue la liste en boucle : le modulo suffit, sans avoir a
     * savoir combien de tours ont ete faits. */
    /* On retranche le retard de diffusion : ce qui compte est ce que le
       spectateur voit, pas ce que ffmpeg encode. */
    $delay   = tcore_playout_delay( $chan );
    $elapsed = fmod( max( 0, time() - $started - $delay ), $total );

    $acc = 0.0;
    $idx = 0;
    foreach ( $items as $i => $it ) {
        if ( $elapsed < $acc + $it['dur'] ) { $idx = $i; break; }
        $acc += $it['dur'];
    }

    /* Habillages : tapis publicitaire, jingles de decrochage, virgules.

       Ils occupent l'antenne, donc ils comptent dans le calcul du temps.
       Mais afficher "sweeper03" ou "ad-slate" n'apprend rien au spectateur :
       on montre alors le titre suivant, celui qui va reprendre. */
    $n = count( $items );
    $shown = $idx;
    for ( $k = 0; $k < $n; $k++ ) {
        if ( ! tcore_is_filler( $items[ ($idx + $k) % $n ]['label'] ) ) {
            $shown = ( $idx + $k ) % $n;
            break;
        }
    }
    $on_air_is_filler = ( $shown !== $idx );

    $cur      = $items[ $idx ];
    $into     = $elapsed - $acc;                 // secondes ecoulees du titre
    $next_idx = ( $shown + 1 ) % count( $items );
    for ( $k = 0; $k < count( $items ); $k++ ) {
        $t = ( $shown + 1 + $k ) % count( $items );
        if ( ! tcore_is_filler( $items[ $t ]['label'] ) ) { $next_idx = $t; break; }
    }

    $out = array(
        'channel' => $chan,
        'now'     => array(
            'artist'    => $items[ $shown ]['artist'],
            'title'     => $items[ $shown ]['title'],
            'label'     => $items[ $shown ]['label'],
            // Vrai quand l'antenne diffuse un habillage : le titre annonce
            // est celui qui suit, pas celui qui passe.
            'upcoming'  => $on_air_is_filler,
            'duration'  => round( $cur['dur'] ),
            'elapsed'   => round( $into ),
            'remaining' => round( $cur['dur'] - $into ),
            'started_at'=> time() - (int) $into,
            'thumb'     => tcore_playout_thumb( $chan, $items[ $shown ]['label'] ),
        ),
        'next'    => array(
            'artist'   => $items[ $next_idx ]['artist'],
            'title'    => $items[ $next_idx ]['title'],
            'label'    => $items[ $next_idx ]['label'],
            'duration' => round( $items[ $next_idx ]['dur'] ),
            'starts_at'=> time() + (int) round( $cur['dur'] - $into ),
        ),
        'server_time' => time(),
        // Retard mesure entre l'encodage et l'ecran, en secondes.
        'delay'       => $delay,
    );

    set_transient( $cache_key, $out, 20 );
    return $out;
}

/**
 * Un element est-il un habillage plutot qu'un programme ?
 *
 * La convention du playout : les titres portent "Artiste - Titre" ou un nom
 * de fichier explicite, les habillages un identifiant technique.
 */
function tcore_is_filler( $label ) {
    $l = strtolower( $label );
    foreach ( array( 'sweeper', 'ad-slate', 'adslate', 'adbreak', 'jingle',
                     'bumper', 'ident', 'filler', 'tapis', 'promo-' ) as $p ) {
        if ( 0 === strpos( $l, $p ) ) return true;
    }
    return false;
}

/**
 * Vignette d'un titre, telle que le playout la nomme.
 *
 * Le nom du fichier porte des espaces : ils doivent etre encodes, sans quoi
 * l'adresse est invalide et l'image ne s'affiche pas.
 */
function tcore_playout_thumb( $chan, $label ) {
    if ( '' === $label ) return '';
    return TCORE_PLAYOUT_BASE . '/api/thumbnails/' . rawurlencode( $chan )
         . '/' . rawurlencode( $label . '.jpg' );
}

/**
 * Liste diffusee, lue depuis le fichier de concatenation.
 *
 * Format produit par le playout :
 *
 *     file '/srv/.../1080p/Zelie - Je ne serai jamais.mp4'
 *     inpoint 0.0
 *     outpoint 263.21
 *
 * La duree est la difference entre les deux points, et non la duree du
 * fichier : le playout coupe parfois les silences de fin.
 */
function tcore_playout_items( $chan ) {

    $key = 'tcore_pl_' . $chan;
    $c   = get_transient( $key );
    if ( false !== $c ) return $c;

    $url = TCORE_PLAYOUT_BASE . '/playlists/' . $chan . '_concat.txt';
    $r   = wp_remote_get( $url, array( 'timeout' => 10 ) );
    if ( is_wp_error( $r ) || 200 !== wp_remote_retrieve_response_code( $r ) ) {
        return array();
    }

    $items = array();
    $cur   = null;

    foreach ( preg_split( "/\r?\n/", wp_remote_retrieve_body( $r ) ) as $line ) {
        $line = trim( $line );

        if ( 0 === strpos( $line, 'file ' ) ) {
            if ( $cur ) $items[] = $cur;
            $path  = trim( substr( $line, 5 ), " '\"" );
            $label = pathinfo( $path, PATHINFO_FILENAME );

            // "Artiste - Titre" quand la convention est respectee, sinon on
            // garde le nom entier comme titre.
            /* Certains fichiers utilisent des soulignes au lieu d'espaces :
               "MIMAA_Du_pastis_et_des_larmes". On les rend lisibles. */
            $clean = str_replace( '_', ' ', $label );

            $artist = '';
            $title  = $clean;

            if ( false !== strpos( $clean, ' - ' ) ) {
                // Convention principale : "Artiste - Titre".
                list( $artist, $title ) = array_map( 'trim', explode( ' - ', $clean, 2 ) );

            } elseif ( false !== strpos( $label, '_' ) ) {
                /* Fichiers a soulignes, sans separateur explicite :
                   "MIMAA_Du_pastis_et_des_larmes", "Peter_Kitsch_Billy".

                   Le premier mot est l'artiste. Quand il est tout en
                   majuscules, il se distingue nettement du reste et on prend
                   ce seul mot ; sinon on suppose un nom en deux parties
                   seulement si le second commence par une majuscule, ce qui
                   evite de couper un titre au milieu. */
                $words = preg_split( '/\s+/', $clean, -1, PREG_SPLIT_NO_EMPTY );
                if ( count( $words ) >= 2 ) {
                    /* Un seul mot d'artiste par defaut.

                       "Mimaa Garage Perez" est indecidable en soi : rien ne
                       dit si l'artiste tient en un ou deux mots. Mais MIMAA
                       apparait ailleurs dans la meme liste avec un separateur
                       clair, et cette occurrence-la fait foi. Le nom d'artiste
                       en deux mots reste donc l'exception, reconnue plus bas
                       quand la liste entiere le confirme. */
                    $artist = $words[0];
                    $title  = implode( ' ', array_slice( $words, 1 ) );
                }
            }

            /* Casse : "PONT DES AMANTS" devient "Pont Des Amants". Les noms
               tout en majuscules viennent du nommage des fichiers, pas d'une
               intention editoriale. */
            if ( $title === mb_strtoupper( $title, 'UTF-8' ) && mb_strlen( $title ) > 3 ) {
                $title = mb_convert_case( mb_strtolower( $title, 'UTF-8' ),
                                          MB_CASE_TITLE, 'UTF-8' );
            }
            /* L'artiste garde ses capitales quand elles sont courtes — un
               nom de scene comme MYLA ou SAM s'ecrit ainsi. Au-dela, c'est
               le nommage du fichier qui crie, pas l'artiste. */
            if ( $artist !== '' && $artist === mb_strtoupper( $artist, 'UTF-8' )
                 && mb_strlen( $artist ) > 6 ) {
                $artist = mb_convert_case( mb_strtolower( $artist, 'UTF-8' ),
                                           MB_CASE_TITLE, 'UTF-8' );
            }
            $cur = array( 'label' => $label, 'artist' => $artist,
                          'title' => $title, 'in' => 0.0, 'out' => 0.0, 'dur' => 0.0 );

        } elseif ( $cur && 0 === strpos( $line, 'inpoint ' ) ) {
            $cur['in'] = (float) substr( $line, 8 );

        } elseif ( $cur && 0 === strpos( $line, 'outpoint ' ) ) {
            $cur['out'] = (float) substr( $line, 9 );
            $cur['dur'] = max( 0.0, $cur['out'] - $cur['in'] );
        }
    }
    if ( $cur ) $items[] = $cur;

    // Une entree sans duree fausserait tout le cumul.
    $items = array_values( array_filter( $items, function ( $i ) { return $i['dur'] > 0.5; } ) );

    // Cinq minutes : la liste est regeneree une fois par jour.
    set_transient( $key, $items, 5 * MINUTE_IN_SECONDS );
    return $items;
}

/**
 * Retard entre l'encodage et l'ecran, en secondes.
 *
 * Le playout encode en avance : les segments s'accumulent dans la fenetre du
 * manifeste avant qu'un lecteur ne les demande. Le spectateur regarde donc le
 * bord ancien de cette fenetre, pas ce que ffmpeg produit a l'instant.
 *
 * Sur nos chaines la fenetre fait pres de cent segments de quatre secondes,
 * soit plus de six minutes : de quoi annoncer un ou deux titres d'avance si
 * on l'ignore. On la mesure plutot que de la fixer, pour rester juste si le
 * reglage change.
 */
function tcore_playout_delay( $chan ) {

    $key = 'tcore_delay_' . $chan;
    $c   = get_transient( $key );
    if ( false !== $c ) return $c;

    $delay = 0;

    foreach ( array( '1080p', '720p', '480p' ) as $rendition ) {
        $r = wp_remote_get(
            TCORE_PLAYOUT_BASE . '/live/' . $chan . '/' . $rendition . '.m3u8',
            array( 'timeout' => 8 )
        );
        if ( is_wp_error( $r ) || 200 !== wp_remote_retrieve_response_code( $r ) ) continue;

        $body = wp_remote_retrieve_body( $r );

        $durations = array();
        if ( preg_match_all( '/#EXTINF:([\d.]+)/', $body, $m ) ) {
            $durations = array_map( 'floatval', $m[1] );
        }
        if ( empty( $durations ) ) continue;

        /* Position du lecteur dans la fenetre.

           La fenetre entiere avait d'abord ete retranchee, ce qui donnait
           six minutes de retard et annoncait un titre en avance. C'etait
           trop : un lecteur ne demarre pas au segment le plus ancien mais
           pres du bord direct.

           La regle du protocole HLS est de commencer trois segments avant
           la fin. Le retard reel est donc la duree de ces trois segments,
           a quoi s'ajoute le temps que le manifeste lui-meme a pris a etre
           publie. */
        $tail  = array_slice( $durations, -3 );
        $delay = (int) round( array_sum( $tail ) );

        /* Age du manifeste : entre le dernier segment annonce et
           maintenant. ffmpeg publie avec un temps d'avance qui compte
           lui aussi dans ce que voit le spectateur. */
        if ( preg_match( '/#EXT-X-PROGRAM-DATE-TIME:(\S+)/', $body, $mm ) ) {
            $first = strtotime( $mm[1] );
            $last  = $first + array_sum( $durations );
            $age   = time() - $last;
            if ( $age > 0 && $age < 120 ) $delay += (int) $age;
        }

        break;
    }

    set_transient( $key, $delay, 2 * MINUTE_IN_SECONDS );
    return $delay;
}

/**
 * Instant ou la lecture de la liste a commence, en secondes Unix.
 *
 * Le manifeste HLS horodate le premier segment de sa fenetre et donne le
 * numero de sequence correspondant. Chaque segment durant quatre secondes,
 * on remonte au debut du flux :
 *
 *     debut = date du premier segment expose - (numero de sequence x duree)
 *
 * C'est cette valeur qui manquait a l'EPG : il partait d'une heure theorique
 * et ne se resynchronisait jamais apres un redemarrage.
 */
function tcore_playout_started( $chan ) {

    $key = 'tcore_start_' . $chan;
    $c   = get_transient( $key );
    if ( false !== $c ) return $c;

    /* Horodatage ecrit par le playout au lancement de la lecture.

       Le manifeste HLS a d'abord servi de source, mais son numero de
       sequence ne se remet pas a zero quand ffmpeg redemarre en fin de
       liste : il remonte au tout premier lancement, et la derive s'ajoute a
       chaque tour. C'est la meme erreur qui rendait la grille EPG fausse. */
    $url = TCORE_PLAYOUT_BASE . '/playlists/' . $chan . '_started.txt';
    $r   = wp_remote_get( $url, array( 'timeout' => 8 ) );

    if ( ! is_wp_error( $r ) && 200 === wp_remote_retrieve_response_code( $r ) ) {
        $t = (int) trim( wp_remote_retrieve_body( $r ) );
        if ( $t > 1600000000 ) {          // horodatage plausible
            set_transient( $key, $t, MINUTE_IN_SECONDS );
            return $t;
        }
    }

    return 0;
}
