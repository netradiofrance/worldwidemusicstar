<?php
/**
 * CHAINES — liste modifiable depuis l'administration.
 *
 * La liste etait auparavant ecrite en dur dans ce fichier : ajouter une
 * chaine, en renommer une ou en retirer une demandait de modifier le code
 * et de redeployer le plugin. L'ecran d'administration ne permettait que
 * de renseigner les adresses de chaines deja declarees ici.
 *
 * Elle vit desormais en base, dans une seule option WordPress. Le code de
 * secours plus bas ne sert qu'a la premiere installation : au premier
 * chargement, il alimente la base, puis n'est plus jamais lu.
 *
 * Le tag publicitaire reste global au site — il se regle dans l'ecran
 * principal du plugin, et vaut pour toutes les chaines.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

const TCORE_CH_OPTION = 'tcore_channels_list';

/** Feed qui fait autorite sur ce qui est reellement a l'antenne. */
const TCORE_FEED_URL = 'https://radiotool.fr/tackendo/tackendo_fire.json';


/* ====================================================================
   LECTURE
   ==================================================================== */

/**
 * Toutes les chaines, actives et inactives, dans l'ordre d'affichage.
 */
function tcore_all_channels() {
    $list = get_option( TCORE_CH_OPTION, null );

    // Premiere installation : on sauve la liste historique en base.
    if ( null === $list || ! is_array( $list ) ) {
        $list = tcore_seed_channels();
        update_option( TCORE_CH_OPTION, $list );
    }

    uasort( $list, function ( $a, $b ) {
        $oa = isset( $a['order'] ) ? (int) $a['order'] : 999;
        $ob = isset( $b['order'] ) ? (int) $b['order'] : 999;
        if ( $oa === $ob ) return strcmp( $a['name'], $b['name'] );
        return $oa - $ob;
    } );
    return $list;
}

/**
 * Les chaines a montrer au public.
 *
 * Conserve le nom historique : le reste du plugin et les gabarits
 * l'appellent ainsi.
 */
function tcore_channels() {
    $out = array();
    foreach ( tcore_all_channels() as $slug => $c ) {
        if ( empty( $c['active'] ) ) continue;
        $out[ $slug ] = $c;
    }
    return $out;
}

function tcore_get_channel( $slug ) {
    $all = tcore_all_channels();
    return isset( $all[ $slug ] ) ? $all[ $slug ] : null;
}

/**
 * Enregistre la liste complete.
 *
 * Aucun nettoyage d'URL ici : esc_url_raw() retire les crochets, or nos
 * adresses portent des macros — [TIMESTAMP_MACRO], [IDFA_MACRO] — que le
 * lecteur remplace au moment de l'appel. Les avoir nettoyees rendait les
 * adresses inutilisables tout en donnant l'impression que le champ
 * n'avait pas ete pris en compte.
 */
function tcore_save_channels( $list ) {
    update_option( TCORE_CH_OPTION, $list );
}


/* ====================================================================
   IMPORT DEPUIS LE FEED
   ==================================================================== */

/**
 * Lit le feed et renvoie les chaines a l'antenne.
 *
 * Le feed porte les noms et les vignettes des applications. Il ne porte
 * pas d'adresse utilisable sur le web : ses URL contiennent des macros
 * d'application — identifiant publicitaire, paquet, magasin — qui n'ont
 * aucun sens dans un navigateur. L'adresse de lecture reste donc saisie
 * a la main.
 */
function tcore_fetch_feed() {
    $r = wp_remote_get( TCORE_FEED_URL, array( 'timeout' => 12 ) );
    if ( is_wp_error( $r ) || 200 !== wp_remote_retrieve_response_code( $r ) ) {
        return array();
    }
    $d = json_decode( wp_remote_retrieve_body( $r ), true );
    if ( empty( $d['tvSpecials'] ) ) return array();

    $out = array();
    foreach ( $d['tvSpecials'] as $t ) {

        // Le titre a longtemps ete vide, le nom se trouvant en tete de
        // shortDescription. On accepte les deux formes.
        $name = ! empty( $t['title'] ) ? trim( $t['title'] ) : '';
        if ( '' === $name && ! empty( $t['shortDescription'] ) ) {
            $name = trim( strstr( $t['shortDescription'] . ' - ', ' - ', true ) );
        }
        if ( '' === $name ) continue;

        $desc = '';
        if ( ! empty( $t['shortDescription'] ) ) {
            $p = strstr( $t['shortDescription'], ' - ' );
            $desc = $p ? trim( substr( $p, 3 ) ) : trim( $t['shortDescription'] );
        }

        $thumb = '';
        foreach ( array( 'thumbnail', 'image', 'poster' ) as $k ) {
            if ( ! empty( $t[ $k ] ) ) { $thumb = $t[ $k ]; break; }
        }

        $out[] = array(
            'name'  => $name,
            'desc'  => $desc,
            'thumb' => $thumb,
            'genre' => ! empty( $t['genres'][0] ) ? $t['genres'][0] : '',
        );
    }
    return $out;
}

/** Cle de rapprochement : insensible a la casse et a la ponctuation. */
function tcore_match_key( $name ) {
    return strtolower( preg_replace( '/[^a-z0-9]/i', '', $name ) );
}

/**
 * Aligne la liste sur le feed.
 *
 * Cree ce qui manque, met a jour noms et vignettes, et desactive ce qui
 * n'est plus diffuse — sans jamais supprimer : une chaine eteinte revient
 * souvent, et son adresse de lecture merite d'etre conservee.
 */
function tcore_sync_from_feed() {
    $feed = tcore_fetch_feed();
    if ( empty( $feed ) ) {
        return array( 'error' => 'Feed injoignable ou vide.' );
    }

    $list  = tcore_all_channels();
    $index = array();
    foreach ( $list as $slug => $c ) {
        $index[ tcore_match_key( $c['name'] ) ] = $slug;
        // Un ancien nom peut avoir ete conserve pour ne pas casser une
        // adresse deja indexee : on rapproche aussi par identifiant.
        $index[ tcore_match_key( $slug ) ] = $slug;
    }

    $added = $updated = 0;
    $seen  = array();
    $order = 0;

    foreach ( $feed as $f ) {
        $k    = tcore_match_key( $f['name'] );
        $slug = isset( $index[ $k ] ) ? $index[ $k ] : '';

        if ( ! $slug ) {
            $slug = sanitize_title( $f['name'] );
            $list[ $slug ] = array(
                'name'    => $f['name'],
                'cat'     => $f['genre'] ? $f['genre'] : 'Music',
                'logo'    => $f['thumb'],
                'desc'    => $f['desc'],
                'hls'     => '',      // a saisir : adresse web
                'epg_url' => '',
                'active'  => 1,
                'order'   => $order,
            );
            $added++;
        } else {
            $list[ $slug ]['name']   = $f['name'];
            if ( $f['thumb'] ) $list[ $slug ]['logo'] = $f['thumb'];
            if ( $f['desc'] )  $list[ $slug ]['desc'] = $f['desc'];
            $list[ $slug ]['active'] = 1;
            $list[ $slug ]['order']  = $order;
            $updated++;
        }
        $seen[ $slug ] = true;
        $order++;
    }

    $off = 0;
    foreach ( $list as $slug => $c ) {
        if ( ! isset( $seen[ $slug ] ) && ! empty( $c['active'] ) ) {
            $list[ $slug ]['active'] = 0;
            $off++;
        }
    }

    tcore_save_channels( $list );
    return array( 'added' => $added, 'updated' => $updated, 'disabled' => $off );
}


/* ====================================================================
   LISTE HISTORIQUE
   Lue une seule fois, a la premiere installation.
   ==================================================================== */

function tcore_seed_channels() {
    $raw = array(
        'fast-music-rising' => array( 'Fast Music Rising', 'Music', 'channel-01',
            'https://tackendo.com/wp-content/uploads/2025/06/FAST-MUSIC-RISING-1080-x-1080-300x300.jpg',
            'Unsigned & independent artists from around the world.', 1 ),
        'made-in-france' => array( 'Made in France', 'Lifestyle', 'channel-15',
            'https://tackendo.com/wp-content/uploads/2026/04/Made-in-France-TV-1024x576.png',
            "Immersive tour of France's heritage.", 1 ),
        'expat-tv' => array( 'Expat TV', 'Lifestyle', 'channel-03',
            'https://tackendo.com/wp-content/uploads/2026/04/EXPAT-TV-1920-x-1080-px-1-1024x576.png',
            'Resources for expats and life abroad.', 0 ),
        'lo-fi' => array( 'Lo-Fi Music', 'Music', 'channel-04',
            '', 'Lo-fi beats to study and relax to.', 1 ),
        'summer-vibes' => array( 'Summer Vibes', 'Music', 'channel-05',
            '', 'Sunshine, beaches and warm-weather music.', 1 ),
        'fireplace' => array( 'Fireplace', 'Lifestyle', 'channel-06',
            '', 'A warm, relaxing fireplace channel — perfect ambience 24/7.', 1 ),
        'winter-ambience' => array( 'Winter Ambience', 'Lifestyle', 'channel-07',
            '', 'Snowy scenes and cosy winter atmospheres.', 1 ),
        'synthwave' => array( 'Synthwave', 'Music', 'channel-08',
            '', 'Retro-futuristic synth music and neon visuals.', 1 ),
        'epic' => array( 'Epic Music', 'Music', 'channel-09',
            '', 'Cinematic and orchestral music for focus.', 1 ),
        'awe-cosmos' => array( 'AWE: COSMOS', 'Lifestyle', 'channel-16',
            '', 'Space, science and the wonder of the universe.', 1 ),
        'netradio-vision' => array( 'Netradio Vision', 'Music', 'channel-11',
            '', 'Pop culture, emerging music and the creator economy.', 1 ),
        'urban-street' => array( 'Urban Street', 'Music', 'channel-12',
            '', 'Hip-hop, street culture and urban sounds.', 0 ),
        'edm' => array( 'EDM', 'Music', 'channel-10',
            '', 'Electronic dance music, around the clock.', 1 ),
        'tzik' => array( 'Tzik', 'Music', 'channel-14', '', '', 0 ),
        'zweester' => array( 'Zweester', 'Music', 'channel-13', '', '', 0 ),
        'halloween' => array( 'Halloween Music', 'Music', 'channel-19',
            '', 'Spooky season soundtrack, all October long.', 1 ),
        'christmas' => array( 'Christmas Music', 'Music', 'channel-20',
            '', 'Christmas classics and winter warmth.', 0 ),
        'good-lifestyle' => array( 'Good Lifestyle', 'Lifestyle', '', '', '', 0 ),
        'finance-vous'   => array( 'Finance & You', 'Lifestyle', '', '', '', 0 ),
        'just-do-biz'    => array( 'Just Do Biz', 'Lifestyle', '', '', '', 0 ),
        'chic-tv'        => array( 'Chic TV', 'Lifestyle', '', '', '', 0 ),
        'zanimo'         => array( 'Zanimo', 'Lifestyle', '', '', '', 0 ),
        'green-life-tv'  => array( 'Green Life TV', 'Lifestyle', '',
            '', 'Sustainable living, eco culture, and green lifestyle inspiration.', 1 ),
    );

    $out = array();
    $i   = 0;
    foreach ( $raw as $slug => $r ) {
        list( $name, $cat, $chan, $logo, $desc, $active ) = $r;
        $out[ $slug ] = array(
            'name'    => $name,
            'cat'     => $cat,
            'logo'    => $logo,
            'desc'    => $desc,
            'hls'     => $chan ? 'https://tackendo.tv/live/' . $chan . '/master.m3u8' : '',
            'epg_url' => $chan ? 'https://tackendo.tv/api/epg/' . $chan . '?days=3' : '',
            'active'  => $active,
            'order'   => $i++,
        );
    }
    return $out;
}
