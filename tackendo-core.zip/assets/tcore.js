const REST = (window.TCORE && window.TCORE.rest) || "/wp-json/tcore/v1";
// ─────────────────────────────────────────────────────────────────
// CHANNEL DATA  ·  Extend this array to add new channels
// ─────────────────────────────────────────────────────────────────
const CH = [
  { slug:'netradio-vision', epg:'https://tackendo.tv/api/epg/channel-11?days=3', name:'Netradio Vision', cat:'pop-culture', catL:'Pop Culture', url:'/netradio-vision/', logo:'https://tackendo.com/wp-content/uploads/2025/06/Netradio-Vision-1080x1080-1-300x300.jpg', desc:'Pop culture, emerging music & the creator economy.' },
  { slug:'fast-music-rising', epg:'https://tackendo.tv/api/epg/channel-01?days=3', name:'Fast Music Rising',  v:'9a0dcecae395ecda833eafd5eba825d8', cat:'music',       catL:'Music',       url:'/fast-music-rising/', logo:'https://tackendo.com/wp-content/uploads/2025/06/FAST-MUSIC-RISING-1080-x-1080-300x300.jpg', desc:'Unsigned & independent artists from around the world. Multi-genre, borderless.' },
  { slug:'urban-street',      name:'Urban Street',       v:'0d18120afa742ef886d2c6a6f5d8b6c8', cat:'music',       catL:'Music',       url:'/urban-street/',      logo:'https://tackendo.com/wp-content/uploads/2025/06/street-1920-x-1080-px-1080-x-1080-px-300x300.png', desc:'Rap, Hip-Hop, and urban sounds. 100% Urban. 100% Attitude.' },
  { slug:'edm',               name:'EDM',                v:'2ccb9abe4917aea3e99c0687406d98f6', cat:'music',       catL:'Music',       url:'/edm/',               logo:'https://tackendo.com/wp-content/uploads/2025/06/Fast-Music-EDM-1080-x-1080-300x300.jpg', desc:'Non-stop electronic dance music and festival-driven culture. Pure energy, 24/7.' },
  { slug:'lo-fi', epg:'https://tackendo.tv/api/epg/channel-04?days=3',             name:'Lo-Fi Music',        v:'bff7a4f6a513be10fd1f11d921d8a581', cat:'music',       catL:'Music',       url:'/lo-fi/',             logo:'https://tackendo.com/wp-content/uploads/2025/06/lofi-thumbnail-square-300x300.jpg', desc:'Cinematic lo-fi soundscapes with anime-style animation. Study, relax, unwind.' },
  { slug:'synthwave', epg:'https://tackendo.tv/api/epg/channel-08?days=3',         name:'Synthwave',          v:'e678b50dcb6393a42608fb10e0d813b5', cat:'music',       catL:'Music',       url:'/synthwave/',         logo:'https://tackendo.com/wp-content/uploads/2025/06/thumbnail-square-300x300.jpg', desc:'Neon-drenched retrofuturistic soundscapes. Nostalgic, immersive, irresistibly cool.' },
  { slug:'epic', epg:'https://tackendo.tv/api/epg/channel-09?days=3',              name:'Epic Music',         v:'a15dfe32073011db49a48691473708d8', cat:'music',       catL:'Music',       url:'/epic/',              logo:'https://tackendo.com/wp-content/uploads/2025/06/Fast-Music-Epic-PNG-300x300.png', desc:'Epic scores, cinematic soundtracks, heroic music. Battle, mystery, and legend.' },
  { slug:'tzik',              name:'Tzik',               v:'e4df2a13dc58c78a8a3678af4467b185', cat:'music',       catL:'Music',       url:'/tzik/',              logo:'https://tackendo.com/wp-content/uploads/2025/06/TZIK-Square-PNG-300x300.png', desc:'Celebrating emerging talent and the most promising unsigned independent artists.' },
  { slug:'winter-ambience', epg:'https://tackendo.tv/api/epg/channel-07?days=3',   name:'Winter Ambience',   v:'afb8269a8aec096feae35d9db34acb80', cat:'music',       catL:'Music',       url:'/winter-ambience/',   logo:'https://tackendo.com/wp-content/uploads/2026/02/Cover-1000x1000-1-300x300.png', desc:'24/7 winter jazz and ambient music for slow, cozy moments.' },
  { slug:'zweester',          name:'Zweester',           v:'b40e24a7a3ac1b02efe9f100f904458c', cat:'music',       catL:'Music',       url:'/zweester/',          logo:'https://tackendo.com/wp-content/uploads/2026/01/ChatGPT-Image-14-janv.-2026-23_41_55-300x298.png', desc:'Non-stop independent music from around the world.' },
  { slug:'halloween',         name:'Halloween Music',    v:'312691ef91491328713d1f12874d9899', cat:'music',       catL:'Music',       url:'/halloween/',         logo:'https://tackendo.com/wp-content/uploads/2025/08/fast-music-halloween-smth-300x300.png', desc:'Original music with long-form animated films. Fantasy, mystery, gothic universe.' },
  { slug:'christmas',         name:'Christmas Music',    v:'c9a295e309b247ef33f4d5838160330e', cat:'music',       catL:'Music',       url:'/christmas/',         logo:'https://tackendo.com/wp-content/uploads/2025/12/Christmas-1080x1080-1-300x300.jpg', desc:'Holiday classics and indie Christmas songs. Pure festive spirit, 24/7.' },
  { slug:'good-lifestyle',    name:'Good Lifestyle',     v:'ecd3b63672c64877a8cd67b18e036c1f', cat:'lifestyle',   catL:'Lifestyle',   url:'/good-lifestyle/',    logo:'https://tackendo.com/wp-content/uploads/2026/04/GOOD-1920-x-1080-px-1024x576.png', desc:'Inspiring original productions — social awareness, feature shows, uplifting storytelling.' },
  { slug:'made-in-france', epg:'https://tackendo.tv/api/epg/channel-02?days=3',    name:'Made in France',     v:'b01d94f2c95a1abe1c6017dea871d82c', cat:'lifestyle',   catL:'Lifestyle',   url:'/made-in-france/',    logo:'https://tackendo.com/wp-content/uploads/2026/04/Made-in-France-TV-1024x576.png', desc:"Immersive tour of France's rich heritage — gastronomy, craftsmanship, entrepreneurs." },
  { slug:'expat-tv', epg:'https://tackendo.tv/api/epg/channel-03?days=3',          name:'Expat TV',           v:'d5db0508a50fde1bbc27bc07970835d9', cat:'lifestyle',   catL:'Lifestyle',   url:'/expat-tv/',          logo:'https://tackendo.com/wp-content/uploads/2026/04/EXPAT-TV-1920-x-1080-px-1-1024x576.png', desc:'Resources for expats and life abroad — visas, housing, cultural integration, stories.' },
  { slug:'finance-vous',      name:'Finance & You',      v:'b42cec80731e93663888fe43ec09708f', cat:'lifestyle',   catL:'Lifestyle',   url:'/finance-vous/',      logo:'https://tackendo.com/wp-content/uploads/2026/04/Finance-Vous.-1920-x-1080-px-1-1024x576.png', desc:'Financial independence, wealth building, and smart money decisions — clear and modern.' },
  { slug:'just-do-biz',       name:'Just Do Biz',        v:'ad58e5c789bdf959cf1e6739ae51b8e9', cat:'lifestyle',   catL:'Lifestyle',   url:'/just-do-biz/',       logo:'https://tackendo.com/wp-content/uploads/2026/04/JustDoBiz-square-white-1-1024x576.png', desc:'Entrepreneurship, innovation, and business culture. Bold founders, breakthrough ideas.' },
  { slug:'chic-tv',           name:'Chic TV',            v:'ad9b9c2ac387b93bd3de245182debadc', cat:'lifestyle',   catL:'Lifestyle',   url:'/chic-tv/',           logo:'https://tackendo.com/wp-content/uploads/2026/04/Chic-TV-1024x576.png', desc:'Luxury, style, and escapism — fashion, gastronomy, premium design, exclusive getaways.' },
  { slug:'zanimo',            name:'Zanimo',             v:'547f00d1627141a6a1eac6fcbfd23767', cat:'lifestyle',   catL:'Lifestyle',   url:'/zanimo/',            logo:'https://tackendo.com/wp-content/uploads/2026/04/zanimo-1920-x-1080-px-300x169.png', desc:'Wildlife, nature, and animal stories — a feel-good channel for animal lovers.' },
  { slug:'summer-vibes', epg:'https://tackendo.tv/api/epg/channel-05?days=3', name:'Summer Vibes', cat:'music', catL:'Music', url:'/summer-vibes/', logo:'https://tackendo.com/wp-content/uploads/2025/06/FAST-MUSIC-RISING-1080-x-1080-300x300.jpg', desc:'Summer vibes all day long.' },
  { slug:'fireplace', epg:'https://tackendo.tv/api/epg/channel-06?days=3',       name:'Fireplace',       cat:'lifestyle', catL:'Lifestyle', url:'/fireplace/', logo:'https://tackendo.com/wp-content/uploads/2026/04/Fireplace_Channel.jpg', desc:'A warm, relaxing fireplace channel — perfect ambience 24/7.' },
  { slug:'green-life-tv',     name:'Green Life TV',      v:'4753f9223fa180ebfd9c082b1e01fa80', cat:'lifestyle',   catL:'Lifestyle',   url:'/green-life-tv/',     logo:'https://tackendo.com/wp-content/uploads/2026/04/LIFE-TV-1920-x-1080-px-1024x576.png', desc:'Sustainable living, eco culture, and green lifestyle inspiration.' },
];
// ─────────────────────────────────────────────────────────────────
// UTILS
// ─────────────────────────────────────────────────────────────────
const fmt = d => d ? d.toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit',hour12:false}) : '';
function chThumb(ch, cls, sz=34) {
  if (ch.logo) return `<img class="${cls}" src="${ch.logo}" alt="${ch.name}" width="${sz}" height="${sz}" loading="lazy"
    onerror="this.style.display='none';this.nextElementSibling.style.removeProperty('display')">
    <div class="${cls}" style="display:none;background:${ch.grad||'#1a1a2e'};align-items:center;justify-content:center;font-size:8px;font-weight:800;color:rgba(255,255,255,.5);text-align:center;padding:4px;">${ch.name.substring(0,4).toUpperCase()}</div>`;
  return `<div class="${cls}" style="background:${ch.grad||'#1a1a2e'};display:flex;align-items:center;justify-content:center;font-size:8px;font-weight:800;color:rgba(255,255,255,.5);text-align:center;padding:4px;">${ch.name.substring(0,4).toUpperCase()}</div>`;
}
// ─────────────────────────────────────────────────────────────────
// XMLTV PARSER  — extracts title, start/stop, description, icon
// ─────────────────────────────────────────────────────────────────
function parseXMLTV(xmlText) {
  const doc = new DOMParser().parseFromString(xmlText, 'text/xml');
  const now = new Date();
  const parseDate = s => {
    if (!s) return null;
    const c = s.replace(/\s.*/,'');
    return new Date(`${c.slice(0,4)}-${c.slice(4,6)}-${c.slice(6,8)}T${c.slice(8,10)}:${c.slice(10,12)}:${c.slice(12,14)}Z`);
  };
  const progs = Array.from(doc.querySelectorAll('programme')).map(p => ({
    title:  p.querySelector('title')?.textContent || '',
    desc:   p.querySelector('desc')?.textContent  || '',
    icon:   p.querySelector('icon')?.getAttribute('src') || null,
    start:  parseDate(p.getAttribute('start')),
    stop:   parseDate(p.getAttribute('stop')),
  })).filter(p => p.start && p.stop);
  return {
    current: progs.find(p => p.start <= now && p.stop > now),
    next:    progs.find(p => p.start > now),
  };
}
// ─────────────────────────────────────────────────────────────────
// API FETCHERS
// ─────────────────────────────────────────────────────────────────
async function fetchEPG(epgUrl, channelSlug) {
  var now = Date.now();
  var progs = [];
  // If no direct EPG URL, try WP proxy
  var url = epgUrl || (REST + '/epg/' + channelSlug);
  try {
    var r = await fetch(url, {cache:'no-store'});
    if (!r.ok) throw new Error('HTTP ' + r.status);
    var data = await r.json();
    progs = data.programs || [];
    if (progs.length === 0 && !epgUrl) return null; // WP proxy returned empty
    console.log('[EPG] OK', channelSlug, progs.length, 'programs');
  } catch(e) {
    console.warn('[EPG] FAILED', url, e.message);
    return null;
  }
  // Normalize: convert ISO8601 strings to Date objects
  progs = progs.map(function(p){
    return {
      title: p.title || '',
      artist: p.artist || '',
      desc:  p.desc  || p.artist || '',
      icon:  p.icon  || '',
      start: new Date(p.start),
      stop:  new Date(p.stop)
    };
  }).filter(function(p){ return !isNaN(p.start.getTime()); });
  var current = null, next = null;
  for (var i = 0; i < progs.length; i++) {
    var p = progs[i];
    var ms = p.start.getTime();
    var me = p.stop.getTime();
    if (ms <= now && me > now && !current) { current = p; }
    else if (ms > now && !next) { next = p; }
    if (current && next) break;
  }
  if (!current && progs.length > 0) {
    var first = progs[0];
    console.warn('[EPG] No current program for', channelSlug,
      '| now:', new Date(now).toISOString(),
      '| first start:', first.start.toISOString(),
      '| first stop:', first.stop.toISOString());
  }
  return { current: current, next: next, programs: progs };
}
async function fetchSchedule(id) {
  try {
    const r = await fetch(`https://deliver.viloud.tv/channel/${id}/schedule`);
    if (!r.ok) throw 0;
    const d = await r.json();
    return d.items || d.playlist || d.content || d.data || [];
  } catch { return []; }
}
// ─────────────────────────────────────────────────────────────────
// HERO EPG
// ─────────────────────────────────────────────────────────────────
async function loadHeroEPG() {
  const ch = CH[0];
  const $title = document.getElementById('hn-title');
  const $time  = document.getElementById('hn-time');
  const $next  = document.getElementById('hn-next');
  const $thumb = document.getElementById('hn-thumb');

  const epg = await fetchEPG(ch.epg, ch.slug);
  if (epg?.current) {
    // Show thumbnail if available
    if (epg.current.icon) {
      $thumb.src = epg.current.icon;
      $thumb.style.display = 'block';
    }
    $title.textContent = epg.current.title;
    $time.textContent  = `${fmt(epg.current.start)} – ${fmt(epg.current.stop)}`;
    if (epg.next) {
      $next.innerHTML = `<strong style="color:var(--grey)">Up next:</strong> ${epg.next.title} at ${fmt(epg.next.start)}`;
    }
    return;
  }
  // Fallback: schedule
  const items = await fetchSchedule(ch.v);
  $title.textContent = items[0]?.title || items[0]?.name || 'Hits Vision';
  $time.textContent  = 'Live now';
  if (items[1]) $next.innerHTML = `<strong style="color:var(--grey)">Up next:</strong> ${items[1].title||items[1].name}`;
}
// ─────────────────────────────────────────────────────────────────
// EPG STRIP
// ─────────────────────────────────────────────────────────────────
function buildStripSkeleton() {
  document.getElementById('epg-strip').innerHTML = CH.slice(0,12).map(ch => `
    <a href="${ch.url}" class="epg-card" id="ec-${ch.slug}" role="listitem" aria-label="${ch.name}">
      <div class="epg-thumb-prog skel">&nbsp;</div>
      <div class="epg-body">
        <div class="epg-top">
          ${chThumb(ch,'epg-logo',32)}
          <span class="epg-ch">${ch.name}</span>
        </div>
        <p class="epg-show"><span class="skel" style="width:140px;height:13px">&nbsp;</span></p>
        <p class="epg-time"><span class="skel" style="width:90px;height:11px;margin-top:4px">&nbsp;</span></p>
        <div class="epg-bar"><div class="epg-fill" style="width:0%"></div></div>
      </div>
    </a>`).join('');
}
async function loadStripEPG() {
  await Promise.all(CH.slice(0,12).map(async ch => {
    const card = document.getElementById(`ec-${ch.slug}`);
    if (!card) return;
    const $prog  = card.querySelector('.epg-thumb-prog');
    const $show  = card.querySelector('.epg-show');
    const $time  = card.querySelector('.epg-time');
    const $fill  = card.querySelector('.epg-fill');

    const epg = await fetchEPG(ch.epg, ch.slug);
    if (epg?.current) {
      $prog.classList.remove('skel');
      var thumbUrl = epg.current.icon || ch.logo || '';
      if (thumbUrl) {
        $prog.style.backgroundImage = "url('" + thumbUrl + "')";
        $prog.style.backgroundSize = 'cover';
        $prog.style.backgroundPosition = 'center';
      }
      $show.textContent = epg.current.title;
      const hStart = epg.current.start instanceof Date ? epg.current.start : new Date(epg.current.start);
      const hStop  = epg.current.stop  instanceof Date ? epg.current.stop  : new Date(epg.current.stop);
      $time.textContent = `${fmt(hStart)} – ${fmt(hStop)}`;
      if (epg.current.start && epg.current.stop) {
        const startMs = epg.current.start instanceof Date ? epg.current.start.getTime() : new Date(epg.current.start).getTime();
        const stopMs  = epg.current.stop  instanceof Date ? epg.current.stop.getTime()  : new Date(epg.current.stop).getTime();
        const pct = Math.min(100, Math.max(0, ((Date.now() - startMs) / (stopMs - startMs)) * 100));
        $fill.style.width = pct + '%';
      }
    } else {
      // Fallback: schedule
      const items = await fetchSchedule(ch.v);
      $prog.classList.remove('skel');
      if (ch.logo) {
        $prog.style.backgroundImage = "url('" + ch.logo + "')";
        $prog.style.backgroundSize = 'cover';
        $prog.style.backgroundPosition = 'center';
      }
      const title = items[0]?.title || items[0]?.name || `Non-Stop ${ch.catL}`;
      $show.textContent = title;
      $time.textContent = 'Live 24/7';
      $fill.style.width = '50%';
    }
  }));
}
// ─────────────────────────────────────────────────────────────────
// CHANNELS GRID
// ─────────────────────────────────────────────────────────────────
function renderGrid(filter = 'all') {
  const list = filter === 'all' ? CH : CH.filter(c => c.cat === filter);
  document.getElementById('ch-grid').innerHTML = list.map(ch => {
    const imgBlock = ch.logo
      ? `<img class="ch-img" src="${ch.logo}" alt="${ch.name}" loading="lazy" width="220" height="220"
           onerror="this.style.display='none';this.nextElementSibling.style.removeProperty('display')">
         <div class="ch-ph" style="display:none;background:${ch.grad||'#1a1a2e'}">${ch.name.toUpperCase()}</div>`
      : `<div class="ch-ph" style="background:${ch.grad||'#1a1a2e'}">${ch.name.toUpperCase()}</div>`;
    return `<a href="${ch.url}" class="ch-card fade" data-cat="${ch.cat}" role="listitem" aria-label="Watch ${ch.name}">
      ${imgBlock}
      <div class="ch-body">
        <p class="ch-tag">${ch.catL}</p>
        <h3 class="ch-name">${ch.name}</h3>
        <p class="ch-desc">${ch.desc}</p>
      </div>
      <div class="ch-foot">
        <span class="ch-live"><span class="live-dot"></span>LIVE</span>
        <span class="ch-watch">Watch →</span>
      </div>
    </a>`;
  }).join('');
  setTimeout(() => {
    document.querySelectorAll('.ch-card').forEach((el,i) => {
      setTimeout(() => el.classList.add('in'), i * 35);
    });
  }, 60);
}
// ─────────────────────────────────────────────────────────────────
// SIDEBAR
// ─────────────────────────────────────────────────────────────────
function renderSidebar() {
  document.getElementById('sb-channels').innerHTML =
    CH.filter(c => c.slug !== 'netradio-vision').slice(0,7).map(ch => `
      <a href="${ch.url}" class="sb-ch" aria-label="Watch ${ch.name}">
        ${ch.logo
          ? `<img class="sb-logo" src="${ch.logo}" alt="${ch.name}" width="34" height="34" loading="lazy">`
          : `<div class="sb-logo" style="background:${ch.grad||'#1a1a2e'};display:flex;align-items:center;justify-content:center;font-size:8px;font-weight:800;color:rgba(255,255,255,.5);">${ch.name.substring(0,3).toUpperCase()}</div>`}
        <div><p class="sb-cn">${ch.name}</p><p class="sb-cc">${ch.catL}</p></div>
        <span class="sb-arr" aria-hidden="true">›</span>
      </a>`).join('');
}
// ─────────────────────────────────────────────────────────────────
// FILTER TABS
// ─────────────────────────────────────────────────────────────────
document.querySelectorAll('.ftab').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.ftab').forEach(b => {
      b.classList.remove('on');
      b.setAttribute('aria-selected','false');
    });
    btn.classList.add('on');
    btn.setAttribute('aria-selected','true');
    renderGrid(btn.dataset.f);
  });
});
// ─────────────────────────────────────────────────────────────────
// INTERSECTION OBSERVER (fade-in)
// ─────────────────────────────────────────────────────────────────
const io = new IntersectionObserver(entries => {
  entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('in'); });
}, { threshold: 0.08 });
// ─────────────────────────────────────────────────────────────────
// INIT
// ─────────────────────────────────────────────────────────────────
/* ── COMING UP: Marcy Beaucoup & La Team ── */
var UPCOMING_SHOWS = [
  { keyword: 'MARCY BEAUCOUP', label: 'Weekly Show' },
  { keyword: 'LA TEAM',        label: 'Next Broadcast' },
];
var _cdT = [];
function _p(n){ return String(n).padStart(2,'0'); }
function _fcd(ms){
  if(ms<=0) return {v:'ON AIR',u:'NOW',live:true};
  var s=Math.floor(ms/1000),m=Math.floor(s/60),h=Math.floor(m/60),d=Math.floor(h/24);
  s%=60;m%=60;h%=24;
  if(d>0) return {v:d+'D '+_p(h)+'H',u:_p(m)+'M',live:false};
  if(h>0) return {v:_p(h)+'H '+_p(m)+'M',u:_p(s)+'S',live:false};
  return {v:_p(m)+"'"+_p(s)+'"',u:'',live:false};
}
function _match(title,kw){
  if(!title)return false;
  var t=title.toUpperCase(),k=kw.toUpperCase();
  return t.includes(k)||k.split(' ').every(function(w){return w.length>1&&t.includes(w);});
}
async function loadUpcomingShows(){
  var row=document.getElementById('upcoming-shows');
  if(!row)return;
  try{
    var nrvCh = CH.find(function(c){return c.slug==='netradio-vision';});
    var nrvEpg = (nrvCh && nrvCh.epg) ? nrvCh.epg : (window.TCORE && TCORE.nrvEpg ? TCORE.nrvEpg : null);
    if(!nrvEpg){document.getElementById('upcoming-shows')&&(document.getElementById('upcoming-shows').style.display='none');return;}
    var r=await fetch(nrvEpg,{cache:'no-store'});
    if(!r.ok)return;
    var data=await r.json();
    var progs=data.programs||[],now=Date.now(),found=[];
    for(var si=0;si<UPCOMING_SHOWS.length;si++){
      var show=UPCOMING_SHOWS[si];
      for(var pi=0;pi<progs.length;pi++){
        var p=progs[pi];
        if((_match(p.title,show.keyword)||_match(p.artist,show.keyword))&&new Date(p.stop).getTime()>now){
          found.push({show:show,prog:p});break;
        }
      }
    }
    if(!found.length){row.style.display='none';return;}
    row.innerHTML='';
    found.forEach(function(item,idx){
      var prog=item.prog,show=item.show;
      var start=new Date(prog.start).getTime(),stop=new Date(prog.stop).getTime();
      var isLive=start<=now&&stop>now;
      var dt=new Date(prog.start),days=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
      var dateStr=days[dt.getDay()]+' '+_p(dt.getHours())+':'+_p(dt.getMinutes());
      var cd=_fcd(start-now);
      var cdStr=cd.v+(cd.u?' '+cd.u:'');
      var card=document.createElement('a');
      card.href='/netradio-vision/';
      card.style.cssText='display:flex;flex-direction:row;height:175px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:12px;overflow:hidden;text-decoration:none;transition:border-color .2s;width:100%';
      var thumb=document.createElement('div');
      var thumbStyle='width:180px;min-width:180px;height:175px;position:relative;flex-shrink:0;background:#09091f';
      if(prog.icon) thumbStyle='width:180px;min-width:180px;height:175px;position:relative;flex-shrink:0;background:url("'+prog.icon+'") center/cover no-repeat #09091f';
      thumb.setAttribute('style',thumbStyle);
      if(isLive){
        var badge=document.createElement('span');
        badge.style.cssText='position:absolute;bottom:8px;left:8px;display:flex;align-items:center;gap:4px;background:#E8001C;color:#fff;font-size:9px;font-weight:900;letter-spacing:.1em;text-transform:uppercase;padding:4px 10px;border-radius:3px';
        badge.innerHTML='<span style="width:6px;height:6px;background:#fff;border-radius:50%;display:inline-block"></span> LIVE NOW';
        thumb.appendChild(badge);
      }
      var body=document.createElement('div');
      body.style.cssText='flex:1;padding:14px 16px;display:flex;flex-direction:column;justify-content:center;min-width:0;overflow:hidden';
      var lbl=document.createElement('p');
      lbl.style.cssText='font-size:8px;font-weight:900;letter-spacing:.18em;text-transform:uppercase;color:#E8001C;margin:0 0 5px';
      lbl.textContent=show.label;
      var title=document.createElement('p');
      title.style.cssText='font-family:Bebas Neue,sans-serif;font-size:22px;font-weight:400;letter-spacing:.04em;line-height:1;color:#fff;margin:0 0 6px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis';
      title.textContent=prog.artist ? (prog.artist + ' — ' + prog.title) : prog.title;
      var desc=document.createElement('p');
      desc.style.cssText='font-size:11px;color:#7a7a90;line-height:1.45;margin:0 0 10px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden';
      if(prog.desc)desc.textContent=prog.desc;
      var footer=document.createElement('div');
      footer.style.cssText='display:flex;align-items:center;justify-content:space-between;padding-top:8px;border-top:1px solid rgba(255,255,255,.07);margin-top:auto';
      var cd_el=document.createElement('span');
      cd_el.id='ucd-'+idx;
      cd_el.style.cssText='font-family:Bebas Neue,sans-serif;font-size:20px;font-weight:400;letter-spacing:.04em;line-height:1;color:'+(isLive?'#E8001C':'#fff');
      cd_el.textContent=cdStr;
      var right=document.createElement('div');
      right.style.cssText='text-align:right';
      var ch=document.createElement('span');
      ch.style.cssText='font-size:8px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;padding:2px 7px;border-radius:3px;border:1px solid rgba(255,255,255,.12);color:#7a7a90;display:block;margin-bottom:3px';
      ch.textContent='Netradio Vision';
      var dt_el=document.createElement('span');
      dt_el.style.cssText='font-size:10px;font-weight:600;color:#7a7a90';
      dt_el.textContent=isLive?'':dateStr;
      right.appendChild(ch);right.appendChild(dt_el);
      footer.appendChild(cd_el);footer.appendChild(right);
      body.appendChild(lbl);body.appendChild(title);
      if(prog.desc)body.appendChild(desc);
      body.appendChild(footer);
      card.appendChild(thumb);card.appendChild(body);
      row.appendChild(card);
      if(!isLive){
        var t=setInterval(function(i,st){return function(){
          var el=document.getElementById('ucd-'+i);
          if(!el){clearInterval(t);return;}
          var c2=_fcd(st-Date.now());
          el.textContent=c2.v+(c2.u?' '+c2.u:'');
          if(c2.live){el.style.color='#E8001C';clearInterval(t);}
        };}(idx,start),1000);
        _cdT.push(t);
      }
    });
  }catch(e){console.warn('[Upcoming]',e);}
}
function tcoreInit() {
  renderGrid('all');
  renderSidebar();
  buildStripSkeleton();
  document.querySelectorAll('.art, .sb-w, .sb-cta').forEach(function(el) {
    el.classList.add('fade');
    io.observe(el);
  });
  loadHeroEPG();
  loadStripEPG();
  loadUpcomingShows();
  setTimeout(function() {
    document.querySelectorAll('.ch-card').forEach(function(el) { io.observe(el); });
  }, 200);
}
// Works whether script is sync OR deferred by SiteGround Speed Optimizer
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', tcoreInit);
} else {
  tcoreInit();
}
/* ── EPG Carousel ── */
function epgScroll(dir) {
  var strip = document.getElementById('epg-strip');
  if (!strip) return;
  strip.scrollBy({ left: dir * 232 * 3, behavior: 'smooth' });
}
// Auto-refresh EPG every 5 minutes
setInterval(function() { loadHeroEPG(); loadStripEPG(); }, 5 * 60 * 1000);
