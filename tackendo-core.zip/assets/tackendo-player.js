/**
 * TACKENDO PLAYER v6.0
 * Google IMA SDK (obligatoire pour Google Ad Manager) + hls.js
 * Architecture identique à Radiant Media Player
 */
(function(W){
'use strict';

function cleanVast(url) {
  if (!url) return '';
  // Fix ONLY what WordPress may have encoded — do NOT decodeURIComponent (it corrupts the URL)
  var u = url
    .replace(/&amp;/g, '&')
    .replace(/&#91;/g, '[').replace(/&#93;/g, ']')
    .replace(/%5B/gi, '[').replace(/%5D/gi, ']');
  // Replace [timestamp] macro with Unix ms (cache-busting correlator)
  u = u.replace(/\[timestamp\]/gi, String(Math.floor(Date.now())));
  return u;
}

function TackendoPlayer(id, opt) {
  this.el = document.getElementById(id);
  if (!this.el) { console.error('[TP] element not found:', id); return; }
  this.opt = Object.assign({
    hls:'', vast:'', poster:'', channelName:'LIVE', midrollEvery:360, proxyBase:''
  }, opt);
  this.hlsEng=null; this.adsManager=null; this.adContainer=null; this.adsLoader=null;
  this.started=false; this.adPlaying=false; this.muted=false;
  this.midT=null; this.ctrlT=null;
  this._build();
}

TackendoPlayer.prototype = {

  _build: function(){
    var self=this, el=this.el;
    el.style.cssText='width:80%;max-width:80%;margin:0 auto;display:block;line-height:0';

    this.ratio=this._d('position:relative;width:100%;padding-top:56.25%;background:#000;overflow:hidden;border-radius:10px');
    this.wrap =this._d('position:absolute;top:0;left:0;right:0;bottom:0');

    this.cv=this._v('position:absolute;top:0;left:0;width:100%;height:100%;display:none;background:#000;object-fit:contain');
    // IMA renders its own video inside adDiv
    this.adDiv=this._d('position:absolute;top:0;left:0;right:0;bottom:0;z-index:10;pointer-events:none');

    this.post=document.createElement('img');
    this.post.style.cssText='position:absolute;top:0;left:0;width:100%;height:100%;object-fit:cover;cursor:pointer;z-index:3;display:block';
    this.post.alt=this.opt.channelName;
    if(this.opt.poster) this.post.src=this.opt.poster; else this.post.style.display='none';
    this.post.onerror=function(){self.post.style.background='#111';};

    this.pbtn=this._d('position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);z-index:5;width:68px;height:68px;border-radius:50%;background:rgba(232,0,28,.9);cursor:pointer;display:flex;align-items:center;justify-content:center;box-shadow:0 4px 24px rgba(0,0,0,.5)');
    this.pbtn.innerHTML='<svg width="28" height="28" viewBox="0 0 24 24" fill="#fff"><path d="M8 5v14l11-7z"/></svg>';

    this.spin=this._d('position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);z-index:6;display:none;pointer-events:none');
    this.spin.innerHTML='<svg width="44" height="44" viewBox="0 0 44 44"><circle cx="22" cy="22" r="18" fill="none" stroke="rgba(255,255,255,.15)" stroke-width="3"/><circle cx="22" cy="22" r="18" fill="none" stroke="#E8001C" stroke-width="3" stroke-dasharray="70 200" stroke-linecap="round"><animateTransform attributeName="transform" type="rotate" from="0 22 22" to="360 22 22" dur=".8s" repeatCount="indefinite"/></circle></svg>';

    this.ctrl=this._d('position:absolute;bottom:0;left:0;right:0;z-index:8;padding:18px 14px 12px;background:linear-gradient(to top,rgba(0,0,0,.8),transparent);display:flex;flex-direction:column;gap:6px;transition:opacity .3s;opacity:0');
    if(!W._tpkf){W._tpkf=1;var st=document.createElement('style');st.textContent='@keyframes tpd{0%,100%{opacity:1}50%{opacity:.3}}@keyframes tpb{0%{transform:translateX(-100%)}100%{transform:translateX(200%)}}';document.head.appendChild(st);}
    var r1=this._d('display:flex;align-items:center;gap:8px');
    var lv=this._d('display:inline-flex;align-items:center;gap:5px;background:#E8001C;color:#fff;font:900 10px/1 Figtree,sans-serif;letter-spacing:.1em;padding:3px 9px;border-radius:3px;text-transform:uppercase;flex-shrink:0');
    lv.innerHTML='<span style="width:6px;height:6px;border-radius:50%;background:#fff;display:inline-block;animation:tpd 1.6s infinite"></span>\u00a0LIVE';
    var pg=this._d('flex:1;height:3px;background:rgba(255,255,255,.15);border-radius:2px;overflow:hidden');
    var pf=this._d('height:100%;background:#E8001C;animation:tpb 2.5s ease-in-out infinite');
    pg.appendChild(pf);r1.appendChild(lv);r1.appendChild(pg);
    var r2=this._d('display:flex;align-items:center;gap:8px');
    this.cbtn=this._sb('M6 19h4V5H6v14zm8-14v14h4V5h-4z','Play/Pause');
    this.vbtn=this._sb('M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02z','Volume');
    this.nmel=this._d('flex:1;font:700 12px/1 Figtree,sans-serif;color:rgba(255,255,255,.85);letter-spacing:.05em;text-transform:uppercase;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding:0 6px');
    this.nmel.textContent=this.opt.channelName;
    this.fbtn=this._sb('M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z','Fullscreen');
    [this.cbtn,this.vbtn,this.nmel,this.fbtn].forEach(function(b){r2.appendChild(b);});
    this.ctrl.appendChild(r1);this.ctrl.appendChild(r2);

    [this.cv,this.adDiv,this.post,this.pbtn,this.spin,this.ctrl].forEach(function(n){self.wrap.appendChild(n);});
    this.ratio.appendChild(this.wrap);el.appendChild(this.ratio);

    this.pbtn.addEventListener('click',function(){self._start();});
    this.post.addEventListener('click',function(){self._start();});
    this.cbtn.addEventListener('click',function(){self._togglePlay();});
    this.vbtn.addEventListener('click',function(){self._toggleMute();});
    this.fbtn.addEventListener('click',function(){self._toggleFS();});
    this.cv.addEventListener('playing',function(){self.spin.style.display='none';self._syncPlay(true);});
    this.cv.addEventListener('waiting',function(){if(!self.adPlaying)self.spin.style.display='block';});
    this.cv.addEventListener('pause',  function(){self._syncPlay(false);});
    this.wrap.addEventListener('mousemove',function(){
      self.ctrl.style.opacity='1';clearTimeout(self.ctrlT);
      if(!self.cv.paused)self.ctrlT=setTimeout(function(){self.ctrl.style.opacity='0';},3000);
    });
    document.addEventListener('fullscreenchange',function(){
      self.fbtn.querySelector('path').setAttribute('d',document.fullscreenElement
        ?'M5 16h3v3h2v-5H5v2zm3-8H5v2h5V5H8v3zm6 11h2v-3h3v-2h-5v5zm2-11V5h-2v5h5V8h-3z'
        :'M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z');
    });
    document.addEventListener('keydown',function(e){
      if(!self.el.matches(':hover'))return;
      if(e.code==='Space'){e.preventDefault();self._togglePlay();}
      if(e.code==='KeyM')self._toggleMute();
      if(e.code==='KeyF')self._toggleFS();
    });
  },

  // ── START — must be called from user click ────────────────────────
  _start: function(){
    if(this.started){this._togglePlay();return;}
    this.started=true;
    this.pbtn.style.display='none';
    this.post.style.display='none';
    this.spin.style.display='block';
    this.ctrl.style.opacity='1';
    this.cv.style.display='block';

    // Store the user gesture flag — iOS needs play() to happen in gesture chain
    this._userGesture = true;

    // Initialize IMA AdDisplayContainer here — inside user gesture (REQUIRED by Google)
    if(this.opt.vast && typeof google!=='undefined' && google.ima){
      try{
        this.adContainer=new google.ima.AdDisplayContainer(this.adDiv,this.cv);
        this.adContainer.initialize();
        console.log('[IMA] AdDisplayContainer ready');
      }catch(e){
        console.warn('[IMA] init failed:',e.message,'→ no ads');
        this.adContainer=null;
      }
    }
    this._loadHLS();
  },

  // ── HLS ──────────────────────────────────────────────────────────
  _loadHLS: function(){
    var self=this, url=this.opt.hls;
    var onReady=function(){
      if(self.opt.vast && self.adContainer){
        self._requestAds();
      }else{
        self._playContent();
      }
    };
    if(typeof Hls!=='undefined'&&Hls.isSupported()){
      this.hlsEng=new Hls({
        liveSyncDurationCount:3,
        liveMaxLatencyDurationCount:10,
        maxBufferLength:30,
        maxBufferHole:0.5,
        // Auto-recover from stalls
        liveDurationInfinity:true,
        enableWorker:true,
        fragLoadingMaxRetry:6,
        fragLoadingRetryDelay:1000,
        manifestLoadingMaxRetry:6,
        levelLoadingMaxRetry:6
      });
      this.hlsEng.loadSource(url);
      this.hlsEng.attachMedia(this.cv);
      this.hlsEng.on(Hls.Events.MANIFEST_PARSED,onReady);
      // Auto-recovery on errors
      this.hlsEng.on(Hls.Events.ERROR,function(e,d){
        if(d.fatal){
          console.warn('[TP] HLS fatal:',d.type,d.details);
          switch(d.type){
            case Hls.ErrorTypes.NETWORK_ERROR:
              console.log('[TP] Network error, recovering...');
              self.hlsEng.startLoad();
              break;
            case Hls.ErrorTypes.MEDIA_ERROR:
              console.log('[TP] Media error, recovering...');
              self.hlsEng.recoverMediaError();
              break;
            default:
              console.log('[TP] Fatal error, reloading stream...');
              self.hlsEng.destroy();
              setTimeout(function(){self._loadHLS();},3000);
              break;
          }
        }
      });
      // Stall detection — if video stuck for 8s, force recovery
      this._stallCheck=setInterval(function(){
        if(self.adPlaying||self.cv.paused||!self.hlsEng)return;
        if(!self._lastTime)self._lastTime=self.cv.currentTime;
        if(Math.abs(self.cv.currentTime-self._lastTime)<0.1){
          self._stallCount=(self._stallCount||0)+1;
          if(self._stallCount>=4){
            console.log('[TP] Stall detected, recovering...');
            self._stallCount=0;
            self.hlsEng.recoverMediaError();
            setTimeout(function(){
              self.cv.play().catch(function(){});
            },500);
          }
        }else{
          self._stallCount=0;
        }
        self._lastTime=self.cv.currentTime;
      },2000);
    }else if(this.cv.canPlayType('application/vnd.apple.mpegurl')){
      // iOS Safari: native HLS — set src and play immediately (still in user gesture)
      this.cv.src=url;
      if(this._userGesture){
        this._userGesture=false;
        var playPromise=this.cv.play();
        if(playPromise&&playPromise.then){
          playPromise.then(function(){
            if(self.opt.vast&&self.adContainer){
              self.cv.pause();
              self._requestAds();
            }
          }).catch(function(e){console.warn('[TP] iOS play:',e.message);});
        }
        if(!this.midT&&this.opt.midrollEvery>0)this._startMidroll();
      }else{
        this.cv.addEventListener('loadedmetadata',onReady,{once:true});
      }
      // iOS stall recovery
      this.cv.addEventListener('stalled',function(){
        console.log('[TP] iOS stalled, retrying...');
        setTimeout(function(){self.cv.play().catch(function(){});},1000);
      });
      this.cv.addEventListener('error',function(){
        console.log('[TP] iOS error, reloading...');
        var t=self.cv.currentTime;
        self.cv.src=url;
        self.cv.play().catch(function(){});
      });
    }else{
      console.error('[TP] HLS not supported');this.spin.style.display='none';
    }
  },

  // ── IMA AD REQUEST ────────────────────────────────────────────────
  // Strategy: pre-fetch VAST XML via WP proxy (PHP has no CORS limits),
  // then pass the XML to IMA via adsResponse instead of adTagUrl.
  // This avoids IMA re-encoding the iu parameter (which causes 400 from Google).
  _requestAds: async function(){
    var self=this;
    if(!this.adContainer){self._playContent();return;}

    var vastUrl=cleanVast(this.opt.vast);
    var adsResponse=null;

    // Step 1: fetch VAST XML server-side via WP proxy (no CORS, no URL re-encoding)
    if(this.opt.proxyBase){
      try{
        var proxyUrl=this.opt.proxyBase+'/vast?url='+encodeURIComponent(vastUrl);
        var r=await fetch(proxyUrl,{cache:'no-store'});
        if(r.ok){
          adsResponse=await r.text();
          // Verify it's valid VAST XML
          if(adsResponse.indexOf('<VAST')<0 && adsResponse.indexOf('<vast')<0){
            console.warn('[IMA] proxy response is not VAST XML');
            adsResponse=null;
          }else{
            console.log('[IMA] VAST XML fetched via proxy, length:',adsResponse.length);
          }
        }else{
          console.warn('[IMA] proxy HTTP',r.status);
        }
      }catch(e){
        console.warn('[IMA] proxy fetch failed:',e.message);
      }
    }

    // Step 2: init IMA with pre-fetched XML or URL fallback
    if(this.adsLoader) try{this.adsLoader.contentComplete();}catch(e){}
    var adsLoader=new google.ima.AdsLoader(this.adContainer);
    this.adsLoader=adsLoader;

    adsLoader.addEventListener(google.ima.AdsManagerLoadedEvent.Type.ADS_MANAGER_LOADED,function(ev){
      var rs=new google.ima.AdsRenderingSettings();
      rs.restoreCustomPlaybackStateOnAdBreakComplete=true;
      var am=ev.getAdsManager(self.cv,rs);
      self.adsManager=am;

      am.addEventListener(google.ima.AdErrorEvent.Type.AD_ERROR,function(e){
        console.warn('[IMA] AdError:',e.getError().toString());
        self._resumeContent();
      });
      am.addEventListener(google.ima.AdEvent.Type.CONTENT_PAUSE_REQUESTED,function(){
        self.adPlaying=true;self.cv.pause();self.spin.style.display='none';
        self.adDiv.style.pointerEvents='auto';
      });
      am.addEventListener(google.ima.AdEvent.Type.CONTENT_RESUME_REQUESTED,function(){
        self.adPlaying=false;self.adDiv.style.pointerEvents='none';
        // Force HLS to re-sync live stream after ad break
        if(self.hlsEng){
          try{
            // For hls.js: recoverMediaError re-attaches and resumes live
            self.hlsEng.startLoad();
          }catch(e){}
        }
        // Small delay to let HLS re-buffer before calling play()
        setTimeout(function(){self._playContent();},300);
      });
      am.addEventListener(google.ima.AdEvent.Type.ALL_ADS_COMPLETED,function(){
        self._resumeContent();
      });
      am.addEventListener(google.ima.AdEvent.Type.STARTED,function(){
        console.log('[IMA] Ad started ✓');
      });

      var rect=self.wrap.getBoundingClientRect();
      var w=Math.round(rect.width)||self.wrap.offsetWidth||960;
      var h=Math.round(rect.height)||Math.round(w*9/16)||540;
      console.log('[IMA] adsManager.init w='+w+' h='+h);
      try{
        am.init(w,h,google.ima.ViewMode.NORMAL);
        am.start();
      }catch(e){
        console.error('[IMA] adsManager error:',e.message);
        self._resumeContent();
      }
    },false);

    adsLoader.addEventListener(google.ima.AdErrorEvent.Type.AD_ERROR,function(e){
      console.warn('[IMA] AdsLoader error:',e.getError().toString());
      self._resumeContent();
    },false);

    var req=new google.ima.AdsRequest();
    var w=self.wrap.offsetWidth||960;
    var h=self.wrap.offsetHeight||Math.round(w*9/16)||540;
    req.linearAdSlotWidth=w;
    req.linearAdSlotHeight=h;

    if(adsResponse){
      // Use pre-fetched XML — IMA won't make another HTTP request
      req.adsResponse=adsResponse;
      console.log('[IMA] using adsResponse (pre-fetched XML)');
    }else{
      // Fallback: pass URL directly (may get 400 if IMA re-encodes iu param)
      req.adTagUrl=vastUrl;
      console.log('[IMA] using adTagUrl (fallback):',vastUrl.substring(0,80)+'...');
    }
    adsLoader.requestAds(req);
  },

  _resumeContent: function(){
    if(this.adsManager){try{this.adsManager.destroy();}catch(e){}this.adsManager=null;}
    this.adPlaying=false;
    this.adDiv.style.pointerEvents='none';
    var self=this;
    if(self.hlsEng){try{self.hlsEng.startLoad();}catch(e){}}
    setTimeout(function(){self._playContent();},300);
  },

  _playContent: function(){
    var self=this;
    this.cv.play().then(function(){
      if(!self.midT&&self.opt.midrollEvery>0)self._startMidroll();
      // Wake Lock — prevent screen from sleeping during playback
      self._acquireWakeLock();
    }).catch(function(e){console.warn('[TP] play():',e.message);});
  },

  _acquireWakeLock: function(){
    var self=this;
    if(this._wakeLock)return;
    if('wakeLock' in navigator){
      navigator.wakeLock.request('screen').then(function(lock){
        self._wakeLock=lock;
        lock.addEventListener('release',function(){self._wakeLock=null;});
        console.log('[TP] Wake lock acquired');
      }).catch(function(e){console.warn('[TP] Wake lock:',e.message);});
    }
    // Fallback for browsers without Wake Lock API: keep-alive via hidden video trick
    if(!this._keepAlive){
      this._keepAlive=setInterval(function(){
        if(!self.cv.paused&&document.visibilityState==='visible'){
          // Prevent browser from throttling by checking buffer
          var buf=self.cv.buffered;
          if(buf.length>0){
            var ahead=buf.end(buf.length-1)-self.cv.currentTime;
            if(ahead<2&&self.hlsEng){
              self.hlsEng.startLoad();
            }
          }
        }
      },5000);
    }
  },

  _startMidroll: function(){
    var self=this;
    this.midT=setInterval(function(){
      if(self.adPlaying||!self.opt.vast||!self.adContainer)return;
      self.cv.pause();
      if(self.adsManager){try{self.adsManager.destroy();}catch(e){}self.adsManager=null;}
      self._requestAds();
    },this.opt.midrollEvery*1000);
  },

  _togglePlay: function(){
    if(!this.started){this._start();return;}
    if(this.adPlaying)return;
    this.cv.paused?this._playContent():this.cv.pause();
  },
  _syncPlay: function(pl){
    this.cbtn.querySelector('path').setAttribute('d',pl
      ?'M6 19h4V5H6v14zm8-14v14h4V5h-4z'
      :'M8 5v14l11-7z');
  },
  _toggleMute: function(){
    this.muted=!this.muted;
    this.cv.muted=this.muted;
    if(this.adsManager)try{this.adsManager.setVolume(this.muted?0:1);}catch(e){}
    this.vbtn.querySelector('path').setAttribute('d',this.muted
      ?'M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z'
      :'M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02z');
  },
  _toggleFS: function(){
    var el=this.wrap;
    document.fullscreenElement?document.exitFullscreen()
      :el.requestFullscreen?el.requestFullscreen()
      :el.webkitRequestFullscreen&&el.webkitRequestFullscreen();
  },
  _d: function(css){var d=document.createElement('div');d.style.cssText=css||'';return d;},
  _v: function(css){var v=document.createElement('video');v.setAttribute('playsinline','');v.preload='none';if(css)v.style.cssText=css;return v;},
  _sb: function(path,label){
    var b=document.createElement('button');
    b.style.cssText='background:none;border:none;cursor:pointer;padding:5px;display:flex;align-items:center;justify-content:center;opacity:.75;flex-shrink:0';
    b.setAttribute('aria-label',label);
    b.onmouseover=function(){b.style.opacity='1';};
    b.onmouseout=function(){b.style.opacity='.75';};
    b.innerHTML='<svg width="20" height="20" viewBox="0 0 24 24" fill="rgba(255,255,255,.85)"><path d="'+path+'"/></svg>';
    return b;
  }
};

W.TackendoPlayer=TackendoPlayer;
})(window);
