<?php
/* Template Name: Tackendo Blog */
if ( ! defined( 'ABSPATH' ) ) exit;

$logo_url = 'https://tackendo.com/wp-content/uploads/2025/06/Tackendo-logo-white-on-transparent-262x76-1.png';
$site_url = esc_url( home_url('/') );

// Pagination
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
$paged = max(1, (int) $paged);

$args = array(
    'post_type'      => 'post',
    'post_status'    => 'publish',
    'posts_per_page' => 12,
    'paged'          => $paged,
);
$blog_query = new WP_Query($args);
$total_pages = $blog_query->max_num_pages;
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>TACKENDO Magazine &mdash; Free FAST TV &amp; CTV Industry News</title>
<meta name="description" content="Daily editorial articles on FAST TV, CTV advertising, music streaming, and the channels of TACKENDO.">
<meta name="robots" content="index, follow">
<link rel="canonical" href="<?php echo $site_url; ?>blog">
<meta property="og:title" content="TACKENDO Magazine">
<meta property="og:description" content="Daily editorial articles on FAST TV, CTV advertising, music streaming and more.">
<meta property="og:type" content="website">
<meta name="theme-color" content="#E8001C">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Figtree:wght@400;500;600;700&display=swap" rel="stylesheet">
<?php wp_head(); ?>
<style>
:root{--bg:#07070f;--surface:#0d0d18;--card:#111120;--red:#E8001C;--white:#fff;--text:#d8d8e8;--grey:#7a7a90;--muted:#4a4a60;--border:#1c1c2e}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body.tackendo-blog{background:var(--bg);color:var(--text);font-family:'Figtree','Segoe UI',sans-serif;font-size:15px;line-height:1.6}
body.tackendo-blog h1,body.tackendo-blog h2,body.tackendo-blog h3{color:#fff!important;font-weight:400!important}
body.tackendo-blog a{color:inherit;text-decoration:none}
/* Hide Astra */
body.tackendo-blog .site-header,body.tackendo-blog #masthead,body.tackendo-blog #ast-fixed-header,body.tackendo-blog .site-footer,body.tackendo-blog #astra-footer-area{display:none!important}
/* Header */
#tb-header{position:sticky;top:0;z-index:200;background:rgba(7,7,15,.92);backdrop-filter:blur(18px);border-bottom:1px solid var(--border);height:64px;padding:0 48px;display:flex;align-items:center;justify-content:space-between}
#tb-header .logo img{height:34px;display:block}
#tb-header nav{display:flex;gap:28px}
#tb-header nav a{color:var(--grey);font-size:12px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;transition:color .2s}
#tb-header nav a:hover,#tb-header nav a.active{color:#fff}
/* Hero */
.mag-hero{background:linear-gradient(160deg,#09090f 0%,#0c0818 100%);border-bottom:1px solid var(--border);padding:60px 48px 48px}
.mag-hero-label{font-size:11px;font-weight:800;letter-spacing:.2em;text-transform:uppercase;color:var(--red);margin-bottom:12px}
.mag-hero-title{font-family:'Bebas Neue',sans-serif;font-size:clamp(48px,6vw,80px);color:#fff;line-height:.92;letter-spacing:.03em;margin-bottom:12px}
.mag-hero-sub{font-size:15px;color:var(--grey);max-width:500px}
/* Category filters */
.mag-filters{display:flex;gap:8px;padding:24px 48px;border-bottom:1px solid var(--border);flex-wrap:wrap;background:var(--surface)}
.mag-filter{padding:6px 16px;border-radius:20px;border:1px solid var(--border);background:transparent;color:var(--grey);font-family:'Figtree',sans-serif;font-size:11px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;cursor:pointer;transition:all .18s;text-decoration:none;display:inline-block}
.mag-filter:hover,.mag-filter.active{background:var(--red);border-color:var(--red);color:#fff}
/* Main layout */
.mag-layout{display:grid;grid-template-columns:1fr 280px;gap:48px;padding:48px 48px;max-width:1400px;margin:0 auto}
/* Articles grid */
.mag-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:24px;align-content:start}
.mag-card{background:var(--card);border:1px solid var(--border);border-radius:12px;overflow:hidden;display:flex;flex-direction:column;transition:all .22s}
.mag-card:hover{transform:translateY(-4px);border-color:rgba(232,0,28,.4);box-shadow:0 12px 40px rgba(0,0,0,.4)}
.mag-card.feat{grid-column:1/-1;display:grid;grid-template-columns:1fr 1fr}
.mag-card-img{position:relative;overflow:hidden}
.mag-card:not(.feat) .mag-card-img{aspect-ratio:16/9}
.mag-card.feat .mag-card-img{min-height:240px}
.mag-card-img img{width:100%;height:100%;object-fit:cover;display:block;transition:transform .3s}
.mag-card:hover .mag-card-img img{transform:scale(1.04)}
.mag-card-body{padding:20px;flex:1;display:flex;flex-direction:column}
.mag-card-meta{display:flex;align-items:center;gap:8px;margin-bottom:10px}
.mag-card-tag{font-size:9px;font-weight:900;letter-spacing:.14em;text-transform:uppercase;color:var(--red);background:rgba(232,0,28,.1);padding:3px 8px;border-radius:3px}
.mag-card-date{font-size:11px;color:var(--muted)}
.mag-card-title{font-family:'Bebas Neue',sans-serif;font-size:19px;letter-spacing:.03em;color:#fff!important;line-height:1.15;margin-bottom:8px}
.mag-card.feat .mag-card-title{font-size:24px}
.mag-card-excerpt{font-size:12px;color:var(--muted);line-height:1.65;flex:1;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}
/* Pagination */
.mag-pagination{display:flex;gap:8px;padding-top:32px;flex-wrap:wrap}
.mag-page-btn{padding:8px 16px;border-radius:8px;border:1px solid var(--border);background:var(--card);color:var(--grey);font-size:13px;font-weight:700;text-decoration:none;transition:all .2s}
.mag-page-btn:hover,.mag-page-btn.current{background:var(--red);border-color:var(--red);color:#fff}
/* Sidebar */
.mag-sidebar{display:flex;flex-direction:column;gap:20px}
.sb-widget{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:20px}
.sb-title{font-family:'Bebas Neue',sans-serif;font-size:20px;letter-spacing:.04em;color:#fff!important;margin-bottom:14px;padding-bottom:12px;border-bottom:1px solid var(--border)}
.sb-ch{display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid rgba(255,255,255,.04);text-decoration:none;color:var(--text);transition:color .18s}
.sb-ch:last-child{border-bottom:none}
.sb-ch:hover{color:#fff}
.sb-ch img{width:36px;height:36px;border-radius:7px;object-fit:cover;flex-shrink:0}
.sb-ch-name{font-size:12px;font-weight:700;color:#fff}
.sb-ch-cat{font-size:10px;color:var(--muted)}
.sb-cta{background:linear-gradient(135deg,rgba(232,0,28,.14),rgba(232,0,28,.05));border:1px solid rgba(232,0,28,.28);border-radius:12px;padding:24px;text-align:center}
.sb-cta-t{font-family:'Bebas Neue',sans-serif;font-size:22px;color:#fff!important;margin-bottom:8px}
.sb-cta-p{font-size:12px;color:var(--grey);margin-bottom:16px;line-height:1.65}
.btn-red{display:flex;align-items:center;justify-content:center;background:var(--red);color:#fff!important;font-weight:700;font-size:13px;padding:12px 20px;border-radius:8px;text-decoration:none;transition:all .2s;margin-bottom:8px}
.btn-red:hover{background:#c8001a;transform:translateY(-2px)}
.btn-ghost{display:flex;align-items:center;justify-content:center;color:var(--text)!important;font-size:13px;padding:12px 20px;border-radius:8px;border:1px solid var(--border);text-decoration:none}
.tag-cloud{display:flex;flex-wrap:wrap;gap:7px}
.tag-pill{padding:5px 12px;border:1px solid var(--border);border-radius:20px;font-size:11px;font-weight:600;color:var(--grey)!important;background:var(--surface);text-decoration:none;transition:all .18s;display:inline-block}
.tag-pill:hover{color:#fff!important;border-color:var(--grey)}
/* Footer */
#tb-footer{background:#050509;border-top:1px solid var(--border);padding:32px 48px;display:flex;align-items:center;justify-content:space-between}
#tb-footer .footer-copy{font-size:12px;color:var(--muted)}
#tb-footer .footer-links{display:flex;gap:20px}
#tb-footer .footer-links a{font-size:12px;color:var(--muted);text-decoration:none}
#tb-footer .footer-links a:hover{color:#fff}
/* No image fallback */
.mag-card-img-fallback{width:100%;height:100%;min-height:160px;display:flex;align-items:center;justify-content:center;font-family:'Bebas Neue',sans-serif;font-size:13px;letter-spacing:.1em;color:rgba(255,255,255,.2)}
@media(max-width:1100px){.mag-layout{grid-template-columns:1fr}}
@media(max-width:900px){#tb-header{padding:0 20px}#tb-header nav{display:none}.mag-hero,.mag-filters,.mag-layout{padding-left:20px;padding-right:20px}.mag-grid{grid-template-columns:1fr}.mag-card.feat{grid-template-columns:1fr}}
@media(max-width:600px){.mag-card.feat{display:block}}
</style>
</head>
<body class="tackendo-blog">

<header id="tb-header">
  <a href="<?php echo $site_url; ?>" class="logo">
    <img src="<?php echo esc_url($logo_url); ?>" alt="TACKENDO" loading="eager" style="height:36px;width:auto">
  </a>
  <nav>
    <a href="<?php echo $site_url; ?>">Home</a>
    <a href="#" class="active">Magazine</a>
    <a href="<?php echo $site_url; ?>#channels">Channels</a>
    <a href="<?php echo esc_url(home_url('/about')); ?>">About</a>
    <a href="<?php echo esc_url(home_url('/advertise')); ?>">Advertise</a>
  </nav>
</header>

<div class="mag-hero">
  <p class="mag-hero-label">Daily &middot; Editorial</p>
  <h1 class="mag-hero-title">TACKENDO<br>Magazine</h1>
  <p class="mag-hero-sub">News and insights on FAST TV, CTV advertising, music streaming, and the channels shaping connected television.</p>
</div>

<div class="mag-filters">
  <a href="<?php echo esc_url(home_url('/blog')); ?>" class="mag-filter active">All</a>
  <?php
  $tags = array('CTV Industry','Music','Advertising','Platform Guide','Channel Spotlight','Streaming Guide');
  foreach ($tags as $t) {
    $tag_obj = get_term_by('name', $t, 'post_tag');
    $tag_url = $tag_obj ? get_tag_link($tag_obj->term_id) : '#';
    echo '<a href="' . esc_url($tag_url) . '" class="mag-filter">' . esc_html($t) . '</a>';
  }
  ?>
</div>

<div class="mag-layout">
  <div>
    <div class="mag-grid">
      <?php
      $first = true;
      if ($blog_query->have_posts()) :
        while ($blog_query->have_posts()) : $blog_query->the_post();
          $post_id  = get_the_ID();
          $tag      = get_post_meta($post_id, '_tcore_topic_tag', true) ?: 'FAST TV';
          $thumb    = get_the_post_thumbnail_url($post_id, 'large');
          $excerpt  = wp_trim_words(get_the_excerpt() ?: wp_strip_all_tags(get_the_content()), 30);
          $feat_cls = ($first && $paged == 1) ? ' feat' : '';
          $first    = false;

          // Fallback gradients per tag
          $grads = array('Music'=>'#1a0533,#3b0764','CTV Industry'=>'#020617,#1e3a5f','Advertising'=>'#001a0d,#005c28','Platform Guide'=>'#05010d,#1a0860','Channel Spotlight'=>'#200004,#8c0018','Streaming Guide'=>'#020920,#0a2540');
          $grad = isset($grads[$tag]) ? $grads[$tag] : '#180824,#080c24';
      ?>
      <a href="<?php the_permalink(); ?>" class="mag-card<?php echo $feat_cls; ?>">
        <div class="mag-card-img">
          <?php if ($thumb) : ?>
            <img src="<?php echo esc_url($thumb); ?>" alt="<?php echo esc_attr(get_the_title()); ?>" loading="lazy">
          <?php else : ?>
            <div class="mag-card-img-fallback" style="background:linear-gradient(135deg,<?php echo $grad; ?>)"><?php echo esc_html($tag); ?></div>
          <?php endif; ?>
        </div>
        <div class="mag-card-body">
          <div class="mag-card-meta">
            <span class="mag-card-tag"><?php echo esc_html($tag); ?></span>
            <span class="mag-card-date"><?php echo get_the_date('M j, Y'); ?></span>
          </div>
          <h2 class="mag-card-title"><?php the_title(); ?></h2>
          <p class="mag-card-excerpt"><?php echo esc_html($excerpt); ?></p>
        </div>
      </a>
      <?php endwhile; wp_reset_postdata(); endif; ?>
    </div>

    <?php if ($total_pages > 1) : ?>
    <div class="mag-pagination">
      <?php
      for ($i = 1; $i <= $total_pages; $i++) {
        $url = ($i == 1) ? home_url('/blog/') : home_url('/blog/page/' . $i . '/');
        $cls = ($i == $paged) ? ' current' : '';
        echo '<a href="' . esc_url($url) . '" class="mag-page-btn' . $cls . '">' . $i . '</a>';
      }
      ?>
    </div>
    <?php endif; ?>
  </div>

  <aside class="mag-sidebar">
    <?php
    // Discover Channels widget
    require_once TCORE_PATH . 'includes/tcore-channels.php';
    $channels = tcore_channels();
    $sidebar_chs = array_slice(array_values($channels), 0, 8);
    ?>
    <div class="sb-widget">
      <h3 class="sb-title">Our Channels</h3>
      <?php foreach ($sidebar_chs as $ch) : ?>
      <a href="<?php echo esc_url(home_url('/' . array_search($ch, $channels) . '/')); ?>" class="sb-ch">
        <img src="<?php echo esc_url($ch['logo']); ?>" alt="<?php echo esc_attr($ch['name']); ?>" loading="lazy">
        <div><p class="sb-ch-name"><?php echo esc_html($ch['name']); ?></p><p class="sb-ch-cat"><?php echo esc_html($ch['cat']); ?></p></div>
      </a>
      <?php endforeach; ?>
    </div>

    <div class="sb-cta">
      <h3 class="sb-cta-t">Watch on Your TV</h3>
      <p class="sb-cta-p">Free, no subscription, no login required.</p>
      <a href="https://channelstore.roku.com/details/8244e521d238b28c45271329a3ebe907/tackendo" class="btn-red" target="_blank" rel="noopener">Add to Roku</a>
      <a href="https://www.amazon.com/gp/product/B0DGNFS8N9" class="btn-ghost" target="_blank" rel="noopener">Fire TV</a>
    </div>

    <div class="sb-widget">
      <h3 class="sb-title">Topics</h3>
      <div class="tag-cloud">
        <?php
        $topics = array('CTV','FAST TV','Music','Advertising','Streaming','OTT','Lifestyle','Pop Culture','Roku','Fire TV');
        foreach ($topics as $t) {
          echo '<a href="' . esc_url(home_url('/tag/' . sanitize_title($t))) . '" class="tag-pill">' . esc_html($t) . '</a>';
        }
        ?>
      </div>
    </div>
  </aside>
</div>

<footer id="tb-footer">
  <p class="footer-copy">&copy; 2024&ndash;<?php echo date('Y'); ?> TACKENDO &mdash; Netradio Network. All rights reserved.</p>
  <div class="footer-links">
    <a href="<?php echo esc_url(home_url('/privacy-policy')); ?>">Privacy Policy</a>
    <a href="<?php echo esc_url(home_url('/contact')); ?>">Contact</a>
    <a href="<?php echo $site_url; ?>">Home</a>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
