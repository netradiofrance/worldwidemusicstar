<?php
/* Template Name: Tackendo Homepage */
if ( ! defined( 'ABSPATH' ) ) exit;

$recent_posts = get_posts( array(
    'numberposts' => 5,
    'post_status' => 'publish',
    'meta_key'    => '_tcore_generated',
    'meta_value'  => 1,
) );
if ( empty( $recent_posts ) ) {
    $recent_posts = get_posts( array( 'numberposts' => 5, 'post_status' => 'publish' ) );
}

$site_url = esc_url( home_url( '/' ) );
$logo_url = 'https://tackendo.com/wp-content/uploads/2025/06/Tackendo-logo-white-on-transparent-262x76-1.png';
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>TACKENDO &mdash; Free FAST TV Channels | Music, Culture &amp; Lifestyle Live 24/7</title>
<meta name="description" content="TACKENDO streams 20+ free live TV channels 24/7 &mdash; music, pop culture, lifestyle and more. Watch on Roku, Fire TV, web and mobile. No subscription required.">
<meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">
<link rel="canonical" href="<?php echo $site_url; ?>">
<meta property="og:type" content="website">
<meta property="og:site_name" content="TACKENDO">
<meta property="og:url" content="<?php echo $site_url; ?>">
<meta property="og:title" content="TACKENDO &mdash; Free FAST TV Channels | Live 24/7">
<meta property="og:description" content="Stream 20+ free live linear TV channels. No account needed.">
<meta property="og:image" content="<?php echo esc_url( $logo_url ); ?>">
<meta property="og:locale" content="en_US">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="TACKENDO &mdash; Free FAST TV Channels">
<meta name="twitter:image" content="<?php echo esc_url( $logo_url ); ?>">
<meta name="theme-color" content="#E8001C">
<link rel="alternate" hreflang="en" href="<?php echo $site_url; ?>">
<link rel="alternate" hreflang="x-default" href="<?php echo $site_url; ?>">
<script type="application/ld+json">
{"@context":"https://schema.org","@graph":[{"@type":"WebSite","url":"<?php echo $site_url; ?>","name":"TACKENDO","description":"Free FAST TV platform, 20+ live linear channels 24/7"},{"@type":"Organization","name":"TACKENDO","legalName":"Netradio Network","url":"<?php echo $site_url; ?>","logo":{"@type":"ImageObject","url":"<?php echo esc_url( $logo_url ); ?>"}}]}
</script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Figtree:wght@400;500;600;700&display=swap" rel="stylesheet">
<?php wp_head(); ?>
<link rel="stylesheet" href="<?php echo esc_url( TCORE_URL . 'assets/tcore.css' ); ?>?v=<?php echo TCORE_VERSION; ?>">
<style>
/* CRITICAL OVERRIDES — inlined to beat SiteGround CSS combine + Astra */
*,*::before,*::after{box-sizing:border-box}
html{scroll-behavior:smooth}
body.tackendo-home{background:#07070f!important;color:#d8d8e8!important;margin:0!important;padding:0!important;font-family:'Figtree','Segoe UI',sans-serif!important}
body.tackendo-home h1,body.tackendo-home h2,body.tackendo-home h3,body.tackendo-home h4,body.tackendo-home h5,body.tackendo-home h6{color:#ffffff!important;font-weight:400!important;line-height:1.1!important;margin:0!important;padding:0!important}
body.tackendo-home p{margin:0!important;padding:0!important}
/* ── Hide ALL Astra native UI elements ── */
body.tackendo-home .site-header,
body.tackendo-home #masthead,
body.tackendo-home #ast-fixed-header,
body.tackendo-home .ast-hfb-wrap,
body.tackendo-home .main-header-bar-wrap,
body.tackendo-home .ast-above-header-section,
body.tackendo-home .ast-below-header,
body.tackendo-home .ast-mobile-header,
body.tackendo-home .site-footer,
body.tackendo-home #astra-footer-area,
body.tackendo-home .ast-breadcrumbs-wrapper,
body.tackendo-home .ast-above-header,
body.tackendo-home .ast-primary-header-bar,
body.tackendo-home .ast-desktop-header,
body.tackendo-home .main-navigation,
body.tackendo-home .astra-breadcrumbs{display:none!important}
/* ── HERO — renamed to .tc-hero to avoid Astra .hero conflict ── */
body.tackendo-home .tc-hero{display:grid!important;grid-template-columns:460px 1fr;position:relative;min-height:520px;overflow:hidden}
body.tackendo-home .tc-hero-bg{position:absolute;inset:0;z-index:0;background:radial-gradient(ellipse 60% 80% at 25% 55%,rgba(232,0,28,.14) 0%,transparent 70%),radial-gradient(ellipse 40% 60% at 70% 30%,rgba(80,0,120,.12) 0%,transparent 60%),linear-gradient(160deg,#090912 0%,#0c0818 100%)}
body.tackendo-home .tc-hero-content{position:relative;z-index:2;padding:60px 32px 60px 52px;display:flex!important;flex-direction:column;justify-content:center;visibility:visible!important;opacity:1!important}
body.tackendo-home .tc-hero-visual{position:relative;z-index:2;display:flex!important;align-items:center;justify-content:center;padding:30px;visibility:visible!important;opacity:1!important}
body.tackendo-home .tc-hero-title{font-family:'Bebas Neue',sans-serif!important;font-size:clamp(52px,6.2vw,82px)!important;line-height:.92!important;color:#ffffff!important;margin-bottom:18px!important;letter-spacing:.02em!important;visibility:visible!important;opacity:1!important}
body.tackendo-home .tc-hero-title em{color:#E8001C!important;font-style:normal!important}
body.tackendo-home .tc-hero-desc{font-size:15px!important;color:#7a7a90!important;max-width:500px;margin-bottom:26px!important;line-height:1.75!important}
body.tackendo-home .tc-hero-desc strong{color:#d8d8e8!important}
body.tackendo-home .tc-hero-epg{background:rgba(255,255,255,.035);border:1px solid #1c1c2e;border-left:3px solid #E8001C;border-radius:0 10px 10px 0;padding:16px 20px;margin-bottom:28px;max-width:480px}
body.tackendo-home .tc-hero-epg-label{font-size:9px!important;font-weight:800!important;letter-spacing:.2em;text-transform:uppercase;color:#E8001C!important;margin-bottom:10px!important;display:flex;align-items:center;gap:6px}
body.tackendo-home #hn-title{font-size:17px!important;font-weight:700!important;color:#ffffff!important;min-height:20px;margin-bottom:3px!important}
body.tackendo-home #hn-time{font-size:12px!important;color:#7a7a90!important;margin-bottom:10px!important}
body.tackendo-home #hn-next{font-size:12px!important;color:#4a4a60!important}
body.tackendo-home .tc-hero-actions{display:flex;gap:12px;flex-wrap:wrap;align-items:center}
/* ── Hero floating card ── */
body.tackendo-home .tc-hero-card{width:270px;height:270px;border-radius:22px;overflow:hidden;box-shadow:0 0 0 1px rgba(232,0,28,.35),0 0 80px rgba(232,0,28,.18),0 48px 80px rgba(0,0,0,.7);animation:tcfloat 7s ease-in-out infinite}
body.tackendo-home .tc-hero-card img{width:100%;height:100%;object-fit:cover;display:block}
@keyframes tcfloat{0%,100%{transform:translateY(0) rotate(-1.5deg)}50%{transform:translateY(-14px) rotate(1.5deg)}}
/* ── Buttons ── */
body.tackendo-home .tc-btn-primary{display:inline-flex;align-items:center;gap:8px;background:#E8001C;color:#fff!important;font-weight:700;font-size:14px;padding:13px 28px;border-radius:8px;text-decoration:none;transition:all .2s;border:none;cursor:pointer}
body.tackendo-home .tc-btn-primary:hover{background:#c8001a;transform:translateY(-2px);color:#fff!important}
body.tackendo-home .tc-btn-ghost{display:inline-flex;align-items:center;gap:8px;color:#d8d8e8!important;font-weight:600;font-size:14px;padding:13px 24px;border-radius:8px;border:1px solid #1c1c2e;text-decoration:none;transition:all .2s}
body.tackendo-home .tc-btn-ghost:hover{border-color:#7a7a90;color:#ffffff!important}
/* ── Section titles force ── */
body.tackendo-home .section-title{color:#ffffff!important;font-family:'Bebas Neue',sans-serif!important;font-size:34px!important;letter-spacing:.04em!important;line-height:1!important}
body.tackendo-home .section-label{color:#7a7a90!important;font-size:10px!important;font-weight:800!important;text-transform:uppercase;letter-spacing:.2em!important}
/* ── Article thumbnails — pure gradient, no emoji ── */
body.tackendo-home .art-thumb-grad{width:100%;height:100%;min-height:160px;display:block}
/* ── Footer — no giant emojis ── */
body.tackendo-home .fp-label{font-size:12px;font-weight:600;color:#d8d8e8!important}
body.tackendo-home .footer-links a{color:#4a4a60!important}
body.tackendo-home .footer-links a:hover{color:#ffffff!important}
body.tackendo-home .footer-copy{color:#4a4a60!important;margin:0!important}
body.tackendo-home .footer-legal a{color:#4a4a60!important}
body.tackendo-home .footer-legal a:hover{color:#ffffff!important}
/* ── Sidebar ── */
body.tackendo-home .sidebar-ch-name{color:#ffffff!important}
body.tackendo-home .sidebar-ch-cat{color:#4a4a60!important}
/* ── Channel cards ── */
body.tackendo-home .ch-name{color:#ffffff!important}
body.tackendo-home .ch-tag{color:#E8001C!important}
body.tackendo-home .ch-desc{color:#4a4a60!important}
/* ── EPG ── */
body.tackendo-home .epg-show{color:#ffffff!important}
body.tackendo-home .epg-ch{color:#7a7a90!important}
body.tackendo-home .epg-time{color:#4a4a60!important}
/* ── Tag cloud links ── */
body.tackendo-home .tag-pill{color:#7a7a90!important}
body.tackendo-home .tag-pill:hover{color:#ffffff!important}
/* ── Live dot ── */
body.tackendo-home .live-dot{background:#E8001C;width:7px;height:7px;border-radius:50%;display:inline-block;animation:tcblink 1.6s ease-in-out infinite}
@keyframes tcblink{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.4;transform:scale(.7)}}
body.tackendo-home .live-badge{display:inline-flex;align-items:center;gap:6px;background:#E8001C;color:#fff!important;font-size:10px;font-weight:800;letter-spacing:.14em;padding:4px 10px;border-radius:3px;text-transform:uppercase}
body.tackendo-home .live-badge .live-dot{background:#fff}
/* ── See all ── */
body.tackendo-home .see-all{color:#E8001C!important;font-size:11px;font-weight:800;text-decoration:none;letter-spacing:.1em;text-transform:uppercase}
/* ── Article cards ── */
body.tackendo-home .article-title{color:#ffffff!important}
body.tackendo-home .article-excerpt{color:#4a4a60!important}
body.tackendo-home .article-tag{color:#E8001C!important}
body.tackendo-home .article-date{color:#4a4a60!important}
/* ── Responsive ── */
@media(max-width:900px){body.tackendo-home .tc-hero{grid-template-columns:1fr!important}body.tackendo-home .tc-hero-visual{display:none!important}body.tackendo-home .tc-hero-content{padding:44px 24px!important}}

/* ── LAYOUT GRIDS — !important to beat Astra ── */
body.tackendo-home .epg-section{display:block!important;background:#0d0d18;border-top:1px solid #1c1c2e;border-bottom:1px solid #1c1c2e;padding:40px 48px}
body.tackendo-home .epg-strip{display:flex!important;gap:12px;overflow-x:auto;scroll-behavior:smooth;-ms-overflow-style:none;scrollbar-width:none!important}body.tackendo-home .epg-strip::-webkit-scrollbar{display:none!important}
body.tackendo-home .epg-card{flex:0 0 220px!important;background:#111120;border:1px solid #1c1c2e;border-radius:12px;overflow:hidden;display:flex!important;flex-direction:column;text-decoration:none;color:#d8d8e8}
body.tackendo-home .channels-section{display:block!important;padding:60px 48px}
body.tackendo-home .channels-grid{display:grid!important;grid-template-columns:repeat(5,1fr)!important;gap:14px}
body.tackendo-home .ch-card{background:#111120;border:1px solid #1c1c2e;border-radius:14px;overflow:hidden;display:flex!important;flex-direction:column;text-decoration:none;color:#d8d8e8;transition:all .24s}
body.tackendo-home .ch-card:hover{transform:translateY(-5px);border-color:rgba(232,0,28,.45)}
body.tackendo-home .ch-img{width:100%;aspect-ratio:1/1;object-fit:cover;background:#0d0d18;display:block}
body.tackendo-home .ch-placeholder{width:100%;aspect-ratio:1/1;display:flex!important;align-items:center;justify-content:center;font-family:'Bebas Neue',sans-serif;font-size:13px;color:rgba(255,255,255,.45);text-align:center;padding:12px}
body.tackendo-home .ch-body{padding:12px 14px;flex:1}
body.tackendo-home .ch-foot{display:flex!important;align-items:center;justify-content:space-between;padding:9px 14px;border-top:1px solid #1c1c2e;background:rgba(255,255,255,.012)}
body.tackendo-home .ch-live{display:flex!important;align-items:center;gap:5px;font-size:9px;font-weight:800;color:#22c55e;letter-spacing:.1em;text-transform:uppercase}
body.tackendo-home .editorial-section{display:block!important;padding:60px 48px;background:#0d0d18;border-top:1px solid #1c1c2e}
body.tackendo-home .editorial-layout{display:grid!important;grid-template-columns:1fr 296px!important;gap:44px}
body.tackendo-home .articles-grid{display:grid!important;grid-template-columns:repeat(2,1fr)!important;gap:20px}
body.tackendo-home .article-card{background:#111120;border:1px solid #1c1c2e;border-radius:12px;overflow:hidden;text-decoration:none;color:#d8d8e8;display:block!important;transition:all .2s}
body.tackendo-home .article-card.featured{grid-column:1/-1!important;display:grid!important;grid-template-columns:1fr 1fr!important}
body.tackendo-home .article-thumb{position:relative;overflow:hidden;aspect-ratio:16/9}
body.tackendo-home .article-card.featured .article-thumb{aspect-ratio:auto;min-height:220px}
body.tackendo-home .article-body{padding:18px 20px}
body.tackendo-home .sidebar{display:flex!important;flex-direction:column;gap:20px}
body.tackendo-home .sidebar-widget{background:#111120;border:1px solid #1c1c2e;border-radius:12px;padding:20px;display:block!important}
body.tackendo-home .sidebar-title{font-family:'Bebas Neue',sans-serif!important;font-size:20px!important;color:#ffffff!important;margin-bottom:14px!important;padding-bottom:12px;border-bottom:1px solid #1c1c2e}
body.tackendo-home .sidebar-ch{display:flex!important;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid rgba(255,255,255,.04);text-decoration:none;color:#d8d8e8}
body.tackendo-home .sidebar-cta{background:linear-gradient(135deg,rgba(232,0,28,.14),rgba(232,0,28,.05));border:1px solid rgba(232,0,28,.28);border-radius:12px;padding:24px;text-align:center;display:block!important}
body.tackendo-home .sidebar-cta-title{font-family:'Bebas Neue',sans-serif!important;font-size:22px!important;color:#ffffff!important;margin-bottom:8px!important}
body.tackendo-home .sidebar-cta-text{font-size:12px!important;color:#7a7a90!important;margin-bottom:16px!important;line-height:1.65}
body.tackendo-home .tag-cloud{display:flex!important;flex-wrap:wrap;gap:7px}
body.tackendo-home .tag-pill{padding:5px 12px!important;border:1px solid #1c1c2e;border-radius:20px;font-size:11px;font-weight:600;color:#7a7a90!important;background:#0d0d18;text-decoration:none;display:inline-block!important;margin:0!important}
body.tackendo-home #tackendo-footer{display:block!important;background:#050509;border-top:1px solid #1c1c2e;padding:52px 48px 32px}
body.tackendo-home .footer-grid{display:grid!important;grid-template-columns:240px 1fr 1fr 1fr!important;gap:44px;margin-bottom:44px}
body.tackendo-home .footer-col-title{font-size:10px!important;font-weight:900!important;letter-spacing:.18em;text-transform:uppercase;color:#7a7a90!important;margin:0 0 16px!important;display:block!important}
body.tackendo-home .footer-links{list-style:none!important;margin:0!important;padding:0!important;display:flex!important;flex-direction:column;gap:9px}
body.tackendo-home .footer-platforms{display:flex!important;flex-direction:column;gap:10px}
body.tackendo-home .footer-platform{display:flex!important;align-items:center;gap:10px;padding:10px 16px;background:#0d0d18;border:1px solid #1c1c2e;border-radius:8px;font-size:12px;font-weight:600;color:#d8d8e8!important;text-decoration:none}
body.tackendo-home .footer-platform:hover{color:#ffffff!important;border-color:#7a7a90}
body.tackendo-home .footer-bottom{display:flex!important;align-items:center;justify-content:space-between;border-top:1px solid #1c1c2e;padding-top:24px}
body.tackendo-home .footer-legal{display:flex!important;gap:20px}
/* ── Section header ── */
body.tackendo-home .section-header{display:flex!important;align-items:flex-end;justify-content:space-between;margin-bottom:28px}
/* ── Filter tabs ── */
body.tackendo-home .filter-tabs{display:flex!important;gap:8px;margin-bottom:28px;flex-wrap:wrap}
body.tackendo-home .ftab{padding:7px 18px;border-radius:30px;border:1px solid #1c1c2e;background:transparent;color:#7a7a90!important;font-size:11px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;cursor:pointer}
body.tackendo-home .ftab.active{background:#E8001C!important;border-color:#E8001C!important;color:#fff!important}
/* ── Header ── */
body.tackendo-home #tackendo-header{position:sticky!important;top:0;z-index:200;background:rgba(7,7,15,.9);backdrop-filter:blur(18px);border-bottom:1px solid #1c1c2e;height:64px;padding:0 48px;display:flex!important;align-items:center;justify-content:space-between}
body.tackendo-home #tackendo-header .logo img{height:36px;width:auto;display:block}
body.tackendo-home #tackendo-header nav{display:flex!important;align-items:center;gap:30px}
body.tackendo-home #tackendo-header nav a{color:#7a7a90!important;text-decoration:none;font-size:12px;font-weight:700;letter-spacing:.08em;text-transform:uppercase}
body.tackendo-home #tackendo-header nav a:hover{color:#ffffff!important}
body.tackendo-home .hdr-right{display:flex!important;align-items:center;gap:8px}
body.tackendo-home .btn-platform{display:inline-flex!important;align-items:center;gap:6px;padding:7px 14px;border-radius:6px;font-size:11px;font-weight:700;text-decoration:none;color:#d8d8e8!important;border:1px solid #1c1c2e;background:#0d0d18}
body.tackendo-home .btn-platform:hover{background:#E8001C!important;border-color:#E8001C!important;color:#fff!important}
/* ── EPG body ── */
body.tackendo-home .epg-body{padding:12px}
body.tackendo-home .epg-top{display:flex!important;align-items:center;gap:8px;margin-bottom:8px}
body.tackendo-home .epg-logo{width:32px;height:32px;border-radius:7px;object-fit:cover;background:#0d0d18;flex-shrink:0;display:block}
body.tackendo-home .epg-thumb-prog{width:100%;aspect-ratio:16/9;background:#07070f #111120;display:block;min-height:80px}
body.tackendo-home .epg-bar{height:2px;background:#1c1c2e;border-radius:1px;overflow:hidden;margin-top:auto}
body.tackendo-home .epg-fill{height:100%;background:#E8001C;border-radius:1px}
/* ── Watch Now button fix ── */
body.tackendo-home .tc-btn-primary{font-size:14px!important}
body.tackendo-home .tc-btn-primary .btn-icon{font-size:12px!important;line-height:1}
/* ── Responsive ── */
@media(max-width:1200px){body.tackendo-home .channels-grid{grid-template-columns:repeat(4,1fr)!important}body.tackendo-home .footer-grid{grid-template-columns:200px 1fr 1fr!important}}
@media(max-width:900px){body.tackendo-home #tackendo-header{padding:0 20px!important}body.tackendo-home #tackendo-header nav{display:none!important}body.tackendo-home .epg-section,body.tackendo-home .channels-section,body.tackendo-home .editorial-section{padding:36px 24px!important}body.tackendo-home .channels-grid{grid-template-columns:repeat(3,1fr)!important}body.tackendo-home .editorial-layout{grid-template-columns:1fr!important}body.tackendo-home .footer-grid{grid-template-columns:1fr 1fr!important}body.tackendo-home #tackendo-footer{padding:40px 24px 24px!important}}
@media(max-width:600px){body.tackendo-home .channels-grid{grid-template-columns:repeat(2,1fr)!important}body.tackendo-home .articles-grid{grid-template-columns:1fr!important}body.tackendo-home .article-card.featured{grid-template-columns:1fr!important}body.tackendo-home .footer-grid{grid-template-columns:1fr!important}}

/* ── Upcoming shows countdown ── */
body.tackendo-home .upcoming-card{background:rgba(255,255,255,.055);border:1px solid rgba(255,255,255,.1);border-radius:10px;display:flex;align-items:center;gap:10px;padding:10px 14px;min-width:180px;max-width:260px;cursor:default}
body.tackendo-home .upcoming-thumb{width:52px;height:34px;border-radius:5px;object-fit:cover;flex-shrink:0;background:var(--surface)}
body.tackendo-home .upcoming-info{}
body.tackendo-home .upcoming-label{font-size:8px;font-weight:900;letter-spacing:.14em;text-transform:uppercase;color:var(--red);margin-bottom:3px}
body.tackendo-home .upcoming-show{font-size:12px;font-weight:700;color:#fff;line-height:1.2;margin-bottom:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:160px}
body.tackendo-home .upcoming-countdown{font-size:11px;color:var(--grey);font-variant-numeric:tabular-nums}
body.tackendo-home .upcoming-countdown span{color:#fff;font-weight:700}

/* ── Upcoming shows — center hero column ── */
/* upcoming column — 2 horizontal cards filling hero height */
body.tackendo-home .tc-hero-upcoming{position:absolute!important;z-index:3;top:0;bottom:0;left:420px;right:360px;display:flex!important;flex-direction:column;gap:12px;justify-content:center;padding:24px 16px}
body.tackendo-home .upcoming-section-label{font-size:9px;font-weight:900;letter-spacing:.22em;text-transform:uppercase;color:var(--grey);margin-bottom:6px;flex-shrink:0}
/* card: full width, horizontal inside */
body.tackendo-home .upcoming-card{width:100%;background:rgba(255,255,255,.045);border:1px solid rgba(255,255,255,.09);border-radius:14px;overflow:hidden;text-decoration:none;display:flex!important;flex-direction:row!important;height:190px;transition:all .3s}
body.tackendo-home .upcoming-card:hover{border-color:rgba(232,0,28,.55);box-shadow:0 8px 32px rgba(0,0,0,.5)}
/* thumb — fixed width, full card height, image fills */
body.tackendo-home .upcoming-card-thumb{width:220px;min-width:220px;flex-shrink:0;position:relative;background:#09091f;background-size:cover!important;background-position:center!important}
body.tackendo-home .upcoming-card-thumb-overlay{position:absolute;inset:0;background:linear-gradient(to right,rgba(0,0,0,.15) 0%,rgba(7,7,15,.75) 100%)}
body.tackendo-home .upcoming-card-live{position:absolute;bottom:10px;left:10px;display:inline-flex;align-items:center;gap:5px;background:var(--red);color:#fff;font-size:9px;font-weight:900;letter-spacing:.1em;text-transform:uppercase;padding:4px 10px;border-radius:3px}
/* body */
body.tackendo-home .upcoming-card-body{flex:1;padding:14px 16px;display:flex;flex-direction:column;min-width:0;overflow:hidden}
body.tackendo-home .upcoming-card-label{font-size:8px;font-weight:900;letter-spacing:.2em;text-transform:uppercase;color:var(--red);margin-bottom:5px;flex-shrink:0}
body.tackendo-home .upcoming-card-title{font-family:'Bebas Neue',sans-serif;font-size:26px!important;letter-spacing:.04em;color:#fff!important;line-height:1;margin-bottom:6px!important;flex-shrink:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
body.tackendo-home .upcoming-card-desc{font-size:11.5px;color:var(--grey);line-height:1.55;flex:1;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden;margin-bottom:8px}
body.tackendo-home .upcoming-card-footer{display:flex;align-items:center;justify-content:space-between;border-top:1px solid rgba(255,255,255,.07);padding-top:8px;flex-shrink:0}
/* countdown */
body.tackendo-home .upcoming-countdown-wrap{}
body.tackendo-home .upcoming-countdown-label{font-size:8px;color:var(--muted);text-transform:uppercase;letter-spacing:.1em;margin-bottom:1px}
body.tackendo-home .upcoming-countdown-value{font-family:'Bebas Neue',sans-serif;font-size:26px!important;letter-spacing:.04em;color:#fff!important;line-height:1;margin:0!important;white-space:nowrap}
body.tackendo-home .upcoming-countdown-value.on-air{color:var(--red)!important;font-size:18px!important;animation:tcpulse 1.5s ease-in-out infinite}
@keyframes tcpulse{0%,100%{opacity:1}50%{opacity:.5}}
/* meta */
body.tackendo-home .upcoming-card-meta{text-align:right;flex-shrink:0}
body.tackendo-home .upcoming-card-channel{font-size:8px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;padding:2px 7px;border-radius:3px;border:1px solid rgba(255,255,255,.12);color:var(--grey);display:block;margin-bottom:3px}
body.tackendo-home .upcoming-card-date{font-size:11px;color:var(--grey);font-weight:600;white-space:nowrap}
@media(max-width:1000px){body.tackendo-home .tc-hero-upcoming{display:none!important}}

/* ── COMING UP BAND ── */
.upcoming-band{background:#0a0a16;border-top:1px solid #1c1c2e;border-bottom:1px solid #1c1c2e}
.upcoming-band-inner{display:flex;align-items:stretch;gap:16px;padding:16px 48px;max-width:100%}
.upcoming-band-label{font-size:9px;font-weight:900;letter-spacing:.2em;text-transform:uppercase;color:#7a7a90;white-space:nowrap;display:flex;align-items:center;padding-right:16px;border-right:1px solid #1c1c2e;flex-shrink:0}
.upcoming-cards-row{display:flex;gap:16px;flex:1;min-width:0}
.uc{flex:1;min-width:0;display:flex!important;flex-direction:row!important;align-items:stretch;background:#111120;border:1px solid #1c1c2e;border-radius:10px;overflow:hidden;text-decoration:none;transition:border-color .2s}
.uc:hover{border-color:rgba(232,0,28,.5)}
.uc-thumb{width:140px;min-width:140px;background:#09091f;background-size:cover!important;background-position:center!important;position:relative;flex-shrink:0}
.uc-live{position:absolute;bottom:8px;left:8px;display:flex;align-items:center;gap:4px;background:#E8001C;color:#fff;font-size:8px;font-weight:900;letter-spacing:.1em;text-transform:uppercase;padding:3px 8px;border-radius:2px}
.uc-body{flex:1;padding:12px 14px;display:flex;flex-direction:column;justify-content:center;min-width:0;overflow:hidden}
.uc-label{font-size:8px;font-weight:900;letter-spacing:.18em;text-transform:uppercase;margin-bottom:4px}
.uc-title{font-family:'Bebas Neue',sans-serif;font-size:20px;letter-spacing:.04em;line-height:1;margin-bottom:5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.uc-desc{font-size:10.5px;line-height:1.45;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;margin-bottom:8px}
.uc-footer{display:flex;align-items:center;justify-content:space-between;padding-top:8px;border-top:1px solid rgba(255,255,255,.06)}
.uc-cd{font-family:'Bebas Neue',sans-serif;font-size:20px;letter-spacing:.04em;line-height:1;white-space:nowrap}
.uc-cd.live{animation:ucpulse 1.5s ease-in-out infinite}
@keyframes ucpulse{0%,100%{opacity:1}50%{opacity:.5}}
.uc-date{font-size:10px;font-weight:600}
.uc-channel{font-size:8px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;padding:2px 7px;border-radius:3px;border:1px solid rgba(255,255,255,.12)}

</style>
</head>
<body class="tackendo-home">

<!-- HEADER -->
<header id="tackendo-header">
  <a href="<?php echo $site_url; ?>" class="logo">
    <img src="<?php echo esc_url( $logo_url ); ?>" alt="TACKENDO" loading="eager" style="height:36px;width:auto">
  </a>
  <nav>
    <a href="#channels">Channels</a>
    <a href="#epg">On Air Now</a>
    <a href="<?php echo esc_url( home_url( '/blog' ) ); ?>">Magazine</a>
    <a href="<?php echo esc_url( home_url( '/about' ) ); ?>">About</a>
    <a href="<?php echo esc_url( home_url( '/advertise' ) ); ?>">Advertise</a>
  </nav>
  <div class="hdr-right">
    <a href="https://channelstore.roku.com/details/8244e521d238b28c45271329a3ebe907/tackendo" class="btn-platform" target="_blank" rel="noopener">Roku</a>
    <a href="https://www.amazon.com/gp/product/B0DGNFS8N9" class="btn-platform" target="_blank" rel="noopener">Fire TV</a>
  </div>
</header>

<!-- HERO — class renamed tc-hero to avoid Astra .hero conflict -->
<section class="tc-hero">
  <div class="tc-hero-bg" aria-hidden="true"></div>
  <div class="tc-hero-content">
    <div class="tc-hero-eyebrow" style="display:flex;align-items:center;gap:10px;margin-bottom:20px">
      <span class="live-badge"><span class="live-dot"></span>Featured Channel</span>
    </div>
    <div style="margin-bottom:20px">
      <div style="width:240px;height:240px;border-radius:20px;overflow:hidden;box-shadow:0 0 0 1px rgba(232,0,28,.4),0 0 60px rgba(232,0,28,.2),0 30px 60px rgba(0,0,0,.7);animation:tcfloat 7s ease-in-out infinite">
        <img src="https://tackendo.com/wp-content/uploads/2025/06/Netradio-Vision-1080x1080-1-300x300.jpg" alt="Netradio Vision" style="width:100%;height:100%;object-fit:cover;display:block">
      </div>
    </div>
    <p class="tc-hero-desc">Pop culture, emerging music &amp; the creator economy &mdash; live 24/7. Featuring <strong>MARCY BEAUCOUP</strong>, the weekly interview show with the voices shaping today's creative landscape.</p>
    <div class="tc-hero-epg">
      <p class="tc-hero-epg-label"><span class="live-dot"></span>&nbsp;On Air Now</p>
      <img id="hn-thumb" src="" alt="Program thumbnail" style="display:none;width:90px;height:56px;border-radius:6px;object-fit:cover;float:right;margin:0 0 4px 12px">
      <p id="hn-title"><span class="skeleton" style="width:200px;height:17px;display:inline-block"></span></p>
      <p id="hn-time" style="margin-top:4px"><span class="skeleton" style="width:130px;height:12px;display:inline-block"></span></p>
      <p id="hn-next">&nbsp;</p>
    </div>
    <div class="tc-hero-actions">
      <a href="<?php echo esc_url( home_url( '/netradio-vision/' ) ); ?>" class="tc-btn-primary">Watch Now &rarr;</a>
      <a href="#channels" class="tc-btn-ghost">Browse All Channels &rarr;</a>
    </div>

  </div>
  <!-- RIGHT COL: 2 upcoming show cards filling the hero -->
  <div style="grid-column:2;grid-row:1;position:relative;z-index:2;display:flex;flex-direction:column;gap:14px;padding:28px 48px 28px 20px;justify-content:center;align-items:stretch">
    <p style="font-size:9px;font-weight:900;letter-spacing:.22em;text-transform:uppercase;color:#7a7a90;margin-bottom:2px;flex-shrink:0">Coming Up on Netradio Vision</p>
    <div id="upcoming-shows" style="display:flex;flex-direction:column;gap:14px;flex:1;justify-content:center"></div>
  </div>
</section>

<!-- ON AIR NOW -->
<section class="epg-section" id="epg">
  <div class="section-header">
    <div><p class="section-label">Live Programming</p><h2 class="section-title">On Air Now</h2></div>
    <span class="live-badge"><span class="live-dot"></span>Live</span>
  </div>
  <div class="epg-carousel" style="position:relative;padding:0 44px">
    <button class="epg-nav-btn epg-nav-prev" onclick="epgScroll(-1)" aria-label="Previous channels" style="position:absolute;left:0;top:50%;transform:translateY(-50%);z-index:10;background:rgba(7,7,15,.95);border:1px solid #E8001C;color:#fff;width:38px;height:38px;border-radius:50%;cursor:pointer;font-size:22px;display:flex;align-items:center;justify-content:center;line-height:1">&#8249;</button>
    <div class="epg-strip" id="epg-strip" role="list" style="overflow:hidden!important;scrollbar-width:none"></div>
    <button class="epg-nav-btn epg-nav-next" onclick="epgScroll(1)" aria-label="Next channels" style="position:absolute;right:0;top:50%;transform:translateY(-50%);z-index:10;background:rgba(7,7,15,.95);border:1px solid #E8001C;color:#fff;width:38px;height:38px;border-radius:50%;cursor:pointer;font-size:22px;display:flex;align-items:center;justify-content:center;line-height:1">&#8250;</button>
  </div>
</section>

<!-- CHANNELS -->
<section class="channels-section" id="channels">
  <div class="section-header">
    <div><p class="section-label">Free &middot; Ad-Supported &middot; 24/7</p><h2 class="section-title">Our Channels</h2></div>
    <a href="#channels" class="see-all">All 20 &rarr;</a>
  </div>
  <div class="filter-tabs" role="tablist">
    <button class="ftab active" data-filter="all" role="tab">All</button>
    <button class="ftab" data-filter="pop-culture" role="tab">Pop Culture</button>
    <button class="ftab" data-filter="music" role="tab">Music</button>
    <button class="ftab" data-filter="lifestyle" role="tab">Lifestyle</button>
  </div>
  <div class="channels-grid" id="ch-grid" role="list"></div>
</section>

<!-- EDITORIAL -->
<section class="editorial-section" id="editorial">
  <div class="section-header">
    <div><p class="section-label">Daily &middot; Editorial</p><h2 class="section-title">TACKENDO Magazine</h2></div>
    <a href="<?php echo esc_url( home_url( '/blog' ) ); ?>" class="see-all">All Articles &rarr;</a>
  </div>
  <div class="editorial-layout">
    <div class="articles-grid">
      <?php if ( ! empty( $recent_posts ) ) : ?>
        <?php foreach ( $recent_posts as $idx => $post ) :
          $link    = get_permalink( $post->ID );
          $tag     = get_post_meta( $post->ID, '_tcore_topic_tag', true );
          if ( empty( $tag ) ) $tag = 'FAST TV';
          $date    = get_the_date( 'M j, Y', $post->ID );
          $excerpt = wp_trim_words( strip_tags( $post->post_content ), 25 );
          $feat    = ( $idx === 0 ) ? ' featured' : '';
          // Gradient colors per article index
          $grads   = array( '#180824,#080c24', '#0a1628,#050d20', '#0a2416,#040e08', '#1a0520,#080c24', '#0a1a40,#1a3060' );
          $grad    = isset( $grads[ $idx ] ) ? $grads[ $idx ] : $grads[0];
        ?>
        <a href="<?php echo esc_url( $link ); ?>" class="article-card<?php echo $feat; ?>" style="text-decoration:none">
          <div class="article-thumb">
            <?php
            // Use WordPress featured image (from Pexels) if available
            $ft_url = get_the_post_thumbnail_url( $post->ID, 'large' );
            if ( $ft_url ) {
              echo '<img src="' . esc_url($ft_url) . '" alt="' . esc_attr(get_the_title($post->ID)) . '" style="width:100%;height:100%;object-fit:cover;display:block;min-height:160px" loading="lazy">';
            } else {
              // Fallback: category-appropriate gradient (shown while Pexels hasn't run yet)
              $tag_grads = array(
                'Music'             => 'linear-gradient(135deg,#1a0533 0%,#3b0764 50%,#4a1080 100%)',
                'CTV Industry'      => 'linear-gradient(135deg,#020617 0%,#0c1a40 50%,#1e3a5f 100%)',
                'Advertising'       => 'linear-gradient(135deg,#001a0d 0%,#003d1a 50%,#005c28 100%)',
                'Platform Guide'    => 'linear-gradient(135deg,#05010d 0%,#12044d 50%,#1a0860 100%)',
                'Channel Spotlight' => 'linear-gradient(135deg,#200004 0%,#5c0010 50%,#8c0018 100%)',
                'Streaming Guide'   => 'linear-gradient(135deg,#020920 0%,#061830 50%,#0a2540 100%)',
              );
              $bg = isset($tag_grads[$tag]) ? $tag_grads[$tag] : 'linear-gradient(135deg,#180824,#080c24)';
              $label = esc_html($tag);
              echo "<div style='width:100%;min-height:160px;height:100%;background:{$bg};display:flex;align-items:center;justify-content:center'><span style='font-size:13px;letter-spacing:.12em;color:rgba(255,255,255,.25);text-transform:uppercase'>{$label}</span></div>";
            }
            ?>
          </div>
          <div class="article-body">
            <div class="article-meta">
              <span class="article-tag"><?php echo esc_html( $tag ); ?></span>
              <span class="article-date"><?php echo esc_html( $date ); ?></span>
            </div>
            <h3 class="article-title"><?php echo esc_html( get_the_title( $post->ID ) ); ?></h3>
            <p class="article-excerpt"><?php echo esc_html( $excerpt ); ?></p>
          </div>
        </a>
        <?php endforeach; ?>
      <?php else : ?>
        <p style="color:#7a7a90;padding:20px 0">Articles being generated &mdash; check back soon.</p>
      <?php endif; ?>
    </div>
    <aside class="sidebar">
      <div class="sidebar-widget">
        <h3 class="sidebar-title">Discover Channels</h3>
        <div id="sb-channels"></div>
      </div>
      <div class="sidebar-cta">
        <h3 class="sidebar-cta-title">Watch on Your TV</h3>
        <p class="sidebar-cta-text">Free, no subscription, no login required.</p>
        <a href="https://channelstore.roku.com/details/8244e521d238b28c45271329a3ebe907/tackendo" class="tc-btn-primary" target="_blank" rel="noopener" style="margin-bottom:8px;display:flex;justify-content:center">Add to Roku</a>
        <a href="https://www.amazon.com/gp/product/B0DGNFS8N9" class="tc-btn-ghost" target="_blank" rel="noopener" style="display:flex;justify-content:center">Fire TV</a>
      </div>
      <div class="sidebar-widget">
        <h3 class="sidebar-title">Topics</h3>
        <div class="tag-cloud">
          <?php
          $tags = array( 'CTV', 'FAST TV', 'Music', 'Advertising', 'Streaming', 'OTT', 'Lifestyle', 'Pop Culture', 'Roku', 'Fire TV' );
          foreach ( $tags as $t ) {
              echo '<a href="' . esc_url( home_url( '/tag/' . sanitize_title( $t ) ) ) . '" class="tag-pill">' . esc_html( $t ) . '</a>';
          }
          ?>
        </div>
      </div>
    </aside>
  </div>
</section>

<!-- FOOTER -->
<footer id="tackendo-footer">
  <div class="footer-grid">
    <div class="footer-brand">
      <img src="<?php echo esc_url( $logo_url ); ?>" alt="TACKENDO" loading="lazy" style="height:30px;width:auto;max-width:180px;margin-bottom:14px;display:block">
      <p class="footer-brand-text" style="font-size:12px;color:#4a4a60;line-height:1.75">A premium FAST TV platform built for Connected TV audiences &mdash; free, ad-supported linear channels across music, culture, and lifestyle.</p>
    </div>
    <div>
      <p class="footer-col-title">Channels</p>
      <ul class="footer-links">
        <?php
        $chans = array( 'Netradio Vision' => 'netradio-vision', 'Fast Music Rising' => 'fast-music-rising', 'Urban Street' => 'urban-street', 'EDM' => 'edm', 'Lo-Fi Music' => 'lo-fi', 'Synthwave' => 'synthwave', 'Summer Vibes' => 'summer-vibes' );
        foreach ( $chans as $label => $slug ) {
            echo '<li><a href="' . esc_url( home_url( '/' . $slug . '/' ) ) . '">' . esc_html( $label ) . '</a></li>';
        }
        ?>
        <li><a href="#channels">All 20 channels &rarr;</a></li>
        <li><a href="https://synthwavetv.com/" target="_blank" rel="noopener">Synthwave TV &rarr;</a></li>
      </ul>
    </div>
    <div>
      <p class="footer-col-title">Platform</p>
      <ul class="footer-links">
        <li><a href="<?php echo esc_url( home_url( '/about' ) ); ?>">About TACKENDO</a></li>
        <li><a href="<?php echo esc_url( home_url( '/advertise' ) ); ?>">Advertise With Us</a></li>
        <li><a href="<?php echo esc_url( home_url( '/blog' ) ); ?>">Magazine</a></li>
        <li><a href="<?php echo esc_url( home_url( '/contact' ) ); ?>">Contact</a></li>
        <li><a href="<?php echo esc_url( home_url( '/privacy-policy' ) ); ?>">Privacy Policy</a></li>
      </ul>
    </div>
    <div>
      <p class="footer-col-title">Watch Now</p>
      <div class="footer-platforms">
        <a href="https://channelstore.roku.com/details/8244e521d238b28c45271329a3ebe907/tackendo" class="footer-platform" target="_blank" rel="noopener"><span style="font-size:13px;font-weight:700">ROKU</span>&nbsp; Watch Free</a>
        <a href="https://www.amazon.com/gp/product/B0DGNFS8N9" class="footer-platform" target="_blank" rel="noopener"><span style="font-size:13px;font-weight:700">FIRE TV</span>&nbsp; Watch Free</a>
        <a href="<?php echo $site_url; ?>" class="footer-platform"><span style="font-size:13px;font-weight:700">WEB</span>&nbsp; Watch Online</a>
      </div>
    </div>
  </div>
  <div class="footer-bottom">
    <p class="footer-copy">&copy; 2024&ndash;<?php echo date( 'Y' ); ?> TACKENDO &mdash; Netradio Network. All rights reserved.</p>
    <div class="footer-legal">
      <a href="<?php echo esc_url( home_url( '/privacy-policy' ) ); ?>">Privacy Policy</a>
      <a href="<?php echo esc_url( home_url( '/contact' ) ); ?>">Contact</a>
    </div>
  </div>
</footer>

<script>
window.TCORE={rest:'<?php echo esc_js( rest_url( "tcore/v1" ) ); ?>',nonce:'<?php echo wp_create_nonce( "wp_rest" ); ?>'};
const REST = (window.TCORE && window.TCORE.rest) || "/wp-json/tcore/v1";
// CHANNEL DATA
const CH = [
  { slug:'netradio-vision', epg:'https://tackendo.tv/api/epg/channel-11?days=3', name:'Netradio Vision', cat:'pop-culture', catL:'Pop Culture', url:'/netradio-vision/', logo:'https://tackendo.com/wp-content/uploads/2025/06/Netradio-Vision-1080x1080-1-300x300.jpg', desc:'Pop culture, emerging music & the creator economy.' },
  { slug:'fast-music-rising', epg:'https://tackendo.tv/api/epg/channel-01?days=3', name:'Fast Music Rising', cat:'music', catL:'Music', url:'/fast-music-rising/', logo:'https://tackendo.com/wp-content/uploads/2025/06/FAST-MUSIC-RISING-1080-x-1080-300x300.jpg', desc:'Unsigned & independent artists from around the world. Multi-genre, borderless.' },
  { slug:'urban-street', name:'Urban Street', cat:'music', catL:'Music', url:'/urban-street/', logo:'https://tackendo.com/wp-content/uploads/2025/06/street-1920-x-1080-px-1080-x-1080-px-300x300.png', desc:'Rap, Hip-Hop, and urban sounds. 100% Urban. 100% Attitude.' },
  { slug:'edm', name:'EDM', cat:'music', catL:'Music', url:'/edm/', logo:'https://tackendo.com/wp-content/uploads/2025/06/Fast-Music-EDM-1080-x-1080-300x300.jpg', desc:'Non-stop electronic dance music and festival-driven culture. Pure energy, 24/7.' },
  { slug:'lo-fi', epg:'https://tackendo.tv/api/epg/channel-04?days=3', name:'Lo-Fi Music', cat:'music', catL:'Music', url:'/lo-fi/', logo:'https://tackendo.com/wp-content/uploads/2025/06/lofi-thumbnail-square-300x300.jpg', desc:'Cinematic lo-fi soundscapes with anime-style animation. Study, relax, unwind.' },
  { slug:'synthwave', epg:'https://tackendo.tv/api/epg/channel-08?days=3', name:'Synthwave', cat:'music', catL:'Music', url:'/synthwave/', logo:'https://tackendo.com/wp-content/uploads/2025/06/thumbnail-square-300x300.jpg', desc:'Neon-drenched retrofuturistic soundscapes. Nostalgic, immersive, irresistibly cool.' },
  { slug:'epic', epg:'https://tackendo.tv/api/epg/channel-09?days=3', name:'Epic Music', cat:'music', catL:'Music', url:'/epic/', logo:'https://tackendo.com/wp-content/uploads/2025/06/Fast-Music-Epic-PNG-300x300.png', desc:'Epic scores, cinematic soundtracks, heroic music. Battle, mystery, and legend.' },
  { slug:'tzik', name:'Tzik', cat:'music', catL:'Music', url:'/tzik/', logo:'https://tackendo.com/wp-content/uploads/2025/06/TZIK-Square-PNG-300x300.png', desc:'Celebrating emerging talent and the most promising unsigned independent artists.' },
  { slug:'winter-ambience', epg:'https://tackendo.tv/api/epg/channel-07?days=3', name:'Winter Ambience', cat:'music', catL:'Music', url:'/winter-ambience/', logo:'https://tackendo.com/wp-content/uploads/2026/02/Cover-1000x1000-1-300x300.png', desc:'24/7 winter jazz and ambient music for slow, cozy moments.' },
  { slug:'zweester', name:'Zweester', cat:'music', catL:'Music', url:'/zweester/', logo:'https://tackendo.com/wp-content/uploads/2026/01/ChatGPT-Image-14-janv.-2026-23_41_55-300x298.png', desc:'Non-stop independent music from around the world.' },
  { slug:'halloween', name:'Halloween Music', cat:'music', catL:'Music', url:'/halloween/', logo:'https://tackendo.com/wp-content/uploads/2025/08/fast-music-halloween-smth-300x300.png', desc:'Original music with long-form animated films. Fantasy, mystery, gothic universe.' },
  { slug:'christmas', name:'Christmas Music', cat:'music', catL:'Music', url:'/christmas/', logo:'https://tackendo.com/wp-content/uploads/2025/12/Christmas-1080x1080-1-300x300.jpg', desc:'Holiday classics and indie Christmas songs. Pure festive spirit, 24/7.' },
  { slug:'good-lifestyle', name:'Good Lifestyle', cat:'lifestyle', catL:'Lifestyle', url:'/good-lifestyle/', logo:'https://tackendo.com/wp-content/uploads/2026/04/GOOD-1920-x-1080-px-1024x576.png', desc:'Inspiring original productions \u2014 social awareness, feature shows, uplifting storytelling.' },
  { slug:'made-in-france', epg:'https://tackendo.tv/api/epg/channel-02?days=3', name:'Made in France', cat:'lifestyle', catL:'Lifestyle', url:'/made-in-france/', logo:'https://tackendo.com/wp-content/uploads/2026/04/Made-in-France-TV-1024x576.png', desc:"Immersive tour of France's rich heritage \u2014 gastronomy, craftsmanship, entrepreneurs." },
  { slug:'expat-tv', epg:'https://tackendo.tv/api/epg/channel-03?days=3', name:'Expat TV', cat:'lifestyle', catL:'Lifestyle', url:'/expat-tv/', logo:'https://tackendo.com/wp-content/uploads/2026/04/EXPAT-TV-1920-x-1080-px-1-1024x576.png', desc:'Resources for expats and life abroad \u2014 visas, housing, cultural integration, stories.' },
  { slug:'finance-vous', name:'Finance & You', cat:'lifestyle', catL:'Lifestyle', url:'/finance-vous/', logo:'https://tackendo.com/wp-content/uploads/2026/04/Finance-Vous.-1920-x-1080-px-1-1024x576.png', desc:'Financial independence, wealth building, and smart money decisions \u2014 clear and modern.' },
  { slug:'just-do-biz', name:'Just Do Biz', cat:'lifestyle', catL:'Lifestyle', url:'/just-do-biz/', logo:'https://tackendo.com/wp-content/uploads/2026/04/JustDoBiz-square-white-1-1024x576.png', desc:'Entrepreneurship, innovation, and business culture. Bold founders, breakthrough ideas.' },
  { slug:'chic-tv', name:'Chic TV', cat:'lifestyle', catL:'Lifestyle', url:'/chic-tv/', logo:'https://tackendo.com/wp-content/uploads/2026/04/Chic-TV-1024x576.png', desc:'Luxury, style, and escapism \u2014 fashion, gastronomy, premium design, exclusive getaways.' },
  { slug:'zanimo', name:'Zanimo', cat:'lifestyle', catL:'Lifestyle', url:'/zanimo/', logo:'https://tackendo.com/wp-content/uploads/2026/04/zanimo-1920-x-1080-px-300x169.png', desc:'Wildlife, nature, and animal stories \u2014 a feel-good channel for animal lovers.' },
  { slug:'summer-vibes', epg:'https://tackendo.tv/api/epg/channel-05?days=3', name:'Summer Vibes', cat:'music', catL:'Music', url:'/summer-vibes/', logo:'https://tackendo.com/wp-content/uploads/2026/05/Summer-Chill-Vibes-logo-2.jpg', desc:'Sun-kissed beats and chill vibes all day long. Your endless summer soundtrack.' },
  { slug:'fireplace', epg:'https://tackendo.tv/api/epg/channel-06?days=3', name:'Fireplace', cat:'lifestyle', catL:'Lifestyle', url:'/fireplace/', logo:'https://tackendo.com/wp-content/uploads/2026/04/Fireplace_Channel.jpg', desc:'A warm, relaxing fireplace channel \u2014 perfect ambience 24/7.' },
  { slug:'green-life-tv', name:'Green Life TV', cat:'lifestyle', catL:'Lifestyle', url:'/green-life-tv/', logo:'https://tackendo.com/wp-content/uploads/2026/04/LIFE-TV-1920-x-1080-px-1024x576.png', desc:'Sustainable living, eco culture, and green lifestyle inspiration.' },
];
const fmt = d => d ? d.toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit',hour12:false}) : '';
function chThumb(ch, cls, sz=34) {
  if (ch.logo) return `<img class="${cls}" src="${ch.logo}" alt="${ch.name}" width="${sz}" height="${sz}" loading="lazy"
    onerror="this.style.display='none';this.nextElementSibling.style.removeProperty('display')">
    <div class="${cls}" style="display:none;background:${ch.grad||'#1a1a2e'};align-items:center;justify-content:center;font-size:8px;font-weight:800;color:rgba(255,255,255,.5);text-align:center;padding:4px;">${ch.name.substring(0,4).toUpperCase()}</div>`;
  return `<div class="${cls}" style="background:${ch.grad||'#1a1a2e'};display:flex;align-items:center;justify-content:center;font-size:8px;font-weight:800;color:rgba(255,255,255,.5);text-align:center;padding:4px;">${ch.name.substring(0,4).toUpperCase()}</div>`;
}
function parseXMLTV(xmlText) {
  const doc = new DOMParser().parseFromString(xmlText, 'text/xml');
  const now = new Date();
  const parseDate = s => {
    if (!s) return null;
    const c = s.replace(/\s.*/,'');
    return new Date(`${c.slice(0,4)}-${c.slice(4,6)}-${c.slice(6,8)}T${c.slice(8,10)}:${c.slice(10,12)}:${c.slice(12,14)}Z`);
  };
  const progs = Array.from(doc.querySelectorAll('programme')).map(p => ({
    title: p.querySelector('title')?.textContent || '',
    desc: p.querySelector('desc')?.textContent || '',
    icon: p.querySelector('icon')?.getAttribute('src') || null,
    start: parseDate(p.getAttribute('start')),
    stop: parseDate(p.getAttribute('stop')),
  })).filter(p => p.start && p.stop);
  return {
    current: progs.find(p => p.start <= now && p.stop > now),
    next: progs.find(p => p.start > now),
  };
}
async function fetchEPG(epgUrl, channelSlug) {
  if (!epgUrl) return null;
  var now = Date.now();
  var progs = [];
  try {
    var r = await fetch(epgUrl, {cache:'no-store'});
    if (!r.ok) throw new Error('HTTP ' + r.status);
    var data = await r.json();
    progs = data.programs || [];
    console.log('[EPG] OK', channelSlug, progs.length, 'programs');
  } catch(e) {
    console.warn('[EPG] FAILED', epgUrl, e.message);
    return null;
  }
  progs = progs.map(function(p){
    return {
      title: p.title || '',
      artist: p.artist || '',
      desc: p.desc || p.artist || '',
      icon: p.icon || '',
      start: new Date(p.start),
      stop: new Date(p.stop)
    };
  }).filter(function(p){ return !isNaN(p.start.getTime()); });
  var current = null, next = null;
  for (var i = 0; i < progs.length; i++) {
    var p = progs[i];
    var ms = p.start.getTime();
    var me = p.stop.getTime();
    if (ms <= now && me > now && !current) { current = p; }
    else if (ms > now && !next) { next = p; }
    if (current && next) break;
  }
  return { current: current, next: next, programs: progs };
}
async function loadHeroEPG() {
  var ch = CH[0];
  var $title = document.getElementById('hn-title');
  var $time = document.getElementById('hn-time');
  var $next = document.getElementById('hn-next');
  var $thumb = document.getElementById('hn-thumb');
  var epg = await fetchEPG(ch.epg, ch.slug);
  if (epg && epg.current) {
    if (epg.current.icon) { $thumb.src = epg.current.icon; $thumb.style.display = 'block'; }
    $title.textContent = epg.current.artist ? (epg.current.artist + ' \u2014 ' + epg.current.title) : epg.current.title;
    $time.textContent = fmt(epg.current.start) + ' \u2013 ' + fmt(epg.current.stop);
    if (epg.next) {
      var nextLabel = epg.next.artist ? (epg.next.artist + ' \u2014 ' + epg.next.title) : epg.next.title;
      $next.innerHTML = '<strong style="color:#7a7a90">Up next:</strong> ' + nextLabel + ' at ' + fmt(epg.next.start);
    }
    return;
  }
  $title.textContent = 'Netradio Vision';
  $time.textContent = 'Live 24/7';
}
function buildStripSkeleton() {
  document.getElementById('epg-strip').innerHTML = CH.slice(0,12).map(ch => `
    <a href="${ch.url}" class="epg-card" id="ec-${ch.slug}" role="listitem" aria-label="${ch.name}">
      <div class="epg-thumb-prog skel">&nbsp;</div>
      <div class="epg-body">
        <div class="epg-top">
          ${chThumb(ch,'epg-logo',32)}
          <span class="epg-ch">${ch.name}</span>
        </div>
        <p class="epg-show"><span class="skel" style="width:140px;height:13px">&nbsp;</span></p>
        <p class="epg-time"><span class="skel" style="width:90px;height:11px;margin-top:4px">&nbsp;</span></p>
        <div class="epg-bar"><div class="epg-fill" style="width:0%"></div></div>
      </div>
    </a>`).join('');
}
async function loadStripEPG() {
  await Promise.all(CH.slice(0,12).map(async ch => {
    var card = document.getElementById('ec-'+ch.slug);
    if (!card) return;
    var $prog = card.querySelector('.epg-thumb-prog');
    var $show = card.querySelector('.epg-show');
    var $time = card.querySelector('.epg-time');
    var $fill = card.querySelector('.epg-fill');
    var epg = await fetchEPG(ch.epg, ch.slug);
    if (epg && epg.current) {
      $prog.classList.remove('skel');
      var thumbUrl = epg.current.icon || ch.logo || '';
      if (thumbUrl) { $prog.style.backgroundImage = "url('"+thumbUrl+"')"; $prog.style.backgroundSize = 'cover'; $prog.style.backgroundPosition = 'center'; }
      $show.textContent = epg.current.artist ? (epg.current.artist + ' \u2014 ' + epg.current.title) : epg.current.title;
      $time.textContent = fmt(epg.current.start) + ' \u2013 ' + fmt(epg.current.stop);
      if (epg.current.start && epg.current.stop) {
        var pct = Math.min(100, Math.max(0, ((Date.now() - epg.current.start.getTime()) / (epg.current.stop.getTime() - epg.current.start.getTime())) * 100));
        $fill.style.width = pct + '%';
      }
    } else {
      $prog.classList.remove('skel');
      if (ch.logo) { $prog.style.backgroundImage = "url('"+ch.logo+"')"; $prog.style.backgroundSize = 'cover'; $prog.style.backgroundPosition = 'center'; }
      $show.textContent = 'Non-Stop ' + (ch.catL || 'Music');
      $time.textContent = 'Live 24/7';
      $fill.style.width = '50%';
    }
  }));
}
function renderGrid(filter = 'all') {
  const list = filter === 'all' ? CH : CH.filter(c => c.cat === filter);
  document.getElementById('ch-grid').innerHTML = list.map(ch => {
    const imgBlock = ch.logo
      ? `<img class="ch-img" src="${ch.logo}" alt="${ch.name}" loading="lazy" width="220" height="220"
           onerror="this.style.display='none';this.nextElementSibling.style.removeProperty('display')">
         <div class="ch-ph" style="display:none;background:${ch.grad||'#1a1a2e'}">${ch.name.toUpperCase()}</div>`
      : `<div class="ch-ph" style="background:${ch.grad||'#1a1a2e'}">${ch.name.toUpperCase()}</div>`;
    return `<a href="${ch.url}" class="ch-card fade" data-cat="${ch.cat}" role="listitem" aria-label="Watch ${ch.name}">
      ${imgBlock}
      <div class="ch-body">
        <p class="ch-tag">${ch.catL}</p>
        <h3 class="ch-name">${ch.name}</h3>
        <p class="ch-desc">${ch.desc}</p>
      </div>
      <div class="ch-foot">
        <span class="ch-live"><span class="live-dot"></span>LIVE</span>
        <span class="ch-watch">Watch \u2192</span>
      </div>
    </a>`;
  }).join('');
  setTimeout(() => {
    document.querySelectorAll('.ch-card').forEach((el,i) => {
      setTimeout(() => el.classList.add('in'), i * 35);
    });
  }, 60);
}
function renderSidebar() {
  document.getElementById('sb-channels').innerHTML =
    CH.filter(c => c.slug !== 'netradio-vision').slice(0,7).map(ch => `
      <a href="${ch.url}" class="sb-ch" aria-label="Watch ${ch.name}">
        ${ch.logo
          ? `<img class="sb-logo" src="${ch.logo}" alt="${ch.name}" width="34" height="34" loading="lazy">`
          : `<div class="sb-logo" style="background:${ch.grad||'#1a1a2e'};display:flex;align-items:center;justify-content:center;font-size:8px;font-weight:800;color:rgba(255,255,255,.5);">${ch.name.substring(0,3).toUpperCase()}</div>`}
        <div><p class="sb-cn">${ch.name}</p><p class="sb-cc">${ch.catL}</p></div>
        <span class="sb-arr" aria-hidden="true">\u203A</span>
      </a>`).join('');
}
document.querySelectorAll('.ftab').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.ftab').forEach(b => { b.classList.remove('on'); b.setAttribute('aria-selected','false'); });
    btn.classList.add('on');
    btn.setAttribute('aria-selected','true');
    renderGrid(btn.dataset.f || btn.dataset.filter);
  });
});
const io = new IntersectionObserver(entries => {
  entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('in'); });
}, { threshold: 0.08 });
var UPCOMING_SHOWS = [
  { keyword: 'MARCY BEAUCOUP', label: 'Weekly Show' },
  { keyword: 'LA TEAM', label: 'Next Broadcast' },
];
var _cdT = [];
function _p(n){ return String(n).padStart(2,'0'); }
function _fcd(ms){
  if(ms<=0) return {v:'ON AIR',u:'NOW',live:true};
  var s=Math.floor(ms/1000),m=Math.floor(s/60),h=Math.floor(m/60),d=Math.floor(h/24);
  s%=60;m%=60;h%=24;
  if(d>0) return {v:d+'D '+_p(h)+'H',u:_p(m)+'M',live:false};
  if(h>0) return {v:_p(h)+'H '+_p(m)+'M',u:_p(s)+'S',live:false};
  return {v:_p(m)+"'"+_p(s)+'"',u:'',live:false};
}
function _match(title,kw){
  if(!title)return false;
  var t=title.toUpperCase(),k=kw.toUpperCase();
  return t.includes(k)||k.split(' ').every(function(w){return w.length>1&&t.includes(w);});
}
async function loadUpcomingShows(){
  var row=document.getElementById('upcoming-shows');
  if(!row)return;
  try{
    var nrvCh = CH.find(function(c){return c.slug==='netradio-vision';});
    var nrvEpg = (nrvCh && nrvCh.epg) ? nrvCh.epg : null;
    if(!nrvEpg){row.style.display='none';return;}
    var r=await fetch(nrvEpg,{cache:'no-store'});
    if(!r.ok)return;
    var data=await r.json();
    var progs=data.programs||[],now=Date.now(),found=[];
    for(var pi=0;pi<progs.length;pi++){
      var p=progs[pi];
      if(new Date(p.stop).getTime()<=now) continue;
      for(var si=0;si<UPCOMING_SHOWS.length;si++){
        var show=UPCOMING_SHOWS[si];
        if(_match(p.title,show.keyword)||_match(p.artist,show.keyword)){
          found.push({show:show,prog:p});
          break;
        }
      }
    }
    if(!found.length){row.style.display='none';return;}
    row.innerHTML='';
    found.forEach(function(item,idx){
      var prog=item.prog,show=item.show;
      var start=new Date(prog.start).getTime(),stop=new Date(prog.stop).getTime();
      var isLive=start<=now&&stop>now;
      var dt=new Date(prog.start),days=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
      var dateStr=days[dt.getDay()]+' '+_p(dt.getHours())+':'+_p(dt.getMinutes());
      var cd=_fcd(start-now);
      var cdStr=cd.v+(cd.u?' '+cd.u:'');
      var card=document.createElement('a');
      card.href='/netradio-vision/';
      card.style.cssText='display:flex;flex-direction:row;height:175px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:12px;overflow:hidden;text-decoration:none;transition:border-color .2s;width:100%';
      var thumb=document.createElement('div');
      var thumbStyle='width:180px;min-width:180px;height:175px;position:relative;flex-shrink:0;background:#09091f';
      if(prog.icon) thumbStyle='width:180px;min-width:180px;height:175px;position:relative;flex-shrink:0;background:url("'+prog.icon+'") center/cover no-repeat #09091f';
      thumb.setAttribute('style',thumbStyle);
      if(isLive){
        var badge=document.createElement('span');
        badge.style.cssText='position:absolute;bottom:8px;left:8px;display:flex;align-items:center;gap:4px;background:#E8001C;color:#fff;font-size:9px;font-weight:900;letter-spacing:.1em;text-transform:uppercase;padding:4px 10px;border-radius:3px';
        badge.innerHTML='<span style="width:6px;height:6px;background:#fff;border-radius:50%;display:inline-block"></span> LIVE NOW';
        thumb.appendChild(badge);
      }
      var body=document.createElement('div');
      body.style.cssText='flex:1;padding:14px 16px;display:flex;flex-direction:column;justify-content:center;min-width:0;overflow:hidden';
      var lbl=document.createElement('p');
      lbl.style.cssText='font-size:8px;font-weight:900;letter-spacing:.18em;text-transform:uppercase;color:#E8001C;margin:0 0 5px';
      lbl.textContent=show.label;
      var titleEl=document.createElement('p');
      titleEl.style.cssText='font-family:Bebas Neue,sans-serif;font-size:22px;font-weight:400;letter-spacing:.04em;line-height:1;color:#fff;margin:0 0 6px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis';
      titleEl.textContent=prog.artist ? (prog.artist + ' \u2014 ' + prog.title) : prog.title;
      var descEl=document.createElement('p');
      descEl.style.cssText='font-size:11px;color:#7a7a90;line-height:1.45;margin:0 0 10px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden';
      if(prog.desc)descEl.textContent=prog.desc;
      var footer=document.createElement('div');
      footer.style.cssText='display:flex;align-items:center;justify-content:space-between;padding-top:8px;border-top:1px solid rgba(255,255,255,.07);margin-top:auto';
      var cd_el=document.createElement('span');
      cd_el.id='ucd-'+idx;
      cd_el.style.cssText='font-family:Bebas Neue,sans-serif;font-size:20px;font-weight:400;letter-spacing:.04em;line-height:1;color:'+(isLive?'#E8001C':'#fff');
      cd_el.textContent=cdStr;
      var right=document.createElement('div');
      right.style.cssText='text-align:right';
      var chEl=document.createElement('span');
      chEl.style.cssText='font-size:8px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;padding:2px 7px;border-radius:3px;border:1px solid rgba(255,255,255,.12);color:#7a7a90;display:block;margin-bottom:3px';
      chEl.textContent='Netradio Vision';
      var dt_el=document.createElement('span');
      dt_el.style.cssText='font-size:10px;font-weight:600;color:#7a7a90';
      dt_el.textContent=isLive?'':dateStr;
      right.appendChild(chEl);right.appendChild(dt_el);
      footer.appendChild(cd_el);footer.appendChild(right);
      body.appendChild(lbl);body.appendChild(titleEl);
      if(prog.desc)body.appendChild(descEl);
      body.appendChild(footer);
      card.appendChild(thumb);card.appendChild(body);
      row.appendChild(card);
      if(!isLive){
        var t=setInterval(function(i,st){return function(){
          var el=document.getElementById('ucd-'+i);
          if(!el){clearInterval(t);return;}
          var c2=_fcd(st-Date.now());
          el.textContent=c2.v+(c2.u?' '+c2.u:'');
          if(c2.live){el.style.color='#E8001C';clearInterval(t);}
        };}(idx,start),1000);
        _cdT.push(t);
      }
    });
  }catch(e){console.warn('[Upcoming]',e);}
}
function tcoreInit() {
  renderGrid('all');
  renderSidebar();
  buildStripSkeleton();
  document.querySelectorAll('.art, .sb-w, .sb-cta').forEach(function(el) { el.classList.add('fade'); io.observe(el); });
  loadHeroEPG();
  loadStripEPG();
  loadUpcomingShows();
  setTimeout(function() { document.querySelectorAll('.ch-card').forEach(function(el) { io.observe(el); }); }, 200);
}
if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', tcoreInit); } else { tcoreInit(); }
function epgScroll(dir) { var strip = document.getElementById('epg-strip'); if (!strip) return; strip.scrollBy({ left: dir * 232 * 3, behavior: 'smooth' }); }
setInterval(function() { loadHeroEPG(); loadStripEPG(); }, 5 * 60 * 1000);

</script>
<?php wp_footer(); ?>
</body>
</html>
