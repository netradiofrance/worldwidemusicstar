<?php
/* Template Name: Tackendo About */
if ( ! defined( 'ABSPATH' ) ) exit;

$logo_url = 'https://tackendo.com/wp-content/uploads/2025/06/Tackendo-logo-white-on-transparent-262x76-1.png';
$site_url = esc_url( home_url('/') );
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>About TACKENDO &mdash; Free FAST TV Platform by Netradio Network</title>
<meta name="description" content="TACKENDO is a premium FAST TV platform by Groupe Netradio, founded by Christophe Marcy and Tatiana Glazova. 20+ free live TV channels across music, culture and lifestyle.">
<meta name="robots" content="index, follow">
<link rel="canonical" href="<?php echo esc_url(home_url('/about')); ?>">
<meta property="og:title" content="About TACKENDO">
<meta property="og:description" content="TACKENDO is a premium FAST TV platform by Groupe Netradio. 20+ free live channels across music, culture and lifestyle.">
<meta property="og:type" content="website">
<meta name="theme-color" content="#E8001C">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Figtree:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&display=swap" rel="stylesheet">
<?php wp_head(); ?>
<style>
:root{--bg:#07070f;--surface:#0d0d18;--card:#111120;--red:#E8001C;--white:#fff;--text:#d8d8e8;--grey:#7a7a90;--muted:#4a4a60;--border:#1c1c2e}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body.tackendo-about{background:var(--bg);color:var(--text);font-family:'Figtree','Segoe UI',sans-serif;font-size:16px;line-height:1.7}
body.tackendo-about h1,body.tackendo-about h2,body.tackendo-about h3{color:#fff!important;font-weight:400!important}
body.tackendo-about a{text-decoration:none;color:inherit}
body.tackendo-about .site-header,body.tackendo-about #masthead,body.tackendo-about #ast-fixed-header,body.tackendo-about .site-footer,body.tackendo-about #astra-footer-area{display:none!important}

/* Header */
#ab-header{position:sticky;top:0;z-index:200;background:rgba(7,7,15,.92);backdrop-filter:blur(18px);border-bottom:1px solid var(--border);height:64px;padding:0 48px;display:flex;align-items:center;justify-content:space-between}
#ab-header img{height:34px;width:auto;display:block}
#ab-header nav{display:flex;gap:28px}
#ab-header nav a{color:var(--grey);font-size:12px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;transition:color .2s}
#ab-header nav a:hover{color:#fff}

/* Hero */
.ab-hero{position:relative;overflow:hidden;padding:100px 48px 80px;text-align:center}
.ab-hero::before{content:'';position:absolute;inset:0;background:radial-gradient(ellipse 80% 60% at 50% 0%,rgba(232,0,28,.12) 0%,transparent 70%),linear-gradient(180deg,#090912 0%,#07070f 100%)}
.ab-hero-inner{position:relative;z-index:1;max-width:720px;margin:0 auto}
.ab-hero-badge{display:inline-block;background:rgba(232,0,28,.12);border:1px solid rgba(232,0,28,.35);color:var(--red);font-size:10px;font-weight:900;letter-spacing:.2em;text-transform:uppercase;padding:5px 14px;border-radius:3px;margin-bottom:24px}
.ab-hero-title{font-family:'Bebas Neue',sans-serif;font-size:clamp(52px,7vw,96px);color:#fff!important;line-height:.9;letter-spacing:.03em;margin-bottom:24px}
.ab-hero-title em{color:var(--red);font-style:normal}
.ab-hero-sub{font-size:17px;color:var(--grey);line-height:1.75;max-width:580px;margin:0 auto}

/* Mission */
.ab-mission{padding:80px 48px;border-top:1px solid var(--border)}
.ab-mission-inner{max-width:1200px;margin:0 auto;display:grid;grid-template-columns:1fr 1fr;gap:80px;align-items:center}
.ab-mission-label{font-size:10px;font-weight:900;letter-spacing:.2em;text-transform:uppercase;color:var(--red);margin-bottom:16px}
.ab-mission-title{font-family:'Bebas Neue',sans-serif;font-size:44px;color:#fff!important;line-height:1;margin-bottom:24px;letter-spacing:.03em}
.ab-mission-text{color:var(--grey);line-height:1.8;margin-bottom:16px}
.ab-mission-text strong{color:var(--text)}
.ab-stats{display:grid;grid-template-columns:repeat(3,1fr);gap:20px;margin-top:40px}
.ab-stat{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:24px;text-align:center}
.ab-stat-num{font-family:'Bebas Neue',sans-serif;font-size:48px;color:var(--red);line-height:1;display:block;margin-bottom:4px}
.ab-stat-lbl{font-size:11px;color:var(--grey);text-transform:uppercase;letter-spacing:.1em}

/* Channel strip */
.ab-channels{padding:0 48px 80px;max-width:1200px;margin:0 auto}
.ab-channels-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-top:32px}
.ab-ch-card{background:var(--card);border:1px solid var(--border);border-radius:10px;overflow:hidden;text-align:center;transition:all .2s}
.ab-ch-card:hover{border-color:rgba(232,0,28,.4);transform:translateY(-3px)}
.ab-ch-card img{width:100%;aspect-ratio:16/9;object-fit:cover;object-position:center;display:block}
.ab-ch-name{font-size:11px;font-weight:700;color:var(--grey);padding:8px 10px;line-height:1.3;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}

/* Team */
.ab-team{padding:80px 48px;background:var(--surface);border-top:1px solid var(--border);border-bottom:1px solid var(--border)}
.ab-team-inner{max-width:1000px;margin:0 auto}
.ab-section-header{text-align:center;margin-bottom:60px}
.ab-section-label{font-size:10px;font-weight:900;letter-spacing:.2em;text-transform:uppercase;color:var(--red);margin-bottom:12px;display:block}
.ab-section-title{font-family:'Bebas Neue',sans-serif;font-size:44px;color:#fff!important;letter-spacing:.03em}
.ab-team-grid{display:grid;grid-template-columns:1fr 1fr;gap:40px}
.ab-person{background:var(--card);border:1px solid var(--border);border-radius:16px;overflow:hidden;display:flex;flex-direction:column}
.ab-person-img{width:100%;aspect-ratio:1/1;object-fit:cover;object-position:center top;display:block}
.ab-person-body{padding:24px 28px 28px}
.ab-person-role{font-size:9px;font-weight:900;letter-spacing:.2em;text-transform:uppercase;color:var(--red);margin-bottom:8px}
.ab-person-name{font-family:'Bebas Neue',sans-serif;font-size:32px;color:#fff!important;line-height:1;margin-bottom:16px;letter-spacing:.04em}
.ab-person-bio{font-size:14px;color:var(--grey);line-height:1.75}
.ab-person-bio strong{color:var(--text)}

/* Partners */
.ab-partners{padding:80px 48px;max-width:1200px;margin:0 auto}
.ab-partners-logos{display:flex;flex-wrap:wrap;gap:32px;align-items:center;justify-content:center;margin-top:40px}
.ab-partner-item{display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);border-radius:10px;padding:14px 22px;transition:all .2s;min-width:100px;min-height:60px}
.ab-partner-item:hover{background:rgba(255,255,255,.13);border-color:rgba(255,255,255,.25)}
.ab-partner-logo{height:36px;width:auto;max-width:140px;filter:grayscale(1) contrast(1) brightness(1.2);opacity:.85;transition:opacity .2s;display:block}
.ab-partner-item:hover .ab-partner-logo{filter:grayscale(0) brightness(1.1);opacity:1}
.ab-partner-text{font-size:11px;font-weight:900;letter-spacing:.1em;color:rgba(255,255,255,.7);text-transform:uppercase;white-space:nowrap}

/* CTA */
.ab-cta{padding:80px 48px;background:linear-gradient(135deg,rgba(232,0,28,.1) 0%,rgba(232,0,28,.03) 100%);border-top:1px solid rgba(232,0,28,.2);text-align:center}
.ab-cta-inner{max-width:600px;margin:0 auto}
.ab-cta-title{font-family:'Bebas Neue',sans-serif;font-size:56px;color:#fff!important;line-height:.9;letter-spacing:.03em;margin-bottom:16px}
.ab-cta-sub{color:var(--grey);margin-bottom:36px;font-size:16px;line-height:1.7}
.ab-cta-btns{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
.btn-red{display:inline-flex;align-items:center;gap:8px;background:var(--red);color:#fff!important;font-weight:700;font-size:14px;padding:13px 28px;border-radius:8px;transition:all .2s;box-shadow:0 0 28px rgba(232,0,28,.3)}
.btn-red:hover{background:#c8001a;transform:translateY(-2px)}
.btn-ghost{display:inline-flex;align-items:center;gap:8px;color:var(--text)!important;font-weight:600;font-size:14px;padding:13px 24px;border-radius:8px;border:1px solid var(--border);transition:all .2s}
.btn-ghost:hover{border-color:var(--grey);color:#fff!important}

/* Footer */
#ab-footer{background:#050509;border-top:1px solid var(--border);padding:28px 48px;display:flex;align-items:center;justify-content:space-between}
#ab-footer .fc{font-size:12px;color:var(--muted)}
#ab-footer .fl{display:flex;gap:20px}
#ab-footer .fl a{font-size:12px;color:var(--muted)}
#ab-footer .fl a:hover{color:#fff}

@media(max-width:900px){
  #ab-header{padding:0 20px}#ab-header nav{display:none}
  .ab-hero,.ab-mission,.ab-team,.ab-channels,.ab-partners,.ab-cta{padding-left:20px;padding-right:20px}
  .ab-mission-inner{grid-template-columns:1fr}
  .ab-team-grid{grid-template-columns:1fr}
  .ab-person-img{width:100%}
  .ab-channels-grid{grid-template-columns:repeat(3,1fr)}
  .ab-stats{grid-template-columns:1fr}
  #ab-footer{flex-direction:column;gap:12px;text-align:center}
}
</style>
</head>
<body class="tackendo-about">

<header id="ab-header">
  <a href="<?php echo $site_url; ?>">
    <img src="<?php echo esc_url($logo_url); ?>" alt="TACKENDO" loading="eager">
  </a>
  <nav>
    <a href="<?php echo $site_url; ?>">Home</a>
    <a href="<?php echo esc_url(home_url('/blog')); ?>">Magazine</a>
    <a href="<?php echo $site_url; ?>#channels">Channels</a>
    <a href="<?php echo esc_url(home_url('/advertise')); ?>">Advertise</a>
    <a href="<?php echo esc_url(home_url('/contact')); ?>">Contact</a>
  </nav>
</header>

<!-- HERO -->
<section class="ab-hero">
  <div class="ab-hero-inner">
    <span class="ab-hero-badge">About TACKENDO</span>
    <h1 class="ab-hero-title">FREE TV,<br><em>DONE RIGHT.</em></h1>
    <p class="ab-hero-sub">TACKENDO is a premium FAST TV platform delivering 20+ free live linear channels across music, pop culture, and lifestyle — built for the Connected TV generation.</p>
  </div>
</section>

<!-- MISSION -->
<section class="ab-mission">
  <div class="ab-mission-inner">
    <div>
      <p class="ab-mission-label">Our Mission</p>
      <h2 class="ab-mission-title">Where Content Discovery Meets Advertising Efficiency</h2>
      <p class="ab-mission-text">TACKENDO is a <strong>FAST channel distribution and discovery platform</strong>, offering viewers free access to premium linear TV channels — and advertisers direct access to engaged audiences through clearly defined content verticals.</p>
      <p class="ab-mission-text">Available on <strong>Roku, Amazon Fire TV, web and mobile</strong>, our channels are designed for high-viewability, long session times, and brand-safe environments. No subscription. No login. Just TV.</p>
      <p class="ab-mission-text">Music-driven channels form the backbone of our lineup, delivering continuous, genre-based programming (Urban, EDM, Lo-Fi, Synthwave, Epic and more) alongside lifestyle, culture, entrepreneurship and informational channels.</p>

      <div class="ab-stats">
        <div class="ab-stat"><span class="ab-stat-num">20+</span><span class="ab-stat-lbl">Live Channels</span></div>
        <div class="ab-stat"><span class="ab-stat-num">4</span><span class="ab-stat-lbl">Platforms</span></div>
        <div class="ab-stat"><span class="ab-stat-num">24/7</span><span class="ab-stat-lbl">Linear Streaming</span></div>
      </div>
    </div>
    <div>
      <img src="https://tackendo.com/wp-content/uploads/2025/06/Netradio-Vision-1080x1080-1-300x300.jpg"
           alt="Netradio Vision — TACKENDO's flagship channel"
           style="width:100%;border-radius:20px;display:block;box-shadow:0 0 0 1px rgba(232,0,28,.3),0 40px 80px rgba(0,0,0,.6)">
    </div>
  </div>
</section>

<!-- OUR CHANNELS STRIP -->
<section style="padding:0 48px 80px">
  <div style="max-width:1200px;margin:0 auto">
    <div class="ab-section-header" style="text-align:left;margin-bottom:32px">
      <span class="ab-section-label">Our Lineup</span>
      <h2 class="ab-section-title">20 Channels, One Platform</h2>
    </div>
    <div class="ab-channels-grid">
      <?php
      require_once TCORE_PATH . 'includes/tcore-channels.php';
      foreach ( tcore_channels() as $slug => $ch ) :
      ?>
      <a href="<?php echo esc_url(home_url('/' . $slug . '/')); ?>" class="ab-ch-card">
        <img src="<?php echo esc_url($ch['logo']); ?>" alt="<?php echo esc_attr($ch['name']); ?>" loading="lazy">
        <p class="ab-ch-name"><?php echo esc_html($ch['name']); ?></p>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- TEAM -->
<section class="ab-team">
  <div class="ab-team-inner">
    <div class="ab-section-header">
      <span class="ab-section-label">The People Behind TACKENDO</span>
      <h2 class="ab-section-title">Founded by Media Pioneers</h2>
    </div>
    <div class="ab-team-grid">

      <div class="ab-person">
        <img class="ab-person-img"
             src="https://groupenetradio.fr/wp-content/uploads/2025/01/Untitled-design.png"
             alt="Christophe Marcy" loading="lazy">
        <div class="ab-person-body">
          <p class="ab-person-role">Founder &amp; CEO</p>
          <h3 class="ab-person-name">Christophe<br>MARCY</h3>
          <p class="ab-person-bio">With over 40 years in broadcasting, <strong>Christophe Marcy</strong> founded the first European pure-play digital radio group, celebrating 25 years of continuous operation across Satellite and DAB+. A veteran media executive, podcast host, and strategic advisor to French-speaking media leaders, Christophe now drives TACKENDO's vision as Europe's leading independent FAST TV platform. He is also the host of <strong>MARCY BEAUCOUP</strong>, Netradio Vision's weekly flagship interview show.</p>
        </div>
      </div>

      <div class="ab-person">
        <img class="ab-person-img"
             src="https://groupenetradio.fr/wp-content/uploads/2025/01/64bdd7b47fe70c7963df0120_Tatiana-Glazova-Marcy.jpg"
             alt="Tatiana Glazova" loading="lazy">
        <div class="ab-person-body">
          <p class="ab-person-role">Co-Founder &amp; General Director</p>
          <h3 class="ab-person-name">Tatiana<br>GLAZOVA</h3>
          <p class="ab-person-bio">A graduate of the Institut Supérieur de Gestion de Paris, <strong>Tatiana Glazova</strong> has built a remarkable career at the crossroads of music, media and technology. In 2004 she founded one of Europe's very first digital distribution companies — at a time when the industry had barely begun its shift online. She went on to lead a French music label before co-founding in 2012 one of the most influential music promotion platforms of its generation.</p>
          <p class="ab-person-bio" style="margin-top:12px">Her career then evolved toward podcast production and video content creation, before turning to FAST TV — where she now serves as General Director of TACKENDO and CEO of two satellite television channels. An expert in niche media strategy and audience development, she brings rare operational depth to TACKENDO's distribution and content management.</p>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- PARTNERS -->
<section class="ab-partners">
  <div class="ab-section-header" style="text-align:center;margin-bottom:40px">
    <span class="ab-section-label">Distribution &amp; Broadcast Partners</span>
    <h2 class="ab-section-title">Available Everywhere You Watch</h2>
  </div>
  <div class="ab-partners-logos">
    <?php
    $dist_logos = array(
      array('f'=>'roku.png',     'n'=>'Roku'),
      array('f'=>'firetv.png',   'n'=>'Amazon Fire TV'),
      array('f'=>'bouygues.png', 'n'=>'Bouygues Telecom'),
      array('f'=>'netgem.jpg',   'n'=>'Netgem'),
      array('f'=>'cloudtv.jpg',  'n'=>'CloudTV OS'),
      array('f'=>'neotv.webp',   'n'=>'NeoTV+'),
      array('f'=>'zeop.jpg',     'n'=>'Zeop'),
      array('f'=>'vialis.svg',   'n'=>'Vialis'),
      array('f'=>'slingtv',      'n'=>'Sling TV'),
      array('f'=>'swifttv',      'n'=>'Swift TV'),
      array('f'=>'switzhtv',    'n'=>'Switzh TV'),
    );
    foreach ( $dist_logos as $logo ) {
      // Bundled assets (always available, no download needed)
      $bundled = array( 'slingtv.jpg', 'swifttv.jpg', 'switzhtv.svg' );
      $f_key   = $logo['f'];
      // Check if this logo is bundled in plugin assets
      $bundled_exts = array( 'slingtv' => 'jpg', 'swifttv' => 'jpg', 'switzhtv' => 'svg' );
      $base = pathinfo( $f_key, PATHINFO_FILENAME );
      if ( isset( $bundled_exts[ $base ] ) ) {
        $src = TCORE_URL . 'assets/logos/' . $base . '.' . $bundled_exts[ $base ];
      } else {
        $src = tcore_logo_url( $logo['f'] );
      }
      echo '<div class="ab-partner-item">';
      if ( $src ) {
        echo '<img class="ab-partner-logo" src="' . esc_url($src) . '" alt="' . esc_attr($logo['n']) . '" loading="lazy">';
      } else {
        echo '<span class="ab-partner-text">' . esc_html($logo['n']) . '</span>';
      }
      echo '</div>';
    }
    ?>
  </div>
</section>

<!-- VIZNET MONETIZATION PARTNER -->
<section style="padding:80px 48px;border-top:1px solid var(--border)">
  <div style="max-width:1200px;margin:0 auto;display:grid;grid-template-columns:1fr 1fr;gap:60px;align-items:center">
    <div>
      <span style="font-size:10px;font-weight:900;letter-spacing:.2em;text-transform:uppercase;color:var(--red);margin-bottom:16px;display:block">Monetization Partner</span>
      <h2 style="font-family:'Bebas Neue',sans-serif;font-size:40px;color:#fff;line-height:1;margin-bottom:20px;letter-spacing:.03em">Powered by<br>Viznet</h2>
      <p style="color:var(--grey);line-height:1.8;margin-bottom:16px">TACKENDO's advertising monetization is powered by <strong style="color:var(--text)">Viznet</strong>, a leading programmatic advertising platform specializing in CTV and streaming environments.</p>
      <p style="color:var(--grey);line-height:1.8;margin-bottom:24px">Through Viznet's advanced programmatic infrastructure, TACKENDO channels deliver <strong style="color:var(--text)">targeted, high-impact ad inventory</strong> to brands and agencies — maximizing CPMs while maintaining a seamless viewing experience for audiences.</p>
      <a href="https://viznet.tv/" target="_blank" rel="noopener" style="display:inline-flex;align-items:center;gap:8px;color:var(--red);font-size:13px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;text-decoration:none">Learn about Viznet &rarr;</a>
    </div>
    <div style="text-align:center">
      <a href="https://viznet.tv/" target="_blank" rel="noopener">
        <img src="<?php echo esc_url( tcore_logo_url('viznet.png') ?: 'https://viznet.tv/wp-content/uploads/2023/09/logo-viznet-blanc.png' ); ?>"
             alt="Viznet — CTV Monetization Partner"
             style="max-width:260px;width:100%;filter:grayscale(1) brightness(1.2);opacity:.85;transition:opacity .2s"
             onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='.85'"
             loading="lazy">
      </a>
      <p style="font-size:11px;color:var(--muted);margin-top:20px;line-height:1.6">CTV Programmatic Advertising<br>Optimization &amp; Revenue Management</p>
    </div>
  </div>
</section>

<!-- TECHNICAL PARTNERS -->
<section style="padding:60px 48px;background:var(--surface);border-top:1px solid var(--border);border-bottom:1px solid var(--border)">
  <div style="max-width:1200px;margin:0 auto">
    <div style="text-align:center;margin-bottom:48px">
      <span style="font-size:10px;font-weight:900;letter-spacing:.2em;text-transform:uppercase;color:var(--red);margin-bottom:12px;display:block">Infrastructure &amp; Technology</span>
      <h2 style="font-family:'Bebas Neue',sans-serif;font-size:40px;color:#fff;letter-spacing:.03em">Our Technical Partners</h2>
    </div>
    <div style="display:flex;flex-wrap:wrap;gap:40px;align-items:center;justify-content:center">

      <div style="text-align:center">
        <a href="https://www.vodfactory.com/" target="_blank" rel="noopener">
          <img src="<?php echo esc_url( tcore_logo_url('vodfactory.png') ?: 'https://cdn.prod.website-files.com/5d1b4c09d7f0159a77c39cb1/5d1b4c51d7f0154fa4c3a021_logoVodFactory-RVB.png' ); ?>"
               alt="VOD Factory" style="height:36px;width:auto;filter:grayscale(1) brightness(1.1);opacity:.85;display:block;margin:0 auto 10px;max-width:130px"
               onerror="this.style.display='none';this.nextElementSibling.style.display='block'" loading="lazy">
          <span style="display:none;font-size:12px;font-weight:900;letter-spacing:.1em;color:rgba(255,255,255,.5);text-transform:uppercase;padding:8px 16px;border:1px solid rgba(255,255,255,.15);border-radius:6px">VOD Factory</span>
        </a>
        <p style="font-size:10px;color:var(--muted);margin-top:6px">Channel Playout</p>
      </div>

      <div style="text-align:center">
        <a href="https://www.viloud.tv/" target="_blank" rel="noopener">
          <img src="<?php echo esc_url( tcore_logo_url('viloud.png') ?: 'https://dm0801zzlveea.cloudfront.net/wp-content/uploads/2019/02/logo_viloud_web_mini.png' ); ?>"
               alt="Viloud" style="height:36px;width:auto;filter:grayscale(1) brightness(1.1);opacity:.85;display:block;margin:0 auto 10px;max-width:130px"
               onerror="this.style.display='none';this.nextElementSibling.style.display='block'" loading="lazy">
          <span style="display:none;font-size:12px;font-weight:900;letter-spacing:.1em;color:rgba(255,255,255,.5);text-transform:uppercase;padding:8px 16px;border:1px solid rgba(255,255,255,.15);border-radius:6px">Viloud</span>
        </a>
        <p style="font-size:10px;color:var(--muted);margin-top:6px">EPG &amp; Scheduling</p>
      </div>

      <div style="text-align:center">
        <a href="https://broadpeak.tv/" target="_blank" rel="noopener">
          <img src="<?php echo esc_url( tcore_logo_url('broadpeak.svg') ?: 'https://broadpeak.tv/wp-content/uploads/Broadpeak_Logo.svg' ); ?>"
               alt="Broadpeak" style="height:36px;width:auto;filter:grayscale(1) brightness(1.1);opacity:.85;display:block;margin:0 auto 10px;max-width:130px"
               onerror="this.style.display='none';this.nextElementSibling.style.display='block'" loading="lazy">
          <span style="display:none;font-size:12px;font-weight:900;letter-spacing:.1em;color:rgba(255,255,255,.5);text-transform:uppercase;padding:8px 16px;border:1px solid rgba(255,255,255,.15);border-radius:6px">Broadpeak</span>
        </a>
        <p style="font-size:10px;color:var(--muted);margin-top:6px">Video Streaming CDN</p>
      </div>

      <div style="text-align:center">
        <a href="https://hosttec.online/" target="_blank" rel="noopener">
          <img src="<?php echo esc_url( tcore_logo_url('hosttec.png') ?: 'https://hosttec.online/img/cropped-hosttecnovologosite.png' ); ?>"
               alt="Hosttec Solutions" style="height:36px;width:auto;filter:grayscale(1) brightness(1.1);opacity:.85;display:block;margin:0 auto 10px;max-width:130px"
               onerror="this.style.display='none';this.nextElementSibling.style.display='block'" loading="lazy">
          <span style="display:none;font-size:12px;font-weight:900;letter-spacing:.1em;color:rgba(255,255,255,.5);text-transform:uppercase;padding:8px 16px;border:1px solid rgba(255,255,255,.15);border-radius:6px">Hosttec</span>
        </a>
        <p style="font-size:10px;color:var(--muted);margin-top:6px">Hosting &amp; Infrastructure</p>
      </div>

    </div>
  </div>
</section>

<!-- CTA -->
<section class="ab-cta">
  <div class="ab-cta-inner">
    <h2 class="ab-cta-title">START WATCHING.<br>IT'S FREE.</h2>
    <p class="ab-cta-sub">No subscription. No account. No credit card. Just 20+ live TV channels across music, culture and lifestyle — on any screen.</p>
    <div class="ab-cta-btns">
      <a href="<?php echo $site_url; ?>#channels" class="btn-red">Browse Channels &rarr;</a>
      <a href="https://channelstore.roku.com/details/8244e521d238b28c45271329a3ebe907/tackendo" class="btn-ghost" target="_blank" rel="noopener">Add to Roku</a>
      <a href="https://www.amazon.com/gp/product/B0DGNFS8N9" class="btn-ghost" target="_blank" rel="noopener">Fire TV</a>
    </div>
  </div>
</section>

<footer id="ab-footer">
  <p class="fc">&copy; 2024&ndash;<?php echo date('Y'); ?> TACKENDO &mdash; Netradio Network. All rights reserved.</p>
  <div class="fl">
    <a href="<?php echo esc_url(home_url('/privacy-policy')); ?>">Privacy Policy</a>
    <a href="<?php echo esc_url(home_url('/contact')); ?>">Contact</a>
    <a href="<?php echo $site_url; ?>">Home</a>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
