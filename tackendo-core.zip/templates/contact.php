<?php
/* Template Name: Tackendo Contact */
if ( ! defined( 'ABSPATH' ) ) exit;

$logo_url = 'https://tackendo.com/wp-content/uploads/2025/06/Tackendo-logo-white-on-transparent-262x76-1.png';
$site_url = esc_url( home_url('/') );

// Handle form submission
$sent = false;
$error = false;
if ( isset($_POST['tcore_contact_nonce']) && wp_verify_nonce($_POST['tcore_contact_nonce'], 'tcore_contact') ) {
    $name    = sanitize_text_field($_POST['contact_name'] ?? '');
    $email   = sanitize_email($_POST['contact_email'] ?? '');
    $subject = sanitize_text_field($_POST['contact_subject'] ?? 'Contact from tackendo.com');
    $message = sanitize_textarea_field($_POST['contact_message'] ?? '');

    if ( $name && is_email($email) && strlen($message) > 10 ) {
        $body  = "Name: $name\nEmail: $email\n\nMessage:\n$message";
        $headers = array('Content-Type: text/plain; charset=UTF-8', "Reply-To: $name <$email>");
        if ( wp_mail('contact@tackendo.com', "[TACKENDO] $subject", $body, $headers) ) {
            $sent = true;
        } else {
            $error = true;
        }
    } else {
        $error = true;
    }
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Contact TACKENDO &mdash; Get in Touch</title>
<meta name="description" content="Contact the TACKENDO team for advertising inquiries, press, partnerships, or general questions.">
<meta name="robots" content="index, follow">
<link rel="canonical" href="<?php echo esc_url(home_url('/contact')); ?>">
<meta name="theme-color" content="#E8001C">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Figtree:wght@400;500;600;700&display=swap" rel="stylesheet">
<?php wp_head(); ?>
<style>
:root{--bg:#07070f;--surface:#0d0d18;--card:#111120;--red:#E8001C;--white:#fff;--text:#d8d8e8;--grey:#7a7a90;--muted:#4a4a60;--border:#1c1c2e;--green:#22c55e}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body.tackendo-contact{background:var(--bg);color:var(--text);font-family:'Figtree','Segoe UI',sans-serif;font-size:16px;line-height:1.7}
body.tackendo-contact h1,body.tackendo-contact h2,body.tackendo-contact h3{color:#fff!important;font-weight:400!important}
body.tackendo-contact a{color:var(--red);text-decoration:none}
body.tackendo-contact a:hover{text-decoration:underline}
body.tackendo-contact .site-header,body.tackendo-contact #masthead,body.tackendo-contact #ast-fixed-header,body.tackendo-contact .site-footer,body.tackendo-contact #astra-footer-area{display:none!important}

/* Header */
#ct-header{position:sticky;top:0;z-index:200;background:rgba(7,7,15,.94);backdrop-filter:blur(18px);border-bottom:1px solid var(--border);height:64px;padding:0 48px;display:flex;align-items:center;justify-content:space-between}
#ct-header img{height:34px;width:auto;display:block}
#ct-header nav{display:flex;gap:28px}
#ct-header nav a{color:var(--grey);font-size:12px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;transition:color .2s;text-decoration:none}
#ct-header nav a:hover{color:#fff}

/* Hero */
.ct-hero{padding:72px 48px 56px;background:linear-gradient(180deg,#090912 0%,#07070f 100%);border-bottom:1px solid var(--border);text-align:center}
.ct-hero-label{font-size:10px;font-weight:900;letter-spacing:.22em;text-transform:uppercase;color:var(--red);margin-bottom:14px;display:block}
.ct-hero-title{font-family:'Bebas Neue',sans-serif;font-size:clamp(48px,6vw,80px);color:#fff!important;line-height:.9;letter-spacing:.03em;margin-bottom:16px}
.ct-hero-sub{font-size:17px;color:var(--grey);max-width:520px;margin:0 auto;line-height:1.75}

/* Quick contact cards */
.ct-cards{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;max-width:900px;margin:0 auto;padding:48px 48px 0}
.ct-card{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:24px;text-align:center;transition:all .2s;text-decoration:none;display:block}
.ct-card:hover{border-color:rgba(232,0,28,.4);transform:translateY(-3px)}
.ct-card-icon{width:48px;height:48px;border-radius:12px;background:rgba(232,0,28,.12);border:1px solid rgba(232,0,28,.25);margin:0 auto 14px;display:flex;align-items:center;justify-content:center}
.ct-card-icon svg{width:22px;height:22px;fill:var(--red)}
.ct-card-title{font-family:'Bebas Neue',sans-serif;font-size:20px;color:#fff!important;letter-spacing:.04em;margin-bottom:6px}
.ct-card-desc{font-size:12px;color:var(--grey);line-height:1.55}
.ct-card-link{font-size:12px;color:var(--red);font-weight:700;margin-top:10px;display:block}

/* Main layout */
.ct-layout{display:grid;grid-template-columns:1fr 420px;gap:60px;max-width:1100px;margin:0 auto;padding:60px 48px}

/* Form */
.ct-form-wrap{}
.ct-form-title{font-family:'Bebas Neue',sans-serif;font-size:36px;color:#fff!important;letter-spacing:.04em;margin-bottom:8px}
.ct-form-sub{font-size:14px;color:var(--grey);margin-bottom:32px}
.ct-success{background:rgba(34,197,94,.12);border:1px solid rgba(34,197,94,.35);border-radius:12px;padding:20px 24px;color:#86efac;font-size:14px;display:flex;align-items:center;gap:12px;margin-bottom:24px}
.ct-error{background:rgba(232,0,28,.1);border:1px solid rgba(232,0,28,.35);border-radius:12px;padding:20px 24px;color:#fca5a5;font-size:14px;margin-bottom:24px}
.ct-form{display:flex;flex-direction:column;gap:16px}
.ct-field{display:flex;flex-direction:column;gap:6px}
.ct-field label{font-size:12px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--grey)}
.ct-field input,.ct-field select,.ct-field textarea{background:var(--card);border:1px solid var(--border);border-radius:8px;padding:12px 16px;color:#fff;font-family:'Figtree',sans-serif;font-size:14px;outline:none;transition:border-color .2s;width:100%}
.ct-field input:focus,.ct-field select:focus,.ct-field textarea:focus{border-color:rgba(232,0,28,.5)}
.ct-field textarea{resize:vertical;min-height:140px;line-height:1.6}
.ct-field select{cursor:pointer;appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' fill='none'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%237a7a90' stroke-width='1.5' stroke-linecap='round'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 14px center}
.ct-submit{background:var(--red);color:#fff;font-family:'Figtree',sans-serif;font-size:14px;font-weight:700;padding:14px 28px;border-radius:8px;border:none;cursor:pointer;transition:all .2s;letter-spacing:.04em;width:100%}
.ct-submit:hover{background:#c8001a;transform:translateY(-1px)}
.ct-form-note{font-size:11px;color:var(--muted);line-height:1.6;margin-top:4px}

/* Sidebar info */
.ct-sidebar{}
.ct-info-box{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:28px;margin-bottom:20px}
.ct-info-box-title{font-family:'Bebas Neue',sans-serif;font-size:22px;color:#fff!important;letter-spacing:.04em;margin-bottom:16px;padding-bottom:14px;border-bottom:1px solid var(--border)}
.ct-info-row{display:flex;gap:12px;margin-bottom:14px;align-items:flex-start}
.ct-info-row:last-child{margin-bottom:0}
.ct-info-dot{width:8px;height:8px;border-radius:50%;background:var(--red);flex-shrink:0;margin-top:7px}
.ct-info-label{font-size:11px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--muted);margin-bottom:3px}
.ct-info-val{font-size:13px;color:var(--text)}
.ct-info-val a{color:var(--red);text-decoration:none}
.ct-social{display:flex;gap:10px;margin-top:16px;flex-wrap:wrap}
.ct-social a{display:flex;align-items:center;gap:7px;background:var(--surface);border:1px solid var(--border);border-radius:8px;padding:8px 14px;font-size:12px;font-weight:700;color:var(--grey);text-decoration:none;transition:all .2s}
.ct-social a:hover{color:#fff;border-color:rgba(255,255,255,.2)}

/* FAQ */
.ct-faq{max-width:1100px;margin:0 auto;padding:0 48px 80px}
.ct-faq-title{font-family:'Bebas Neue',sans-serif;font-size:40px;color:#fff!important;letter-spacing:.04em;margin-bottom:32px}
.ct-faq-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.ct-faq-item{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:24px;cursor:pointer;transition:border-color .2s}
.ct-faq-item:hover{border-color:rgba(232,0,28,.3)}
.ct-faq-q{font-size:15px;font-weight:700;color:#fff;line-height:1.4;margin-bottom:12px;display:flex;align-items:flex-start;gap:10px}
.ct-faq-q::before{content:'Q';display:inline-flex;flex-shrink:0;width:22px;height:22px;background:var(--red);border-radius:4px;font-size:11px;font-weight:900;color:#fff;align-items:center;justify-content:center;margin-top:1px}
.ct-faq-a{font-size:13px;color:var(--grey);line-height:1.7}
.ct-faq-a a{color:var(--red)}

/* Footer */
#ct-footer{background:#050509;border-top:1px solid var(--border);padding:28px 48px;display:flex;align-items:center;justify-content:space-between}
#ct-footer p{font-size:12px;color:var(--muted)}
#ct-footer nav{display:flex;gap:20px}
#ct-footer nav a{font-size:12px;color:var(--muted);text-decoration:none}
#ct-footer nav a:hover{color:#fff}

@media(max-width:900px){
  #ct-header{padding:0 20px}#ct-header nav{display:none}
  .ct-hero,.ct-cards,.ct-layout,.ct-faq{padding-left:20px;padding-right:20px}
  .ct-cards{grid-template-columns:1fr}
  .ct-layout{grid-template-columns:1fr}
  .ct-faq-grid{grid-template-columns:1fr}
  #ct-footer{flex-direction:column;gap:12px}
}
</style>
</head>
<body class="tackendo-contact">

<header id="ct-header">
  <a href="<?php echo $site_url; ?>">
    <img src="<?php echo esc_url($logo_url); ?>" alt="TACKENDO" loading="eager">
  </a>
  <nav>
    <a href="<?php echo $site_url; ?>">Home</a>
    <a href="<?php echo esc_url(home_url('/about')); ?>">About</a>
    <a href="<?php echo esc_url(home_url('/advertise')); ?>">Advertise</a>
    <a href="<?php echo esc_url(home_url('/blog')); ?>">Magazine</a>
  </nav>
</header>

<div class="ct-hero">
  <span class="ct-hero-label">Get in Touch</span>
  <h1 class="ct-hero-title">Contact<br>TACKENDO</h1>
  <p class="ct-hero-sub">Whether you're a brand, agency, press contact, or viewer — we'd love to hear from you.</p>
</div>

<!-- Quick contact cards -->
<div class="ct-cards">
  <a href="mailto:contact@tackendo.com?subject=Advertising%20Inquiry" class="ct-card">
    <div class="ct-card-icon">
      <svg viewBox="0 0 24 24"><path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>
    </div>
    <h3 class="ct-card-title">Advertising</h3>
    <p class="ct-card-desc">Media kits, rates, campaign planning, and programmatic partnerships</p>
    <span class="ct-card-link">contact@tackendo.com &rarr;</span>
  </a>
  <a href="https://okfast.fr/" target="_blank" rel="noopener" class="ct-card">
    <div class="ct-card-icon">
      <svg viewBox="0 0 24 24"><path d="M21 3L3 10.5v.9l6.8 2.8 2.8 6.8h.9L21 3z"/></svg>
    </div>
    <h3 class="ct-card-title">Self-Serve Ads</h3>
    <p class="ct-card-desc">Launch your own FAST TV campaign directly via our OKFAST platform</p>
    <span class="ct-card-link">okfast.fr &rarr;</span>
  </a>
  <a href="mailto:contact@tackendo.com?subject=Press%20Inquiry" class="ct-card">
    <div class="ct-card-icon">
      <svg viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 3c1.93 0 3.5 1.57 3.5 3.5S13.93 13 12 13s-3.5-1.57-3.5-3.5S10.07 6 12 6zm7 13H5v-.23c0-.62.28-1.2.76-1.58C7.47 15.82 9.64 15 12 15s4.53.82 6.24 2.19c.48.38.76.97.76 1.58V19z"/></svg>
    </div>
    <h3 class="ct-card-title">Press &amp; Media</h3>
    <p class="ct-card-desc">Press releases, editorial collaborations, interviews and media enquiries</p>
    <span class="ct-card-link">Press contact &rarr;</span>
  </a>
</div>

<!-- Form + Sidebar -->
<div class="ct-layout">
  <div class="ct-form-wrap">
    <h2 class="ct-form-title">Send Us a Message</h2>
    <p class="ct-form-sub">Fill in the form below and we'll get back to you within 2 business days.</p>

    <?php if ($sent) : ?>
    <div class="ct-success">
      <span style="font-size:20px;line-height:1">✓</span>
      <div><strong>Message sent!</strong> Thank you — we'll get back to you within 2 business days.</div>
    </div>
    <?php elseif ($error) : ?>
    <div class="ct-error">Something went wrong. Please try again or email us directly at <strong>contact@tackendo.com</strong>.</div>
    <?php endif; ?>

    <?php if (!$sent) : ?>
    <form method="POST" class="ct-form">
      <?php wp_nonce_field('tcore_contact', 'tcore_contact_nonce'); ?>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
        <div class="ct-field">
          <label for="contact_name">Your Name *</label>
          <input type="text" id="contact_name" name="contact_name" required placeholder="John Smith" value="<?php echo esc_attr($_POST['contact_name'] ?? ''); ?>">
        </div>
        <div class="ct-field">
          <label for="contact_email">Email Address *</label>
          <input type="email" id="contact_email" name="contact_email" required placeholder="you@company.com" value="<?php echo esc_attr($_POST['contact_email'] ?? ''); ?>">
        </div>
      </div>
      <div class="ct-field">
        <label for="contact_subject">Subject</label>
        <select id="contact_subject" name="contact_subject">
          <option value="Advertising Inquiry">Advertising Inquiry</option>
          <option value="Campaign via OKFAST">Launch a Campaign (OKFAST)</option>
          <option value="Press & Media">Press &amp; Media</option>
          <option value="Channel Partnership">Channel Partnership</option>
          <option value="Distribution Partnership">Distribution Partnership</option>
          <option value="Technical Issue">Technical Issue</option>
          <option value="General Question">General Question</option>
          <option value="Other">Other</option>
        </select>
      </div>
      <div class="ct-field">
        <label for="contact_message">Message *</label>
        <textarea id="contact_message" name="contact_message" required placeholder="Tell us what you need..."><?php echo esc_textarea($_POST['contact_message'] ?? ''); ?></textarea>
      </div>
      <button type="submit" class="ct-submit">Send Message &rarr;</button>
      <p class="ct-form-note">By submitting this form, you agree to our <a href="<?php echo esc_url(home_url('/privacy-policy')); ?>" style="color:var(--red)">Privacy Policy</a>. We never share your data with third parties.</p>
    </form>
    <?php endif; ?>
  </div>

  <!-- Sidebar -->
  <aside class="ct-sidebar">
    <div class="ct-info-box">
      <h3 class="ct-info-box-title">Contact Information</h3>
      <div class="ct-info-row">
        <span class="ct-info-dot"></span>
        <div><p class="ct-info-label">General</p><p class="ct-info-val"><a href="mailto:contact@tackendo.com">contact@tackendo.com</a></p></div>
      </div>
      <div class="ct-info-row">
        <span class="ct-info-dot"></span>
        <div><p class="ct-info-label">Advertising</p><p class="ct-info-val"><a href="mailto:contact@tackendo.com?subject=Advertising%20Inquiry">contact@tackendo.com</a></p></div>
      </div>
      <div class="ct-info-row">
        <span class="ct-info-dot"></span>
        <div><p class="ct-info-label">Self-Serve Campaigns</p><p class="ct-info-val"><a href="https://okfast.fr" target="_blank" rel="noopener">okfast.fr</a></p></div>
      </div>
      <div class="ct-info-row">
        <span class="ct-info-dot"></span>
        <div><p class="ct-info-label">Entity</p><p class="ct-info-val">TACKENDO — Netradio Network</p></div>
      </div>
      <div class="ct-info-row">
        <span class="ct-info-dot"></span>
        <div><p class="ct-info-label">Response Time</p><p class="ct-info-val">Within 2 business days</p></div>
      </div>
      <div class="ct-social">
        <a href="https://www.linkedin.com/in/chrismarcy/" target="_blank" rel="noopener">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="#7a7a90"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
          LinkedIn
        </a>
        <a href="https://www.facebook.com/netradio.france/" target="_blank" rel="noopener">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="#7a7a90"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
          Facebook
        </a>
        <a href="https://www.instagram.com/netradio.fr/" target="_blank" rel="noopener">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="#7a7a90"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg>
          Instagram
        </a>
      </div>
    </div>

    <div class="ct-info-box">
      <h3 class="ct-info-box-title">Watch TACKENDO</h3>
      <div style="display:flex;flex-direction:column;gap:10px">
        <a href="https://channelstore.roku.com/details/8244e521d238b28c45271329a3ebe907/tackendo" target="_blank" rel="noopener" style="display:flex;align-items:center;justify-content:space-between;background:var(--surface);border:1px solid var(--border);border-radius:8px;padding:12px 16px;text-decoration:none;color:var(--text);font-size:13px;font-weight:600;transition:border-color .2s">
          <span>Add to Roku</span><span style="color:var(--red)">Free &rarr;</span>
        </a>
        <a href="https://www.amazon.com/gp/product/B0DGNFS8N9" target="_blank" rel="noopener" style="display:flex;align-items:center;justify-content:space-between;background:var(--surface);border:1px solid var(--border);border-radius:8px;padding:12px 16px;text-decoration:none;color:var(--text);font-size:13px;font-weight:600;transition:border-color .2s">
          <span>Amazon Fire TV</span><span style="color:var(--red)">Free &rarr;</span>
        </a>
        <a href="<?php echo $site_url; ?>#channels" style="display:flex;align-items:center;justify-content:space-between;background:var(--surface);border:1px solid var(--border);border-radius:8px;padding:12px 16px;text-decoration:none;color:var(--text);font-size:13px;font-weight:600">
          <span>Watch on Web</span><span style="color:var(--red)">Free &rarr;</span>
        </a>
      </div>
    </div>
  </aside>
</div>

<!-- FAQ -->
<div class="ct-faq">
  <h2 class="ct-faq-title">Frequently Asked Questions</h2>
  <div class="ct-faq-grid">

    <div class="ct-faq-item">
      <p class="ct-faq-q">Is TACKENDO really free? How does it work?</p>
      <p class="ct-faq-a">Yes — completely free, no subscription, no account required. TACKENDO is an ad-supported FAST TV platform. You watch for free; brands pay for the ads you see. Simple as that.</p>
    </div>

    <div class="ct-faq-item">
      <p class="ct-faq-q">How can I advertise on TACKENDO channels?</p>
      <p class="ct-faq-a">Two ways: (1) Contact us directly for a custom media plan and rate card. (2) Use <a href="https://okfast.fr">OKFAST</a> — our self-serve platform where SMEs can launch FAST TV campaigns from a few hundred euros with no agency needed.</p>
    </div>

    <div class="ct-faq-item">
      <p class="ct-faq-q">What platforms is TACKENDO available on?</p>
      <p class="ct-faq-a">TACKENDO channels are available on <strong>Roku</strong>, <strong>Amazon Fire TV</strong>, the web (tackendo.com), and via connected TV platforms including Bouygues Telecom, Netgem, CloudTV, and Zeop.</p>
    </div>

    <div class="ct-faq-item">
      <p class="ct-faq-q">I'm a content creator. Can I get my channel on TACKENDO?</p>
      <p class="ct-faq-a">We're selective about new channel additions to maintain quality. Contact us with your channel concept, content catalog, and target audience. We'll review your proposal within 5 business days.</p>
    </div>

    <div class="ct-faq-item">
      <p class="ct-faq-q">I'm a journalist. Who should I contact for press?</p>
      <p class="ct-faq-a">Send your press inquiry to <a href="mailto:contact@tackendo.com?subject=Press%20Inquiry">contact@tackendo.com</a> with "Press" in the subject line. Our team will respond promptly with relevant assets, spokespersons, and information.</p>
    </div>

    <div class="ct-faq-item">
      <p class="ct-faq-q">How do I report a technical issue with a channel?</p>
      <p class="ct-faq-a">Use the contact form above and select "Technical Issue". Please include the channel name, platform (Roku, Fire TV, web), your device type, and a description of the problem. We typically resolve stream issues within 24 hours.</p>
    </div>

    <div class="ct-faq-item">
      <p class="ct-faq-q">Can I become a distribution partner?</p>
      <p class="ct-faq-a">Yes. If you operate a smart TV platform, IPTV service, or connected device ecosystem and would like to carry TACKENDO channels, contact us at <a href="mailto:contact@tackendo.com?subject=Distribution%20Partnership">contact@tackendo.com</a>.</p>
    </div>

    <div class="ct-faq-item">
      <p class="ct-faq-q">How do I exercise my GDPR / privacy rights?</p>
      <p class="ct-faq-a">Contact us at <a href="mailto:contact@tackendo.com?subject=Privacy%20Request">contact@tackendo.com</a> with your request. We respond to all privacy requests within 30 days. See our <a href="<?php echo esc_url(home_url('/privacy-policy')); ?>">Privacy Policy</a> for full details.</p>
    </div>

  </div>
</div>

<footer id="ct-footer">
  <p>&copy; 2024&ndash;<?php echo date('Y'); ?> TACKENDO &mdash; Netradio Network. All rights reserved.</p>
  <nav>
    <a href="<?php echo $site_url; ?>">Home</a>
    <a href="<?php echo esc_url(home_url('/privacy-policy')); ?>">Privacy Policy</a>
    <a href="<?php echo esc_url(home_url('/about')); ?>">About</a>
  </nav>
</footer>

<?php wp_footer(); ?>
</body>
</html>
