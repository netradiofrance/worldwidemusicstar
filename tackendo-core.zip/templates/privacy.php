<?php
/* Template Name: Tackendo Privacy */
if ( ! defined( 'ABSPATH' ) ) exit;

$logo_url = 'https://tackendo.com/wp-content/uploads/2025/06/Tackendo-logo-white-on-transparent-262x76-1.png';
$site_url = esc_url( home_url('/') );
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Privacy Policy &mdash; TACKENDO</title>
<meta name="description" content="TACKENDO Privacy Policy — how we collect, use and protect your data on our free FAST TV platform.">
<meta name="robots" content="index, follow">
<link rel="canonical" href="<?php echo esc_url(home_url('/privacy-policy')); ?>">
<meta name="theme-color" content="#E8001C">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Figtree:wght@400;500;600;700&display=swap" rel="stylesheet">
<?php wp_head(); ?>
<style>
:root{--bg:#07070f;--surface:#0d0d18;--card:#111120;--red:#E8001C;--white:#fff;--text:#d8d8e8;--grey:#7a7a90;--muted:#4a4a60;--border:#1c1c2e}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body.tackendo-privacy{background:var(--bg);color:var(--text);font-family:'Figtree','Segoe UI',sans-serif;font-size:16px;line-height:1.7}
body.tackendo-privacy a{color:var(--red);text-decoration:none}
body.tackendo-privacy a:hover{text-decoration:underline}
body.tackendo-privacy .site-header,body.tackendo-privacy #masthead,body.tackendo-privacy #ast-fixed-header,body.tackendo-privacy .site-footer,body.tackendo-privacy #astra-footer-area{display:none!important}

/* Header */
#pp-header{position:sticky;top:0;z-index:200;background:rgba(7,7,15,.94);backdrop-filter:blur(18px);border-bottom:1px solid var(--border);height:64px;padding:0 48px;display:flex;align-items:center;justify-content:space-between}
#pp-header img{height:34px;width:auto;display:block}
#pp-header nav{display:flex;gap:28px}
#pp-header nav a{color:var(--grey);font-size:12px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;transition:color .2s;text-decoration:none}
#pp-header nav a:hover{color:#fff}

/* Hero */
.pp-hero{padding:72px 48px 52px;background:linear-gradient(180deg,#090912 0%,#07070f 100%);border-bottom:1px solid var(--border)}
.pp-hero-label{font-size:10px;font-weight:900;letter-spacing:.22em;text-transform:uppercase;color:var(--red);margin-bottom:14px;display:block}
.pp-hero-title{font-family:'Bebas Neue',sans-serif;font-size:56px;color:#fff;letter-spacing:.03em;line-height:.95;margin-bottom:16px}
.pp-hero-updated{font-size:13px;color:var(--muted)}

/* Layout */
.pp-layout{display:grid;grid-template-columns:220px 1fr;gap:60px;max-width:1100px;margin:0 auto;padding:60px 48px}

/* TOC sidebar */
.pp-toc{position:sticky;top:80px;height:fit-content}
.pp-toc-title{font-size:10px;font-weight:900;letter-spacing:.18em;text-transform:uppercase;color:var(--muted);margin-bottom:16px}
.pp-toc-list{list-style:none;display:flex;flex-direction:column;gap:2px}
.pp-toc-list a{font-size:12px;color:var(--grey);text-decoration:none;padding:5px 10px;border-radius:5px;display:block;border-left:2px solid transparent;transition:all .18s;line-height:1.4}
.pp-toc-list a:hover{color:#fff;border-color:var(--red);background:rgba(232,0,28,.06)}

/* Content */
.pp-content{}
.pp-section{margin-bottom:48px;padding-bottom:48px;border-bottom:1px solid var(--border)}
.pp-section:last-child{border-bottom:none;margin-bottom:0}
.pp-section-num{font-size:10px;font-weight:900;letter-spacing:.2em;text-transform:uppercase;color:var(--red);margin-bottom:8px;display:block}
.pp-section h2{font-family:'Bebas Neue',sans-serif;font-size:32px;color:#fff;letter-spacing:.04em;margin-bottom:16px}
.pp-section h3{font-size:14px;font-weight:700;color:#fff;margin:20px 0 8px}
.pp-section p{color:var(--grey);line-height:1.8;margin-bottom:12px;font-size:15px}
.pp-section p strong{color:var(--text)}
.pp-section ul{list-style:none;padding-left:0;margin:8px 0 16px;display:flex;flex-direction:column;gap:6px}
.pp-section ul li{color:var(--grey);font-size:14px;padding-left:20px;position:relative;line-height:1.6}
.pp-section ul li::before{content:'';position:absolute;left:0;top:9px;width:6px;height:6px;border-radius:50%;background:var(--red);opacity:.6}
.pp-highlight{background:var(--card);border:1px solid var(--border);border-left:3px solid var(--red);border-radius:0 8px 8px 0;padding:16px 20px;margin:16px 0;font-size:14px;color:var(--text)}
.pp-contact-box{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:28px;margin-top:16px}
.pp-contact-box p{font-size:14px;color:var(--grey);margin-bottom:8px}
.pp-contact-box a{color:var(--red);font-weight:600;font-size:15px;text-decoration:none}
.pp-contact-box a:hover{text-decoration:underline}

/* Footer */
#pp-footer{background:#050509;border-top:1px solid var(--border);padding:28px 48px;display:flex;align-items:center;justify-content:space-between;margin-top:0}
#pp-footer p{font-size:12px;color:var(--muted)}
#pp-footer nav{display:flex;gap:20px}
#pp-footer nav a{font-size:12px;color:var(--muted);text-decoration:none}
#pp-footer nav a:hover{color:#fff}

@media(max-width:800px){
  #pp-header{padding:0 20px}#pp-header nav{display:none}
  .pp-hero,.pp-layout{padding-left:20px;padding-right:20px}
  .pp-layout{grid-template-columns:1fr}
  .pp-toc{display:none}
  #pp-footer{flex-direction:column;gap:12px}
}
</style>
</head>
<body class="tackendo-privacy">

<header id="pp-header">
  <a href="<?php echo $site_url; ?>">
    <img src="<?php echo esc_url($logo_url); ?>" alt="TACKENDO" loading="eager">
  </a>
  <nav>
    <a href="<?php echo $site_url; ?>">Home</a>
    <a href="<?php echo esc_url(home_url('/about')); ?>">About</a>
    <a href="<?php echo esc_url(home_url('/advertise')); ?>">Advertise</a>
    <a href="<?php echo esc_url(home_url('/contact')); ?>">Contact</a>
  </nav>
</header>

<div class="pp-hero">
  <span class="pp-hero-label">Legal</span>
  <h1 class="pp-hero-title">Privacy Policy</h1>
  <p class="pp-hero-updated">Last updated: June 2, 2025 &mdash; TACKENDO / Netradio Network</p>
</div>

<div class="pp-layout">

  <!-- TOC -->
  <aside class="pp-toc">
    <p class="pp-toc-title">Contents</p>
    <ul class="pp-toc-list">
      <li><a href="#s1">1. Information We Collect</a></li>
      <li><a href="#s2">2. Cookies & Tracking</a></li>
      <li><a href="#s3">3. Advertising Partners</a></li>
      <li><a href="#s4">4. Google Advertising</a></li>
      <li><a href="#s5">5. Legal Basis (GDPR)</a></li>
      <li><a href="#s6">6. Your Rights</a></li>
      <li><a href="#s7">7. Data Sharing</a></li>
      <li><a href="#s8">8. Data Security</a></li>
      <li><a href="#s9">9. Children's Privacy</a></li>
      <li><a href="#s10">10. Policy Updates</a></li>
      <li><a href="#s11">11. Contact Us</a></li>
    </ul>
  </aside>

  <!-- Content -->
  <main class="pp-content">

    <div class="pp-section">
      <p>At <strong>TACKENDO</strong> ("we", "our", or "us"), accessible from <a href="https://tackendo.com">tackendo.com</a>, we are committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website or use our free FAST TV streaming service.</p>
      <p>TACKENDO is a free, ad-supported streaming television (FAST) platform. Our service is funded by advertising, which means that some data collection is necessary to deliver relevant ads and measure their effectiveness.</p>
    </div>

    <div class="pp-section" id="s1">
      <span class="pp-section-num">Section 01</span>
      <h2>Information We Collect</h2>
      <h3>a) Automatic Technical Data</h3>
      <p>When you visit TACKENDO, we automatically collect certain technical information, including:</p>
      <ul>
        <li>IP address (used for geolocation and fraud prevention)</li>
        <li>Device identifiers and type</li>
        <li>Browser type and version</li>
        <li>Operating system</li>
        <li>Connected TV platform (Roku, Fire TV, etc.)</li>
      </ul>
      <h3>b) Usage Data</h3>
      <ul>
        <li>Pages visited and content viewed</li>
        <li>Time spent on the site and session duration</li>
        <li>Referring URLs and navigation paths</li>
        <li>Streaming and playback data</li>
      </ul>
      <h3>c) Advertising Identifiers</h3>
      <ul>
        <li>Cookies and similar tracking technologies</li>
        <li>Connected TV advertising IDs (e.g. Roku Advertising ID, Amazon Advertising ID)</li>
        <li>IP-based location data (non-precise)</li>
      </ul>
      <div class="pp-highlight">We do <strong>not</strong> require users to create an account. TACKENDO is fully anonymous — no login, no subscription, no personal registration.</div>
    </div>

    <div class="pp-section" id="s2">
      <span class="pp-section-num">Section 02</span>
      <h2>Cookies &amp; Tracking Technologies</h2>
      <p>We use cookies and similar technologies to:</p>
      <ul>
        <li>Deliver and optimize streaming content</li>
        <li>Measure audience size and engagement</li>
        <li>Serve relevant and contextual advertising</li>
        <li>Prevent fraud and ensure platform security</li>
        <li>Analyze performance and improve user experience</li>
      </ul>
      <p>You can manage or disable cookies through your browser settings at any time. Note that disabling cookies may affect the functionality of some features and the relevance of ads served.</p>
    </div>

    <div class="pp-section" id="s3">
      <span class="pp-section-num">Section 03</span>
      <h2>Advertising &amp; Third-Party Partners</h2>
      <p>TACKENDO is a <strong>FAST / CTV platform fully supported by advertising</strong>. To fund the free service, we work with a curated ecosystem of third-party advertising and technology partners, including:</p>
      <ul>
        <li>Supply-Side Platforms (SSPs): Viously, Sparteo, Bidmatic, Adtelligent, Vidverto, VoiseTech, Robust Apps, Aniview</li>
        <li>Demand-Side Platforms (DSPs) accessing our inventory programmatically</li>
        <li>Ad exchanges and auction platforms</li>
        <li>Measurement, verification and analytics providers</li>
        <li>Our monetization partner: Viznet (<a href="https://viznet.tv" target="_blank" rel="noopener">viznet.tv</a>)</li>
        <li>Our self-serve ad platform: OKFAST (<a href="https://okfast.fr" target="_blank" rel="noopener">okfast.fr</a>)</li>
      </ul>
      <p>These partners may collect and process data independently to deliver personalized or contextual advertising, measure campaign performance, and prevent fraud. Each partner operates under their own privacy policies.</p>
    </div>

    <div class="pp-section" id="s4">
      <span class="pp-section-num">Section 04</span>
      <h2>Google Advertising &amp; Programmatic Demand</h2>
      <p>TACKENDO may use <strong>Google advertising technologies</strong>, including Google Ad Manager and related Google demand sources. Google and its partners may use cookies, device identifiers, or other tracking technologies to serve ads based on:</p>
      <ul>
        <li>Visits to this and other websites</li>
        <li>Device type and usage information</li>
        <li>Geographic location (non-precise)</li>
        <li>Audience segments and interest categories</li>
      </ul>
      <p>You can learn more about Google's data usage and opt-out options at: <a href="https://policies.google.com/privacy" target="_blank" rel="noopener">policies.google.com/privacy</a></p>
    </div>

    <div class="pp-section" id="s5">
      <span class="pp-section-num">Section 05</span>
      <h2>Legal Basis for Processing (GDPR)</h2>
      <p>For users located in the European Economic Area (EEA), we process personal data under the following legal bases:</p>
      <ul>
        <li><strong>Legitimate interest</strong> — for operating the platform, delivering content, and serving advertising that funds the free service</li>
        <li><strong>User consent</strong> — where required by applicable law (e.g. for certain cookies or targeted advertising)</li>
        <li><strong>Legal obligation</strong> — when required to comply with applicable laws or regulations</li>
      </ul>
      <p>Where we rely on consent, you may withdraw it at any time without affecting the lawfulness of processing before withdrawal.</p>
    </div>

    <div class="pp-section" id="s6">
      <span class="pp-section-num">Section 06</span>
      <h2>Your Privacy Rights</h2>
      <p>Depending on your location, you may have the following rights regarding your personal data:</p>
      <ul>
        <li><strong>Right of access</strong> — to know what personal data we hold about you</li>
        <li><strong>Right to rectification</strong> — to correct inaccurate or incomplete data</li>
        <li><strong>Right to erasure</strong> — to request deletion of your personal data</li>
        <li><strong>Right to object</strong> — to processing based on legitimate interest</li>
        <li><strong>Right to portability</strong> — to receive your data in a structured, machine-readable format</li>
        <li><strong>Right to restrict processing</strong> — in certain circumstances</li>
      </ul>
      <h3>California Residents (CCPA / CPRA)</h3>
      <p>California users have additional rights, including the right to know what personal data is collected, to request deletion, and to opt out of the sale or sharing of personal information. We do <strong>not sell personal data directly</strong>. To exercise your rights, contact us at the address below.</p>
    </div>

    <div class="pp-section" id="s7">
      <span class="pp-section-num">Section 07</span>
      <h2>Data Sharing</h2>
      <p>We may share data with the following categories of recipients:</p>
      <ul>
        <li>Advertising and monetization partners (as described in Section 3)</li>
        <li>Analytics and measurement providers</li>
        <li>Legal authorities, when required by law or to protect our rights</li>
        <li>Technology infrastructure providers (hosting, CDN, streaming)</li>
      </ul>
      <div class="pp-highlight">We <strong>do not sell</strong> personal data to third parties. Data shared with advertising partners is used solely for the purpose of delivering and measuring advertising on our platform.</div>
    </div>

    <div class="pp-section" id="s8">
      <span class="pp-section-num">Section 08</span>
      <h2>Data Security</h2>
      <p>We implement reasonable and appropriate technical and organizational measures to protect your information against unauthorized access, accidental loss, alteration, or disclosure. These measures include encrypted connections (HTTPS), access controls, and regular security reviews.</p>
      <p>However, no system is entirely secure. We cannot guarantee absolute security and encourage you to take appropriate precautions when using any online service.</p>
    </div>

    <div class="pp-section" id="s9">
      <span class="pp-section-num">Section 09</span>
      <h2>Children's Privacy</h2>
      <p>TACKENDO is <strong>not intended for children under the age of 13</strong>. We do not knowingly collect personal data from children. If you believe a child has provided personal data to us, please contact us immediately and we will take steps to delete such information.</p>
    </div>

    <div class="pp-section" id="s10">
      <span class="pp-section-num">Section 10</span>
      <h2>Changes to This Policy</h2>
      <p>We may update this Privacy Policy from time to time to reflect changes in our practices, technology, legal requirements, or for other operational reasons. The updated version will be indicated by a revised "Last updated" date at the top of this page.</p>
      <p>We encourage you to review this Policy periodically to stay informed about how we protect your information.</p>
    </div>

    <div class="pp-section" id="s11">
      <span class="pp-section-num">Section 11</span>
      <h2>Contact Us</h2>
      <p>If you have any questions, requests, or concerns about this Privacy Policy or how we handle your personal data, please contact us:</p>
      <div class="pp-contact-box">
        <p><strong>TACKENDO — Netradio Network</strong></p>
        <p>Email: <a href="mailto:contact@tackendo.com">contact@tackendo.com</a></p>
        <p>Website: <a href="https://tackendo.com">tackendo.com</a></p>
        <p style="margin-top:12px;font-size:12px;color:var(--muted)">We aim to respond to all privacy-related inquiries within 30 days.</p>
      </div>
    </div>

  </main>
</div>

<footer id="pp-footer">
  <p>&copy; 2024&ndash;<?php echo date('Y'); ?> TACKENDO &mdash; Netradio Network. All rights reserved.</p>
  <nav>
    <a href="<?php echo $site_url; ?>">Home</a>
    <a href="<?php echo esc_url(home_url('/about')); ?>">About</a>
    <a href="<?php echo esc_url(home_url('/contact')); ?>">Contact</a>
  </nav>
</footer>

<?php wp_footer(); ?>
</body>
</html>
