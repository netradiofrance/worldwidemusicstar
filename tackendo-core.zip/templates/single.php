<?php
/* Template Name: Tackendo Article */
// This file is loaded via template_include for single posts
if ( ! defined( 'ABSPATH' ) ) exit;

require_once TCORE_PATH . 'includes/tcore-channels.php';

$logo_url = 'https://tackendo.com/wp-content/uploads/2025/06/Tackendo-logo-white-on-transparent-262x76-1.png';
$site_url = esc_url( home_url('/') );

the_post();

$post_id   = get_the_ID();
$tag       = get_post_meta($post_id, '_tcore_topic_tag', true) ?: 'FAST TV';
$thumb_url = get_the_post_thumbnail_url($post_id, 'full');
$channels  = array_slice(array_values(tcore_channels()), 0, 6);

// Related articles
$related = get_posts(array(
    'post_type'      => 'post',
    'post_status'    => 'publish',
    'numberposts'    => 4,
    'exclude'        => array($post_id),
    'meta_key'       => '_tcore_generated',
    'meta_value'     => 1,
    'orderby'        => 'rand',
));

$grads = array('Music'=>'#1a0533,#3b0764','CTV Industry'=>'#020617,#1e3a5f','Advertising'=>'#001a0d,#005c28','Platform Guide'=>'#05010d,#1a0860','Channel Spotlight'=>'#200004,#8c0018','Streaming Guide'=>'#020920,#0a2540');
$grad = isset($grads[$tag]) ? $grads[$tag] : '#180824,#080c24';
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php the_title(); ?> &mdash; TACKENDO Magazine</title>
<meta name="description" content="<?php echo esc_attr(wp_trim_words(get_the_excerpt() ?: wp_strip_all_tags(get_the_content()), 25)); ?>">
<meta name="robots" content="index, follow">
<link rel="canonical" href="<?php the_permalink(); ?>">
<meta property="og:title" content="<?php the_title_attribute(); ?>">
<meta property="og:type" content="article">
<meta property="og:url" content="<?php the_permalink(); ?>">
<?php if ($thumb_url) : ?>
<meta property="og:image" content="<?php echo esc_url($thumb_url); ?>">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:image" content="<?php echo esc_url($thumb_url); ?>">
<?php endif; ?>
<meta name="theme-color" content="#E8001C">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Figtree:ital,wght@0,400;0,500;0,600;0,700;1,400&display=swap" rel="stylesheet">
<?php wp_head(); ?>
<style>
:root{--bg:#07070f;--surface:#0d0d18;--card:#111120;--red:#E8001C;--white:#fff;--text:#d8d8e8;--grey:#7a7a90;--muted:#4a4a60;--border:#1c1c2e}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body.tackendo-article{background:var(--bg);color:var(--text);font-family:'Figtree','Segoe UI',sans-serif;font-size:16px;line-height:1.7}
body.tackendo-article a{color:inherit}
/* Hide Astra */
body.tackendo-article .site-header,body.tackendo-article #masthead,body.tackendo-article #ast-fixed-header,body.tackendo-article .site-footer,body.tackendo-article #astra-footer-area{display:none!important}
/* Header */
#art-header{position:sticky;top:0;z-index:200;background:rgba(7,7,15,.92);backdrop-filter:blur(18px);border-bottom:1px solid var(--border);height:64px;padding:0 48px;display:flex;align-items:center;justify-content:space-between}
#art-header .logo img{height:34px;width:auto;display:block}
#art-header nav{display:flex;gap:28px}
#art-header nav a{color:var(--grey);text-decoration:none;font-size:12px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;transition:color .2s}
#art-header nav a:hover{color:#fff}
/* Hero */
.art-hero{position:relative;min-height:420px;overflow:hidden;display:flex;align-items:flex-end}
.art-hero-img{position:absolute;inset:0;background-size:cover;background-position:center}
.art-hero-overlay{position:absolute;inset:0;background:linear-gradient(to top, rgba(7,7,15,1) 0%, rgba(7,7,15,.7) 40%, rgba(7,7,15,.2) 100%)}
.art-hero-content{position:relative;z-index:2;padding:48px 48px 52px;max-width:900px}
.art-tag{display:inline-block;background:rgba(232,0,28,.15);border:1px solid rgba(232,0,28,.4);color:var(--red);font-size:10px;font-weight:900;letter-spacing:.14em;text-transform:uppercase;padding:4px 12px;border-radius:3px;margin-bottom:16px}
.art-title{font-family:'Bebas Neue',sans-serif;font-size:clamp(38px,5.5vw,66px);color:#fff;line-height:.95;letter-spacing:.02em;margin-bottom:20px}
.art-meta{display:flex;align-items:center;gap:16px;font-size:13px;color:var(--grey)}
.art-meta-sep{color:var(--muted)}
/* Layout */
.art-layout{display:grid;grid-template-columns:1fr 300px;gap:52px;max-width:1300px;margin:0 auto;padding:52px 48px}
/* Content */
.art-content{min-width:0}
.art-content p{color:var(--text);font-size:16px;line-height:1.8;margin-bottom:1.5rem}
.art-content h1,.art-content h2,.art-content h3{color:#fff;font-family:'Bebas Neue',sans-serif;letter-spacing:.03em;margin:2rem 0 1rem;line-height:1.1}
.art-content h2{font-size:30px}
.art-content h3{font-size:22px}
.art-content strong{color:#fff;font-weight:700}
.art-content em{color:var(--grey);font-style:italic}
.art-content ul,.art-content ol{color:var(--text);padding-left:1.5rem;margin-bottom:1.5rem}
.art-content li{margin-bottom:.5rem;line-height:1.7}
.art-content blockquote{border-left:3px solid var(--red);padding:16px 20px;margin:1.5rem 0;background:rgba(232,0,28,.05);border-radius:0 8px 8px 0}
.art-content blockquote p{color:var(--grey);font-style:italic;margin:0}
.art-content a{color:var(--red);text-decoration:underline}
.art-content a:hover{color:#fff}
/* Author bar */
.art-author{display:flex;align-items:center;gap:14px;padding:24px;background:var(--card);border:1px solid var(--border);border-radius:12px;margin-top:40px}
.art-author-avatar{width:48px;height:48px;border-radius:50%;background:var(--red);display:flex;align-items:center;justify-content:center;font-family:'Bebas Neue',sans-serif;font-size:20px;color:#fff;flex-shrink:0}
.art-author-name{font-size:13px;font-weight:700;color:#fff;margin-bottom:2px}
.art-author-bio{font-size:12px;color:var(--muted)}
/* Related */
.art-related{margin-top:48px}
.art-related h3{font-family:'Bebas Neue',sans-serif;font-size:24px;letter-spacing:.04em;color:#fff;margin-bottom:20px}
.art-related-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:16px}
.rel-card{background:var(--card);border:1px solid var(--border);border-radius:10px;overflow:hidden;text-decoration:none;display:block;transition:all .2s}
.rel-card:hover{transform:translateY(-3px);border-color:rgba(232,0,28,.35)}
.rel-card-img{aspect-ratio:16/9;overflow:hidden;position:relative}
.rel-card-img img{width:100%;height:100%;object-fit:cover;display:block}
.rel-card-body{padding:12px}
.rel-tag{font-size:9px;font-weight:900;letter-spacing:.14em;text-transform:uppercase;color:var(--red);margin-bottom:4px}
.rel-title{font-size:13px;font-weight:700;color:#fff;line-height:1.3}
/* Sidebar */
.art-sidebar{display:flex;flex-direction:column;gap:20px}
.sb-widget{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:20px}
.sb-title{font-family:'Bebas Neue',sans-serif;font-size:20px;color:#fff;margin-bottom:14px;padding-bottom:12px;border-bottom:1px solid var(--border);letter-spacing:.04em}
.sb-ch{display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid rgba(255,255,255,.04);text-decoration:none;color:var(--text);transition:color .18s}
.sb-ch:last-child{border-bottom:none}
.sb-ch:hover{color:#fff}
.sb-ch img{width:36px;height:36px;border-radius:7px;object-fit:cover;flex-shrink:0}
.sb-ch-name{font-size:12px;font-weight:700;color:#fff}
.sb-ch-cat{font-size:10px;color:var(--muted)}
.sb-cta{background:linear-gradient(135deg,rgba(232,0,28,.14),rgba(232,0,28,.05));border:1px solid rgba(232,0,28,.28);border-radius:12px;padding:24px;text-align:center}
.sb-cta-t{font-family:'Bebas Neue',sans-serif;font-size:22px;color:#fff;margin-bottom:8px}
.sb-cta-p{font-size:12px;color:var(--grey);margin-bottom:16px;line-height:1.65}
.btn-red{display:flex;align-items:center;justify-content:center;background:var(--red);color:#fff;font-weight:700;font-size:13px;padding:12px 20px;border-radius:8px;text-decoration:none;margin-bottom:8px;transition:all .2s}
.btn-red:hover{background:#c8001a;color:#fff}
.btn-ghost{display:flex;align-items:center;justify-content:center;color:var(--text);font-size:13px;padding:12px 20px;border-radius:8px;border:1px solid var(--border);text-decoration:none}
/* Nav */
.art-nav{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:40px;padding-top:32px;border-top:1px solid var(--border)}
.art-nav-link{padding:16px;background:var(--card);border:1px solid var(--border);border-radius:10px;text-decoration:none;color:var(--text);transition:all .2s}
.art-nav-link:hover{border-color:rgba(232,0,28,.35);color:#fff}
.art-nav-label{font-size:10px;font-weight:800;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);margin-bottom:6px}
.art-nav-title{font-size:13px;font-weight:700;color:#fff;line-height:1.35}
.art-nav-link.next{text-align:right}
/* Footer */
#art-footer{background:#050509;border-top:1px solid var(--border);padding:28px 48px;display:flex;align-items:center;justify-content:space-between}
#art-footer .footer-copy{font-size:12px;color:var(--muted)}
#art-footer .footer-links{display:flex;gap:20px}
#art-footer .footer-links a{font-size:12px;color:var(--muted);text-decoration:none}
#art-footer .footer-links a:hover{color:#fff}
@media(max-width:1000px){.art-layout{grid-template-columns:1fr}.art-sidebar{display:none}}
@media(max-width:700px){#art-header{padding:0 20px}#art-header nav{display:none}.art-hero-content,.art-layout{padding-left:20px;padding-right:20px}.art-related-grid{grid-template-columns:1fr}.art-nav{grid-template-columns:1fr}}
</style>
</head>
<body class="tackendo-article">

<header id="art-header">
  <a href="<?php echo $site_url; ?>" class="logo">
    <img src="<?php echo esc_url($logo_url); ?>" alt="TACKENDO" loading="eager">
  </a>
  <nav>
    <a href="<?php echo $site_url; ?>">Home</a>
    <a href="<?php echo esc_url(home_url('/blog')); ?>" style="color:#fff">Magazine</a>
    <a href="<?php echo $site_url; ?>#channels">Channels</a>
  </nav>
</header>

<!-- ARTICLE HERO with featured image -->
<div class="art-hero">
  <?php if ($thumb_url) : ?>
  <div class="art-hero-img" style="background-image:url('<?php echo esc_url($thumb_url); ?>')"></div>
  <?php else : ?>
  <div class="art-hero-img" style="background:linear-gradient(135deg,<?php echo $grad; ?>)"></div>
  <?php endif; ?>
  <div class="art-hero-overlay"></div>
  <div class="art-hero-content">
    <span class="art-tag"><?php echo esc_html($tag); ?></span>
    <h1 class="art-title"><?php the_title(); ?></h1>
    <div class="art-meta">
      <span><?php echo get_the_date('F j, Y'); ?></span>
      <span class="art-meta-sep">&bull;</span>
      <span><?php echo ceil(str_word_count(wp_strip_all_tags(get_the_content())) / 200); ?> min read</span>
    </div>
  </div>
</div>

<!-- ARTICLE LAYOUT -->
<div class="art-layout">

  <main class="art-content">
    <?php the_content(); ?>

    <!-- Author bar -->
    <div class="art-author">
      <div class="art-author-avatar">T</div>
      <div>
        <p class="art-author-name">TACKENDO Magazine</p>
        <p class="art-author-bio">News and insights on FAST TV, CTV advertising, music streaming and connected television.</p>
      </div>
    </div>

    <!-- Prev / Next navigation -->
    <?php
    $prev = get_previous_post();
    $next = get_next_post();
    if ($prev || $next) :
    ?>
    <div class="art-nav">
      <?php if ($prev) : ?>
      <a href="<?php echo get_permalink($prev->ID); ?>" class="art-nav-link prev">
        <p class="art-nav-label">&larr; Previous</p>
        <p class="art-nav-title"><?php echo esc_html(get_the_title($prev->ID)); ?></p>
      </a>
      <?php else : ?><div></div><?php endif; ?>
      <?php if ($next) : ?>
      <a href="<?php echo get_permalink($next->ID); ?>" class="art-nav-link next">
        <p class="art-nav-label">Next &rarr;</p>
        <p class="art-nav-title"><?php echo esc_html(get_the_title($next->ID)); ?></p>
      </a>
      <?php endif; ?>
    </div>
    <?php endif; ?>

    <!-- Related articles -->
    <?php if (!empty($related)) : ?>
    <div class="art-related">
      <h3>More from the Magazine</h3>
      <div class="art-related-grid">
        <?php foreach ($related as $rp) :
          $rthumb = get_the_post_thumbnail_url($rp->ID, 'medium');
          $rtag   = get_post_meta($rp->ID, '_tcore_topic_tag', true) ?: 'FAST TV';
          $rgrad  = isset($grads[$rtag]) ? $grads[$rtag] : '#180824,#080c24';
        ?>
        <a href="<?php echo get_permalink($rp->ID); ?>" class="rel-card">
          <div class="rel-card-img">
            <?php if ($rthumb) : ?>
              <img src="<?php echo esc_url($rthumb); ?>" alt="<?php echo esc_attr(get_the_title($rp->ID)); ?>" loading="lazy">
            <?php else : ?>
              <div style="width:100%;height:100%;background:linear-gradient(135deg,<?php echo $rgrad; ?>);min-height:120px"></div>
            <?php endif; ?>
          </div>
          <div class="rel-card-body">
            <p class="rel-tag"><?php echo esc_html($rtag); ?></p>
            <h4 class="rel-title"><?php echo esc_html(get_the_title($rp->ID)); ?></h4>
          </div>
        </a>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>
  </main>

  <!-- Sidebar -->
  <aside class="art-sidebar">
    <div class="sb-widget">
      <h3 class="sb-title">Our Channels</h3>
      <?php foreach ($channels as $ch_slug => $ch) :
        $all_channels = tcore_channels();
        $real_slug = array_search($ch, $all_channels);
      ?>
      <a href="<?php echo esc_url(home_url('/' . ($real_slug ?: 'channels') . '/')); ?>" class="sb-ch">
        <img src="<?php echo esc_url($ch['logo']); ?>" alt="<?php echo esc_attr($ch['name']); ?>" loading="lazy">
        <div><p class="sb-ch-name"><?php echo esc_html($ch['name']); ?></p><p class="sb-ch-cat"><?php echo esc_html($ch['cat']); ?></p></div>
      </a>
      <?php endforeach; ?>
    </div>

    <div class="sb-cta">
      <h3 class="sb-cta-t">Watch on Your TV</h3>
      <p class="sb-cta-p">Free, no subscription, no login required.</p>
      <a href="https://channelstore.roku.com/details/8244e521d238b28c45271329a3ebe907/tackendo" class="btn-red" target="_blank" rel="noopener">Add to Roku</a>
      <a href="https://www.amazon.com/gp/product/B0DGNFS8N9" class="btn-ghost" target="_blank" rel="noopener">Fire TV</a>
    </div>
  </aside>

</div>

<footer id="art-footer">
  <p class="footer-copy">&copy; 2024&ndash;<?php echo date('Y'); ?> TACKENDO &mdash; Netradio Network. All rights reserved.</p>
  <div class="footer-links">
    <a href="<?php echo esc_url(home_url('/privacy-policy')); ?>">Privacy Policy</a>
    <a href="<?php echo esc_url(home_url('/contact')); ?>">Contact</a>
    <a href="<?php echo $site_url; ?>">Home</a>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
