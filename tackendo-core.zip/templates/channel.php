<?php
/* Template Name: Tackendo Channel */
if ( ! defined( 'ABSPATH' ) ) exit;

require_once TCORE_PATH . 'includes/tcore-channels.php';

$logo_url = 'https://tackendo.com/wp-content/uploads/2025/06/Tackendo-logo-white-on-transparent-262x76-1.png';
$site_url = esc_url( home_url('/') );

// Get current channel from page slug
$slug    = get_post_field('post_name', get_the_ID());
$channel = tcore_get_channel($slug);

// Related articles
$related = get_posts(array(
    'post_type'      => 'post',
    'post_status'    => 'publish',
    'numberposts'    => 4,
    'meta_query'     => array(array('key' => '_tcore_generated', 'value' => 1)),
    'orderby'        => 'rand',
));

// Other channels for discovery
$all_channels = tcore_channels();
$other_channels = array_filter($all_channels, function($k) use ($slug) { return $k !== $slug; }, ARRAY_FILTER_USE_KEY);
$other_channels = array_slice($other_channels, 0, 8);
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php if ($channel) : ?>
<title><?php echo esc_html($channel['name']); ?> &mdash; Free FAST TV Channel on TACKENDO</title>
<meta name="description" content="<?php echo esc_attr($channel['desc']); ?> Available free on Roku, Fire TV, and web.">
<?php else : ?>
<title><?php the_title(); ?> &mdash; TACKENDO</title>
<?php endif; ?>
<meta name="robots" content="index, follow">
<link rel="canonical" href="<?php the_permalink(); ?>">
<?php if ($channel) : ?>
<meta property="og:title" content="<?php echo esc_attr($channel['name']); ?> — Free on TACKENDO">
<meta property="og:description" content="<?php echo esc_attr($channel['desc']); ?>">
<meta property="og:image" content="<?php echo esc_url($channel['logo']); ?>">
<meta property="og:type" content="website">
<?php endif; ?>
<meta name="theme-color" content="#E8001C">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Figtree:wght@400;500;600;700&display=swap" rel="stylesheet">
<?php wp_head(); ?>
<style>
:root{--bg:#07070f;--surface:#0d0d18;--card:#111120;--red:#E8001C;--white:#fff;--text:#d8d8e8;--grey:#7a7a90;--muted:#4a4a60;--border:#1c1c2e}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body.tackendo-channel{background:var(--bg);color:var(--text);font-family:'Figtree','Segoe UI',sans-serif;font-size:15px;line-height:1.6}
body.tackendo-channel h1,body.tackendo-channel h2,body.tackendo-channel h3{color:#fff!important;font-weight:400!important}
body.tackendo-channel a{text-decoration:none;color:inherit}
/* Hide Astra */
body.tackendo-channel .site-header,body.tackendo-channel #masthead,body.tackendo-channel #ast-fixed-header,body.tackendo-channel .site-footer,body.tackendo-channel #astra-footer-area{display:none!important}
/* Header */
#ch-header{position:sticky;top:0;z-index:200;background:rgba(7,7,15,.92);backdrop-filter:blur(18px);border-bottom:1px solid var(--border);height:64px;padding:0 48px;display:flex;align-items:center;justify-content:space-between}
#ch-header .logo img{height:34px;display:block}
#ch-header nav{display:flex;gap:28px}
#ch-header nav a{color:var(--grey);font-size:12px;font-weight:700;letter-spacing:.08em;text-transform:uppercase}
#ch-header nav a:hover{color:#fff}
.hdr-btns{display:flex;gap:8px}
.btn-sm{padding:7px 14px;border-radius:6px;font-size:11px;font-weight:700;border:1px solid var(--border);background:var(--surface);color:var(--text);transition:all .2s}
.btn-sm:hover{background:var(--red);border-color:var(--red);color:#fff}
/* Channel hero */
.ch-hero{position:relative;overflow:hidden;padding:0}
.ch-hero-bg{position:absolute;inset:0;background:linear-gradient(160deg,#090912 0%,#0c0818 100%);z-index:0}
.ch-hero-inner{position:relative;z-index:1;display:grid;grid-template-columns:1fr 1fr;min-height:340px}
.ch-hero-left{padding:52px 40px 52px 48px;display:flex;flex-direction:column;justify-content:center;align-items:flex-start}
.ch-cat-badge{display:inline-block;align-self:flex-start;background:rgba(232,0,28,.15);border:1px solid rgba(232,0,28,.4);color:var(--red);font-size:10px;font-weight:800;letter-spacing:.14em;text-transform:uppercase;padding:4px 12px;border-radius:3px;margin-bottom:16px}
.ch-title{font-family:'Bebas Neue',sans-serif;font-size:clamp(44px,5.5vw,72px);color:#fff!important;line-height:.92;margin-bottom:16px;letter-spacing:.02em}
.ch-desc{font-size:15px;color:var(--grey);max-width:480px;margin-bottom:28px;line-height:1.75}
.ch-actions{display:flex;gap:12px;flex-wrap:wrap}
.btn-watch{display:inline-flex;align-items:center;gap:8px;background:var(--red);color:#fff!important;font-weight:700;font-size:14px;padding:13px 28px;border-radius:8px;transition:all .2s;letter-spacing:.03em}
.btn-watch:hover{background:#c8001a;transform:translateY(-2px)}
.btn-outline{display:inline-flex;align-items:center;gap:8px;color:var(--text)!important;font-size:14px;font-weight:600;padding:12px 20px;border-radius:8px;border:1px solid var(--border);transition:all .2s}
.btn-outline:hover{border-color:var(--grey);color:#fff!important}
/* Channel logo */
.ch-hero-right{display:flex;align-items:center;justify-content:center;padding:40px}
.ch-logo-wrap{width:250px;height:250px;border-radius:20px;overflow:hidden;box-shadow:0 0 0 1px rgba(232,0,28,.3),0 0 60px rgba(232,0,28,.15),0 40px 80px rgba(0,0,0,.6);animation:chfloat 7s ease-in-out infinite}
.ch-logo-wrap img{width:100%;height:100%;object-fit:cover;display:block}
@keyframes chfloat{0%,100%{transform:translateY(0) rotate(-1deg)}50%{transform:translateY(-10px) rotate(1deg)}}
/* EPG Now */
.epg-now-section{background:var(--surface);border-bottom:1px solid var(--border);padding:28px 48px}
.epg-now-inner{display:grid;grid-template-columns:auto 1fr auto;align-items:center;gap:24px;max-width:1000px}
.epg-now-badge{display:inline-flex;align-items:center;gap:6px;background:var(--red);color:#fff;font-size:10px;font-weight:800;letter-spacing:.14em;padding:4px 10px;border-radius:3px;text-transform:uppercase;white-space:nowrap}
.live-dot{display:inline-block;width:7px;height:7px;background:#fff;border-radius:50%;animation:blink 1.6s ease-in-out infinite}
@keyframes blink{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.4;transform:scale(.7)}}
.epg-now-content{display:flex;align-items:center;gap:16px}
.epg-now-thumb{width:80px;height:50px;border-radius:6px;object-fit:cover;background:var(--card);flex-shrink:0}
.epg-now-title{font-size:16px;font-weight:700;color:#fff;margin-bottom:2px}
.epg-now-time{font-size:12px;color:var(--grey)}
.epg-next{font-size:12px;color:var(--muted);text-align:right}
.epg-next strong{color:var(--grey);display:block}
/* Schedule strip */
.schedule-section{padding:36px 48px;border-bottom:1px solid var(--border)}
.schedule-section h2{font-family:'Bebas Neue',sans-serif;font-size:26px;color:#fff!important;letter-spacing:.04em;margin-bottom:20px}
.schedule-list{display:flex;flex-direction:column;gap:0}
.schedule-item{display:grid;grid-template-columns:90px auto 1fr;align-items:center;gap:16px;padding:12px 0;border-bottom:1px solid rgba(255,255,255,.04)}
.schedule-item:last-child{border-bottom:none}
.schedule-item.is-current{background:rgba(232,0,28,.06);border-radius:8px;padding:12px 12px;margin:0 -12px}
.sch-time{font-size:13px;font-weight:700;color:var(--grey);font-family:'Figtree',monospace}
.sch-live-badge{display:inline-flex;align-items:center;gap:4px;background:var(--red);color:#fff;font-size:9px;font-weight:800;padding:2px 7px;border-radius:2px;letter-spacing:.08em;text-transform:uppercase}
.sch-live-dot{width:5px;height:5px;background:#fff;border-radius:50%;animation:blink 1.6s infinite}
.sch-title{font-size:14px;font-weight:600;color:var(--text)}
.schedule-item.is-current .sch-title{color:#fff}
/* Player section */
.player-section{padding:36px 48px;border-bottom:1px solid var(--border);background:var(--surface)}.player-wrapper{max-width:100%;aspect-ratio:16/9}
.player-section h2{font-family:'Bebas Neue',sans-serif;font-size:26px;color:#fff!important;letter-spacing:.04em;margin-bottom:20px}
.player-wrapper{border-radius:12px;overflow:hidden;background:#000}
.player-wrapper iframe,.player-wrapper video{display:block}
/* Related articles */
.related-section{padding:36px 48px;border-bottom:1px solid var(--border)}
.related-section h2{font-family:'Bebas Neue',sans-serif;font-size:26px;color:#fff!important;letter-spacing:.04em;margin-bottom:20px}
.related-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:16px}
.rel-card{background:var(--card);border:1px solid var(--border);border-radius:10px;overflow:hidden;transition:all .2s}
.rel-card:hover{transform:translateY(-3px);border-color:rgba(232,0,28,.35)}
.rel-card-img{aspect-ratio:16/9;overflow:hidden}
.rel-card-img img{width:100%;height:100%;object-fit:cover;display:block}
.rel-card-body{padding:12px}
.rel-tag{font-size:8px;font-weight:900;letter-spacing:.14em;text-transform:uppercase;color:var(--red);margin-bottom:4px}
.rel-title{font-size:13px;font-weight:700;color:#fff!important;line-height:1.3}
/* Other channels */
.other-section{padding:36px 48px}
.other-section h2{font-family:'Bebas Neue',sans-serif;font-size:26px;color:#fff!important;letter-spacing:.04em;margin-bottom:20px}
.other-grid{display:grid;grid-template-columns:repeat(8,1fr);gap:12px}
.other-card{display:flex;flex-direction:column;align-items:center;text-align:center;gap:8px;text-decoration:none;transition:transform .2s}
.other-card:hover{transform:translateY(-4px)}
.other-logo{width:72px;height:72px;border-radius:12px;object-fit:cover;background:var(--card);border:1px solid var(--border)}
.other-name{font-size:10px;font-weight:700;color:var(--grey);line-height:1.2}
.other-card:hover .other-name{color:#fff}
/* Footer */
#ch-footer{background:#050509;border-top:1px solid var(--border);padding:28px 48px;display:flex;align-items:center;justify-content:space-between}
#ch-footer .footer-copy{font-size:12px;color:var(--muted)}
#ch-footer .footer-links{display:flex;gap:20px}
#ch-footer .footer-links a{font-size:12px;color:var(--muted);text-decoration:none}
#ch-footer .footer-links a:hover{color:#fff}
/* Skeleton */
.skel{background:linear-gradient(90deg,var(--card) 25%,#181828 50%,var(--card) 75%);background-size:200%;animation:sk 1.4s infinite;border-radius:4px;display:inline-block}
@keyframes sk{0%{background-position:200% 0}100%{background-position:-200% 0}}
/* Responsive */
@media(max-width:900px){#ch-header{padding:0 20px}#ch-header nav{display:none}.ch-hero-inner{grid-template-columns:1fr}.ch-hero-right{display:none}.epg-now-section,.schedule-section,.player-section,.related-section,.other-section{padding-left:20px;padding-right:20px}.related-grid{grid-template-columns:repeat(2,1fr)}.other-grid{grid-template-columns:repeat(4,1fr)}}
@media(max-width:600px){.related-grid{grid-template-columns:1fr}.other-grid{grid-template-columns:repeat(3,1fr)}.epg-now-inner{grid-template-columns:auto 1fr}}
</style>
</head>
<body class="tackendo-channel">

<!-- HEADER -->
<header id="ch-header">
  <a href="<?php echo $site_url; ?>" class="logo">
    <img src="<?php echo esc_url($logo_url); ?>" alt="TACKENDO" loading="eager" style="height:36px;width:auto">
  </a>
  <nav>
    <a href="<?php echo $site_url; ?>">Home</a>
    <a href="<?php echo esc_url(home_url('/blog')); ?>">Magazine</a>
    <a href="<?php echo $site_url; ?>#channels">Channels</a>
    <a href="<?php echo esc_url(home_url('/about')); ?>">About</a>
  </nav>
  <div class="hdr-btns">
    <a href="https://channelstore.roku.com/details/8244e521d238b28c45271329a3ebe907/tackendo" class="btn-sm" target="_blank" rel="noopener">Roku</a>
    <a href="https://www.amazon.com/gp/product/B0DGNFS8N9" class="btn-sm" target="_blank" rel="noopener">Fire TV</a>
  </div>
</header>

<!-- CHANNEL HERO -->
<?php if ($channel) : ?>
<section class="ch-hero">
  <div class="ch-hero-bg"></div>
  <div class="ch-hero-inner">
    <div class="ch-hero-left">
      <span class="ch-cat-badge"><?php echo esc_html($channel['cat']); ?></span>
      <h1 class="ch-title"><?php echo esc_html($channel['name']); ?></h1>
      <p class="ch-desc"><?php echo esc_html($channel['desc']); ?></p>
      <div class="ch-actions">
        <a href="#watch-live" class="btn-watch" onclick="document.getElementById('watch-live').scrollIntoView({behavior:'smooth'});return false;">&#x25BC; Watch Now</a>
        <a href="<?php echo $site_url; ?>#channels" class="btn-outline">All Channels &rarr;</a>
      </div>
    </div>
    <div class="ch-hero-right">
      <div class="ch-logo-wrap">
        <img src="<?php echo esc_url($channel['logo']); ?>" alt="<?php echo esc_attr($channel['name']); ?>" width="250" height="250" loading="eager">
      </div>
    </div>
  </div>
</section>

<!-- EPG NOW PLAYING -->
<section class="epg-now-section">
  <div class="epg-now-inner">
    <span class="epg-now-badge"><span class="live-dot"></span>On Air Now</span>
    <div class="epg-now-content">
      <img id="epg-thumb" class="epg-now-thumb" src="" alt="" style="display:none">
      <div>
        <p class="epg-now-title" id="epg-title"><span class="skel" style="width:180px;height:16px">&nbsp;</span></p>
        <p class="epg-now-time" id="epg-time"><span class="skel" style="width:100px;height:12px;margin-top:4px">&nbsp;</span></p>
      </div>
    </div>
    <div class="epg-next" id="epg-next">&nbsp;</div>
  </div>
</section>

<!-- TACKENDO PLAYER (replaces Radiant Media Player) -->
<section class="player-section" id="watch-live">
  <h2>Watch Live</h2>
  <div class="player-wrapper" style="border-radius:12px;overflow:hidden;background:#000;line-height:0;width:100%">
    <?php echo tcore_player_html( $slug ); ?>
  </div>
  <?php if ( has_blocks( get_the_content() ) || trim(get_the_content()) ) : ?>
  <!-- Legacy Radiant embed (shown only if page still has it) -->
  <div style="display:none"><?php the_content(); ?></div>
  <?php endif; ?>
</section>

<!-- SCHEDULE -->
<section class="schedule-section">
  <h2>Up Next</h2>
  <div class="schedule-list" id="schedule-list">
    <?php for ($i = 0; $i < 6; $i++) : ?>
    <div class="schedule-item"><span class="skel" style="width:70px;height:14px">&nbsp;</span><span></span><span class="skel" style="width:200px;height:14px">&nbsp;</span></div>
    <?php endfor; ?>
  </div>
</section>

<?php else : ?>
<!-- Fallback: just show page content -->
<section style="padding:60px 48px">
  <h1><?php the_title(); ?></h1>
  <div><?php the_content(); ?></div>
</section>
<?php endif; ?>

<!-- RELATED ARTICLES -->
<?php if (!empty($related)) : ?>
<section class="related-section">
  <h2>From the Magazine</h2>
  <div class="related-grid">
    <?php foreach ($related as $rpost) :
      $rthumb = get_the_post_thumbnail_url($rpost->ID, 'medium');
      $rtag   = get_post_meta($rpost->ID, '_tcore_topic_tag', true) ?: 'FAST TV';
    ?>
    <a href="<?php echo get_permalink($rpost->ID); ?>" class="rel-card">
      <?php if ($rthumb) : ?>
      <div class="rel-card-img"><img src="<?php echo esc_url($rthumb); ?>" alt="<?php echo esc_attr(get_the_title($rpost->ID)); ?>" loading="lazy"></div>
      <?php else : ?>
      <div class="rel-card-img" style="background:linear-gradient(135deg,#180824,#080c24);display:flex;align-items:center;justify-content:center"><span style="font-size:11px;color:rgba(255,255,255,.2)"><?php echo esc_html($rtag); ?></span></div>
      <?php endif; ?>
      <div class="rel-card-body">
        <p class="rel-tag"><?php echo esc_html($rtag); ?></p>
        <h3 class="rel-title"><?php echo esc_html(get_the_title($rpost->ID)); ?></h3>
      </div>
    </a>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<!-- OTHER CHANNELS -->
<?php if (!empty($other_channels)) : ?>
<section class="other-section">
  <h2>Explore More Channels</h2>
  <div class="other-grid">
    <?php foreach ($other_channels as $ch_slug => $och) : ?>
    <a href="<?php echo esc_url(home_url('/' . $ch_slug . '/')); ?>" class="other-card">
      <img class="other-logo" src="<?php echo esc_url($och['logo']); ?>" alt="<?php echo esc_attr($och['name']); ?>" loading="lazy">
      <span class="other-name"><?php echo esc_html($och['name']); ?></span>
    </a>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<footer id="ch-footer">
  <p class="footer-copy">&copy; 2024&ndash;<?php echo date('Y'); ?> TACKENDO &mdash; Netradio Network. All rights reserved.</p>
  <div class="footer-links">
    <a href="<?php echo esc_url(home_url('/privacy-policy')); ?>">Privacy Policy</a>
    <a href="<?php echo esc_url(home_url('/contact')); ?>">Contact</a>
    <a href="<?php echo $site_url; ?>">Home</a>
  </div>
</footer>

<?php if ($channel) : ?>
<?php
$ch_epg_admin  = get_option( 'tcore_ch_epg_' . sanitize_key($slug), '' );
$ch_epg_direct = $ch_epg_admin ?: ( $channel['epg_url'] ?? '' );
$ch_proxy_url  = rest_url( 'tcore/v1/epg/' . $slug );
?>
<script>
(function() {
  var EPG_DIRECT = <?php echo wp_json_encode($ch_epg_direct); ?>;
  var EPG_PROXY  = <?php echo wp_json_encode($ch_proxy_url); ?>;

  async function loadChannelEPG() {
    if (!EPG_DIRECT) { console.warn('[EPG] No EPG URL for this channel'); return; }
    var data = null;
    try {
      var r = await fetch(EPG_DIRECT, {cache:'no-store'});
      if (r.ok) data = await r.json();
    } catch(e) { console.warn('[EPG] fetch failed:', e.message); }
    if (!data || !data.programs || !data.programs.length) { console.warn('[EPG] no programs'); return; }

    var progs = data.programs || [];
    var now = Date.now();
    var current = null, upcoming = [];

    for (var i = 0; i < progs.length; i++) {
      var p = progs[i];
      var start = new Date(p.start).getTime();
      var stop  = new Date(p.stop).getTime();
      if (start <= now && stop > now) { current = p; }
      else if (start > now) { upcoming.push(p); }
    }

    if (current) {
      var $title = document.getElementById('epg-title');
      var $time  = document.getElementById('epg-time');
      var $next  = document.getElementById('epg-next');
      var $thumb = document.getElementById('epg-thumb');
      if ($title) $title.textContent = current.title || '';
      var s = new Date(current.start), e = new Date(current.stop);
      var fmt = function(d){ return d.toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit',hour12:false}); };
      if ($time) $time.textContent = fmt(s) + ' – ' + fmt(e);
      if ($thumb && current.icon) { $thumb.src = current.icon; $thumb.style.display='block'; }
      if ($next && upcoming[0]) {
        var ns = new Date(upcoming[0].start);
        $next.innerHTML = '<strong>Up next</strong>' + (upcoming[0].title||'') + '<br>' + fmt(ns);
      }
    }

    var $sched = document.getElementById('schedule-list');
    if ($sched && upcoming.length) {
      $sched.innerHTML = '';
      upcoming.slice(0,8).forEach(function(p){
        var t = new Date(p.start).toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit',hour12:false});
        $sched.innerHTML += '<div class="schedule-item"><span class="sch-time">'+t+'</span><span></span><span class="sch-title">'+(p.title||'—')+'</span></div>';
      });
    }
  }

  // Init
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', loadChannelEPG);
  } else {
    loadChannelEPG();
  }
  // Refresh every 5 min
  setInterval(loadChannelEPG, 5 * 60 * 1000);
})();
</script>
<?php endif; ?>

<?php wp_footer(); ?>
</body>
</html>
