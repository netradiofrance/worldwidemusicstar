<?php
/* Template Name: Tackendo Advertise */
if ( ! defined( 'ABSPATH' ) ) exit;

$logo_url = 'https://tackendo.com/wp-content/uploads/2025/06/Tackendo-logo-white-on-transparent-262x76-1.png';
$site_url = esc_url( home_url('/') );
$L        = TCORE_URL . 'assets/logos/';
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Advertise on TACKENDO &mdash; FAST TV Programmatic Advertising</title>
<meta name="description" content="Reach millions of Connected TV viewers with targeted programmatic advertising on TACKENDO FAST channels. Premium CTV inventory, brand-safe environments, SSP-powered.">
<meta name="robots" content="index, follow">
<link rel="canonical" href="<?php echo esc_url(home_url('/advertise')); ?>">
<meta property="og:title" content="Advertise on TACKENDO — CTV & FAST TV Advertising">
<meta property="og:type" content="website">
<meta name="theme-color" content="#E8001C">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Figtree:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&display=swap" rel="stylesheet">
<?php wp_head(); ?>
<style>
:root{--bg:#07070f;--surface:#0d0d18;--card:#111120;--red:#E8001C;--white:#fff;--text:#d8d8e8;--grey:#7a7a90;--muted:#4a4a60;--border:#1c1c2e}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body.tackendo-advertise{background:var(--bg);color:var(--text);font-family:'Figtree','Segoe UI',sans-serif;font-size:16px;line-height:1.7}
body.tackendo-advertise h1,body.tackendo-advertise h2,body.tackendo-advertise h3{color:#fff!important;font-weight:400!important}
body.tackendo-advertise a{text-decoration:none;color:inherit}
body.tackendo-advertise .site-header,body.tackendo-advertise #masthead,body.tackendo-advertise #ast-fixed-header,body.tackendo-advertise .site-footer,body.tackendo-advertise #astra-footer-area{display:none!important}

/* Header */
#adv-header{position:sticky;top:0;z-index:200;background:rgba(7,7,15,.94);backdrop-filter:blur(18px);border-bottom:1px solid var(--border);height:64px;padding:0 48px;display:flex;align-items:center;justify-content:space-between}
#adv-header img{height:34px;width:auto;display:block}
#adv-header nav{display:flex;gap:28px}
#adv-header nav a{color:var(--grey);font-size:12px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;transition:color .2s}
#adv-header nav a:hover{color:#fff}
.hdr-cta{display:inline-flex;align-items:center;background:var(--red);color:#fff!important;font-size:12px;font-weight:700;padding:8px 18px;border-radius:6px;letter-spacing:.06em;text-transform:uppercase;transition:background .2s}
.hdr-cta:hover{background:#c8001a}

/* Hero */
.adv-hero{position:relative;overflow:hidden;min-height:560px;display:flex;align-items:center}
.adv-hero-bg{position:absolute;inset:0;background:
  radial-gradient(ellipse 70% 80% at 20% 50%,rgba(232,0,28,.15) 0%,transparent 60%),
  radial-gradient(ellipse 50% 60% at 80% 30%,rgba(80,0,200,.1) 0%,transparent 60%),
  linear-gradient(160deg,#08090f 0%,#0b0718 100%)}
.adv-hero-inner{position:relative;z-index:1;padding:80px 48px;max-width:760px}
.adv-hero-badge{display:inline-flex;align-items:center;gap:8px;background:rgba(232,0,28,.12);border:1px solid rgba(232,0,28,.35);color:var(--red);font-size:10px;font-weight:900;letter-spacing:.2em;text-transform:uppercase;padding:5px 14px;border-radius:3px;margin-bottom:28px}
.adv-hero-title{font-family:'Bebas Neue',sans-serif;font-size:clamp(52px,6.5vw,92px);color:#fff!important;line-height:.9;letter-spacing:.03em;margin-bottom:24px}
.adv-hero-title em{color:var(--red);font-style:normal}
.adv-hero-sub{font-size:18px;color:var(--grey);line-height:1.75;max-width:580px;margin-bottom:36px}
.adv-hero-btns{display:flex;gap:14px;flex-wrap:wrap}
.btn-red{display:inline-flex;align-items:center;gap:8px;background:var(--red);color:#fff!important;font-weight:700;font-size:15px;padding:14px 30px;border-radius:8px;transition:all .2s;box-shadow:0 0 32px rgba(232,0,28,.3)}
.btn-red:hover{background:#c8001a;transform:translateY(-2px)}
.btn-ghost{display:inline-flex;align-items:center;gap:8px;color:var(--text)!important;font-size:15px;font-weight:600;padding:14px 24px;border-radius:8px;border:1px solid var(--border);transition:all .2s}
.btn-ghost:hover{border-color:var(--grey);color:#fff!important}

/* Stats bar */
.adv-stats{background:var(--surface);border-top:1px solid var(--border);border-bottom:1px solid var(--border);padding:32px 48px;display:flex;gap:0;justify-content:center}
.adv-stat{flex:1;text-align:center;padding:0 32px;border-right:1px solid var(--border)}
.adv-stat:last-child{border-right:none}
.adv-stat-num{font-family:'Bebas Neue',sans-serif;font-size:48px;color:var(--red);line-height:1;display:block}
.adv-stat-lbl{font-size:12px;color:var(--grey);text-transform:uppercase;letter-spacing:.1em;margin-top:4px}

/* Sections common */
.adv-section{padding:80px 48px;max-width:1280px;margin:0 auto}
.adv-section-full{padding:80px 48px;border-top:1px solid var(--border)}
.adv-label{font-size:10px;font-weight:900;letter-spacing:.22em;text-transform:uppercase;color:var(--red);margin-bottom:14px;display:block}
.adv-title{font-family:'Bebas Neue',sans-serif;font-size:clamp(36px,4vw,52px);color:#fff!important;letter-spacing:.03em;line-height:1;margin-bottom:24px}
.adv-text{color:var(--grey);line-height:1.85;margin-bottom:16px}
.adv-text strong{color:var(--text)}

/* FAST TV intro — 2 col */
.adv-intro-grid{display:grid;grid-template-columns:1fr 1fr;gap:60px;align-items:start}
.adv-growth-chart{background:var(--card);border:1px solid var(--border);border-radius:16px;padding:32px;position:relative;overflow:hidden}
.adv-growth-title{font-size:12px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--grey);margin-bottom:24px}
.adv-bar-row{display:flex;align-items:center;gap:12px;margin-bottom:14px}
.adv-bar-year{font-size:12px;color:var(--muted);width:36px;flex-shrink:0;text-align:right}
.adv-bar-track{flex:1;background:rgba(255,255,255,.06);border-radius:4px;height:22px;overflow:hidden}
.adv-bar-fill{height:100%;border-radius:4px;background:linear-gradient(90deg,#8a0010,var(--red));display:flex;align-items:center;padding-left:10px;font-size:11px;font-weight:700;color:#fff;white-space:nowrap;transition:width 1.2s ease}
.adv-bar-val{font-size:11px;color:var(--grey);flex-shrink:0;width:50px}
.adv-growth-note{font-size:10px;color:var(--muted);margin-top:16px;line-height:1.6;border-top:1px solid var(--border);padding-top:12px}

/* Programmatic section */
.adv-prog-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:20px;margin-top:40px}
.adv-prog-card{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:24px;display:flex;flex-direction:column}
.adv-prog-icon{width:40px;height:40px;border-radius:10px;background:rgba(232,0,28,.12);border:1px solid rgba(232,0,28,.25);display:flex;align-items:center;justify-content:center;margin-bottom:16px;flex-shrink:0;font-family:Figtree,sans-serif;font-size:9px;font-weight:900;letter-spacing:.08em;color:var(--red);text-transform:uppercase}
.adv-prog-name{font-family:'Bebas Neue',sans-serif;font-size:22px;color:#fff!important;letter-spacing:.04em;margin-bottom:10px}
.adv-prog-desc{font-size:13px;color:var(--grey);line-height:1.65}

/* Viznet */
.adv-viznet{background:linear-gradient(135deg,rgba(232,0,28,.08) 0%,rgba(80,0,200,.06) 100%);border-top:1px solid rgba(232,0,28,.2);border-bottom:1px solid rgba(232,0,28,.2);padding:80px 48px}
.adv-viznet-inner{max-width:1280px;margin:0 auto;display:grid;grid-template-columns:1fr 1fr;gap:60px;align-items:center}
.adv-viznet-logo{text-align:center}
.adv-viznet-logo img{max-width:220px;width:100%;filter:brightness(1.1)}

/* SSP Grid */
.adv-ssp-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-top:40px}
.adv-ssp-card{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:24px 20px;display:flex;flex-direction:column;align-items:center;text-align:center;gap:16px;transition:all .25s}
.adv-ssp-card:hover{border-color:rgba(232,0,28,.4);transform:translateY(-4px);box-shadow:0 12px 32px rgba(0,0,0,.4)}
.adv-ssp-logo{width:80px;height:80px;border-radius:12px;object-fit:contain;background:#fff;padding:8px;display:block}
.adv-ssp-name{font-family:'Bebas Neue',sans-serif;font-size:20px;letter-spacing:.06em;color:#fff!important}
.adv-ssp-desc{font-size:11.5px;color:var(--grey);line-height:1.55}

/* OKFAST hero block */
.adv-okfast{background:var(--surface);border-top:1px solid var(--border);padding:80px 48px}
.adv-okfast-inner{max-width:1280px;margin:0 auto;display:grid;grid-template-columns:1fr 1fr;gap:60px;align-items:center}
.adv-okfast-logo{display:flex;flex-direction:column;align-items:center;gap:20px}
.adv-okfast-logo img{max-width:280px;width:100%;border-radius:20px}
.adv-okfast-features{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:28px}
.adv-feature{background:var(--card);border:1px solid var(--border);border-radius:10px;padding:16px}
.adv-feature-icon{font-size:16px;margin-bottom:8px;display:block;line-height:1}
.adv-feature-title{font-size:13px;font-weight:700;color:#fff;margin-bottom:4px}
.adv-feature-desc{font-size:11px;color:var(--grey);line-height:1.5}

/* CTA */
.adv-cta{padding:100px 48px;text-align:center;background:linear-gradient(180deg,#07070f 0%,#0d0414 100%);border-top:1px solid var(--border)}
.adv-cta-title{font-family:'Bebas Neue',sans-serif;font-size:clamp(48px,6vw,80px);color:#fff!important;line-height:.9;margin-bottom:20px;letter-spacing:.03em}
.adv-cta-sub{font-size:17px;color:var(--grey);max-width:520px;margin:0 auto 40px;line-height:1.75}
.adv-contact-form{display:flex;gap:12px;max-width:480px;margin:0 auto;flex-wrap:wrap;justify-content:center}
.adv-contact-form a{padding:14px 28px;border-radius:8px;font-size:14px;font-weight:700}

/* Footer */
#adv-footer{background:#050509;border-top:1px solid var(--border);padding:28px 48px;display:flex;align-items:center;justify-content:space-between}
#adv-footer .fc{font-size:12px;color:var(--muted)}
#adv-footer .fl{display:flex;gap:20px}
#adv-footer .fl a{font-size:12px;color:var(--muted)}
#adv-footer .fl a:hover{color:#fff}

@media(max-width:1000px){
  #adv-header{padding:0 20px}#adv-header nav{display:none}
  .adv-hero-inner,.adv-section,.adv-section-full,.adv-viznet,.adv-okfast,.adv-cta{padding-left:20px;padding-right:20px}
  .adv-intro-grid,.adv-viznet-inner,.adv-okfast-inner{grid-template-columns:1fr}
  .adv-prog-grid{grid-template-columns:1fr 1fr}
  .adv-ssp-grid{grid-template-columns:repeat(2,1fr)}
  .adv-stats{flex-wrap:wrap}
  .adv-stat{border-right:none;border-bottom:1px solid var(--border);padding:20px}
  #adv-footer{flex-direction:column;gap:12px}
}
@media(max-width:600px){
  .adv-prog-grid{grid-template-columns:1fr}
  .adv-ssp-grid{grid-template-columns:1fr 1fr}
  .adv-okfast-features{grid-template-columns:1fr}
}
</style>
</head>
<body class="tackendo-advertise">

<header id="adv-header">
  <a href="<?php echo $site_url; ?>">
    <img src="<?php echo esc_url($logo_url); ?>" alt="TACKENDO" loading="eager">
  </a>
  <nav>
    <a href="<?php echo $site_url; ?>">Home</a>
    <a href="<?php echo esc_url(home_url('/about')); ?>">About</a>
    <a href="<?php echo esc_url(home_url('/blog')); ?>">Magazine</a>
    <a href="<?php echo $site_url; ?>#channels">Channels</a>
  </nav>
  <a href="mailto:contact@tackendo.com?subject=Advertising%20on%20TACKENDO" class="hdr-cta">Contact Us</a>
</header>

<!-- HERO -->
<section class="adv-hero">
  <div class="adv-hero-bg"></div>
  <div class="adv-hero-inner">
    <span class="adv-hero-badge"><span style="width:8px;height:8px;background:var(--red);border-radius:50%;animation:adpulse 1.6s infinite;display:inline-block"></span> Now Available</span>
    <h1 class="adv-hero-title">REACH YOUR<br>AUDIENCE ON<br><em>CONNECTED TV</em></h1>
    <p class="adv-hero-sub">TACKENDO delivers premium programmatic CTV advertising inventory across 20+ free live channels — brand-safe, targeted, and performance-driven.</p>
    <div class="adv-hero-btns">
      <a href="mailto:contact@tackendo.com?subject=Advertising%20on%20TACKENDO" class="btn-red">Get a Media Kit &rarr;</a>
      <a href="https://okfast.fr/" target="_blank" rel="noopener" class="btn-ghost">Launch a Campaign</a>
    </div>
  </div>
</section>
<style>@keyframes adpulse{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.4;transform:scale(.7)}}</style>

<!-- STATS -->
<div class="adv-stats">
  <div class="adv-stat"><span class="adv-stat-num">20+</span><span class="adv-stat-lbl">Live FAST Channels</span></div>
  <div class="adv-stat"><span class="adv-stat-num">4</span><span class="adv-stat-lbl">Distribution Platforms</span></div>
  <div class="adv-stat"><span class="adv-stat-num">24/7</span><span class="adv-stat-lbl">Linear Broadcast</span></div>
  <div class="adv-stat"><span class="adv-stat-num">8</span><span class="adv-stat-lbl">SSP Partners</span></div>
</div>

<!-- FAST TV INTRO -->
<div class="adv-section" style="border-top:1px solid var(--border)">
  <div class="adv-intro-grid">
    <div>
      <span class="adv-label">The FAST TV Revolution</span>
      <h2 class="adv-title">The Fastest Growing Ad Medium Since Cable TV</h2>
      <p class="adv-text">Free Ad-Supported Streaming Television (FAST) has fundamentally changed the advertising landscape. After years dominated by subscription fatigue, viewers are returning to <strong>free, linear TV</strong> — and advertisers are following.</p>
      <p class="adv-text">Global FAST TV advertising revenue surpassed <strong>$6 billion in 2023</strong> and is projected to exceed <strong>$12 billion by 2027</strong> (Omdia, 2024). CTV now accounts for nearly <strong>20% of total video ad spend</strong> in the US, with Europe accelerating rapidly behind.</p>
      <p class="adv-text">FAST channels attract <strong>highly engaged, lean-back audiences</strong> — viewers who chose the channel intentionally, watch longer sessions, and see significantly fewer ads than traditional broadcast. This translates into exceptional viewability rates, lower ad fatigue, and measurably higher brand recall.</p>
      <p class="adv-text">Unlike social media feeds or pre-roll interruptions, FAST advertising appears in a <strong>genuine TV context</strong> — full-screen, unskippable, and consumed on the biggest screen in the home.</p>
    </div>
    <div>
      <div class="adv-growth-chart">
        <p class="adv-growth-title">Global FAST Ad Revenue — Estimated Growth</p>
        <?php
        $bars = array(
          '2020' => array('val'=>'$1.4B', 'pct'=>12),
          '2021' => array('val'=>'$2.1B', 'pct'=>18),
          '2022' => array('val'=>'$3.8B', 'pct'=>32),
          '2023' => array('val'=>'$6.1B', 'pct'=>52),
          '2024' => array('val'=>'$8.3B', 'pct'=>70),
          '2025' => array('val'=>'$10.2B', 'pct'=>86),
          '2027' => array('val'=>'$12B+', 'pct'=>100),
        );
        foreach ($bars as $year => $d) {
          echo '<div class="adv-bar-row">';
          echo '<span class="adv-bar-year">' . $year . '</span>';
          echo '<div class="adv-bar-track"><div class="adv-bar-fill" style="width:' . $d['pct'] . '%">' . ($d['pct'] > 20 ? $d['val'] : '') . '</div></div>';
          echo ($d['pct'] <= 20 ? '<span class="adv-bar-val">' . $d['val'] . '</span>' : '<span class="adv-bar-val"></span>');
          echo '</div>';
        }
        ?>
        <p class="adv-growth-note">Sources: Omdia, Kagan, S&amp;P Global Market Intelligence. Projections for 2025–2027. Europe represents approx. 18% of global FAST revenue and is growing at 2× the rate of North America.</p>
      </div>
    </div>
  </div>
</div>

<!-- PROGRAMMATIC -->
<div class="adv-section-full" style="background:var(--surface)">
  <div style="max-width:1280px;margin:0 auto">
    <span class="adv-label">How It Works</span>
    <h2 class="adv-title">Programmatic Advertising on FAST TV</h2>
    <p class="adv-text" style="max-width:700px">Programmatic advertising is the automated, data-driven buying and selling of digital ad inventory in real time. On FAST channels, it brings the precision of digital targeting to the reach and impact of television.</p>
    <div class="adv-prog-grid">
      <div class="adv-prog-card">
        <span class="adv-prog-icon" style="font-size:14px;display:flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:8px;background:rgba(232,0,28,.12);border:1px solid rgba(232,0,28,.25);color:var(--red);font-weight:900;letter-spacing:.06em;font-family:Figtree,sans-serif;text-transform:uppercase;font-size:9px;flex-shrink:0">RTB</span>
        <h3 class="adv-prog-name">Real-Time Bidding</h3>
        <p class="adv-prog-desc">Ad slots are auctioned in milliseconds via SSPs and DSPs. Brands bid on individual impressions based on audience data, content context, and campaign goals — ensuring every euro is spent efficiently.</p>
      </div>
      <div class="adv-prog-card">
        <span class="adv-prog-icon" style="font-size:14px;display:flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:8px;background:rgba(232,0,28,.12);border:1px solid rgba(232,0,28,.25);color:var(--red);font-weight:900;letter-spacing:.06em;font-family:Figtree,sans-serif;text-transform:uppercase;font-size:9px;flex-shrink:0">Target</span>
        <h3 class="adv-prog-name">Audience Targeting</h3>
        <p class="adv-prog-desc">Reach viewers by geography, device type, viewing behavior, content genre, and household demographics. FAST channels offer genre-based targeting that aligns brand messaging naturally with content context.</p>
      </div>
      <div class="adv-prog-card">
        <span class="adv-prog-icon" style="font-size:14px;display:flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:8px;background:rgba(232,0,28,.12);border:1px solid rgba(232,0,28,.25);color:var(--red);font-weight:900;letter-spacing:.06em;font-family:Figtree,sans-serif;text-transform:uppercase;font-size:9px;flex-shrink:0">Data</span>
        <h3 class="adv-prog-name">Measurable Performance</h3>
        <p class="adv-prog-desc">Full campaign reporting: impressions, completion rates, viewability scores, frequency capping, and reach. Unlike traditional TV, programmatic CTV gives you real data on every ad served.</p>
      </div>
      <div class="adv-prog-card">
        <span class="adv-prog-icon" style="font-size:14px;display:flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:8px;background:rgba(232,0,28,.12);border:1px solid rgba(232,0,28,.25);color:var(--red);font-weight:900;letter-spacing:.06em;font-family:Figtree,sans-serif;text-transform:uppercase;font-size:9px;flex-shrink:0">Safety</span>
        <h3 class="adv-prog-name">Brand Safety</h3>
        <p class="adv-prog-desc">TACKENDO channels are editorially curated and brand-safe by design. No user-generated content, no controversial adjacency. Your ad appears in a premium, controlled environment.</p>
      </div>
      <div class="adv-prog-card">
        <span class="adv-prog-icon" style="font-size:14px;display:flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:8px;background:rgba(232,0,28,.12);border:1px solid rgba(232,0,28,.25);color:var(--red);font-weight:900;letter-spacing:.06em;font-family:Figtree,sans-serif;text-transform:uppercase;font-size:9px;flex-shrink:0">CTV</span>
        <h3 class="adv-prog-name">Full-Screen Impact</h3>
        <p class="adv-prog-desc">CTV ads run full-screen on the main TV — unskippable, high-viewability, and consumed in a lean-back attention state. Completion rates on FAST average 95%+ vs 60–70% on desktop video.</p>
      </div>
      <div class="adv-prog-card">
        <span class="adv-prog-icon" style="font-size:14px;display:flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:8px;background:rgba(232,0,28,.12);border:1px solid rgba(232,0,28,.25);color:var(--red);font-weight:900;letter-spacing:.06em;font-family:Figtree,sans-serif;text-transform:uppercase;font-size:9px;flex-shrink:0">Cross-Platform</span>
        <h3 class="adv-prog-name">Cross-Platform Reach</h3>
        <p class="adv-prog-desc">Available on Roku, Amazon Fire TV, web browsers, and connected TV devices. One campaign, unified reach across all screens where TACKENDO content is consumed.</p>
      </div>
    </div>
  </div>
</div>

<!-- VIZNET -->
<div class="adv-viznet">
  <div class="adv-viznet-inner">
    <div>
      <span class="adv-label">Monetization Partner</span>
      <h2 class="adv-title">Powered by Viznet</h2>
      <p class="adv-text">TACKENDO's advertising monetization infrastructure is powered by <strong>Viznet</strong>, a leading programmatic advertising platform specializing in CTV and streaming environments.</p>
      <p class="adv-text">Through Viznet's advanced programmatic layer, TACKENDO channels access <strong>premium demand from top-tier brands and agencies</strong> via real-time bidding auctions — maximizing CPMs while maintaining a seamless viewing experience for audiences.</p>
      <p class="adv-text">Viznet's technology enables dynamic ad insertion (DAI), audience segmentation, frequency management and cross-device attribution — all fully integrated into TACKENDO's channel infrastructure.</p>
      <a href="https://viznet.tv/" target="_blank" rel="noopener" style="display:inline-flex;align-items:center;gap:8px;color:var(--red);font-size:13px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;margin-top:8px">Learn about Viznet &rarr;</a>
    </div>
    <div class="adv-viznet-logo">
      <a href="https://viznet.tv/" target="_blank" rel="noopener">
        <img src="<?php echo esc_url( tcore_logo_url('viznet.png') ?: 'https://viznet.tv/wp-content/uploads/2023/09/logo-viznet-blanc.png' ); ?>"
             alt="Viznet" style="max-width:240px;width:100%;filter:brightness(1.1)" loading="lazy">
      </a>
      <div style="margin-top:24px;display:grid;grid-template-columns:1fr 1fr;gap:10px;text-align:left">
        <?php foreach(array('Dynamic Ad Insertion','Real-Time Bidding','Audience Segmentation','Cross-Device Attribution','Frequency Capping','Full Campaign Reporting') as $feat): ?>
        <div style="background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);border-radius:8px;padding:10px 12px;font-size:11px;color:var(--grey);display:flex;align-items:center;gap:7px">
          <span style="color:var(--red);font-size:14px">✓</span><?php echo $feat; ?>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<!-- SSP PARTNERS -->
<div class="adv-section-full">
  <div style="max-width:1280px;margin:0 auto">
    <span class="adv-label">Supply-Side Partners</span>
    <h2 class="adv-title">Our SSP Ecosystem</h2>
    <p class="adv-text" style="max-width:700px">TACKENDO's inventory is connected to a curated stack of leading Supply-Side Platforms — ensuring maximum fill rates, competitive CPMs, and access to global programmatic demand.</p>
    <div class="adv-ssp-grid">
      <?php
      $ssps = array(
        array('file'=>'viously.jpg',    'name'=>'Viously',      'desc'=>'Video advertising & content monetization platform with proprietary technology for publishers.'),
        array('file'=>'sparteo.jpg',    'name'=>'Sparteo',      'desc'=>'Next-gen monetization platform combining AI-powered technology with premium video demand.'),
        array('file'=>'bidmatic.jpg',   'name'=>'Bidmatic',     'desc'=>'CTV & video SSP specializing in programmatic auctions with advanced fraud prevention and brand safety.'),
        array('file'=>'adtelligent.jpg','name'=>'Adtelligent',  'desc'=>'Programmatic advertising platform delivering premium video and CTV inventory at scale globally.'),
        array('file'=>'vidverto.jpg',   'name'=>'Vidverto',     'desc'=>'Video monetization platform with advanced header bidding and unified auction technology for CTV.'),
        array('file'=>'voisetech.jpg',  'name'=>'VoiseTech',    'desc'=>'Innovative AdTech company delivering high-performance CTV and video advertising solutions.'),
        array('file'=>'robustapps.jpg', 'name'=>'Robust Apps',  'desc'=>'Mobile and CTV app monetization specialist with deep expertise in Connected TV ecosystems.'),
        array('file'=>'aniview.jpg',    'name'=>'Aniview',      'desc'=>'End-to-end video advertising platform with comprehensive SSP, ad server and analytics capabilities.'),
      );
      foreach ($ssps as $ssp) {
        $src = TCORE_URL . 'assets/logos/' . $ssp['file'];
        echo '<div class="adv-ssp-card">';
        echo '<img class="adv-ssp-logo" src="' . esc_url($src) . '" alt="' . esc_attr($ssp['name']) . '" loading="lazy">';
        echo '<h3 class="adv-ssp-name">' . esc_html($ssp['name']) . '</h3>';
        echo '<p class="adv-ssp-desc">' . esc_html($ssp['desc']) . '</p>';
        echo '</div>';
      }
      ?>
    </div>
  </div>
</div>

<!-- OKFAST -->
<div class="adv-okfast">
  <div class="adv-okfast-inner">
    <div>
      <span class="adv-label">Our Own Ad Network</span>
      <h2 class="adv-title">OKFAST Programmatic — TV Advertising for Every Budget</h2>
      <p class="adv-text"><strong>OKFAST</strong> is TACKENDO's proprietary programmatic advertising network, designed specifically to give <strong>SMEs and mid-market brands direct access to Connected TV advertising</strong> at an accessible cost — without needing a trading desk or agency.</p>
      <p class="adv-text">Traditionally, CTV advertising has been the preserve of large brands with six-figure media budgets. OKFAST changes that equation: brands can now launch a television campaign on FAST channels <strong>from a few hundred euros</strong>, with full transparency, real-time reporting, and targeted reach.</p>
      <p class="adv-text">Campaigns can be distributed across <strong>TACKENDO's own 20+ channels</strong> as well as partner FAST channels — reaching audiences across Roku, Amazon Fire TV, web and mobile simultaneously.</p>
      <div class="adv-okfast-features">
        <div class="adv-feature"><span style="display:inline-block;background:rgba(232,0,28,.15);border:1px solid rgba(232,0,28,.3);color:var(--red);font-size:9px;font-weight:900;letter-spacing:.1em;text-transform:uppercase;padding:3px 8px;border-radius:3px;margin-bottom:10px">Budget</span><p class="adv-feature-title">Accessible Budgets</p><p class="adv-feature-desc">TV campaigns from a few hundred euros. No minimum spend barrier.</p></div>
        <div class="adv-feature"><span style="display:inline-block;background:rgba(232,0,28,.15);border:1px solid rgba(232,0,28,.3);color:var(--red);font-size:9px;font-weight:900;letter-spacing:.1em;text-transform:uppercase;padding:3px 8px;border-radius:3px;margin-bottom:10px">Network</span><p class="adv-feature-title">FAST Channel Network</p><p class="adv-feature-desc">Reach across TACKENDO channels + partner FAST inventory.</p></div>
        <div class="adv-feature"><span style="display:inline-block;background:rgba(232,0,28,.15);border:1px solid rgba(232,0,28,.3);color:var(--red);font-size:9px;font-weight:900;letter-spacing:.1em;text-transform:uppercase;padding:3px 8px;border-radius:3px;margin-bottom:10px">Targeting</span><p class="adv-feature-title">Programmatic Targeting</p><p class="adv-feature-desc">Geo, genre, device, and audience-based targeting options.</p></div>
        <div class="adv-feature"><span style="display:inline-block;background:rgba(232,0,28,.15);border:1px solid rgba(232,0,28,.3);color:var(--red);font-size:9px;font-weight:900;letter-spacing:.1em;text-transform:uppercase;padding:3px 8px;border-radius:3px;margin-bottom:10px">Analytics</span><p class="adv-feature-title">Real-Time Dashboard</p><p class="adv-feature-desc">Live campaign stats: impressions, completions, CPM, reach.</p></div>
      </div>
      <div style="margin-top:32px">
        <a href="https://okfast.fr/" target="_blank" rel="noopener" class="btn-red" style="display:inline-flex">Launch a Campaign on OKFAST &rarr;</a>
      </div>
    </div>
    <div class="adv-okfast-logo">
      <div style="background:#000;border-radius:20px;overflow:hidden;box-shadow:0 0 0 1px rgba(255,255,255,.08),0 40px 80px rgba(0,0,0,.7);padding:32px;display:flex;align-items:center;justify-content:center">
        <img src="<?php echo esc_url(TCORE_URL . 'assets/logos/okfast.png'); ?>" alt="OKFAST Programmatic" style="max-width:240px;width:100%;display:block" loading="lazy">
      </div>
      <div style="margin-top:24px;text-align:center;background:var(--card);border:1px solid var(--border);border-radius:12px;padding:20px">
        <p style="font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.1em;margin-bottom:8px">Self-serve platform</p>
        <p style="font-family:'Bebas Neue',sans-serif;font-size:28px;color:#fff;letter-spacing:.04em">okfast.fr</p>
        <p style="font-size:12px;color:var(--grey);margin-top:6px">SME / PMI / Brand Advertising<br>on FAST TV Channels</p>
      </div>
    </div>
  </div>
</div>

<!-- CTA -->
<section class="adv-cta">
  <h2 class="adv-cta-title">READY TO<br>ADVERTISE?</h2>
  <p class="adv-cta-sub">Contact our team for a tailored media plan, rate card, or to access OKFAST directly for self-serve campaigns.</p>
  <div class="adv-contact-form">
    <a href="mailto:contact@tackendo.com?subject=Advertising%20on%20TACKENDO" class="btn-red">Request a Media Kit &rarr;</a>
    <a href="https://okfast.fr/" target="_blank" rel="noopener" class="btn-ghost">Launch via OKFAST</a>
  </div>
</section>

<footer id="adv-footer">
  <p class="fc">&copy; 2024&ndash;<?php echo date('Y'); ?> TACKENDO &mdash; Netradio Network. All rights reserved.</p>
  <div class="fl">
    <a href="<?php echo esc_url(home_url('/about')); ?>">About</a>
    <a href="<?php echo esc_url(home_url('/privacy-policy')); ?>">Privacy Policy</a>
    <a href="<?php echo $site_url; ?>">Home</a>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
