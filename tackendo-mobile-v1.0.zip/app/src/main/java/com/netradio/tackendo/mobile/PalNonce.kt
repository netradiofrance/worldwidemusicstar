package com.netradio.tackendo.mobile

import android.content.Context
import android.util.Log
import com.google.ads.interactivemedia.pal.ConsentSettings
import com.google.ads.interactivemedia.pal.NonceLoader
import com.google.ads.interactivemedia.pal.NonceManager
import com.google.ads.interactivemedia.pal.NonceRequest

/**
 * Nonce PAL de Google. Genere une fois au demarrage pour ne jamais
 * retarder le lancement d'une chaine.
 */
object PalNonce {

    private const val TAG = "TACKENDO"
    @Volatile private var loader: NonceLoader? = null
    @Volatile private var manager: NonceManager? = null
    @Volatile var nonce: String = ""

    fun init(context: Context) {
        try {
            val consent = ConsentSettings.builder()
                .allowStorage(!AdvertisingId.limitAdTracking)
                .build()
            loader = NonceLoader(context.applicationContext, consent)
            request()
        } catch (e: Throwable) {
            Log.w(TAG, "PAL indisponible: ${e.message}")
        }
    }

    fun request() {
        val l = loader ?: return
        try {
            val req = NonceRequest.builder()
                .descriptionURL("https://tackendo.com/")
                .iconsSupported(false)
                .playerType("ExoPlayer")
                .playerVersion("2.19.1")
                .ppid("")
                .videoPlayerHeight(720)
                .videoPlayerWidth(1280)
                .willAdAutoPlay(true)
                .willAdPlayMuted(false)
                .continuousPlayback(false)
                .build()

            l.loadNonceManager(req)
                .addOnSuccessListener { m ->
                    manager = m
                    nonce = m.nonce
                    Log.i(TAG, "PAL nonce genere (${nonce.length} car.)")
                }
                .addOnFailureListener { e ->
                    Log.w(TAG, "PAL echec: ${e.message}")
                    nonce = ""
                }
        } catch (e: Throwable) {
            Log.w(TAG, "PAL erreur: ${e.message}")
        }
    }

    fun onAdStart() { try { manager?.sendAdImpression() } catch (_: Throwable) {} }
    fun onAdClick() { try { manager?.sendAdClick() } catch (_: Throwable) {} }
    fun onPlaybackEnd() { try { manager?.sendPlaybackEnd() } catch (_: Throwable) {} }
}
