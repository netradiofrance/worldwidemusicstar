package com.netradio.tackendo.mobile

import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.PlaybackException
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.ext.ima.ImaAdsLoader
import com.google.android.exoplayer2.source.DefaultMediaSourceFactory
import com.google.android.exoplayer2.ui.StyledPlayerView
import com.google.android.exoplayer2.upstream.DefaultHttpDataSource

/**
 * Lecteur mobile avec pre-roll.
 *
 * La pub est demandee au waterfall Tackendo. Sur mobile, le serveur
 * privilegie le tag web, qui remplit nettement mieux que les unites CTV.
 * Si aucune pub ne remonte, la chaine demarre directement.
 */
class PlayerActivity : AppCompatActivity() {

    private lateinit var playerView: StyledPlayerView
    private lateinit var loader: ProgressBar
    private var player: ExoPlayer? = null
    private var adsLoader: ImaAdsLoader? = null
    private var streamUrl: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)

        playerView = findViewById(R.id.playerView)
        loader = findViewById(R.id.loader)
        streamUrl = intent.getStringExtra("url").orEmpty()

        if (streamUrl.isEmpty()) {
            finish()
            return
        }
        adsLoader = ImaAdsLoader.Builder(this).build()
    }

    override fun onStart() {
        super.onStart()
        if (player == null) initPlayer()
    }

    private fun initPlayer() {
        val dsf = DefaultHttpDataSource.Factory()
        val msf = DefaultMediaSourceFactory(dsf)
            .setLocalAdInsertionComponents({ adsLoader }, playerView)

        val p = ExoPlayer.Builder(this).setMediaSourceFactory(msf).build()
        player = p
        adsLoader?.setPlayer(p)
        playerView.player = p
        playerView.useController = true

        val item = MediaItem.Builder().setUri(Uri.parse(streamUrl))

        if (AdvertisingId.loaded) {
            val tag = Api.vastTag(AdvertisingId.id, AdvertisingId.limitAdTracking, PalNonce.nonce)
            Log.i("TACKENDO", "VAST tag = $tag")
            item.setAdsConfiguration(
                MediaItem.AdsConfiguration.Builder(Uri.parse(tag)).build()
            )
        } else {
            Log.w("TACKENDO", "AAID indisponible — lecture sans pre-roll")
        }

        p.setMediaItem(item.build())
        p.prepare()
        p.playWhenReady = true

        p.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                loader.visibility = if (isPlaying) View.GONE else View.VISIBLE
            }
            override fun onPlayerError(error: PlaybackException) {
                Log.e("TACKENDO", "Erreur de lecture: ${error.message}")
                loader.visibility = View.GONE
            }
        })
    }

    private fun release() {
        PalNonce.onPlaybackEnd()
        adsLoader?.setPlayer(null)
        playerView.player = null
        player?.release()
        player = null
    }

    override fun onStop() {
        super.onStop()
        release()
    }

    override fun onDestroy() {
        release()
        adsLoader?.release()
        adsLoader = null
        super.onDestroy()
    }
}
