package com.netradio.tackendo.mobile

import android.content.Context
import android.util.Log
import com.google.android.gms.ads.identifier.AdvertisingIdClient

/**
 * Identifiant publicitaire Android (AAID).
 * Sur mobile, les Google Play Services sont presents : lecture directe.
 */
object AdvertisingId {

    @Volatile var id: String = ""
    @Volatile var limitAdTracking: Boolean = false
    @Volatile var loaded: Boolean = false

    fun loadAsync(context: Context, onDone: (() -> Unit)? = null) {
        Thread {
            try {
                val info = AdvertisingIdClient.getAdvertisingIdInfo(context.applicationContext)
                id = info.id ?: ""
                limitAdTracking = info.isLimitAdTrackingEnabled
                Log.i("TACKENDO", "AAID = $id (limitAdTracking=$limitAdTracking)")
            } catch (e: Exception) {
                Log.w("TACKENDO", "AAID indisponible: ${e.message}")
                id = ""
                limitAdTracking = true
            } finally {
                loaded = true
                onDone?.invoke()
            }
        }.start()
    }
}
