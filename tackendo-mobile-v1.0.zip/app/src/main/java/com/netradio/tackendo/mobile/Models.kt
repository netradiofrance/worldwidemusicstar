package com.netradio.tackendo.mobile

data class Feed(
    val providerName: String? = null,
    val tvSpecials: List<TvSpecial> = emptyList(),
    val playlists: List<Playlist> = emptyList()
)

data class TvSpecial(
    val id: String = "",
    val shortDescription: String = "",
    val thumbnail: String = "",
    val content: Content = Content()
)

data class Content(val videos: List<Video> = emptyList())
data class Video(val url: String = "")
data class Playlist(val name: String = "", val itemIds: List<String> = emptyList())

/** Chaine prete a afficher. */
data class Channel(
    val id: String,
    val name: String,
    val desc: String,
    val thumb: String,
    val url: String
)

fun Feed.toChannels(): List<Channel> = tvSpecials.mapNotNull { t ->
    val url = t.content.videos.firstOrNull()?.url ?: return@mapNotNull null
    val parts = t.shortDescription.split(" - ", limit = 2)
    Channel(
        id = t.id,
        name = parts.firstOrNull()?.trim().orEmpty().ifEmpty { t.id },
        desc = parts.getOrNull(1)?.trim().orEmpty(),
        thumb = t.thumbnail,
        url = url
    )
}
