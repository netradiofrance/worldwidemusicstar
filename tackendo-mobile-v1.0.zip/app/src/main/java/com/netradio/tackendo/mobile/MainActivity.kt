package com.netradio.tackendo.mobile

import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.gson.Gson
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {

    private lateinit var grid: RecyclerView
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var loader: ProgressBar
    private lateinit var errorText: TextView
    private lateinit var adapter: ChannelAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Android 15 impose l'affichage bord a bord aux applis ciblant
        // l'API 35 : on decale le contenu sous la barre d'etat et
        // au-dessus de la barre de navigation.
        val root = findViewById<View>(android.R.id.content)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, bars.top, 0, bars.bottom)
            insets
        }

        grid = findViewById(R.id.grid)
        swipe = findViewById(R.id.swipe)
        loader = findViewById(R.id.loader)
        errorText = findViewById(R.id.errorText)

        adapter = ChannelAdapter(emptyList()) { channel ->
            val i = Intent(this, PlayerActivity::class.java)
            i.putExtra("url", channel.url)
            i.putExtra("name", channel.name)
            startActivity(i)
        }
        grid.layoutManager = GridLayoutManager(this, columnCount())
        grid.adapter = adapter

        swipe.setOnRefreshListener { loadFeed(false) }
        swipe.setColorSchemeResources(R.color.accent)

        // Identifiant publicitaire puis nonce PAL, en tache de fond.
        AdvertisingId.loadAsync(applicationContext) {
            PalNonce.init(applicationContext)
        }

        loadFeed(true)
    }

    private fun columnCount(): Int {
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val wide = resources.configuration.smallestScreenWidthDp >= 600
        return if (wide) (if (land) 4 else 3) else (if (land) 3 else 2)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        (grid.layoutManager as? GridLayoutManager)?.spanCount = columnCount()
    }

    private fun loadFeed(showLoader: Boolean) {
        if (showLoader) loader.visibility = View.VISIBLE
        errorText.visibility = View.GONE

        Thread {
            var channels: List<Channel>? = null
            try {
                val conn = URL(Api.FEED).openConnection() as HttpURLConnection
                conn.connectTimeout = 10000
                conn.readTimeout = 15000
                val json = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                channels = Gson().fromJson(json, Feed::class.java).toChannels()
            } catch (e: Exception) {
                android.util.Log.w("TACKENDO", "Feed: ${e.message}")
            }

            runOnUiThread {
                loader.visibility = View.GONE
                swipe.isRefreshing = false
                if (channels.isNullOrEmpty()) {
                    if (adapter.itemCount == 0) errorText.visibility = View.VISIBLE
                } else {
                    errorText.visibility = View.GONE
                    adapter.update(channels)
                }
            }
        }.start()
    }
}
