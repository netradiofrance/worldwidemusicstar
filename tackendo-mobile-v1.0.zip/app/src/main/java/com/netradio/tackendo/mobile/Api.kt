package com.netradio.tackendo.mobile

class Api {
    companion object {
        /** Flux des chaines. */
        const val FEED = "https://radiotool.fr/tackendo/tackendo_fire.json"

        /** Unite GAM web VoiseTech — celle qui remplit a 99% sur navigateur. */
        private const val GAM_UNIT =
            "/23124331701,12626570/NetRadio/NetRadio-tackendo.com_Open-Video-Multi_Web-07Jan26"

        /**
         * Tag publicitaire appele DIRECTEMENT par l'IMA SDK depuis l'appareil.
         *
         * On ne passe pas par notre ad server : Google ne sert aucune demande
         * a une requete venant d'un datacenter. Le contexte reel du telephone
         * (IP residentielle, User-Agent, identifiant publicitaire) doit
         * atteindre Google sans intermediaire.
         */
        fun vastTag(ifa: String, limitAdTracking: Boolean, givn: String): String {
            val id = if (limitAdTracking || ifa.isEmpty())
                "00000000-0000-0000-0000-000000000000" else ifa
            var u = "https://pubads.g.doubleclick.net/gampad/ads" +
                    "?iu=" + GAM_UNIT +
                    "&description_url=https%3A%2F%2Ftackendo.com%2F" +
                    "&tfcd=0&npa=0" +
                    "&sz=640x480" +
                    "&gdfp_req=1&unviewed_position_start=1" +
                    "&output=vast&env=vp&impl=s" +
                    "&plcmt=1&vpmute=0&vpa=auto&hl=en" +
                    "&rdid=" + id +
                    "&idtype=adid" +
                    "&is_lat=" + (if (limitAdTracking) "1" else "0") +
                    "&correlator=" + System.currentTimeMillis()
            if (givn.isNotEmpty()) u += "&givn=" + givn
            return u
        }
    }
}
